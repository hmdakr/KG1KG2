(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Interface_atlas_1", frames: [[1624,578,132,107],[1935,145,110,115],[1893,338,153,122],[1001,0,238,132],[1648,454,153,122],[1803,462,153,122],[1169,413,153,122],[1324,413,153,122],[1977,262,42,46],[1931,262,44,48],[1648,392,63,44],[1758,586,132,107],[1241,0,175,143],[1001,134,175,143],[1418,0,175,143],[1595,0,175,143],[1772,0,175,143],[1178,145,132,170],[1519,200,204,94],[1728,145,205,95],[1001,511,123,143],[1725,242,204,94],[1892,586,132,107],[1312,200,205,95],[1519,296,204,94],[1001,279,166,114],[1312,297,166,114],[1001,395,166,114],[1725,338,166,114],[0,0,999,611],[1126,588,132,107],[1479,507,143,104],[1260,588,132,107],[1312,145,414,53],[1126,537,346,49],[1480,392,166,113]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Bitmap1 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap10 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap12 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap13 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap14 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap15 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap16 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap17 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap18 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap19 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap20 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap21 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap22 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap23 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap24 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap25 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap26 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap27 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap28 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap29 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap3 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap30 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap31 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap33 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap34 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap35 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap36 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap37 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap4 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap8 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap9 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* stop();
		this.blnPlay = false;*/
	}
	this.frame_1 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_134 = function() {
		/* MovieClip(parent).fChangeQuestion();
		this.blnPlay = false;
		gotoAndStop(1);
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(133).call(this.frame_134).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap7();
	this.instance.setTransform(-205,-15);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-205,-15,414,53);


(lib.right_wrong = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}
	this.frame_1 = function() {
		this.stop();
		this.blnPlay = false;
	}
	this.frame_2 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1));

	// Layer_3
	this.instance = new lib.Bitmap18();
	this.instance.setTransform(-25,-22);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-31,-26);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).wait(1));

	// Layer_1
	this.instance_2 = new lib.Bitmap17();
	this.instance_2.setTransform(-24,-21);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-26,63,52);


(lib.pumpkinop2_34 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap21();
	this.instance.setTransform(-83,-103);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-83,-103,175,143);


(lib.pumpkinop2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap35();
	this.instance.setTransform(-74,-76);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74,-76,166,114);


(lib.potatorop2_34 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap22();
	this.instance.setTransform(-83,-94);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-83,-94,175,143);


(lib.potatorop2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap13();
	this.instance.setTransform(-74,-79);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74,-79,153,122);


(lib.potatorop2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap36();
	this.instance.setTransform(-74,-76);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74,-76,166,114);


(lib.orangeop2_34 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap23();
	this.instance.setTransform(-83,-67);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-83,-67,175,143);


(lib.orangeop2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap14();
	this.instance.setTransform(-74,-79);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74,-79,153,122);


(lib.heading_ = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap8();
	this.instance.setTransform(-136,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#9A5639").s().p("A9WELIAAoVMA6tAAAIAAGAQAACViWAAg");
	this.shape.setTransform(41.025,-0.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-146.9,-27.5,375.9,53.5);


(lib.grapesop2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap16();
	this.instance.setTransform(-74,-79);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74,-79,153,122);


(lib.grapesop2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap34();
	this.instance.setTransform(-74,-76);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74,-76,166,114);


(lib.btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("EgjAAHeIAAu7MBGBAAAIAAO7g");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-224.1,-47.8,448.2,95.6), null);


(lib.broadCastInterface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_1 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_599 = function() {
		/* stop();
		this.blnPlay = false;
		MovieClip(parent.parent.parent.parent).mcForward.mcGlow.gotoAndPlay(6);*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(598).call(this.frame_599).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.brinjalop2_34 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap24();
	this.instance.setTransform(-83,-73);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-83,-73,175,143);


(lib.brinjalop2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap15();
	this.instance.setTransform(-74,-79);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74,-79,153,122);


(lib.brinjalop2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap33();
	this.instance.setTransform(-74,-76);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74,-76,166,114);


(lib.bgg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap37();
	this.instance.setTransform(-500,-306);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bgg, new cjs.Rectangle(-500,-306,999,611), null);


(lib.strawberryop2_345 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(12.15,-2.9,0.5041,1.0889,0,0,0,0.5,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap26();
	this.instance.setTransform(-92,-55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-101,-55,225.9,104.3);


(lib.strawberryop2_34 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(5.55,-30.85,0.3992,1.4649,0,0,0,0.4,0);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap20();
	this.instance.setTransform(-83,-103);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84,-103,178.9,143);


(lib.strawberryop2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(11.55,-18.85,0.3992,1.4649,0,0,0,0.4,0);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap11();
	this.instance.setTransform(-74,-79);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-78,-88.9,178.9,140.10000000000002);


(lib.strawberryop2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(15.55,-18.85,0.3992,1.4649,0,0,0,0.4,0);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap9();
	this.instance.setTransform(-74,-76);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74,-88.9,178.9,140.10000000000002);


(lib.strawberry = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(10.05,-6.3,0.3345,1.3506,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap1();
	this.instance.setTransform(-55,-58);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64.9,-71.1,149.9,129.2);


(lib.pumpkinop2_345 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(12.15,-2.9,0.5041,1.0889,0,0,0,0.5,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap27();
	this.instance.setTransform(-103,-53);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-103,-54.9,227.9,104.19999999999999);


(lib.pumpkinop2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(1.2,-24.9,0.571,1.5905,0,0,0,0.5,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap12();
	this.instance.setTransform(-120,-93);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-127,-100.8,255.9,152.1);


(lib.pumpkin = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(10.05,-6.3,0.3345,1.3506,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap2();
	this.instance.setTransform(-55,-58);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64.9,-71.1,149.9,129.2);


(lib.potatorop2_345 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(12.15,-21.45,0.5041,1.4771,0,0,0,0.5,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap28();
	this.instance.setTransform(-54,-92);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-101,-92,225.9,143);


(lib.potator = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(10.05,3.7,0.3345,1.3506,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap3();
	this.instance.setTransform(-56,-48);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64.9,-61.1,149.9,129.2);


(lib.orangeop2_345 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(12.15,-2.9,0.5041,1.0889,0,0,0,0.5,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap29();
	this.instance.setTransform(-93,-38);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-101,-54.9,225.9,110.9);


(lib.orangeop2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(15.55,-18.85,0.3992,1.4649,0,0,0,0.4,0);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap10();
	this.instance.setTransform(-48,-74);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74,-88.9,178.9,140.10000000000002);


(lib.orange = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(10.05,3.7,0.3345,1.3506,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap4();
	this.instance.setTransform(-55,-43);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64.9,-61.1,149.9,129.2);


(lib.mcMain3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay =  true;*/
	}
	this.frame_99 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 2;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(99).call(this.frame_99).wait(1));

	// Layer_2
	this.mcFish = new lib.Symbol2();
	this.mcFish.name = "mcFish";
	this.mcFish.setTransform(-460.5,-189);

	this.timeline.addTween(cjs.Tween.get(this.mcFish).wait(100));

	// _
	this.mcTick_6 = new lib.right_wrong();
	this.mcTick_6.name = "mcTick_6";
	this.mcTick_6.setTransform(347.3,243.65,1.0032,1.0032);

	this.mcTick_5 = new lib.right_wrong();
	this.mcTick_5.name = "mcTick_5";
	this.mcTick_5.setTransform(2.2,243.65,1.0032,1.0032);

	this.mcTick_4 = new lib.right_wrong();
	this.mcTick_4.name = "mcTick_4";
	this.mcTick_4.setTransform(-340.8,243.65,1.0032,1.0032);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(347.3,15.5,1.0032,1.0032);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(2.2,15.5,1.0032,1.0032);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-340.8,15.5,1.0032,1.0032);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3},{t:this.mcTick_4},{t:this.mcTick_5},{t:this.mcTick_6}]},99).wait(1));

	// _
	this.mc_6 = new lib.strawberryop2_3();
	this.mc_6.name = "mc_6";
	this.mc_6.setTransform(332.85,141.05);

	this.mc_5 = new lib.strawberryop2_3();
	this.mc_5.name = "mc_5";
	this.mc_5.setTransform(-13.45,147.1);

	this.mc_4 = new lib.strawberryop2_3();
	this.mc_4.name = "mc_4";
	this.mc_4.setTransform(-355.25,141.05);

	this.mc_3 = new lib.strawberryop2_3();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(334.4,-86.55);

	this.mc_2 = new lib.pumpkinop2_3();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(-12.25,-75.7);

	this.mc_1 = new lib.strawberryop2_3();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-355.25,-75.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mc_4},{t:this.mc_5},{t:this.mc_6}]},99).wait(1));

	// Layer_19
	this.mc_6_1 = new lib.grapesop2_3();
	this.mc_6_1.name = "mc_6_1";
	this.mc_6_1.setTransform(332.85,263.05);
	this.mc_6_1.alpha = 0;
	this.mc_6_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_6_1).wait(73).to({_off:false},0).to({y:107.5,alpha:1},10,cjs.Ease.get(1)).to({y:141.05},5).to({_off:true},11).wait(1));

	// Layer_20
	this.mc_5_1 = new lib.brinjalop2_3();
	this.mc_5_1.name = "mc_5_1";
	this.mc_5_1.setTransform(-13.45,269.1);
	this.mc_5_1.alpha = 0;
	this.mc_5_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_5_1).wait(63).to({_off:false},0).to({y:113.55,alpha:1},10,cjs.Ease.get(1)).to({y:147.1},5).to({_off:true},21).wait(1));

	// Layer_21
	this.mc_4_1 = new lib.orangeop2_3();
	this.mc_4_1.name = "mc_4_1";
	this.mc_4_1.setTransform(-355.25,263.05);
	this.mc_4_1.alpha = 0;
	this.mc_4_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_4_1).wait(53).to({_off:false},0).to({y:107.5,alpha:1},10,cjs.Ease.get(1)).to({y:141.05},5).to({_off:true},31).wait(1));

	// Layer_22
	this.mc_3_1 = new lib.potatorop2_3();
	this.mc_3_1.name = "mc_3_1";
	this.mc_3_1.setTransform(334.4,35.45);
	this.mc_3_1.alpha = 0;
	this.mc_3_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_3_1).wait(43).to({_off:false},0).to({y:-120.1,alpha:1},10,cjs.Ease.get(1)).to({y:-86.55},5).to({_off:true},41).wait(1));

	// Layer_23
	this.mc_2_1 = new lib.pumpkinop2_3();
	this.mc_2_1.name = "mc_2_1";
	this.mc_2_1.setTransform(-12.25,46.3);
	this.mc_2_1.alpha = 0;
	this.mc_2_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_2_1).wait(33).to({_off:false},0).to({y:-109.25,alpha:1},10,cjs.Ease.get(1)).to({y:-75.7},5).to({_off:true},51).wait(1));

	// Layer_24
	this.mc_1_1 = new lib.strawberryop2_3();
	this.mc_1_1.name = "mc_1_1";
	this.mc_1_1.setTransform(-355.25,46.3);
	this.mc_1_1.alpha = 0;
	this.mc_1_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_1_1).wait(23).to({_off:false},0).to({y:-109.25,alpha:1},10,cjs.Ease.get(1)).to({y:-75.7},5).to({_off:true},61).wait(1));

	// Layer_25
	this.mc_6_2 = new lib.strawberryop2();
	this.mc_6_2.name = "mc_6_2";
	this.mc_6_2.setTransform(332.85,141);

	this.timeline.addTween(cjs.Tween.get(this.mc_6_2).wait(7).to({y:141.05},0).to({y:107.5},5).to({y:263.05,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(77));

	// Layer_26
	this.mc_5_2 = new lib.strawberryop2();
	this.mc_5_2.name = "mc_5_2";
	this.mc_5_2.setTransform(-13.45,147.1);

	this.timeline.addTween(cjs.Tween.get(this.mc_5_2).wait(6).to({y:113.55},5).to({y:269.1,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(78));

	// Layer_27
	this.mc_4_2 = new lib.orangeop2();
	this.mc_4_2.name = "mc_4_2";
	this.mc_4_2.setTransform(-355.25,141.05);

	this.timeline.addTween(cjs.Tween.get(this.mc_4_2).wait(5).to({y:107.5},5).to({y:263.05,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(79));

	// Layer_28
	this.mc_3_2 = new lib.strawberryop2();
	this.mc_3_2.name = "mc_3_2";
	this.mc_3_2.setTransform(334.4,-86.55);

	this.timeline.addTween(cjs.Tween.get(this.mc_3_2).wait(4).to({y:-120.1},5).to({y:35.45,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(80));

	// Layer_29
	this.mc_2_2 = new lib.strawberryop2();
	this.mc_2_2.name = "mc_2_2";
	this.mc_2_2.setTransform(-12.25,-75.7);

	this.timeline.addTween(cjs.Tween.get(this.mc_2_2).wait(3).to({y:-109.25},5).to({y:46.3,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(81));

	// Layer_30
	this.mc_1_2 = new lib.strawberryop2();
	this.mc_1_2.name = "mc_1_2";
	this.mc_1_2.setTransform(-355.25,-75.7);

	this.timeline.addTween(cjs.Tween.get(this.mc_1_2).wait(2).to({y:-109.25},5).to({y:46.3,alpha:0},10,cjs.Ease.get(-1)).wait(83));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-433.3,-210.1,872.6,530.4);


(lib.grapesop2_345 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(12.15,9.1,0.5041,1.0889,0,0,0,0.5,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap31();
	this.instance.setTransform(-97,-33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-101,-42.9,225.9,104.19999999999999);


(lib.grapesop2_34 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(5.55,2.3,0.3992,1.9458,0,0,0,0.4,0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap25();
	this.instance.setTransform(-67,-87);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84,-91,178.9,186.1);


(lib.grapes = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(10.05,6.7,0.3345,1.3506,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap6();
	this.instance.setTransform(-55,-43);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64.9,-58.1,149.9,129.2);


(lib.brinjalop2_345 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(12.15,-2.9,0.5041,1.0889,0,0,0,0.5,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap30();
	this.instance.setTransform(-90,-42);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-101,-54.9,225.9,107.9);


(lib.brinjal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(13.05,3.7,0.3345,1.3506,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap5();
	this.instance.setTransform(-59,-46);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61.9,-61.1,149.9,129.2);


(lib.mcMain5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_99 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 3;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{
					this.play();
					//this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				this.play();
				//this.parent.strFrame = "strFrame2";
				//this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}
	this.frame_100 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_108 = function() {
		/* stop();
		this.blnPlay = false;
		fCalculateScore();
		function fCalculateScore() {
			var nP = Math.floor((__nScore/5)*100);
			trace(__nScore + "---------------------"+5+"---------"+nP);
			if (nP < 70) {
				MovieClip(parent.parent.parent).mcFinal.mcRank.gotoAndPlay("rank2");
			} else {
				MovieClip(parent.parent.parent).mcFinal.mcRank.gotoAndPlay("rank1_1");
			}
		}*/
		
		this.stop();
		//alert("finalScreen");
		main.showRestartBtn();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(99).call(this.frame_99).wait(1).call(this.frame_100).wait(8).call(this.frame_108).wait(1));

	// Layer_2
	this.mcFish = new lib.Symbol2();
	this.mcFish.name = "mcFish";
	this.mcFish.setTransform(-460.5,-189);

	this.timeline.addTween(cjs.Tween.get(this.mcFish).wait(109));

	// Layer_4
	this.mcInterfaceBlinker = new lib.broadCastInterface();
	this.mcInterfaceBlinker.name = "mcInterfaceBlinker";
	this.mcInterfaceBlinker.setTransform(-453,-389,1,1,0,0,0,11.5,8);
	this.mcInterfaceBlinker._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mcInterfaceBlinker).wait(99).to({_off:false},0).to({_off:true},1).wait(9));

	// _
	this.mcTick_6 = new lib.right_wrong();
	this.mcTick_6.name = "mcTick_6";
	this.mcTick_6.setTransform(347.3,243.65,1.0032,1.0032);

	this.mcTick_5 = new lib.right_wrong();
	this.mcTick_5.name = "mcTick_5";
	this.mcTick_5.setTransform(2.2,243.65,1.0032,1.0032);

	this.mcTick_4 = new lib.right_wrong();
	this.mcTick_4.name = "mcTick_4";
	this.mcTick_4.setTransform(-340.8,243.65,1.0032,1.0032);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(347.3,15.5,1.0032,1.0032);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(2.2,15.5,1.0032,1.0032);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-340.8,15.5,1.0032,1.0032);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3},{t:this.mcTick_4},{t:this.mcTick_5},{t:this.mcTick_6}]},99).to({state:[{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3},{t:this.mcTick_4},{t:this.mcTick_5},{t:this.mcTick_6}]},9).wait(1));

	// _
	this.mc_6 = new lib.grapesop2_345();
	this.mc_6.name = "mc_6";
	this.mc_6.setTransform(332.85,141.05);

	this.mc_5 = new lib.brinjalop2_345();
	this.mc_5.name = "mc_5";
	this.mc_5.setTransform(-13.45,147.1);

	this.mc_4 = new lib.orangeop2_345();
	this.mc_4.name = "mc_4";
	this.mc_4.setTransform(-355.25,141.05);

	this.mc_3 = new lib.potatorop2_345();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(334.4,-86.55);

	this.mc_2 = new lib.pumpkinop2_345();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(-12.25,-75.7);

	this.mc_1 = new lib.strawberryop2_345();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-355.25,-75.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mc_4},{t:this.mc_5},{t:this.mc_6}]},99).wait(10));

	// Layer_7
	this.mc_6_1 = new lib.grapesop2_345();
	this.mc_6_1.name = "mc_6_1";
	this.mc_6_1.setTransform(332.85,263.05);
	this.mc_6_1.alpha = 0;
	this.mc_6_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_6_1).wait(73).to({_off:false},0).to({y:107.5,alpha:1},10,cjs.Ease.get(1)).to({y:141.05},5).to({_off:true},11).wait(10));

	// Layer_8
	this.mc_5_1 = new lib.brinjalop2_345();
	this.mc_5_1.name = "mc_5_1";
	this.mc_5_1.setTransform(-13.45,269.1);
	this.mc_5_1.alpha = 0;
	this.mc_5_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_5_1).wait(63).to({_off:false},0).to({y:113.55,alpha:1},10,cjs.Ease.get(1)).to({y:147.1},5).to({_off:true},21).wait(10));

	// Layer_9
	this.mc_4_1 = new lib.orangeop2_345();
	this.mc_4_1.name = "mc_4_1";
	this.mc_4_1.setTransform(-355.25,263.05);
	this.mc_4_1.alpha = 0;
	this.mc_4_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_4_1).wait(53).to({_off:false},0).to({y:107.5,alpha:1},10,cjs.Ease.get(1)).to({y:141.05},5).to({_off:true},31).wait(10));

	// Layer_10
	this.mc_3_1 = new lib.potatorop2_345();
	this.mc_3_1.name = "mc_3_1";
	this.mc_3_1.setTransform(334.4,35.45);
	this.mc_3_1.alpha = 0;
	this.mc_3_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_3_1).wait(43).to({_off:false},0).to({y:-120.1,alpha:1},10,cjs.Ease.get(1)).to({y:-86.55},5).to({_off:true},41).wait(10));

	// Layer_11
	this.mc_2_1 = new lib.pumpkinop2_345();
	this.mc_2_1.name = "mc_2_1";
	this.mc_2_1.setTransform(-12.25,46.3);
	this.mc_2_1.alpha = 0;
	this.mc_2_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_2_1).wait(33).to({_off:false},0).to({y:-109.25,alpha:1},10,cjs.Ease.get(1)).to({y:-75.7},5).to({_off:true},51).wait(10));

	// Layer_12
	this.mc_1_1 = new lib.strawberryop2_345();
	this.mc_1_1.name = "mc_1_1";
	this.mc_1_1.setTransform(-355.25,46.3);
	this.mc_1_1.alpha = 0;
	this.mc_1_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_1_1).wait(23).to({_off:false},0).to({y:-109.25,alpha:1},10,cjs.Ease.get(1)).to({y:-75.7},5).to({_off:true},61).wait(10));

	// Layer_13
	this.mc_6_2 = new lib.grapesop2_34();
	this.mc_6_2.name = "mc_6_2";
	this.mc_6_2.setTransform(332.85,141.05);

	this.timeline.addTween(cjs.Tween.get(this.mc_6_2).wait(7).to({y:107.5},5).to({y:263.05,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(86));

	// Layer_14
	this.mc_5_2 = new lib.brinjalop2_34();
	this.mc_5_2.name = "mc_5_2";
	this.mc_5_2.setTransform(-13.45,147.1);

	this.timeline.addTween(cjs.Tween.get(this.mc_5_2).wait(6).to({y:113.55},5).to({y:269.1,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(87));

	// Layer_15
	this.mc_4_2 = new lib.orangeop2_34();
	this.mc_4_2.name = "mc_4_2";
	this.mc_4_2.setTransform(-355.25,141.05);

	this.timeline.addTween(cjs.Tween.get(this.mc_4_2).wait(5).to({y:107.5},5).to({y:263.05,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(88));

	// Layer_16
	this.mc_3_2 = new lib.potatorop2_34();
	this.mc_3_2.name = "mc_3_2";
	this.mc_3_2.setTransform(334.4,-86.55);

	this.timeline.addTween(cjs.Tween.get(this.mc_3_2).wait(4).to({y:-120.1},5).to({y:35.45,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(89));

	// Layer_17
	this.mc_2_2 = new lib.pumpkinop2_34();
	this.mc_2_2.name = "mc_2_2";
	this.mc_2_2.setTransform(-12.25,-75.7);

	this.timeline.addTween(cjs.Tween.get(this.mc_2_2).wait(3).to({y:-109.25},5).to({y:46.3,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(90));

	// Layer_18
	this.mc_1_2 = new lib.strawberryop2_34();
	this.mc_1_2.name = "mc_1_2";
	this.mc_1_2.setTransform(-355.25,-75.7);

	this.timeline.addTween(cjs.Tween.get(this.mc_1_2).wait(2).to({y:-109.25},5).to({y:46.3,alpha:0},10,cjs.Ease.get(-1)).wait(92));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-456.3,-214.1,915.6,572.3);


(lib.mcMain4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_98 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 6;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(98).call(this.frame_98).wait(1));

	// Layer_2
	this.mcFish = new lib.Symbol2();
	this.mcFish.name = "mcFish";
	this.mcFish.setTransform(-460.5,-189);

	this.timeline.addTween(cjs.Tween.get(this.mcFish).wait(99));

	// _
	this.mcTick_6 = new lib.right_wrong();
	this.mcTick_6.name = "mcTick_6";
	this.mcTick_6.setTransform(347.3,243.65,1.0032,1.0032);

	this.mcTick_5 = new lib.right_wrong();
	this.mcTick_5.name = "mcTick_5";
	this.mcTick_5.setTransform(2.2,243.65,1.0032,1.0032);

	this.mcTick_4 = new lib.right_wrong();
	this.mcTick_4.name = "mcTick_4";
	this.mcTick_4.setTransform(-340.8,243.65,1.0032,1.0032);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(347.3,15.5,1.0032,1.0032);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(2.2,15.5,1.0032,1.0032);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-340.8,15.5,1.0032,1.0032);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3},{t:this.mcTick_4},{t:this.mcTick_5},{t:this.mcTick_6}]},98).wait(1));

	// _
	this.mc_6 = new lib.grapesop2_34();
	this.mc_6.name = "mc_6";
	this.mc_6.setTransform(332.85,141.05);

	this.mc_5 = new lib.strawberryop2_34();
	this.mc_5.name = "mc_5";
	this.mc_5.setTransform(-13.45,147.1);

	this.mc_4 = new lib.strawberryop2_34();
	this.mc_4.name = "mc_4";
	this.mc_4.setTransform(-355.25,141.05);

	this.mc_3 = new lib.strawberryop2_34();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(334.4,-86.55);

	this.mc_2 = new lib.strawberryop2_34();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(-12.25,-75.7);

	this.mc_1 = new lib.strawberryop2_34();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-355.25,-75.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mc_4},{t:this.mc_5},{t:this.mc_6}]},98).wait(1));

	// Layer_13
	this.mc_6_1 = new lib.grapesop2_34();
	this.mc_6_1.name = "mc_6_1";
	this.mc_6_1.setTransform(332.85,263.05);
	this.mc_6_1.alpha = 0;
	this.mc_6_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_6_1).wait(72).to({_off:false},0).to({y:107.5,alpha:1},10,cjs.Ease.get(1)).to({y:141.05},5).to({_off:true},11).wait(1));

	// Layer_14
	this.mc_5_1 = new lib.brinjalop2_34();
	this.mc_5_1.name = "mc_5_1";
	this.mc_5_1.setTransform(-13.45,269.1);
	this.mc_5_1.alpha = 0;
	this.mc_5_1._off = true;

	this.mc_5_2 = new lib.strawberryop2_34();
	this.mc_5_2.name = "mc_5_2";
	this.mc_5_2.setTransform(-13.45,147.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_5_1}]},62).to({state:[{t:this.mc_5_1}]},10).to({state:[{t:this.mc_5_2}]},5).to({state:[]},21).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.mc_5_1).wait(62).to({_off:false},0).to({y:113.55,alpha:1},10,cjs.Ease.get(1)).to({_off:true,y:147.1},5).wait(22));

	// Layer_15
	this.mc_4_1 = new lib.orangeop2_34();
	this.mc_4_1.name = "mc_4_1";
	this.mc_4_1.setTransform(-355.25,263.05);
	this.mc_4_1.alpha = 0;
	this.mc_4_1._off = true;

	this.mc_4_2 = new lib.strawberryop2_34();
	this.mc_4_2.name = "mc_4_2";
	this.mc_4_2.setTransform(-355.25,141.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_4_1}]},52).to({state:[{t:this.mc_4_1}]},10).to({state:[{t:this.mc_4_2}]},5).to({state:[]},31).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.mc_4_1).wait(52).to({_off:false},0).to({y:107.5,alpha:1},10,cjs.Ease.get(1)).to({_off:true,y:141.05},5).wait(32));

	// Layer_16
	this.mc_3_1 = new lib.potatorop2_34();
	this.mc_3_1.name = "mc_3_1";
	this.mc_3_1.setTransform(334.4,35.45);
	this.mc_3_1.alpha = 0;
	this.mc_3_1._off = true;

	this.mc_3_2 = new lib.strawberryop2_34();
	this.mc_3_2.name = "mc_3_2";
	this.mc_3_2.setTransform(334.4,-86.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_3_1}]},42).to({state:[{t:this.mc_3_1}]},10).to({state:[{t:this.mc_3_2}]},5).to({state:[]},41).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.mc_3_1).wait(42).to({_off:false},0).to({y:-120.1,alpha:1},10,cjs.Ease.get(1)).to({_off:true,y:-86.55},5).wait(42));

	// Layer_17
	this.mc_2_1 = new lib.pumpkinop2_34();
	this.mc_2_1.name = "mc_2_1";
	this.mc_2_1.setTransform(-12.25,46.3);
	this.mc_2_1.alpha = 0;
	this.mc_2_1._off = true;

	this.mc_2_2 = new lib.strawberryop2_34();
	this.mc_2_2.name = "mc_2_2";
	this.mc_2_2.setTransform(-12.25,-75.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_2_1}]},32).to({state:[{t:this.mc_2_1}]},10).to({state:[{t:this.mc_2_2}]},5).to({state:[]},51).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.mc_2_1).wait(32).to({_off:false},0).to({y:-109.25,alpha:1},10,cjs.Ease.get(1)).to({_off:true,y:-75.7},5).wait(52));

	// Layer_18
	this.mc_1_1 = new lib.strawberryop2_34();
	this.mc_1_1.name = "mc_1_1";
	this.mc_1_1.setTransform(-355.25,46.3);
	this.mc_1_1.alpha = 0;
	this.mc_1_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_1_1).wait(23).to({_off:false},0).to({y:-109.25,alpha:1},9,cjs.Ease.get(1)).to({y:-75.7},5).to({_off:true},61).wait(1));

	// Layer_19
	this.mc_6_2 = new lib.grapesop2_3();
	this.mc_6_2.name = "mc_6_2";
	this.mc_6_2.setTransform(332.85,141.05);

	this.timeline.addTween(cjs.Tween.get(this.mc_6_2).wait(7).to({y:107.5},5).to({y:263.05,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(76));

	// Layer_20
	this.mc_5_3 = new lib.brinjalop2_3();
	this.mc_5_3.name = "mc_5_3";
	this.mc_5_3.setTransform(-13.45,147.1);

	this.timeline.addTween(cjs.Tween.get(this.mc_5_3).wait(6).to({y:113.55},5).to({y:269.1,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(77));

	// Layer_21
	this.mc_4_3 = new lib.orangeop2_3();
	this.mc_4_3.name = "mc_4_3";
	this.mc_4_3.setTransform(-355.25,141.05);

	this.timeline.addTween(cjs.Tween.get(this.mc_4_3).wait(5).to({y:107.5},5).to({y:263.05,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(78));

	// Layer_22
	this.mc_3_3 = new lib.potatorop2_3();
	this.mc_3_3.name = "mc_3_3";
	this.mc_3_3.setTransform(334.4,-86.55);

	this.timeline.addTween(cjs.Tween.get(this.mc_3_3).wait(4).to({y:-120.1},5).to({y:35.45,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(79));

	// Layer_23
	this.mc_2_3 = new lib.pumpkinop2_3();
	this.mc_2_3.name = "mc_2_3";
	this.mc_2_3.setTransform(-12.25,-75.7);

	this.timeline.addTween(cjs.Tween.get(this.mc_2_3).wait(3).to({y:-109.25},5).to({y:46.3,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(80));

	// Layer_24
	this.mc_1_2 = new lib.strawberryop2_3();
	this.mc_1_2.name = "mc_1_2";
	this.mc_1_2.setTransform(-355.25,-75.7);

	this.timeline.addTween(cjs.Tween.get(this.mc_1_2).wait(2).to({y:-109.25},5).to({y:46.3,alpha:0},10,cjs.Ease.get(-1)).wait(82));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-439.3,-214.1,868.6,572.3);


(lib.mcMain2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_99 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 4;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(99).call(this.frame_99).wait(1));

	// Layer_2
	this.mcFish = new lib.Symbol2();
	this.mcFish.name = "mcFish";
	this.mcFish.setTransform(-460.5,-189);

	this.timeline.addTween(cjs.Tween.get(this.mcFish).wait(100));

	// _
	this.mcTick_6 = new lib.right_wrong();
	this.mcTick_6.name = "mcTick_6";
	this.mcTick_6.setTransform(347.3,243.65,1.0032,1.0032);

	this.mcTick_5 = new lib.right_wrong();
	this.mcTick_5.name = "mcTick_5";
	this.mcTick_5.setTransform(2.2,243.65,1.0032,1.0032);

	this.mcTick_4 = new lib.right_wrong();
	this.mcTick_4.name = "mcTick_4";
	this.mcTick_4.setTransform(-340.8,243.65,1.0032,1.0032);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(347.3,15.5,1.0032,1.0032);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(2.2,15.5,1.0032,1.0032);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-340.8,15.5,1.0032,1.0032);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3},{t:this.mcTick_4},{t:this.mcTick_5},{t:this.mcTick_6}]},99).wait(1));

	// _
	this.mc_3 = new lib.strawberryop2();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(334.4,-86.55);

	this.mc_6 = new lib.strawberryop2();
	this.mc_6.name = "mc_6";
	this.mc_6.setTransform(332.85,141.05);

	this.mc_5 = new lib.strawberryop2();
	this.mc_5.name = "mc_5";
	this.mc_5.setTransform(-13.45,147.1);

	this.mc_4 = new lib.orangeop2();
	this.mc_4.name = "mc_4";
	this.mc_4.setTransform(-355.25,141.05);

	this.mc_2 = new lib.strawberryop2();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(-12.25,-75.7);

	this.mc_1 = new lib.strawberryop2();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-355.25,-75.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_4},{t:this.mc_5},{t:this.mc_6},{t:this.mc_3}]},99).wait(1));

	// Layer_25
	this.mc_6_1 = new lib.grapesop2();
	this.mc_6_1.name = "mc_6_1";
	this.mc_6_1.setTransform(332.85,263.05);
	this.mc_6_1.alpha = 0;
	this.mc_6_1._off = true;

	this.mc_6_2 = new lib.strawberryop2();
	this.mc_6_2.name = "mc_6_2";
	this.mc_6_2.setTransform(332.85,141.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_6_1}]},73).to({state:[{t:this.mc_6_1}]},10).to({state:[{t:this.mc_6_2}]},5).to({state:[]},11).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.mc_6_1).wait(73).to({_off:false},0).to({y:107.5,alpha:1},10,cjs.Ease.get(1)).to({_off:true,y:141.05},5).wait(12));

	// Layer_26
	this.mc_5_1 = new lib.brinjalop2();
	this.mc_5_1.name = "mc_5_1";
	this.mc_5_1.setTransform(-13.45,269.1);
	this.mc_5_1.alpha = 0;
	this.mc_5_1._off = true;

	this.mc_5_2 = new lib.strawberryop2();
	this.mc_5_2.name = "mc_5_2";
	this.mc_5_2.setTransform(-13.45,147.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_5_1}]},63).to({state:[{t:this.mc_5_1}]},10).to({state:[{t:this.mc_5_2}]},5).to({state:[]},21).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.mc_5_1).wait(63).to({_off:false},0).to({y:113.55,alpha:1},10,cjs.Ease.get(1)).to({_off:true,y:147.1},5).wait(22));

	// Layer_27
	this.mc_4_1 = new lib.orangeop2();
	this.mc_4_1.name = "mc_4_1";
	this.mc_4_1.setTransform(-355.25,263.05);
	this.mc_4_1.alpha = 0;
	this.mc_4_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_4_1).wait(53).to({_off:false},0).to({y:107.5,alpha:1},10,cjs.Ease.get(1)).to({y:141.05},5).to({_off:true},31).wait(1));

	// Layer_28
	this.mc_3_1 = new lib.potatorop2();
	this.mc_3_1.name = "mc_3_1";
	this.mc_3_1.setTransform(334.4,35.45);
	this.mc_3_1.alpha = 0;
	this.mc_3_1._off = true;

	this.mc_3_2 = new lib.strawberryop2();
	this.mc_3_2.name = "mc_3_2";
	this.mc_3_2.setTransform(334.4,-86.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_3_1}]},43).to({state:[{t:this.mc_3_1}]},10).to({state:[{t:this.mc_3_2}]},5).to({state:[]},41).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.mc_3_1).wait(43).to({_off:false},0).to({y:-120.1,alpha:1},10,cjs.Ease.get(1)).to({_off:true,y:-86.55},5).wait(42));

	// Layer_29
	this.mc_2_1 = new lib.pumpkinop2();
	this.mc_2_1.name = "mc_2_1";
	this.mc_2_1.setTransform(-12.25,46.3);
	this.mc_2_1.alpha = 0;
	this.mc_2_1._off = true;

	this.mc_2_2 = new lib.strawberryop2();
	this.mc_2_2.name = "mc_2_2";
	this.mc_2_2.setTransform(-12.25,-75.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_2_1}]},33).to({state:[{t:this.mc_2_1}]},10).to({state:[{t:this.mc_2_2}]},5).to({state:[]},51).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.mc_2_1).wait(33).to({_off:false},0).to({y:-109.25,alpha:1},10,cjs.Ease.get(1)).to({_off:true,y:-75.7},5).wait(52));

	// Layer_30
	this.mc_1_1 = new lib.strawberryop2();
	this.mc_1_1.name = "mc_1_1";
	this.mc_1_1.setTransform(-355.25,46.3);
	this.mc_1_1.alpha = 0;
	this.mc_1_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_1_1).wait(23).to({_off:false},0).to({y:-109.25,alpha:1},10,cjs.Ease.get(1)).to({y:-75.7},5).to({_off:true},61).wait(1));

	// Layer_31
	this.instance = new lib.grapes();
	this.instance.setTransform(332.85,141.05);

	this.mc_6_3 = new lib.grapes();
	this.mc_6_3.name = "mc_6_3";
	this.mc_6_3.setTransform(332.85,141.05);
	this.mc_6_3._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.mc_6_3}]},7).to({state:[{t:this.mc_6_3}]},5).to({state:[{t:this.mc_6_3}]},10).to({state:[]},1).wait(77));
	this.timeline.addTween(cjs.Tween.get(this.mc_6_3).wait(7).to({_off:false},0).to({y:107.5},5).to({y:263.05,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(77));

	// Layer_32
	this.instance_1 = new lib.brinjal();
	this.instance_1.setTransform(-13.45,147.1);

	this.mc_5_3 = new lib.brinjal();
	this.mc_5_3.name = "mc_5_3";
	this.mc_5_3.setTransform(-13.45,147.1);
	this.mc_5_3._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.mc_5_3}]},6).to({state:[{t:this.mc_5_3}]},5).to({state:[{t:this.mc_5_3}]},10).to({state:[]},1).wait(78));
	this.timeline.addTween(cjs.Tween.get(this.mc_5_3).wait(6).to({_off:false},0).to({y:113.55},5).to({y:269.1,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(78));

	// Layer_33
	this.instance_2 = new lib.orange();
	this.instance_2.setTransform(-355.25,141.05);

	this.mc_4_2 = new lib.orange();
	this.mc_4_2.name = "mc_4_2";
	this.mc_4_2.setTransform(-355.25,141.05);
	this.mc_4_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).to({state:[{t:this.mc_4_2}]},5).to({state:[{t:this.mc_4_2}]},5).to({state:[{t:this.mc_4_2}]},10).to({state:[]},1).wait(79));
	this.timeline.addTween(cjs.Tween.get(this.mc_4_2).wait(5).to({_off:false},0).to({y:107.5},5).to({y:263.05,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(79));

	// Layer_34
	this.instance_3 = new lib.potator();
	this.instance_3.setTransform(334.4,-86.55);

	this.mc_3_3 = new lib.potator();
	this.mc_3_3.name = "mc_3_3";
	this.mc_3_3.setTransform(334.4,-86.55);
	this.mc_3_3._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3}]}).to({state:[{t:this.mc_3_3}]},4).to({state:[{t:this.mc_3_3}]},5).to({state:[{t:this.mc_3_3}]},10).to({state:[]},1).wait(80));
	this.timeline.addTween(cjs.Tween.get(this.mc_3_3).wait(4).to({_off:false},0).to({y:-120.1},5).to({y:35.45,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(80));

	// Layer_35
	this.instance_4 = new lib.pumpkin();
	this.instance_4.setTransform(-12.25,-75.7);

	this.mc_2_3 = new lib.pumpkin();
	this.mc_2_3.name = "mc_2_3";
	this.mc_2_3.setTransform(-12.25,-75.7);
	this.mc_2_3._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4}]}).to({state:[{t:this.mc_2_3}]},3).to({state:[{t:this.mc_2_3}]},5).to({state:[{t:this.mc_2_3}]},10).to({state:[]},1).wait(81));
	this.timeline.addTween(cjs.Tween.get(this.mc_2_3).wait(3).to({_off:false},0).to({y:-109.25},5).to({y:46.3,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(81));

	// Layer_36
	this.instance_5 = new lib.strawberry();
	this.instance_5.setTransform(-355.25,-75.7);

	this.mc_1_2 = new lib.strawberry();
	this.mc_1_2.name = "mc_1_2";
	this.mc_1_2.setTransform(-355.25,-75.7);
	this.mc_1_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5}]}).to({state:[{t:this.mc_1_2}]},2).to({state:[{t:this.mc_1_2}]},5).to({state:[{t:this.mc_1_2}]},10).to({state:[]},1).wait(82));
	this.timeline.addTween(cjs.Tween.get(this.mc_1_2).wait(2).to({_off:false},0).to({y:-109.25},5).to({y:46.3,alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(82));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-429.3,-198.2,868.6,535.4);


(lib.mcMain1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;
		var objRef = this;
		var __nCorrectAnswer = 0;
		var blnLastQuestion = false;
		var __nScore = 0;
		function init() {
			for (var i:Number = 1; objRef["mc_"+i] != null; i++) {
				objRef["mc_"+i].id = i;
				objRef["mc_" + i].addEventListener(MouseEvent.CLICK, fClickEvent);
				objRef["mc_"+i].buttonMode = true;
			}
		}
		function fClickEvent(e) {
			fRemoveListeners();	
			mcFish.gotoAndPlay(2);
			if (e.currentTarget.id == __nCorrectAnswer) {
				__nScore++;
				var mcRight = new Right();
				objRef.addChild(mcRight);
				objRef["mcTick_"+e.currentTarget.id].gotoAndStop(3);
				return;
			}
			var mcWrong = new ShowAnswer();
			objRef.addChild(mcWrong);
			objRef["mcTick_"+e.currentTarget.id].gotoAndStop(2);
		}
		function fChangeQuestion() {		
			play();
		}
		function fRemoveListeners() {
			for (var i:Number = 1; objRef["mc_"+i] != null; i++) {
				objRef["mc_" + i].removeEventListener(MouseEvent.CLICK, fClickEvent);
				objRef["mc_"+i].buttonMode = false;
			}
		}
		function fShowCorrectAnswer() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(2);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(3);
		}*/
	}
	this.frame_87 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 5;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(87).call(this.frame_87).wait(1));

	// Layer_2
	this.mcFish = new lib.Symbol2();
	this.mcFish.name = "mcFish";
	this.mcFish.setTransform(-460.5,-189);

	this.timeline.addTween(cjs.Tween.get(this.mcFish).to({_off:true},16).wait(72));

	// _
	this.mcTick_6 = new lib.right_wrong();
	this.mcTick_6.name = "mcTick_6";
	this.mcTick_6.setTransform(347.3,243.65,1.0032,1.0032);

	this.mcTick_5 = new lib.right_wrong();
	this.mcTick_5.name = "mcTick_5";
	this.mcTick_5.setTransform(2.2,243.65,1.0032,1.0032);

	this.mcTick_4 = new lib.right_wrong();
	this.mcTick_4.name = "mcTick_4";
	this.mcTick_4.setTransform(-340.8,243.65,1.0032,1.0032);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(347.3,15.5,1.0032,1.0032);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(2.2,15.5,1.0032,1.0032);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-340.8,15.5,1.0032,1.0032);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3},{t:this.mcTick_4},{t:this.mcTick_5},{t:this.mcTick_6}]},87).wait(1));

	// _
	this.mc_6 = new lib.pumpkin();
	this.mc_6.name = "mc_6";
	this.mc_6.setTransform(332.85,141.05);

	this.mc_5 = new lib.brinjal();
	this.mc_5.name = "mc_5";
	this.mc_5.setTransform(-13.45,147.1);

	this.mc_4 = new lib.pumpkin();
	this.mc_4.name = "mc_4";
	this.mc_4.setTransform(-355.25,141.05);

	this.mc_3 = new lib.pumpkin();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(334.4,-86.55);

	this.mc_2 = new lib.pumpkin();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(-12.25,-75.7);

	this.mc_1 = new lib.strawberry();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-355.25,-75.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mc_4},{t:this.mc_5},{t:this.mc_6}]},87).wait(1));

	// Layer_31
	this.mc_6_1 = new lib.grapes();
	this.mc_6_1.name = "mc_6_1";
	this.mc_6_1.setTransform(332.85,263.05);
	this.mc_6_1.alpha = 0;
	this.mc_6_1._off = true;

	this.instance = new lib.pumpkin();
	this.instance.setTransform(332.85,141.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_6_1}]},81).to({state:[{t:this.instance}]},4).to({state:[]},2).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.mc_6_1).wait(81).to({_off:false},0).to({_off:true,y:141.05,alpha:1},4,cjs.Ease.get(1)).wait(3));

	// Layer_32
	this.mc_5_1 = new lib.brinjal();
	this.mc_5_1.name = "mc_5_1";
	this.mc_5_1.setTransform(-13.45,269.1);
	this.mc_5_1.alpha = 0;
	this.mc_5_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_5_1).wait(71).to({_off:false},0).to({y:113.55,alpha:1},10,cjs.Ease.get(1)).to({y:147.1},4).to({_off:true},2).wait(1));

	// Layer_33
	this.mc_4_1 = new lib.orange();
	this.mc_4_1.name = "mc_4_1";
	this.mc_4_1.setTransform(-355.25,263.05);
	this.mc_4_1.alpha = 0;
	this.mc_4_1._off = true;

	this.instance_1 = new lib.pumpkin();
	this.instance_1.setTransform(-355.25,141.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_4_1}]},61).to({state:[{t:this.mc_4_1}]},10).to({state:[{t:this.instance_1}]},5).to({state:[]},11).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.mc_4_1).wait(61).to({_off:false},0).to({y:107.5,alpha:1},10,cjs.Ease.get(1)).to({_off:true,y:141.05},5).wait(12));

	// Layer_34
	this.mc_3_1 = new lib.potator();
	this.mc_3_1.name = "mc_3_1";
	this.mc_3_1.setTransform(334.4,35.45);
	this.mc_3_1.alpha = 0;
	this.mc_3_1._off = true;

	this.instance_2 = new lib.pumpkin();
	this.instance_2.setTransform(334.4,-86.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_3_1}]},51).to({state:[{t:this.mc_3_1}]},10).to({state:[{t:this.instance_2}]},5).to({state:[]},21).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.mc_3_1).wait(51).to({_off:false},0).to({y:-120.1,alpha:1},10,cjs.Ease.get(1)).to({_off:true,y:-86.55},5).wait(22));

	// Layer_35
	this.mc_2_1 = new lib.pumpkin();
	this.mc_2_1.name = "mc_2_1";
	this.mc_2_1.setTransform(-12.25,46.3);
	this.mc_2_1.alpha = 0;
	this.mc_2_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_2_1).wait(41).to({_off:false},0).to({y:-109.25,alpha:1},10,cjs.Ease.get(1)).to({y:-75.7},5).to({_off:true},31).wait(1));

	// Layer_36
	this.mc_1_1 = new lib.strawberry();
	this.mc_1_1.name = "mc_1_1";
	this.mc_1_1.setTransform(-355.25,46.3);
	this.mc_1_1.alpha = 0;
	this.mc_1_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_1_1).wait(31).to({_off:false},0).to({y:-109.25,alpha:1},10,cjs.Ease.get(1)).to({y:-75.7},5).to({_off:true},41).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-420.2,-181.2,839.5999999999999,518.4);


// stage content:
(lib.Interface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,31];
	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		stage.enableMouseOver(10); 
		//this.strFrame = "strFrame1"
		this.nF = 1;
		this.fLaunchProduct = function()
		{
			if(this.mcAttachMovieClip)
			{
				this.removeChild(this.mcAttachMovieClip);
			}
			this.mcAttachMovieClip = new lib["mcMain"+this.nF];
			this.mcAttachMovieClip.x = 488.1;
			this.mcAttachMovieClip.y = 295.05;	
			this.mcAttachMovieClip.gotoAndPlay(this.strFrame);
			this.addChild(this.mcAttachMovieClip);	
			if(this.nF == 1)
			{
				this.play();
				this.fbAudio = main.playAudio('instruction');
			}
			this.nF = this.nF + 1;
		}
		//this.fLaunchProduct();
	}
	this.frame_31 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(31).call(this.frame_31).wait(1));

	// HEADING
	this.instance = new lib.heading_("synched",0);
	this.instance.setTransform(-184.35,21.25);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).to({x:145.65},11,cjs.Ease.get(1)).wait(17));

	// ani
	this.instance_1 = new lib.Symbol1("synched",0);
	this.instance_1.setTransform(1201.5,68.75);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(11).to({_off:false},0).to({x:464},15,cjs.Ease.get(1)).to({x:476.5},5,cjs.Ease.get(1)).wait(1));

	// bg
	this.instance_2 = new lib.bgg();
	this.instance_2.setTransform(489.95,293.5);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({alpha:0.3203},11).wait(1).to({alpha:1},0).wait(20));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(157.3,281.5,1253.2,317);
// library properties:
lib.properties = {
	id: 'ECDF1A6AC5E395468828BABD79B3D8C3',
	width: 977,
	height: 588,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Interface_atlas_1.png?1638118459897", id:"Interface_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['ECDF1A6AC5E395468828BABD79B3D8C3'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;