(function ()
{
	var InputData = {}
	var _this = InputData;
	
	_this.Audios = [
		{src:"../global_assets/sounds/bgm1.mp3", id:"bgm"},
		{src:"sounds/instruction.mp3", id:"instruction"},
		{src:"../global_assets/sounds/rightThatsgreat.mp3", id:"thatsgreat"},
		{src:"../global_assets/sounds/rightThatsright.mp3", id:"thatsright"},
		{src:"../global_assets/sounds/rightWow.mp3", id:"rightWow"},
		{src:"../global_assets/sounds/incorrect.mp3", id:"incorrect"},
		{src:"../global_assets/sounds/showAnswer.mp3", id:"showAnswer"}
    ];

	window.InputData = InputData;

}());