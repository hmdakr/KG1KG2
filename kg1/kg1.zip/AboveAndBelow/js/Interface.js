(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Interface_atlas_1", frames: [[0,618,155,173],[739,698,396,42],[1575,0,452,119],[1575,121,452,119],[1355,668,415,42],[1137,712,396,42],[1021,613,332,83],[1575,242,452,119],[1021,528,373,83],[1021,286,452,119],[1475,363,452,119],[322,618,343,54],[1876,605,165,166],[157,618,163,138],[1475,286,67,70],[1021,0,298,278],[1929,459,67,70],[1929,363,87,94],[0,0,1019,616],[1321,0,252,284],[1396,528,67,70],[1396,605,478,61],[322,674,415,42],[1021,407,452,119],[1475,484,452,119],[1535,712,124,86]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_270 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap13 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap14 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap15 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap16 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap17 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap19 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap20 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap21 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap22 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap23 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap24 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap25 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap26 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap27 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap28 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap29 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap3 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap30 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap31 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap32 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap33 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap34 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap35 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap36 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap4 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap15();
	this.instance.setTransform(-26,-34);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-34,452,119);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}
	this.frame_1 = function() {
		this.blnPlay = true;
	}
	this.frame_134 = function() {
		this.parent.fChangeQuestion();
		this.blnPlay = false;
		this.gotoAndStop(0);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(133).call(this.frame_134).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_270();
	this.instance.setTransform(-22.45,-25,0.2894,0.2894);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.4,-25,44.8,50.1);


(lib.numbring01_2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap27();
	this.instance.setTransform(-34,-35);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34,-35,67,70);


(lib.numbring01_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap29();
	this.instance.setTransform(-34,-35);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34,-35,67,70);


(lib.numbring01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap32();
	this.instance.setTransform(-34,-35);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34,-35,67,70);


(lib.house_shadow_2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_5
	this.instance = new lib.Bitmap26();
	this.instance.setTransform(-127,-186);

	this.instance_1 = new lib.Bitmap25();
	this.instance_1.setTransform(-125,-41);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-127,-186,167,311);


(lib.house_shadow_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.Bitmap28();
	this.instance.setTransform(-173,-167);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-173,-167,298,278);


(lib.house_shadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.Bitmap31();
	this.instance.setTransform(-129,-168);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-129,-168,252,284);


(lib.heading_txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap33();
	this.instance.setTransform(-231,-31);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-231,-31,478,61);


(lib.heading_ = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap24();
	this.instance.setTransform(-147,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-147,-28,343,54);


(lib.btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("EgjAAHeIAAu7MBGBAAAIAAO7g");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-224.1,-47.8,448.2,95.6), null);


(lib.broadCastInterface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_1 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_599 = function() {
		/* stop();
		this.blnPlay = false;
		MovieClip(parent.parent.parent.parent).mcForward.mcGlow.gotoAndPlay(6);*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(598).call(this.frame_599).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.bg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.Bitmap30();
	this.instance.setTransform(-492,-297);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-492,-297,1019,616);


(lib.right_wrong = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// Layer_1
	this.instance = new lib.Symbol1("synched",0);
	this.instance.setTransform(-3.45,1.75);
	this.instance.alpha = 0.0117;

	this.instance_1 = new lib.Bitmap3();
	this.instance_1.setTransform(-24,-22,0.5,0.5);

	this.instance_2 = new lib.Bitmap4();
	this.instance_2.setTransform(-27,-22,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27,-23.2,62,50);


(lib.heading02_2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_5
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_4
	this.instance = new lib.Bitmap21();
	this.instance.setTransform(-195,-40);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

	// Layer_2
	this.instance_1 = new lib.Bitmap22();
	this.instance_1.setTransform(-235,-72);

	this.instance_2 = new lib.Bitmap23();
	this.instance_2.setTransform(-235,-72);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-235,-72,459.2,119.7);


(lib.heading02_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_5
	this.instance = new lib.Bitmap34();
	this.instance.setTransform(-216,-21);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

	// Layer_3
	this.instance_1 = new lib.Bitmap35();
	this.instance_1.setTransform(-235,-71);

	this.instance_2 = new lib.Bitmap36();
	this.instance_2.setTransform(-235,-72);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-235,-72,459.2,120);


(lib.heading02 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-3.9,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap16();
	this.instance.setTransform(-216,-19);

	this.instance_1 = new lib.txt1("synched",0);
	this.instance_1.setTransform(190.85,-37.3,1,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-235.1,-71.3,455.29999999999995,119);


(lib.heading01_2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap19();
	this.instance.setTransform(-169,-40);

	this.instance_1 = new lib.Bitmap20();
	this.instance_1.setTransform(-226,-71);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-226,-71,452,119);


(lib.heading01_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap17();
	this.instance.setTransform(-198,-21);

	this.instance_1 = new lib.txt1("synched",0);
	this.instance_1.setTransform(-199.8,-37.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-225.8,-71.3,452,119);


(lib.heading01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_5
	this.instance = new lib.Bitmap13();
	this.instance.setTransform(-198,-22);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

	// Layer_1
	this.instance_1 = new lib.txt1("synched",0);
	this.instance_1.setTransform(-199.8,-37.3);

	this.instance_2 = new lib.Bitmap14();
	this.instance_2.setTransform(-226,-72);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-226,-72,452.2,119.7);


(lib.mcMain3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {strFrame3:0};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay =  true;*/
	}
	this.frame_131 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 2;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();
			//objRef.mcFish.gotoAndPlay(2);
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.fbAudio = main.playAudio('rightWow');
				setTimeout(function()
				{
					//this.parent.strFrame = "strFrame3";
					//this.parent.fLaunchProduct();
					this.play();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				this.parent.strFrame = "strFrame3";
				//this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
				this.play();
			}.bind(this), 5000);
		}
		this.init();
	}
	this.frame_132 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_173 = function() {
		/* stop();
		this.blnPlay = false;
		//MovieClip(parent.parent.parent).mcFinal.gotoAndPlay(2);
		fCalculateScore();
		function fCalculateScore() {
			var nP = Math.floor((__nScore/3)*100);
			trace(__nScore + "------------------------------"+nP);
			if (nP < 70) {
				MovieClip(parent.parent.parent).mcFinal.mcRank.gotoAndPlay("rank2");
			} else {
				MovieClip(parent.parent.parent).mcFinal.mcRank.gotoAndPlay("rank1_1");
			}
		}*/
		
		this.stop();
		//alert("----------Activity End---");
		main.showRestartBtn();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(131).call(this.frame_131).wait(1).call(this.frame_132).wait(41).call(this.frame_173).wait(1));

	// _
	this.mcFish = new lib.Symbol2();
	this.mcFish.name = "mcFish";
	this.mcFish.setTransform(-450.5,-189);

	this.timeline.addTween(cjs.Tween.get(this.mcFish).wait(174));

	// Layer_4
	this.mcInterfaceBlinker = new lib.broadCastInterface();
	this.mcInterfaceBlinker.name = "mcInterfaceBlinker";
	this.mcInterfaceBlinker.setTransform(-453,-389,1,1,0,0,0,11.5,8);
	this.mcInterfaceBlinker._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mcInterfaceBlinker).wait(131).to({_off:false},0).to({_off:true},1).wait(42));

	// right_wrong_audio
	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(301.7,109.15,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-220.55,109.15,1.728,1.728);

	this.mc_2 = new lib.heading02_2_3();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(249.35,209.9);

	this.mc_1 = new lib.heading01_2_3();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-238.9,209.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mcTick_1},{t:this.mcTick_2}]},131).wait(43));

	// HEADING
	this.instance = new lib.heading_("synched",0);
	this.instance.setTransform(-342.85,-272.75);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(174));

	// heading02
	this.instance_1 = new lib.heading02_2_3("single",0);
	this.instance_1.setTransform(249.35,399.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(104).to({_off:false},0).to({y:199.9},10,cjs.Ease.get(1)).to({y:209.9},5).to({_off:true},12).wait(1).to({_off:false},0).wait(42));

	// heading01
	this.instance_2 = new lib.heading01_2_3("synched",0);
	this.instance_2.setTransform(-238.9,399.9);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(99).to({_off:false},0).to({y:199.9},10,cjs.Ease.get(1)).to({y:209.9},5).to({_off:true},17).wait(1).to({_off:false},0).wait(42));

	// house_shadow
	this.instance_3 = new lib.house_shadow_2_3("synched",0);
	this.instance_3.setTransform(699,14.5,1,1,0,0,0,-0.2,-0.2);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(82).to({_off:false},0).to({x:19},12,cjs.Ease.get(1)).to({x:29},5,cjs.Ease.get(1)).wait(75));

	// numbring01
	this.instance_4 = new lib.numbring01_2_3("synched",0);
	this.instance_4.setTransform(-387.6,-129.8,2,2);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(78).to({_off:false},0).to({scaleX:0.9,scaleY:0.9,alpha:1},12,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5).wait(79));

	// heading02
	this.instance_5 = new lib.heading02_2("single",0);
	this.instance_5.setTransform(249.35,209.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(45).to({startPosition:0},0).to({y:199.9},6).to({y:339.9},13,cjs.Ease.get(-1)).to({_off:true},1).wait(109));

	// heading01
	this.instance_6 = new lib.heading01_2("synched",0);
	this.instance_6.setTransform(-238.9,209.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(42).to({startPosition:0},0).to({y:199.9},6).to({y:339.9},13,cjs.Ease.get(-1)).to({_off:true},1).wait(112));

	// house_shadow
	this.instance_7 = new lib.house_shadow_2("synched",0);
	this.instance_7.setTransform(29,18.5,1,1,0,0,0,-0.2,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(32).to({startPosition:0},0).to({x:39},6,cjs.Ease.get(1)).to({x:-661},13,cjs.Ease.get(1)).to({_off:true},1).wait(122));

	// numbring01
	this.instance_8 = new lib.numbring01_2("synched",0);
	this.instance_8.setTransform(-387.6,-129.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(23).to({startPosition:0},0).to({scaleX:0.9,scaleY:0.9},6,cjs.Ease.get(1)).to({scaleX:2,scaleY:2,alpha:0},10,cjs.Ease.get(1)).to({_off:true},1).wait(134));

	// heading_txt
	this.instance_9 = new lib.heading_txt("synched",0);
	this.instance_9.setTransform(0,-212.15);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(174));

	// bg
	this.instance_10 = new lib.bg();

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(174));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-833.8,-300.7,1573,748.5999999999999);


(lib.mcMain2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {strFrame2:0};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_129 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 2;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();
			//objRef.mcFish.gotoAndPlay(2);
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.fbAudio = main.playAudio('thatsright');
				setTimeout(function()
				{
					this.parent.strFrame = "strFrame3";
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame3";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(129).call(this.frame_129).wait(1));

	// _
	this.mcFish = new lib.Symbol2();
	this.mcFish.name = "mcFish";
	this.mcFish.setTransform(-450.5,-189);

	this.timeline.addTween(cjs.Tween.get(this.mcFish).wait(130));

	// right_wrong_audio
	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(301.7,108.75,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-220.55,108.75,1.728,1.728);

	this.mc_2 = new lib.heading02_2();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(249.35,209.9);

	this.mc_1 = new lib.heading01_2();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-238.9,209.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mcTick_1},{t:this.mcTick_2}]},129).wait(1));

	// HEADING
	this.instance = new lib.heading_("synched",0);
	this.instance.setTransform(-342.85,-272.75);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(130));

	// heading02
	this.instance_1 = new lib.heading02_2("single",0);
	this.instance_1.setTransform(249.35,399.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(100).to({_off:false},0).to({y:199.9},10,cjs.Ease.get(1)).to({y:209.9},5).to({_off:true},14).wait(1));

	// heading01
	this.instance_2 = new lib.heading01_2("synched",0);
	this.instance_2.setTransform(-238.9,399.9);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(95).to({_off:false},0).to({y:199.9},10,cjs.Ease.get(1)).to({y:209.9},5).to({_off:true},19).wait(1));

	// house_shadow
	this.instance_3 = new lib.house_shadow_2("synched",0);
	this.instance_3.setTransform(699,18.5,1,1,0,0,0,-0.2,-0.2);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(78).to({_off:false},0).to({x:19},12,cjs.Ease.get(1)).to({x:29},5,cjs.Ease.get(1)).wait(35));

	// numbring01
	this.instance_4 = new lib.numbring01_2("synched",0);
	this.instance_4.setTransform(-387.6,-129.8,2,2);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(74).to({_off:false},0).to({scaleX:0.9,scaleY:0.9,alpha:1},12,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5).wait(39));

	// heading02
	this.instance_5 = new lib.heading02("synched",0);
	this.instance_5.setTransform(249.35,209.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(44).to({startPosition:0},0).to({y:199.9},6).to({y:339.9},13,cjs.Ease.get(-1)).to({_off:true},1).wait(66));

	// heading01
	this.instance_6 = new lib.heading01("single",0);
	this.instance_6.setTransform(-238.9,209.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(41).to({startPosition:0},0).to({y:199.9},6).to({y:339.9},13,cjs.Ease.get(-1)).to({_off:true},1).wait(69));

	// house_shadow
	this.instance_7 = new lib.house_shadow("synched",0);
	this.instance_7.setTransform(29,8.5,1,1,0,0,0,-0.2,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(31).to({startPosition:0},0).to({x:39},6,cjs.Ease.get(1)).to({x:-661},13,cjs.Ease.get(1)).to({_off:true},1).wait(79));

	// numbring01
	this.instance_8 = new lib.numbring01("synched",0);
	this.instance_8.setTransform(-387.6,-129.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(22).to({startPosition:0},0).to({scaleX:0.9,scaleY:0.9},6,cjs.Ease.get(1)).to({scaleX:2,scaleY:2,alpha:0},10,cjs.Ease.get(1)).to({_off:true},1).wait(91));

	// heading_txt
	this.instance_9 = new lib.heading_txt("synched",0);
	this.instance_9.setTransform(0,-212.15);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(130));

	// bg
	this.instance_10 = new lib.bg();

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(130));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-789.8,-300.7,1614,748.5999999999999);


(lib.mcMain1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {strFrame1:0};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.fbAudio = main.playAudio('instruction');
	}
	this.frame_85 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 1;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();
			//objRef.mcFish.gotoAndPlay(2);
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.fbAudio = main.playAudio('thatsgreat');
				setTimeout(function()
				{
					this.parent.strFrame = "strFrame2";
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(85).call(this.frame_85).wait(1));

	// _
	this.mcFish = new lib.Symbol2();
	this.mcFish.name = "mcFish";
	this.mcFish.setTransform(-450.5,-189);

	this.timeline.addTween(cjs.Tween.get(this.mcFish).to({_off:true},85).wait(1));

	// right_wrong_audio
	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(301.7,116.75,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-220.55,116.75,1.728,1.728);

	this.mc_2 = new lib.heading02();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(249.35,209.9);

	this.mc_1 = new lib.heading01();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-238.9,209.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mcTick_1},{t:this.mcTick_2}]},85).wait(1));

	// HEADING
	this.instance = new lib.heading_("synched",0);
	this.instance.setTransform(-672.85,-272.75);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).to({x:-342.85},11,cjs.Ease.get(1)).wait(71));

	// heading02
	this.instance_1 = new lib.heading02("synched",0);
	this.instance_1.setTransform(249.35,399.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(55).to({_off:false},0).to({y:199.9},10,cjs.Ease.get(1)).to({y:209.9},5).to({_off:true},15).wait(1));

	// heading01
	this.instance_2 = new lib.heading01("single",0);
	this.instance_2.setTransform(-238.9,399.9);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).to({y:199.9},10,cjs.Ease.get(1)).to({y:209.9},5).to({_off:true},20).wait(1));

	// house_shadow
	this.instance_3 = new lib.house_shadow("synched",0);
	this.instance_3.setTransform(699,8.5,1,1,0,0,0,-0.2,-0.2);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(33).to({_off:false},0).to({x:19},12,cjs.Ease.get(1)).to({x:29},5,cjs.Ease.get(1)).wait(36));

	// numbring01
	this.instance_4 = new lib.numbring01("synched",0);
	this.instance_4.setTransform(-387.6,-129.8,2,2);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(29).to({_off:false},0).to({scaleX:0.9,scaleY:0.9,alpha:1},12,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5).wait(40));

	// heading_txt
	this.instance_5 = new lib.heading_txt("synched",0);
	this.instance_5.setTransform(740,-212.15);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(7).to({_off:false},0).to({x:-10},12,cjs.Ease.get(1)).to({x:0},6,cjs.Ease.get(1)).wait(61));

	// bg
	this.instance_6 = new lib.bg();
	this.instance_6.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({alpha:1},11).wait(75));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-819.8,-300.7,1806.8,748.3);


// stage content:
(lib.Interface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
		this.strFrame = "strFrame1"
		this.nF = 1;
		this.fLaunchProduct = function()
		{
			if(this.mcAttachMovieClip)
			{
				this.removeChild(this.mcAttachMovieClip);
			}
			this.mcAttachMovieClip = new lib["mcMain"+this.nF];
			this.mcAttachMovieClip.x = 488;
			this.mcAttachMovieClip.y = 295;	
			this.mcAttachMovieClip.gotoAndPlay(this.strFrame);
			this.addChild(this.mcAttachMovieClip);	
			this.nF = this.nF + 1;
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);
// library properties:
lib.properties = {
	id: 'ECDF1A6AC5E395468828BABD79B3D8C3',
	width: 977,
	height: 588,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Interface_atlas_1.png?1638118839464", id:"Interface_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['ECDF1A6AC5E395468828BABD79B3D8C3'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;