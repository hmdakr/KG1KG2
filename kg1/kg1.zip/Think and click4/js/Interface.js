(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Interface_atlas_1", frames: [[0,0,1954,1210],[1758,1560,246,238],[663,1641,304,395],[969,1909,730,78],[1758,1800,168,204],[969,1641,208,168],[1329,1212,481,344],[663,1212,664,427],[1812,1212,194,346],[1329,1558,427,349],[0,1212,661,661]]},
		{name:"Interface_atlas_2", frames: [[959,0,53,53],[405,56,50,50],[951,155,31,41],[0,0,153,224],[155,0,302,54],[459,0,123,119],[155,56,123,119],[280,56,123,119],[584,0,123,119],[709,0,123,119],[834,0,123,119],[405,121,123,119],[155,177,123,119],[280,177,123,119],[0,226,123,119],[530,121,123,119],[655,121,123,119],[780,121,123,119],[405,242,123,119],[125,298,123,119],[0,347,123,119],[959,101,45,52],[905,121,44,48],[959,55,63,44],[375,363,228,56],[250,298,123,119],[530,242,123,119],[655,242,123,119],[780,242,123,119]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_234 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_233 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_232 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_231 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_230 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_229 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap10 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap12 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap13 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap15 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap16 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap17 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap18 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap19 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap20 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap21 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap22 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap23 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap24 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap25 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap26 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap27 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap28 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap29 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap30 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap31 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap32 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap33 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap34 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap35 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap36 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap37 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap4 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap9 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.trx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_234();
	this.instance.setTransform(-488.5,-302.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-488.5,-302.4,977,605);


(lib.text01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap2();
	this.instance.setTransform(-365,-37);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-365,-37,730,78);


(lib.Suneye = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag9A+QgagaAAgkQAAgjAagaQAagaAjAAQAkAAAaAaQAaAaAAAjQAAAkgaAaQgaAagkAAQgjAAgagag");
	mask.setTransform(-0.025,-0.025);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DE7307").ss(1,1,1).p("Ah3htIDvAAIAADbQh0h8h7B8g");
	this.shape.setTransform(-0.15,-15.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FAA316").s().p("Ah3BuIAAjbIDvAAIAADbQh0h8h7B8g");
	this.shape_1.setTransform(-0.15,-15.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#DE7307").ss(1,1,1).p("Ah3htIDvAAIAADbQh1gnh6Ang");
	this.shape_2.setTransform(-0.3,-12.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FAA316").s().p("Ah3BuIAAjbIDvAAIAADbQh1gnh6Ang");
	this.shape_3.setTransform(-0.3,-12.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#DE7307").ss(1,1,1).p("Ah3h5IDvAAIAADbQh3Avh4gvg");
	this.shape_4.setTransform(-0.4,-8.725);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FAA316").s().p("Ah3BiIAAjbIDvAAIAADbQg8AYg8AAQg7AAg8gYg");
	this.shape_5.setTransform(-0.4,-8.725);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#DE7307").ss(1,1,1).p("AB4iOIAADbQh4CEh3iEIAAjbg");
	this.shape_6.setTransform(-0.55,-3.9875);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FAA316").s().p("Ah3BNIAAjbIDvAAIAADbQg8BCg8AAQg7AAg8hCg");
	this.shape_7.setTransform(-0.55,-3.9875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#DE7307").ss(1,1,1).p("Ah3iOIDvAAIAADbQh4CEh3iEg");
	this.shape_8.setTransform(-0.55,-3.9875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#DE7307").ss(1,1,1).p("Ah3h+IDvAAIAADbQh3BEh4hEg");
	this.shape_9.setTransform(-0.45,-7.5375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FAA316").s().p("Ah3BdIAAjbIDvAAIAADbQg7Aig8AAQg7AAg9gig");
	this.shape_10.setTransform(-0.45,-7.5375);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#DE7307").ss(1,1,1).p("Ah3huIDvAAIAADbQh2AEh5gEg");
	this.shape_11.setTransform(-0.35,-11.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FAA316").s().p("Ah3BtIAAjbIDvAAIAADbQg7ACg8AAQg7AAg9gCg");
	this.shape_12.setTransform(-0.35,-11.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#DE7307").ss(1,1,1).p("Ah3htIDvAAIAADbQh1g8h6A8g");
	this.shape_13.setTransform(-0.25,-13.15);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FAA316").s().p("Ah3BuIAAjbIDvAAIAADbQh1g8h6A8g");
	this.shape_14.setTransform(-0.25,-13.15);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},14).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).to({state:[{t:this.shape_7},{t:this.shape_6}]},1).to({state:[{t:this.shape_7},{t:this.shape_8}]},1).to({state:[{t:this.shape_7},{t:this.shape_8}]},1).to({state:[{t:this.shape_7},{t:this.shape_8}]},1).to({state:[{t:this.shape_7},{t:this.shape_6}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_1},{t:this.shape}]},1).to({state:[]},1).wait(74));

	// Layer_1
	this.instance = new lib.CachedBmp_233();
	this.instance.setTransform(-9.75,-9.75,0.3705,0.3705);

	this.instance_1 = new lib.CachedBmp_232();
	this.instance_1.setTransform(-9.25,-9.25,0.3705,0.3705);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(100));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.7,-9.7,19.6,19.6);


(lib.right_wrong = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// _
	this.instance = new lib.Bitmap28();
	this.instance.setTransform(-26,-26);

	this.instance_1 = new lib.Bitmap29();
	this.instance_1.setTransform(-25,-22);

	this.instance_2 = new lib.Bitmap30();
	this.instance_2.setTransform(-31,-18);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-26,63,52);


(lib.rabbit__eye1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#C0C0C0").ss(0.5,1,1).p("ABvhhQATBIgfBmQgqB3h1gwQAAAAgBAAQgBAAAAgBQgBAAAAAAQgBAAAAgBQgGgCgEgCQgBgBgBAAIglgpQgKgaAKglQAAgBAAgBQAKgmARghQAAgBABgBQAFgMAHgLQALgRAJgNQACgDACgCQABgCABgBQAngzApgJQA5gLAVBJg");
	this.shape.setTransform(0.001,-0.0139);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(91));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag8CUIgBAAIgBgBIgBAAIgBgBIgKgEIgCgBIglgpQgJgaAKglIABgCIgCAAIACgBIABgFQAAgJAJgUQACgHADgFQAFgPAFgJIABgCQAFgMAHgLIAUgeIAEgFIABgBIABgCQAngzApgJQA5gLAVBJQATBIgfBmQgeBVhFAAQgaAAgigOg");
	mask.setTransform(0.0443,-0.0139);

	// Layer_5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#C0C0C0").ss(0.5,1,1).p("ACZBpQidltiUFtIAAjRIExAAg");
	this.shape_1.setTransform(5.0274,-9.7691,1.0536,0.999,18.8257);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E6EEFF").s().p("AiYBpIAAjRIExAAIAADRQidltiUFtg");
	this.shape_2.setTransform(5.0274,-9.7691,1.0536,0.999,18.8257);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#C0C0C0").ss(0.5,1,1).p("Ai5AvIBDjFIEwBoIhDDFQhNkijjC6g");
	this.shape_3.setTransform(5.025,-9.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E6EEFF").s().p("Ai5AvIBDjFIEwBoIhDDFQhNkijjC6g");
	this.shape_4.setTransform(5.025,-9.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#C0C0C0").ss(0.5,1,1).p("Ai5AvIBDjFIEwBoIhDDFQhyi1i+BNg");
	this.shape_5.setTransform(5.025,-9.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E6EEFF").s().p("Ai5AvIBDjFIEwBoIhDDFQhyi1i+BNg");
	this.shape_6.setTransform(5.025,-9.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#C0C0C0").ss(0.5,1,1).p("Ai5AvIBDjFIEwBoIhDDFQiXhKiZgeg");
	this.shape_7.setTransform(5.025,-9.775);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E6EEFF").s().p("Ai5AvIBDjFIEwBoIhDDFQiXhKiZgeg");
	this.shape_8.setTransform(5.025,-9.775);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#C0C0C0").ss(0.5,1,1).p("Ai5ArIBDjEIEwBoIhDDEQi9AjhziLg");
	this.shape_9.setTransform(5.025,-9.423);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#E6EEFF").s().p("Ai5ArIBDjEIEwBoIhDDEQgmAHgjAAQiLAAhchvg");
	this.shape_10.setTransform(5.025,-9.423);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#C0C0C0").ss(0.5,1,1).p("Ai5AUIBDjEIEwBoIhDDEQjiCQhOj4g");
	this.shape_11.setTransform(5.025,-7.1417);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#E6EEFF").s().p("Ai5AUIBDjEIEwBoIhDDEQhUA1g+AAQhtAAgxidg");
	this.shape_12.setTransform(5.025,-7.1417);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#C0C0C0").ss(0.5,1,1).p("Ai5gEIBDjGIEwBoIhDDFQkID8goljg");
	this.shape_13.setTransform(5.025,-4.5526);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#E6EEFF").s().p("Ai5gEIBDjGIEwBoIhDDFQhuBohGAAQhlAAgXjPg");
	this.shape_14.setTransform(5.025,-4.5526);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#C0C0C0").ss(0.5,1,1).p("ACZgEQigG2iRm2IAAjRIExAAg");
	this.shape_15.setTransform(1.4901,0.6065,1.0536,0.999,18.8257);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E6EEFF").s().p("AiYgEIAAjRIExAAIAADRQhQDahMAAQhMAAhJjag");
	this.shape_16.setTransform(1.4901,0.6065,1.0536,0.999,18.8257);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},11).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_16},{t:this.shape_15}]},1).to({state:[{t:this.shape_16},{t:this.shape_15}]},4).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).wait(62));

	// Layer_2
	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgDAEQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQABAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAABgBAAQAAAAAAgBQgBAAAAAAQgBAAAAAAQgBgBAAAAg");
	this.shape_17.setTransform(-2.8212,-1.8721,3.5278,3.5278);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgEBAIgNgEQgIgDgDgDQgDgDgEgBIgCgBIgGgIIgBgBQgCgFAFgNIAEgPIAIgYIAGgQIALgYQAKgLANAFQAVAHAIAVQAIAWgFAbQgGAagKAOQgJALgNAAIgJgBg");
	this.shape_18.setTransform(-6.6391,0.7694);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#441003").s().p("AgVBuQg6gBAJhCIACADIABABIAGAIIACABQAEABADADQADADAIADIANAEIAKABQANAAAIgLQAKgOAGgaQAFgbgIgWQgIgVgUgHQgOgFgKALQAPgaAUgZQApgXAWA1QAVA4gYBAQgXA+g3AAIgCAAg");
	this.shape_19.setTransform(-4.2349,0.1672);

	var maskedShapeInstanceList = [this.shape_17,this.shape_18,this.shape_19];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17}]}).wait(91));

	// Layer_3
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#F4F3F9").s().p("AggBEIAAgCQAKgmARghQgFAIgFAQQgDAEgCAIQgJAUAAAJIgBAGIgCAAIACABIgBABIgBAAgAAhhDIgBABIgBABIACgCg");
	this.shape_20.setTransform(-8.075,-3.15);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("Ag8CUIgBAAIgBgBIgBAAIgBgBIgKgEIgCgBIglgpQgJgaAKglIABgCIgCAAIACgBIABgFQAAgJAJgUQACgHADgFQAFgPAFgJIABgCQAFgMAHgLIAUgeIAEgFIABgBIABgCQAngzApgJQA5gLAVBJQATBIgfBmQgeBVhFAAQgaAAgigOg");
	this.shape_21.setTransform(0.0443,-0.0139);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20}]}).wait(91));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12.8,-17.2,25.700000000000003,34.4);


(lib.p_eye = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#809C0C").ss(0.5,1,1).p("ABmhnQgIgPgLgMQgbgWgnAEQgkACgtAqQgGAFgFAFQgPAQgMATQgUAjgHArQAAADgBACQgEAyAcAgQASASAcAMQAmASAigGQAkgGAfgcQA4gzgEhPQgDgvgagog");
	this.shape.setTransform(0.7633,-0.0394);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(80));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag8CIQgcgMgSgSQgcggAEgyIABgFQAHgrAUgjQAMgTAPgQIALgKQAtgqAkgCQAngEAbAWQALAMAIAPQAaAoADAvQAEBPg4AzQgfAcgkAGIgQACQgbAAgdgOg");
	mask.setTransform(0.7633,-0.0394);

	// Layer_5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#809C0C").ss(0.5,1,1).p("AjFBpIAAjRIGLAAIAADRQiLlNkAFNg");
	this.shape_1.setTransform(2.2468,-10.4968,0.9997,0.9997,5.7951);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#AED70F").s().p("AjFBpIAAjRIGLAAIAADRQiLlNkAFNg");
	this.shape_2.setTransform(2.2468,-10.4968,0.9997,0.9997,5.7951);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#809C0C").ss(0.5,1,1).p("AjPBVIAVjRIGKAoIgVDRQiJjVkBCtg");
	this.shape_3.setTransform(2.25,-10.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#AED70F").s().p("AjPBUIAWjQIGJAoIgWDRQiIjVkBCsg");
	this.shape_4.setTransform(2.25,-10.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#809C0C").ss(0.5,1,1).p("AjPBVIAVjRIGKAoIgVDRQiphRjhApg");
	this.shape_5.setTransform(2.25,-10.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#AED70F").s().p("AjPBUIAWjQIGJAoIgWDRQinhRjiAog");
	this.shape_6.setTransform(2.25,-10.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#809C0C").ss(0.5,1,1).p("AjPBLIAVjQIGKAoIgVDQQjHA1jDhdg");
	this.shape_7.setTransform(2.25,-9.538);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#AED70F").s().p("AjPBLIAWjQIGJAoIgWDQQhIAThIAAQh9AAh8g7g");
	this.shape_8.setTransform(2.25,-9.538);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#809C0C").ss(0.5,1,1).p("AjPArIAVjQIGKAoIgVDQQjnC6ijjig");
	this.shape_9.setTransform(2.25,-6.3015);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#AED70F").s().p("AjPArIAWjQIGJAoIgWDQQhoBThZAAQhuAAhah7g");
	this.shape_10.setTransform(2.25,-6.3015);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#809C0C").ss(0.5,1,1).p("AjFATIAAjRIGLAAIAADRQjkFYinlYg");
	this.shape_11.setTransform(1.3775,-1.9317,0.9997,0.9997,5.7951);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#AED70F").s().p("AjFATIAAjRIGLAAIAADRQhyCshiAAQhjAAhUisg");
	this.shape_12.setTransform(1.3775,-1.9317,0.9997,0.9997,5.7951);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},14).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},4).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).wait(52));

	// Layer_2
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgGAGQgCgCgBgEQABgDACgDQADgCADAAQAEAAADACQACADAAADQAAAEgCACQgDAEgEAAQgDAAgDgEg");
	this.shape_13.setTransform(-1.6801,0.255,2.6304,2.6304,0,0,180);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgxAxQgTgUgBgdQABgbATgWQAVgTAcAAQAdAAAUATQAUAWAAAbQAAAdgUAUQgUAVgdgBQgcABgVgVg");
	this.shape_14.setTransform(-6.9,3.85);

	var maskedShapeInstanceList = [this.shape_13,this.shape_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13}]}).wait(80));

	// Layer_3
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag8CIQgcgMgSgSQgcggAEgyIABgFQAHgrAUgjQAMgTAPgQIALgKQAtgqAkgCQAngEAbAWQALAMAIAPQAaAoADAvQAEBPg4AzQgfAcgkAGIgQACQgbAAgdgOg");
	this.shape_15.setTransform(0.7633,-0.0394);

	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(80));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-13.3,-16,28.200000000000003,32);


(lib.heading_ = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap1();
	this.instance.setTransform(-147,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-147,-28,302,54);


(lib.vnvbbn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgqA8QgTgZABgjQgBgiATgaQASgYAYAAQAaAAARAYQATAagBAiQAAAjgSAZQgRAZgaAAQgYAAgSgZg");
	mask.setTransform(0,-0.025);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(0.5,1,1).p("ABdBNQhXhwhiBwIAAiaIC5AAg");
	this.shape.setTransform(-0.25,-11.45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FACEA3").s().p("AhcBNIAAiaIC5AAIAACaQhXhwhiBwg");
	this.shape_1.setTransform(-0.25,-11.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#333333").ss(0.5,1,1).p("AhchNIC5AAIAACbQhYg/hhA/g");
	this.shape_2.setTransform(-0.25,-9.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FACEA3").s().p("AhcBOIAAiaIC5AAIAACaQhYhAhhBAg");
	this.shape_3.setTransform(-0.25,-9.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#333333").ss(0.5,1,1).p("AhchNIC5AAIAACaQhagMhfAMg");
	this.shape_4.setTransform(-0.25,-7.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FACEA3").s().p("AhcBNIAAiZIC5AAIAACZQhagMhfAMg");
	this.shape_5.setTransform(-0.25,-7.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#333333").ss(0.5,1,1).p("AhchWIC5AAIAACaQhbAmhegmg");
	this.shape_6.setTransform(-0.25,-4.0875);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FACEA3").s().p("AhcBEIAAiaIC5AAIAACaQguATguAAQguAAgvgTg");
	this.shape_7.setTransform(-0.25,-4.0875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#333333").ss(0.5,1,1).p("ABdhjIAACaQhdBahchaIAAiag");
	this.shape_8.setTransform(-0.25,-0.7125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FACEA3").s().p("AhcA3IAAiaIC5AAIAACaQgvAtguAAQgtAAgvgtg");
	this.shape_9.setTransform(-0.25,-0.7125);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#333333").ss(0.5,1,1).p("AhchjIC5AAIAACaQhdBahchag");
	this.shape_10.setTransform(-0.25,-0.7125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#333333").ss(0.5,1,1).p("ABdA3QhdBahchaIAAiaIC5AAg");
	this.shape_11.setTransform(-0.25,-0.7125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#333333").ss(0.5,1,1).p("AhchaIC5AAIAACaQhcA3hdg3g");
	this.shape_12.setTransform(-0.25,-2.9625);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FACEA3").s().p("AhcBAIAAiaIC5AAIAACaQguAbgvAAQgtAAgvgbg");
	this.shape_13.setTransform(-0.25,-2.9625);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#333333").ss(0.5,1,1).p("AhchSIC5AAIAACaQhbAWhegWg");
	this.shape_14.setTransform(-0.25,-5.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FACEA3").s().p("AhcBIIAAiaIC5AAIAACaQguALguAAQgtAAgwgLg");
	this.shape_15.setTransform(-0.25,-5.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#333333").ss(0.5,1,1).p("AhchNIC5AAIAACbQhZguhgAug");
	this.shape_16.setTransform(-0.25,-8.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FACEA3").s().p("AhcBOIAAibIC5AAIAACbQhZgvhgAvg");
	this.shape_17.setTransform(-0.25,-8.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#333333").ss(0.5,1,1).p("AhchNIC5AAIAACbQhYhPhhBPg");
	this.shape_18.setTransform(-0.25,-10.05);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FACEA3").s().p("AhcBNIAAiaIC5AAIAACaQhYhOhhBOg");
	this.shape_19.setTransform(-0.25,-10.05);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},19).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).to({state:[{t:this.shape_7},{t:this.shape_6}]},1).to({state:[{t:this.shape_9},{t:this.shape_8}]},1).to({state:[{t:this.shape_9},{t:this.shape_10}]},1).to({state:[{t:this.shape_9},{t:this.shape_10}]},1).to({state:[{t:this.shape_9},{t:this.shape_11}]},1).to({state:[{t:this.shape_13},{t:this.shape_12}]},1).to({state:[{t:this.shape_15},{t:this.shape_14}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).to({state:[{t:this.shape_17},{t:this.shape_16}]},1).to({state:[{t:this.shape_19},{t:this.shape_18}]},1).to({state:[{t:this.shape_1},{t:this.shape}]},1).to({state:[]},1).wait(67));

	// Layer_1
	this.instance = new lib.CachedBmp_231();
	this.instance.setTransform(-6.85,-9.2,0.4468,0.4468);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(100));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6.8,-9.2,13.8,18.299999999999997);


(lib.btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("EgjAAHeIAAu7MBGBAAAIAAO7g");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-224.1,-47.8,448.2,95.6), null);


(lib.boy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_6
	this.instance = new lib.Bitmap19();
	this.instance.setTransform(-130,-149);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-130,-149,304,395);


(lib.box_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		/* stop();
		this.blnPlay=false;*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.instance = new lib.CachedBmp_229();
	this.instance.setTransform(-36.7,-57.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.CachedBmp_230();
	this.instance_1.setTransform(-61.5,-59.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61.5,-59.5,123,119);


(lib.rabbit_body1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.rabbit__eye1();
	this.instance.setTransform(7,-21.9,0.98,0.98);

	this.instance_1 = new lib.rabbit__eye1();
	this.instance_1.setTransform(-46.8,-39.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[]},1).wait(1));

	// Layer_1
	this.instance_2 = new lib.Bitmap31();
	this.instance_2.setTransform(-117,-159);

	this.instance_3 = new lib.Bitmap32();
	this.instance_3.setTransform(-91,12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).to({state:[{t:this.instance_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-117,-159,234,339);


(lib.rabbit_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// rabbit_body
	this.instance = new lib.rabbit_body1("single",0);
	this.instance.setTransform(-42.1,37.2,1,1,0,0,0,-42.1,37.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(11).to({startPosition:0},0).to({regX:-42.2,regY:37.3,scaleX:0.9995,scaleY:0.9995,rotation:-8.2929,x:-42.15,y:37.3},12).wait(6).to({startPosition:0},0).to({regX:-42.1,regY:37.2,scaleX:1,scaleY:1,rotation:0,x:-42.1,y:37.2},12).wait(9));

	// rabbit_body
	this.instance_1 = new lib.rabbit_body1("single",1);
	this.instance_1.setTransform(4.9,155.3,1,1,0,0,0,4.9,155.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(11).to({startPosition:1},0).to({startPosition:1},12).wait(6).to({startPosition:1},0).to({startPosition:1},12).wait(9));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-144.4,-170.2,261.4,350.2);


(lib.oranges01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.p_eye();
	this.instance.setTransform(201.15,-143.2,0.6561,0.6561,-14.9997,0,0,0.2,0);

	this.instance_1 = new lib.p_eye();
	this.instance_1.setTransform(149.4,-141.2,1,1,0,0,0,0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_2
	this.instance_2 = new lib.Bitmap37();
	this.instance_2.setTransform(-186,-183);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-186,-183,427,349);


(lib.gh = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.trx();
	this.instance.setTransform(-3.4,-4.1);
	this.instance.alpha = 0.4805;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gh, new cjs.Rectangle(-491.9,-306.5,977,605), null);


(lib.Elephant = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.Suneye();
	this.instance.setTransform(75.9,3.7,1.2269,1.2269);

	this.instance_1 = new lib.Suneye();
	this.instance_1.setTransform(5.4,3.7,1.2269,1.2269);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_3
	this.instance_2 = new lib.Bitmap9();
	this.instance_2.setTransform(-292,-299);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-292,-299,661,661);


(lib.queen1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AmBXbQg1g4gmg+QitELmnh7QoRicAmmbQmGAmjXkQQkblkDtl2Ql2mCFjmpQCojIE9gpQAfnlJ1hGQC/gWCgBPQBrA1BHBNQCtk5HfAVQDjAIC4BeQDKB8AyC+IAIAgQFVjYFPBaQFQBaBIDqQBHDpgbCtQIeDMgdHSQgcHSpBCOIAfC1IgKAHQgQFImUCfQkaBwjoiUQgREcluB4QjGBBipAAQk2AAjUjdg");
	mask.setTransform(31.3084,-10.2481);

	// Layer_2
	this.instance = new lib.vnvbbn();
	this.instance.setTransform(10.8,-39.85);

	this.instance_1 = new lib.vnvbbn();
	this.instance_1.setTransform(58.75,-39.85);

	var maskedShapeInstanceList = [this.instance,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_2 = new lib.Bitmap36();
	this.instance_2.setTransform(-56,-153);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// Layer_3
	this.instance_3 = new lib.Bitmap35();
	this.instance_3.setTransform(-309,-237);

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// Layer_6
	this.instance_4 = new lib.Bitmap34();
	this.instance_4.setTransform(-209,-182);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-209.4,-182.3,481.4,344.3);


(lib.Doll = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.rabbit_1();
	this.instance.setTransform(42.1,36.5,1.2312,1.2312,0,0,0,-0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.instance_1 = new lib.Bitmap33();
	this.instance_1.setTransform(-82,204);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-101.8,-159.2,288.1,419.2);


(lib.cat_mov = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.oranges01();
	this.instance.setTransform(75.6,46.75,1.0804,1.0804,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-184.8,-150.9,461.40000000000003,377);


(lib.box3_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap22();
	this.instance.setTransform(-62,-60);

	this.instance_1 = new lib.Bitmap23();
	this.instance_1.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box3_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap18();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box3_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap13();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box3_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap5();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap27();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box2_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap21();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box2_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap17();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap11();
	this.instance.setTransform(-62,-60);

	this.instance_1 = new lib.Bitmap12();
	this.instance_1.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap6();
	this.instance.setTransform(-62,-60);

	this.instance_1 = new lib.Bitmap7();
	this.instance_1.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap25();
	this.instance.setTransform(-62,-60);

	this.instance_1 = new lib.Bitmap26();
	this.instance_1.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap20();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap15();
	this.instance.setTransform(-62,-60);

	this.instance_1 = new lib.Bitmap16();
	this.instance_1.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box_3copy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap10();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap4();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap24();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.Apple = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.queen1("synched",0);
	this.instance.setTransform(-10.5,44.6,1.0174,1.0174);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-223.5,-140.9,489.8,350.4);


(lib.mcMain5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_75 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 3;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					//this.parent.fLaunchProduct();
					this.play();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				//this.parent.fLaunchProduct();
				this.play();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}
	this.frame_76 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_87 = function() {
		/* stop();
		this.blnPlay = false;
		
		fCalculateScore();
		function fCalculateScore() {
			mcNext.mcBlinker.gotoAndStop(2);
			var nPercentage = (__nScore/5)*100;
			nPercentage = Math.ceil(nPercentage);
			trace(nPercentage + "---------------------");
			if (nPercentage < 70) {
				mcFinal.mcRank.gotoAndPlay("rank2");		
			} else {
				mcFinal.mcRank.gotoAndPlay("rank1_1");
			}
		}*/
		
		this.stop();
		//alert("endslide");
		main.showRestartBtn();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(75).call(this.frame_75).wait(1).call(this.frame_76).wait(11).call(this.frame_87).wait(1));

	// _
	this.mc_3 = new lib.box3_5();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,178.45);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_2 = new lib.box2_5();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,54.7);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.box_5();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3},{t:this.mc_1},{t:this.mc_2},{t:this.mc_3}]},75).wait(13));

	// box3
	this.instance = new lib.box3_5();
	this.instance.setTransform(566.5,178.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(59).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},3).wait(1).to({_off:false},0).wait(12));

	// box2
	this.instance_1 = new lib.box2_5();
	this.instance_1.setTransform(566.5,54.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(55).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},7).wait(1).to({_off:false},0).wait(12));

	// box
	this.instance_2 = new lib.box_5();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},12).wait(1).to({_off:false},0).wait(12));

	// elephant
	this.instance_3 = new lib.boy("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(39).to({_off:false},0).to({scaleX:1.05,scaleY:1.05},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(33));

	// box3
	this.instance_4 = new lib.box3_4();
	this.instance_4.setTransform(196.5,178.45);
	this.instance_4.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(12).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(58));

	// box2
	this.instance_5 = new lib.box2_4();
	this.instance_5.setTransform(196.5,54.7);
	this.instance_5.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(10).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(60));

	// box
	this.instance_6 = new lib.box_4();
	this.instance_6.setTransform(196.5,-69.05);
	this.instance_6.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(8).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(62));

	// elephant
	this.instance_7 = new lib.cat_mov("single",0);
	this.instance_7.setTransform(-179.05,9.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(4).to({startPosition:0},0).to({scaleX:1.1,scaleY:1.1},6).to({scaleX:0.1,scaleY:0.1},11,cjs.Ease.get(-1)).to({_off:true},1).wait(66));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-382.3,-156.6,1040.8,424.4);


(lib.mcMain4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_84 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 1;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(84).call(this.frame_84).wait(1));

	// _
	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.mc_3 = new lib.box3_4();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,178.45);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_2 = new lib.box2_4();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,54.7);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.box_4();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},84).wait(1));

	// box3
	this.instance = new lib.box3_4();
	this.instance.setTransform(566.5,178.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(60).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},11).wait(1));

	// box2
	this.instance_1 = new lib.box2_4();
	this.instance_1.setTransform(566.5,54.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(56).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},15).wait(1));

	// box
	this.instance_2 = new lib.box_4();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(51).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},20).wait(1));

	// elephant
	this.instance_3 = new lib.cat_mov("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(40).to({_off:false},0).to({scaleX:1.05,scaleY:1.05},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(29));

	// box3
	this.instance_4 = new lib.box3_3();
	this.instance_4.setTransform(196.5,178.45);
	this.instance_4.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(14).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(53));

	// box2
	this.instance_5 = new lib.box2_3();
	this.instance_5.setTransform(196.5,54.7);
	this.instance_5.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(11).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(56));

	// box
	this.instance_6 = new lib.box_3();
	this.instance_6.setTransform(196.5,-69.05);
	this.instance_6.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(9).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(58));

	// elephant
	this.instance_7 = new lib.Elephant("single",0);
	this.instance_7.setTransform(-179.05,9.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(5).to({startPosition:0},0).to({scaleX:1.1,scaleY:1.1},6).to({scaleX:0.1,scaleY:0.1},11,cjs.Ease.get(-1)).to({_off:true},1).wait(62));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-500.2,-319.4,1158.7,727.0999999999999);


(lib.mcMain3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_80 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 2;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(80).call(this.frame_80).wait(1));

	// _
	this.mc_3 = new lib.box3_3();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,178.45);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.mc_2 = new lib.box2_3();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,54.7);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.box_3copy();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3},{t:this.mc_3}]},80).wait(1));

	// box3
	this.instance = new lib.box3_3();
	this.instance.setTransform(566.5,178.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(59).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},8).wait(1));

	// box2
	this.instance_1 = new lib.box2_3();
	this.instance_1.setTransform(566.5,54.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(54).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},13).wait(1));

	// box
	this.instance_2 = new lib.box_3();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(49).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},18).wait(1));

	// elephant
	this.instance_3 = new lib.Elephant("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(38).to({_off:false},0).to({scaleX:1.05,scaleY:1.05,alpha:1},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(27));

	// box3
	this.instance_4 = new lib.box3_2();
	this.instance_4.setTransform(196.5,54.45);
	this.instance_4.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(8).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(55));

	// box2
	this.instance_5 = new lib.box2_2();
	this.instance_5.setTransform(196.5,178.7);
	this.instance_5.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(11).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(52));

	// box
	this.instance_6 = new lib.box_2();
	this.instance_6.setTransform(196.5,-69.05);
	this.instance_6.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(5).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(58));

	// ani
	this.instance_7 = new lib.Apple("single",0);
	this.instance_7.setTransform(-179.05,9.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(2).to({startPosition:0},0).to({scaleX:1.1,scaleY:1.1},6).to({scaleX:0.1,scaleY:0.1},11,cjs.Ease.get(-1)).to({_off:true},1).wait(61));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-485.6,-304.4,1144.1,694);


(lib.mcMain2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_73 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 3;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(73).call(this.frame_73).wait(1));

	// _
	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.mc_2 = new lib.box3_2();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,54.45);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_3 = new lib.box2_2();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,178.7);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.box_2();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_3},{t:this.mc_2},{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},73).wait(1));

	// box3
	this.instance = new lib.box3_2();
	this.instance.setTransform(566.5,54.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(56).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},4).wait(1));

	// box2
	this.instance_1 = new lib.box2_2();
	this.instance_1.setTransform(566.5,178.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(52).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},8).wait(1));

	// box
	this.instance_2 = new lib.box_2();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(47).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},13).wait(1));

	// ani
	this.instance_3 = new lib.Apple("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(36).to({_off:false},0).to({scaleX:1.05,scaleY:1.05},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(22));

	// box3
	this.instance_4 = new lib.box3();
	this.instance_4.setTransform(196.5,178.45);
	this.instance_4.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(12).to({x:186.5},6,cjs.Ease.get(1)).to({x:576.5},13,cjs.Ease.get(1)).to({_off:true},1).wait(42));

	// box2
	this.instance_5 = new lib.box2();
	this.instance_5.setTransform(196.5,54.7);
	this.instance_5.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(7).to({x:186.5},6,cjs.Ease.get(1)).to({x:576.5},13,cjs.Ease.get(1)).to({_off:true},1).wait(47));

	// box
	this.instance_6 = new lib.box();
	this.instance_6.setTransform(196.5,-69.05);
	this.instance_6.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(3).to({x:186.5},6,cjs.Ease.get(1)).to({x:576.5},13,cjs.Ease.get(1)).to({_off:true},1).wait(51));

	// ani
	this.instance_7 = new lib.Doll("synched",0);
	this.instance_7.setTransform(-179.05,9.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(2).to({mode:"single"},0).to({scaleX:1.1,scaleY:1.1},1,cjs.Ease.get(1)).to({scaleX:0.1,scaleY:0.1},13,cjs.Ease.get(1)).to({_off:true},1).wait(57));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-413.7,-165.7,1072.2,461.09999999999997);


(lib.mcMain1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;
		var objRef = this;
		var __nCorrectAnswer = 0;
		var blnLastQuestion = false;
		var blnOk = false;
		var __nScore = 0;
		var blnEnd = false;
		function init() {
			for (var i:Number = 1; objRef["mc_"+i] != null; i++) {
				objRef["mc_"+i].id = i;
				objRef["mc_" + i].addEventListener(MouseEvent.CLICK, fClickEvent);
				objRef["mc_"+i].buttonMode = true;
			}
		}
		
		function fClickEvent(e) {
			mcFish.gotoAndPlay(2);
			fRemoveListeners();
			if (e.currentTarget.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.gotoAndStop(2);
				blnOk = true;
				var mcRight = new Right();
				objRef.addChild(mcRight);
				objRef["mcTick_" + e.currentTarget.id].gotoAndStop(3);
				return;
			}
			blnOk = false;
			var mcWrong = new ShowAnswer();
			objRef.addChild(mcWrong);
			objRef["mcTick_" + e.currentTarget.id].gotoAndStop(2);
		}
		function fShowCorrectAnswer() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(2);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(3);
		}
		function fChangeQuestion() {
			if (!blnLastQuestion) {
		
			}
			fRemoveListeners();
			play();
		}
		function fRemoveListeners() {
			for (var i:Number = 1; objRef["mc_"+i] != null; i++) {
				if (!blnEnd) {
					objRef["mc_" + i].gotoAndStop(1);
				}
				objRef["mc_" + i].removeEventListener(MouseEvent.CLICK, fClickEvent);
				objRef["mc_"+i].buttonMode = false;
			}
		}*/
	}
	this.frame_47 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 2;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(47).call(this.frame_47).wait(1));

	// _
	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.mc_3 = new lib.box3();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,178.45);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_2 = new lib.box2();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,54.7);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.box();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},47).wait(1));

	// box3
	this.instance = new lib.box3();
	this.instance.setTransform(566.5,178.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(30).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},4).wait(1));

	// box2
	this.instance_1 = new lib.box2();
	this.instance_1.setTransform(566.5,54.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(26).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},8).wait(1));

	// box
	this.instance_2 = new lib.box();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(21).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},13).wait(1));

	// ani
	this.instance_3 = new lib.Doll("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(10).to({_off:false},0).to({scaleX:1.05,scaleY:1.05},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,mode:"synched"},5,cjs.Ease.get(1)).wait(22));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-285.9,-157.7,944.4,440.09999999999997);


// stage content:
(lib.Interface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
		stage.enableMouseOver(10); 
		//this.strFrame = "strFrame1"
		this.nF = 1;
		this.fLaunchProduct = function()
		{
			if(this.mcAttachMovieClip)
			{
				this.removeChild(this.mcAttachMovieClip);
			}
			this.mcAttachMovieClip = new lib["mcMain"+this.nF];
			this.mcAttachMovieClip.x = 488.1;
			this.mcAttachMovieClip.y = 295.05;	
			this.mcAttachMovieClip.gotoAndPlay(this.strFrame);
			this.addChild(this.mcAttachMovieClip);	
			if(this.nF == 1)
			{
				//this.play();
				this.fbAudio = main.playAudio('instruction');
			}
			this.nF = this.nF + 1;
		}
		//this.fLaunchProduct();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// HEADING
	this.instance = new lib.heading_("synched",0);
	this.instance.setTransform(145.65,21.25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.text01("synched",0);
	this.instance_1.setTransform(472.45,83.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// bg
	this.instance_2 = new lib.gh();
	this.instance_2.setTransform(491.9,298.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(487.2,285.6,489.8,311);
// library properties:
lib.properties = {
	id: 'ECDF1A6AC5E395468828BABD79B3D8C3',
	width: 977,
	height: 588,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Interface_atlas_1.png?1638118488657", id:"Interface_atlas_1"},
		{src:"images/Interface_atlas_2.png?1638118488658", id:"Interface_atlas_2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['ECDF1A6AC5E395468828BABD79B3D8C3'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;