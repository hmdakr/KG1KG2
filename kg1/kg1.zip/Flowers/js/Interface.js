(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Interface_atlas_1", frames: [[1297,452,150,87],[1549,278,344,82],[1661,446,166,87],[982,362,344,82],[982,446,313,87],[982,278,392,82],[982,535,122,87],[1549,362,344,82],[1106,535,161,54],[1619,190,179,43],[1961,0,67,67],[1961,69,67,67],[1961,138,67,67],[1449,452,67,67],[1449,521,67,67],[1549,446,110,177],[1919,216,124,193],[1224,0,224,219],[982,0,240,234],[982,236,935,40],[1376,278,171,172],[1619,0,186,188],[0,0,980,608],[1807,0,152,214],[1450,0,167,230],[1328,387,23,26],[2011,411,23,25],[1328,362,32,23],[1895,411,114,175]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_220 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_219 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_218 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_217 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_216 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_215 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_214 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_213 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap10 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap12 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap13 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap14 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap15 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap16 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap17 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap18 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap19 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap20 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap21 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap22 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap3 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap4 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap9 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.tulip_txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_218();
	this.instance.setTransform(-7.45,-21.65,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_217();
	this.instance_1.setTransform(-80.15,-20.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-80.1,-21.6,172,43.5);


(lib.Symbol6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#756F26").ss(0.5,1,1).p("AC5hiQAIgGALgDQAUgHAVAAQAoAAAQAQQADAEADAJQgGAAgGACQgXAHgcAfQgmAqgVgBQgWgBgbgTQgZgVgIgEQAKgJALgHQgOgBgMAIQgMAIgBAAQABgCACgDQAEgGADgFQAJgNACgDQgIAEgIAGQgJgLAAgTQAAglAygeQAWgNAhgYQAIgHAJgGQABADACAHQABAMAAAYQAAANgDAOQgGAVgNAbQgCAEgDAFAh6koQgmASgZgIQgagJgVgQQgWgRgNgFQgOgFgYABQgBgGACgGQAEgLAQgMQAZgQAbgBQARgBAMADQgFgFgEgQQgFgRAAgNQAAgPAJgTQAHgPAIgKQACAQAXAbQADADADAEQgCgOAIgQQAFgJAIgJQAEgGAHgGIAAgBQABASAOAXQAIAMAKANQAcAkAAAjQAAAKgFAPQgFAMgJAPQAEAEAEAGQASAaAPApQAbBGAFBDQAAADABACQAAACAAABAiim/QAMAMARATAjLmDQAHACAFADAh6koQgKgHgMgBQAMgKALAAQAAgUAEgLQAOAJANARAgeCgQgWCqgGC5IgWAAIgQAAQAJihANh/QALiBAMhQQAMhPgfiRQgUhGgggUAgPA2QgBADAAADQgDARgEAcAgPA2QAKgZAigpQAegmAfgWABngxQgtAkgjA3QgqBEgLAyAgRhpQAdiEAWhOQAXhQA5h3AgXBoQgEAcgDAcABznUQhYDxgqEZ");
	this.shape.setTransform(-21.3031,35.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#325F29").ss(0.5,1,1).p("AABAAQgBAAAAAA");
	this.shape_1.setTransform(6.025,-42.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#B5AB3C").ss(0.5,1,1).p("ADmneQBIg+BOABQBgACABBEQABBEgWAoQgNAVgUAdQAqADAmAMQA1ARAEAyQADAyhEAtQhFAthbAFQAVAPAVAVQBXBTAKA0QAKAzgdASQgdARgpgDQgqgEg6gcQgBgBgBAAQgCAAgBgBQg3gagjgHQgjgGgIACQAIgpALg7QAAgagJgHQgGgFgVAAQgWAAgZAFQgEAAgDABQgGgBgFgCQgdAbgYBFQgYBGAAAzABImLQgFgyAcgzQAgg3AtAAQAfAAAMAbQAHAPAIAfABsksQAAAWAEAwABsksQAAgEACgDIgDgBQAAADABAFgABImLQAjA3AAAgAC4iwQBHguA8gCQA8gDgCADAB3jNQAVgtBdghQBTgeBFAAQATAAATACAhyj5Qg/g0AAhrQAAhCAYguQAZguArAKQAsAKBKBgQAXAeAQAZABukzQAVhGBEhIQAPgQAQgNACzkwQAgg9A2gtQA2guAqgGABwhoQACgCADgCQAggZA2AAQBCAABCAxACLhCQAWgEAUAAQAoAAAnAcQAkAaALAgABWiBQgCABgBABQgJAHgNAAIgCABQAAAAAAgBQgLAAgIgHQgGgFgCgFQgBgDAAgDQAAgFACgEQACgEAFgEQAFgEAGgBQAFgCAFAAQAJAAAGADQAEABADADQADADADAEQADAFAAAFQAAAHgGAHQAQAEAKAVAA7h3QAOATgGAeAgLgsQAWgYANAAQAWgBAIATQAEAKAHAEABZiZQAUgMAgAGABMghQAIguAcgZAEYCIQABACAAABQAMAoAEAeQACAdgCAhQgEAigtgDQgugCglgdQgkgbgIglQADgHADgHQAEgLAQhTABMikQAFgoAagNAAzilQgBgkgMgKAB0HPQASgBAUACQgCAkgYAYQgZAZgQAJAgHG/QA9gvBSAcQgTAhgBACAgJH+QAjgfAxgLQATgEAWgBAB5DPQgaA/gmAyQgqA3gcAAQghAAgahEQgVg2gEhBQgBgHgBgGQAAgKAAgJQAAgHAAgHQABgcAIgbAhMmqQAJA5ArA2QAXAeAkAzAjcgCIghAAQgVADgugBQgugCgZgUQgagUABgsQACgtBtg8QBtg8BDABQAHAAAIABQACAAADAAQAzAFAcAaQANANAIAJAnwBbQABgBACgBQAJgCAWgEQAcgFAWAJQAWAJAOAYQAOAWAFATAnwBbQACAAADAAQAiAAAlAcQAiAaARAiAoFEzQgXgbgKgtQgLgtADgpQACgpAKgKQAMAJATAaQATAaAPAlAoiBiQAIgHAqAAAkphuQAagWAqgOQAqgOAfACQAfABAYAFQAXAFAQALAjcgCQAPgRALgHQAVgPA9gMQA8gMApAVQgRARgVAdQgdAogMAtQgtA5gaAcQgbAbgnAIQgmAJgRgQQgTgSAAgrQAAgrAug6QAUgZAPgPgAAgiJQgkgBgXApAAhiYQgcgPgaAN");
	this.shape_2.setTransform(0.0354,-30.6467);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#918A30").s().p("AhOHzIAAgFQAAhyAWi5IAcj9QAHhGgihgQgihggEgCIACgFIALABQASAaAQApQAbBHAFBDIAAAEIAAAEQAIgIAgiBQAhh+A5h5IACAMQhYDygrEYIgBAHIgGAtIAAgBIgIA3QgVCrgHC5gAgOAsIABgHQALgYAigpQAegnAfgWQAHgFAIgEIgKAQIgHAKQglAlgTAYQggAlgXA/IAGgtgACdgsQgSgIAAgOQAAgFAGgJIAFgIQAAgFgOAAQgLgBgDABIAHgOIgBgBQgKADgIgFQgHgEAAgIQAAgcAmgTQAlgUANgWQABAZgJAhIgRA+QAIgBAwgQQAsgOAEATQgPAHgkAgQgYAbgFAAQgSABgPgIgAjAlGQgUgIgigbQgGgEgRgBQAIgYApACQApADAWACQgBgCgQgWQgPgVAEgOQACgHgBgKQAOAhAqAJIANAAIAAgIIgFgmIASAdQAOAWABAOQABANgHAPQgOgKgMAAQgFAIgCAQQgDAPgCACIgJAFIgYAOIgGABQgIAAgOgHg");
	this.shape_3.setTransform(-21.575,36.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#837C2C").s().p("AhgIDQAJihANh/QALiBAMhQQAMhPgfiRQgUhGgggUQgKgHgMgBQAMgKALAAQAAgUAEgLQAOAJANARQgNgRgOgJQgEALAAAUQgLAAgMAKQAMABAKAHQgmASgZgIQgagJgVgQQgWgRgNgFQgOgFgYABQgBgGACgGQAEgLAQgMQAZgQAbgBQARgBAMADQgFgFgEgQQgFgRAAgNQAAgPAJgTQAHgPAIgKQACAQAXAbIAGAHQgCgOAIgQQAFgJAIgJIALgMIAAgBQABASAOAXIASAZQAcAkAAAjQAAAKgFAPQgFAMgJAPIAIAKIgMgCIgBAFQAEACAhBhQAiBggHBFIgcD9QgVC5AABzIAAAEgAkQleQASABAGAFQAiAaAUAJQAUAIAHgDIAZgNIAJgGQABgCADgPQADgQAFgIQALAAAOALQAHgQgBgNQgBgOgNgWIgTgdIAFAnIAAAHIgMAAQgqgJgOggQAAAJgCAHQgEAOAQAWQAQAVAAACQgWgCgpgDIgGAAQgkAAgHAWgAi/l+QgFgDgHgCQAHACAFADgAiFmgIgdgfIAdAfgAgXBoIAAABQAYg/AfgmQAUgWAkglIAHgLIALgQQgIAEgIAGQgJgLAAgTQAAglAygeQAWgNAhgYIARgNIADAKQABAMAAAYQAAANgDAOQgGAVgNAbQAIgGALgDQAUgHAVAAQAoAAAQAQQADAEADAJQgGAAgGACQgXAHgcAfQgmAqgVgBQgWgBgbgTQgZgVgIgEQAKgJALgHIgCAAIgBAAIAAAAIgBAAQgLAAgJAGIgBAAIgBABIgNAIIADgFIgDAFIANgIIABgBIABAAQAJgGALAAIABAAIAAAAIABAAIACAAQgLAHgKAJQgtAkgjA3QgqBEgLAyIAHg4gACFhNQAPAAAAAGIgGAIQgGAIAAAFQAAAOASAJQAPAHASAAQAFAAAYgbQAlghAPgHQgFgTgrAPQgwAPgJACIASg/QAIggAAgaQgOAWglAUQgmAUAAAbQAAAIAIAFQAHAEAKgCIABABIgHANIAIAAIAGAAgAC0hZIAFgJIgFAJgAgQhkIgBgFQAdiEAWhOQAXhQA5h3IgBAOIABATQg6B5ghB/QggCAgHAIIAAgDg");
	this.shape_4.setTransform(-21.3031,35.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#AEA639").s().p("AgBAYQgLgBgJgHQgFgEgCgGIgCgGQAAgDADgEQACgFAEgEQAGgEAGgBQAFgCAEAAQAJAAAGAEQADABADACIAHAIQADAEgBAEQAAAIgFAGIgEACQgIAIgNAAIgBAAg");
	this.shape_5.setTransform(6.15,-45.075);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FDFCF7").s().p("AAoH8QAAgZAtgGQAWgDAeABQgwAugiAAQgPAAAAgNgAAOHHQAAgOAOgHQALgGASAAIARAAQAGAAAFAFIAHAIIADADQgJgBgdAMQgZAKgKAAQgIAAAAgKgAC9DvQgZgaAAgeQAAgXAVgFQANgEAogGIAFAAQAhAzAAAtQAAAQgFAFQgFAFgSAAQghAAgagcgAAMDbQgBgRAAguQAAg0AUg6QAahIAmAAQARAAAFAKQAHAKAJAAIAGgBQgSA2gUB0QgYBlguAAQgPAAgEgtgAoWDYQgHgcABgnQAIAJAHADQAHADAJAQQAOAbAAASQAAAZgNAAQgRAAgJgigAhADDQgCgOAAgrQAAg8AVg1QAXg3AeAAQAHAAAFAGIABABQgOAPgMAgQgNAhgHAtQgBABgCA/QgDA/gMAAQgRAAgEgigAngCaQgWgVAAgOQAAgGAIgGQAIgFAIAAQAEAAALAJQAJAHAEAEQAHAJAAAcIgBANIgEAQQgEgJgcgZgAGMCAQhMgPgkgOQhTgfAAgyQAAgMAHgIQAHgIAJAAQAFAAAjAdQAjAdAZAAIAPAAQgYhJgygkIgtghQAAgGALgEQALgDAKAAQApAABLBFQBPBIAAA5QAAAXgNAHQgJAHgbAAIgCAAgAjrBtQgDgKAAgMQAAg2AtgeQAogZA9AAQAEAAAHACIABABQgiAvgXAeQgxA+glAAQgHAAgFgLgAksg5QgKgBAAgIQAAgVBLgXQBKgWA9AAIARAAQAGAGAAAIQAAAbhLASQg+AQg/AAIgOAAIgJAAgAEviLQhBgMgIgSQAKgLAGgEIAEgDIATgGIABAAQAegJAdgHIAzgHQAkgEAIgDIAAgKQgRgHgLgDQgLgEgVgEQgWgDgeAGIg5ALIgbAAQgpgEAfgPQATgJBDgPQA6gOA2AAQAkgFAsARQAtASAAAXQAAAxgyAhQgsAdgwAAQgtAAgzgJgAkbidIAAgIQBChFBmAAQAeAAARAeQAZAqACACQgYgQgVgCIgggCIgDAAQgxABgbACQgxAFgbAPgAhLkWQgigPgGgFQgigWAAhPQAAgZALgRQAJgQANAAQAQAAAOA5IASBHQAFAJASATIAZAcQALARAFATIAEASQgrgtgggOgAgLlKQgvgwAAgzQAAgVAJgMQAKgPATAJQASAIAUAyQAWAxAJAgQAJAggBAGIgDARQgqgggXgYgAE2mSQBEg5AiAAQAOAAAHANQAFAJAAALQAABBhgAXQhNAKgnAIQAfgnA1grgAC9mOQARglAhghQAqgpAoAAQAVAAAJAHIAOALIgIAAQgsAFg2AtQg0AygSANgABkmnQAAgYANggQASgpAbAAQAOAAAIASIAOAaIAAABQgJAHgeAlQgfAmgMAAQgMAAAAgeg");
	this.shape_6.setTransform(0.0188,-30.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F9F4E1").s().p("AAgIeQgVAAgUAHQgLADgHAGQANgbAFgVQAjgfAxgLQATgEAWgBQASgBAUACQgCAkgYAYQgZAZgQAJQgQgQgnAAgABVHiQgtAGAAAZQAAANAPAAQAiAAAwguIgIAAQgZAAgTACgAgFHjQAAgYgCgMQA9gvBSAcIgUAjQgWABgTAEQgxALgjAfQAEgOAAgNgAAcG3QgOAHAAAOQAAAKAIAAQAKAAAZgKQAdgMAJABIgDgDIgHgIQgFgFgGAAIgRAAQgSAAgLAGgAhIEzQgVg2gEhBIgCgNIAAgTIAAgOQABgcAIgbQAMgtAdgoQAVgdARgRQgagNghAAIgBAAIAAAAQgSAAgUAEIgDAAQg9AMgVAPQgLAHgPARQAPgRALgHQAVgPA9gMIADAAQAUgEASAAIAAAAIABAAQAhAAAaANQgRARgVAdQgdAogMAtQgtA5gaAcQgbAbgnAIQgmAJgRgQQgTgSAAgrQAAgrAug6QAUgZAPgPIghAAQgVADgugBQgugCgZgUQgagUABgsQACgtBtg8QBtg8BDABIAPABQg/g0AAhrQAAhCAYguQAZguArAKQAsAKBKBgQAXAeAQAZQAjA3AAAgQAAgggjg3QgFgyAcgzQAgg3AtAAQAfAAAMAbQAHAPAIAfQBIg+BOABQBgACABBEQABBEgWAoQgNAVgUAdQAqADAmAMQA1ARAEAyQADAyhEAtQhFAthbAFQAVAPAVAVQBXBTAKA0QAKAzgdASQgdARgpgDQgqgEg6gcIgCgBIgDgBIABADQAMAoAEAeQACAdgCAhQgEAigtgDQgugCglgdQgkgbgIglIAGgOQAEgLAQhTIAAAAIAHAAIAAAAIAIAAIAAAAIACAAIADABIAAAAIAKABIABAAIAFABIAFABIACAAQAjAHA3AaQg3gagjgHIgCAAIgFgBIgFgBIgBAAIgKgBIAAAAIgDgBIgCAAIAAAAIgIAAIAAAAIgHAAIAAAAIAThkQAAgagJgHQgGgFgVAAQgWAAgZAFIgHABQAIguAcgZIAFgEQAggZA2AAQBCAABCAxQhCgxhCAAQg2AAggAZIgFAEQgKgVgQgEQAGgHAAgHQAAgFgDgFIgGgHQgDgDgEgBQAFgoAagNQgaANgFAoQgGgDgJAAQgFAAgFACQgBgkgMgKQAMAKABAkQgGABgFAEQgFAEgCAEIAAAAIgBAAIAAAAQgPgIgNAAIgBAAIgBAAQgLAAgMAGQAMgGALAAIABAAIABAAQANAAAPAIIAAAAIABAAIAAAAQgCAEAAAFIABAGQACAFAGAFQAIAHALAAIAAABIACgBQANAAAJgHIADgCQAQAEAKAVQgcAZgIAuQgGgBgFgCQAFACAGABIAHgBQAZgFAWAAQAVAAAGAFQAJAHAAAaIgTBkQgQBTgEALIgGAOQgaA/gmAyQgqA3gcAAQghAAgahEgAC5CgQgVAFAAAXQAAAeAZAaQAaAcAhAAQASAAAFgFQAFgFAAgQQAAgtghgzIgFAAQgoAGgNAEgAAfAzQgUA6AAA0QAAAuABARQAEAtAPAAQAuAAAYhlQAUh0ASg2IgGABQgJAAgHgKQgFgKgRAAQgmAAgaBIgAgtAeQgVA1AAA8QAAArACAOQAEAiARAAQAMAAADg/QACg/ABgBQAHgtANghQAMggAOgPIgBgBQgFgGgHAAQgeAAgXA3gAAMA8QgYBGAAAzQAAgzAYhGQAYhFAdgbQgdAbgYBFgADQACQgHAJAAAMQAAAyBTAfQAkAOBMAPIACAAQAbAAAJgHQANgHAAgXQAAg5hPhIQhLhFgpAAQgKAAgLADQgLAEAAAGIAtAhQAyAkAYBJIgPAAQgZAAgjgdQgjgdgFAAQgJAAgHAHgAjBAIQgtAeAAA2QAAAMADAKQAFALAHAAQAlAAAxg+QAXgeAigvIgBgBQgHgCgEAAQg9AAgoAZgAEEgqQAkAaALAgQgLgggkgaQgngcgoAAQgUAAgWAEQAWgEAUAAQAoAAAnAcgAA2gyQAEAKAHAEQgHgEgEgKIAAAAIAAgBIgBgBIAAAAQgIgQgTAAIAAAAIAAAAIgBAAIgBAAQgNAAgWAYQAWgYANAAIABAAIABAAIAAAAIAAAAQATAAAIAQIAAAAIABABIAAABIAAAAgAjrhpQhLAXAAAVQAAAIAKABQAGABARgBQA/AAA+gQQBLgSAAgbQAAgIgGgGIgRAAQg9AAhKAWgABDhGQABgJAAgIQABgSgKgOQAKAOgBASQAAAIgBAJgAgbhhIAAgBIABgBIAAAAQAXgmAhAAIABAAIABAAIgBAAIgBAAQghAAgXAmIAAAAIgBABIAAABgAjliSQgqAOgaAWQAagWAqgOIAEgBIADgBIAAAAQAhgKAaAAIABAAIAAAAIADAAIADAAQAfABAYAFQAXAFAQALQgQgLgXgFQgYgFgfgBIgDAAIgDAAIAAAAIgBAAQgaAAghAKIAAAAIgDABIgEABIAAAAgAFsj2QAVAEALAEQALADARAHIAAAKQgIADgkAEIgzAHQgdAHgeAJIgBAAIgTAGIgEADQgGAEgKALQAIASBBAMQAzAJAtAAQAwAAAsgdQAyghAAgxQAAgXgtgSQgsgRgkAFQg2AAg6AOQhDAPgTAJQgfAPApAEIAbAAIA5gLQATgEAQAAIARABgAkbigIAAAIIAKAAQAbgPAxgFQAbgCAxgBIADAAIAgACQAVACAYAQQgCgCgZgqQgRgegeAAQhmAAhCBFgABZiZIABAAQANgIASAAIAAAAIAAAAQAJAAALACQgLgCgJAAIAAAAIAAAAQgSAAgNAIIgBAAgAE7jgQg8AChHAuQBHguA8gCQA6gCAAACIAAAAIAAAAQAAgBgNAAIgtABgAhtj5QAzAFAcAaIAVAWIgVgWQgcgagzgFIgFAAIAFAAgADpkbQhdAhgVAtQAVgtBdghQBTgeBFAAQATAAATACQgTgCgTAAQhFAAhTAegAiKm0QgLARAAAZQAABPAiAWQAGAFAiAPQAgAOArAtIgEgSQgFgTgLgRIgZgcQgSgTgFgJIgShHQgOg5gQAAQgNAAgJAQgABsksQAAAWAEAwQgEgwAAgWQAAgEACgDIgDgBIABAIgAgYk7QAXAeAkAzQgkgzgXgeQgrg2gJg5QAJA5ArA2gAgxnJQgJAMAAAVQAAAzAvAwQAXAYAqAgIADgRQABgGgJggQgJgggWgxQgUgygSgIQgHgDgGAAQgKAAgGAJgAEJmaQg2AtggA9QAgg9A2gtQA2guAqgGQgqAGg2AugADHnBQhEBIgVBGQAVhGBEhIQAPgQAQgNQgQANgPAQgAE2mNQg1ArgfAnQAngIBNgKQBggXAAhBQAAgLgFgJQgHgNgOAAQgiAAhEA5gADvnPQghAhgRAlIAAAUQASgNA0gyQA2gtAsgFIAIAAIgOgLQgJgHgVAAQgoAAgqApgABxnaQgNAgAAAYQAAAeAMAAQAMAAAfgmQAeglAJgHIAAgBIgOgaQgIgSgOAAQgbAAgSApgAomDrQgLgtADgpQACgpAKgKQAIgHAqAAIAFAAIgCgCQAJgCAWgEQAcgFAWAJQAWAJAOAYQAOAWAFATQgIAJgEAJQgRgigigaQglgcgiAAQAiAAAlAcQAiAaARAiQgJAQADAOIgGgHQgYgbgCgQQgHAKgHAPQgJATAAAPQAAANAEARQAFAQAEAFQgLgDgRABQgcABgYAQQgQAMgEALQgXgbgKgtgAoWDdQAJAiARAAQANAAAAgZQAAgSgOgbQgJgQgHgDQgHgDgIgJQgBAnAHAcgAoDCFQATAaAPAlQgPglgTgaQgTgagMgJQAMAJATAagAnuBwQgIAGAAAGQAAAOAWAVQAcAZAEAJIAEgQIABgNQAAgcgHgJQgEgEgJgHQgLgJgEAAQgIAAgIAFgAlxCzIAAAAgABMghIAAAAgABWiBIAAAAgAAzilIAAAAg");
	this.shape_7.setTransform(0.0354,-30.6467);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol6, new cjs.Rectangle(-56.9,-87.5,113.9,175.1), null);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* stop();
		this.blnPlay = false;*/
	}
	this.frame_1 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_135 = function() {
		/* MovieClip(parent).fChangeQuestion();
		this.blnPlay = false;
		gotoAndStop(1);*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(134).call(this.frame_135).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.sun_txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_216();
	this.instance.setTransform(-69.55,-21.65,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_215();
	this.instance_1.setTransform(-80.15,-20.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-80.1,-21.6,196,43.5);


(lib.rose_txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_220();
	this.instance.setTransform(-18.85,-21.65,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_219();
	this.instance_1.setTransform(-85.85,-20.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-85.8,-21.6,172,43.5);


(lib.right_wrong = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// _
	this.instance = new lib.Bitmap5();
	this.instance.setTransform(-13,-11);

	this.instance_1 = new lib.Bitmap6();
	this.instance_1.setTransform(-13,-11);

	this.instance_2 = new lib.Bitmap7();
	this.instance_2.setTransform(-16,-9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16,-11,32,26);


(lib.lily_txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_214();
	this.instance.setTransform(-18.85,-21.65,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_213();
	this.instance_1.setTransform(-85.85,-20.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-85.8,-21.6,172,43.5);


(lib.jasmine_txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap10();
	this.instance.setTransform(-81,-22);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-81,-22,179,43);


(lib.heading01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap2();
	this.instance.setTransform(-434,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-434,-23,935,40);


(lib.heading_ = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap1();
	this.instance.setTransform(-147,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-147,-28,161,54);


(lib.gh = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap22();
	this.instance.setTransform(-492,-307);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gh, new cjs.Rectangle(-492,-307,980,608), null);


(lib.btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("EgjAAHeIAAu7MBGBAAAIAAO7g");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-224.1,-47.8,448.2,95.6), null);


(lib.tulip = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.5,-3.2,0.5331,2.3091,0,0,0,-0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_1
	this.instance = new lib.Bitmap18();
	this.instance.setTransform(-112,-109);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-118,-115);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-118.9,-115,240.9,234);


(lib.sun = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-14,-3,0.3123,2.3091,0,0,0,-0.3,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_1
	this.instance = new lib.Bitmap16();
	this.instance.setTransform(-67,-97);

	this.instance_1 = new lib.Bitmap17();
	this.instance_1.setTransform(-73,-103);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-83.9,-113.9,140,220.8);


(lib.rose = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-14,-3,0.3123,2.3091,0,0,0,-0.3,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_1
	this.instance = new lib.Bitmap3();
	this.instance.setTransform(-76,-107);

	this.instance_1 = new lib.Bitmap4();
	this.instance_1.setTransform(-82,-113);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-83.9,-113.9,168.9,230.9);


(lib.lily = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.45,-10.85,0.3767,2.1522,0,0,0,-0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_1
	this.instance = new lib.Bitmap20();
	this.instance.setTransform(-86,-86);

	this.instance_1 = new lib.Bitmap21();
	this.instance_1.setTransform(-92,-92);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-92,-114,186,210);


(lib.jas = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(6,-3,0.3123,2.3091,0,0,0,-0.3,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_1
	this.instance = new lib.Bitmap9();
	this.instance.setTransform(-57,-88);

	this.instance_1 = new lib.Symbol6();
	this.instance_1.shadow = new cjs.Shadow("rgba(128,121,41,1)",0,0,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-67.2,-113.9,143.3,220.8);


(lib.aud5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(33.45,33.55,0.1494,0.7007,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap15();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aud5, new cjs.Rectangle(0,-0.1,67,67.1), null);


(lib.aud4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(33.45,33.55,0.1494,0.7007,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap14();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aud4, new cjs.Rectangle(0,-0.1,67,67.1), null);


(lib.aud3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(33.45,33.55,0.1494,0.7007,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap13();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aud3, new cjs.Rectangle(0,-0.1,67,67.1), null);


(lib.aud2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(33.45,33.55,0.1494,0.7007,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// _
	this.instance = new lib.Bitmap12();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aud2, new cjs.Rectangle(0,-0.1,67,67.1), null);


(lib.aud = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(33.45,33.55,0.1494,0.7007,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// _
	this.instance = new lib.Bitmap11();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aud, new cjs.Rectangle(0,-0.1,67,67.1), null);


(lib.mcMain1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_152 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nAudioUsed = 0;
		var __nCount = 0;
		var mcPreviousAudio = undefined;
		var __nButtonPush = 0;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_" + i].id = i;
				objRef["mc_" + i].str = "Audio";		
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fPressFunction.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
			for (var k = 1; objRef["mcA_" + k] != undefined; k++) {
				objRef["mcA_" + k].id = k;		
				objRef["mcA_" + k].btn.addEventListener("mousedown", objRef["mcA_" + k].listener = this.fPressFunction.bind(this));
				objRef["mcA_" + k].btn.cursor = "pointer";		
			}
		}
		this.fSetInteraction = function(str, b) {
			for (var i = 1; objRef[str + i] != undefined; i++) {
				objRef[str + i].btn.mouseEnabled = b;
			}
		}
		this.fPressFunction = function(e) {
			if (e.currentTarget.parent.str == "Audio") {
				//fSetInteraction("mc_", false);
				if (mcPreviousAudio != undefined) {
					mcPreviousAudio.gotoAndStop(0);
				}
				__nAudioUsed = e.currentTarget.parent.id;
				//e.currentTarget.parent.play();
				this.fbAudio = main.playAudio('audio'+__nAudioUsed);
				//audioCode-----
				mcPreviousAudio = e.currentTarget.parent;
				this.fSetInteraction("mcA_", true);
				return;
			}
			this.fSetInteraction("mcA_", false);
			//mcFish.gotoAndPlay(2);
			this.fCheckAnswer(e.currentTarget.parent.id);
		}
		this.fCheckAnswer = function(n) {
			this.fSetInteraction("mc_", false);
			mcPreviousAudio.gotoAndStop(0);
			__nCount++;
			__nButtonPush = __nButtonPush + 1;
			if (n == __nAudioUsed) {
				//this.fSetInteraction("mcA_", true);
				objRef["mc_" + __nAudioUsed].btn.removeEventListener("mousedown", objRef["mc_" + __nAudioUsed].listener, false);
				objRef["mc_" + __nAudioUsed].btn.cursor = null;		
				objRef["mc_" + __nAudioUsed].alpha = .5;
				//objRef["mc_" + __nAudioUsed].removeEventListener(MouseEvent.MOUSE_DOWN, fPressFunction);
				//objRef["mc_" + __nAudioUsed].buttonMode = false;		
				//objRef["mcA_" + __nAudioUsed].removeEventListener(MouseEvent.MOUSE_DOWN, fPressFunction);
				//objRef["mcA_" + __nAudioUsed].buttonMode = false;
				objRef["mcA_" + __nAudioUsed].btn.removeEventListener("mousedown", objRef["mcA_" + __nAudioUsed].listener, false);
				objRef["mcA_" + __nAudioUsed].btn.cursor = null;		
				objRef["mcA_" + __nAudioUsed].gotoAndStop(1);
				__nScore++;
				//var mcRight = new Right();
				//objRef.addChild(mcRight);
				objRef["mcTick_" + n].gotoAndStop(2);
				var nRandom = Math.floor(Math.random()*3);
				nRandom = nRandom + 1;		
				this.fbAudio = main.playAudio('right'+nRandom);		
				this.fbAudio.addEventListener('complete', this.strAudEnt = function()
				{ 
					this.fChangeQuestion();
					this.fbAudio.removeEventListener('complete', this.strAudEnt);			
				}.bind(this));				
				return;
			}
			//var mcWrong = new ShowAnswer();
			//objRef.addChild(mcWrong);
			objRef["mcTick_" + n].gotoAndStop(1);
			
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.strAudEnt = function()
			{ 
				//this.fChangeQuestion();
				this.fShowCorrectAnswer();
				this.fbAudio.removeEventListener('complete', this.strAudEnt);			
			}.bind(this));	
		}
		
		this.fShowCorrectAnswer = function() {	
			objRef["mc_" + __nAudioUsed].btn.removeEventListener("mousedown", objRef["mc_" + __nAudioUsed].listener, false);
			objRef["mc_" + __nAudioUsed].btn.cursor = null;
			objRef["mc_" + __nAudioUsed].alpha = .5;
			objRef["mcA_" + __nAudioUsed].btn.removeEventListener("mousedown", objRef["mcA_" + __nAudioUsed].listener, false);
			objRef["mcA_" + __nAudioUsed].btn.cursor = null;
			objRef["mcA_" + __nAudioUsed].gotoAndStop(1);
			objRef["mcTick_" + __nAudioUsed].gotoAndStop(2);
			this.fbAudio = main.playAudio('showAnswer');
			/*this.fbAudio.addEventListener('complete', this.strAudEnt = function()
			{ 
				this.fChangeQuestion();
				this.fbAudio.removeEventListener('complete', this.strAudEnt);			
			}.bind(this));*/
			setTimeout(function(){objRef.fChangeQuestion();}.bind(this), 3000);
		}
		this.fChangeQuestion = function() {
			console.log(__nCount + "-----------__nCount");
			if (__nCount > 4) {
				//MovieClip(parent.parent.parent).mcFinal.gotoAndPlay(2);
				this.fCalculateScore();
				return;
			}
			for (var i = 1; objRef["mcTick_" + i] != undefined; i++) {
				if (objRef["mcTick_" + i].currentFrame == 1) {
					objRef["mcTick_" + i].gotoAndStop(0);
				}
			}
			mcPreviousAudio = undefined;
			this.fSetInteraction("mc_", true);
			this.fSetInteraction("mcA_", false);
		}
		this.init();
		this.fSetInteraction("mcA_", false);
		
		this.fCalculateScore = function() {
			var nP = Math.floor((__nScore/__nCount)*100);
			//alert("----finalScreen---");
			main.showRestartBtn();
			/*trace(__nScore + "---------------------"+__nCount+"---------"+nP);
			if (nP < 70) {
				MovieClip(parent.parent.parent).mcFinal.mcRank.gotoAndPlay("rank2");
			} else {
				MovieClip(parent.parent.parent).mcFinal.mcRank.gotoAndPlay("rank1_1");
			}*/
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(152).call(this.frame_152).wait(1));

	// Layer_2
	this.mcFish = new lib.Symbol2();
	this.mcFish.name = "mcFish";
	this.mcFish.setTransform(-516.5,-260);

	this.timeline.addTween(cjs.Tween.get(this.mcFish).wait(153));

	// _
	this.mc_1 = new lib.aud();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(418.1,-127.7,1,1,0,0,0,33.6,33.6);

	this.mc_2 = new lib.aud2();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(418.1,-47.1,1,1,0,0,0,33.6,33.6);

	this.mc_3 = new lib.aud3();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(418.1,33.5,1,1,0,0,0,33.6,33.6);

	this.mc_4 = new lib.aud4();
	this.mc_4.name = "mc_4";
	this.mc_4.setTransform(418.1,114.1,1,1,0,0,0,33.6,33.6);

	this.mc_5 = new lib.aud5();
	this.mc_5.name = "mc_5";
	this.mc_5.setTransform(418.1,194.75,1,1,0,0,0,33.6,33.6);

	this.mcTick_4 = new lib.right_wrong();
	this.mcTick_4.name = "mcTick_4";
	this.mcTick_4.setTransform(284.05,211.85,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(-106.05,228.75,1.728,1.728);

	this.mcTick_5 = new lib.right_wrong();
	this.mcTick_5.name = "mcTick_5";
	this.mcTick_5.setTransform(57.45,137.8,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-399.65,23.2,1.728,1.728);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(194.4,-11.95,1.728,1.728);

	this.mcA_3 = new lib.jas();
	this.mcA_3.name = "mcA_3";
	this.mcA_3.setTransform(253.7,-73.15);

	this.mcA_4 = new lib.sun();
	this.mcA_4.name = "mcA_4";
	this.mcA_4.setTransform(251.2,159.2);

	this.mcA_5 = new lib.tulip();
	this.mcA_5.name = "mcA_5";
	this.mcA_5.setTransform(-32.6,60.45);

	this.mcA_2 = new lib.lily();
	this.mcA_2.name = "mcA_2";
	this.mcA_2.setTransform(-329.35,179.75);

	this.mcA_1 = new lib.rose();
	this.mcA_1.name = "mcA_1";
	this.mcA_1.setTransform(-315.75,-53.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcA_1},{t:this.mcA_2},{t:this.mcA_5},{t:this.mcA_4},{t:this.mcA_3},{t:this.mcTick_3},{t:this.mcTick_1},{t:this.mcTick_5},{t:this.mcTick_2},{t:this.mcTick_4},{t:this.mc_5},{t:this.mc_4},{t:this.mc_3},{t:this.mc_2},{t:this.mc_1}]},152).wait(1));

	// mc_1
	this.instance = new lib.aud();
	this.instance.setTransform(418.1,437.8,1,1,0,0,0,33.6,33.6);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(111).to({_off:false},0).to({y:-127.7},16,cjs.Ease.get(1)).to({_off:true},25).wait(1));

	// mc_2
	this.instance_1 = new lib.aud2();
	this.instance_1.setTransform(418.1,518.4,1,1,0,0,0,33.6,33.6);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(113).to({_off:false},0).to({y:-47.1},16,cjs.Ease.get(1)).to({_off:true},23).wait(1));

	// mc_3
	this.instance_2 = new lib.aud3();
	this.instance_2.setTransform(418.1,599,1,1,0,0,0,33.6,33.6);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(116).to({_off:false},0).to({y:33.5},16,cjs.Ease.get(1)).to({_off:true},20).wait(1));

	// mc_4
	this.instance_3 = new lib.aud4();
	this.instance_3.setTransform(418.1,679.6,1,1,0,0,0,33.6,33.6);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(119).to({_off:false},0).to({y:114.1},16,cjs.Ease.get(1)).to({_off:true},17).wait(1));

	// mc_5
	this.instance_4 = new lib.aud5();
	this.instance_4.setTransform(418.1,760.25,1,1,0,0,0,33.6,33.6);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(122).to({_off:false},0).to({y:194.75},16,cjs.Ease.get(1)).to({_off:true},14).wait(1));

	// jas
	this.instance_5 = new lib.jas();
	this.instance_5.setTransform(253.7,-73.15,0.1,0.1);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(55).to({_off:false},0).to({scaleX:1,scaleY:1},13,cjs.Ease.get(1)).to({_off:true},84).wait(1));

	// Layer_11 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_68 = new cjs.Graphics().p("ArrDcIA4m3IWfAAIAAG3g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(68).to({graphics:mask_graphics_68,x:298.35,y:-9.2}).wait(85));

	// Layer_12
	this.instance_6 = new lib.jasmine_txt("synched",0);
	this.instance_6.setTransform(126.05,-8.25);
	this.instance_6._off = true;

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(68).to({_off:false},0).to({x:270.05},11,cjs.Ease.get(1)).wait(74));

	// sun
	this.instance_7 = new lib.sun();
	this.instance_7.setTransform(251.2,159.2,0.1,0.1);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(59).to({_off:false},0).to({scaleX:1,scaleY:1},13,cjs.Ease.get(1)).to({_off:true},80).wait(1));

	// Layer_14 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_72 = new cjs.Graphics().p("AuIDqIAAnTIbZAAQAkCCAUFRg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(72).to({graphics:mask_1_graphics_72,x:159.575,y:211.8}).wait(81));

	// Layer_15
	this.instance_8 = new lib.sun_txt("synched",0);
	this.instance_8.setTransform(331.65,212.55);
	this.instance_8._off = true;

	var maskedShapeInstanceList = [this.instance_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(72).to({_off:false},0).to({x:151.65},11,cjs.Ease.get(1)).wait(70));

	// tulip
	this.instance_9 = new lib.tulip();
	this.instance_9.setTransform(-32.6,60.45,0.1,0.1);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(49).to({_off:false},0).to({scaleX:1,scaleY:1},13,cjs.Ease.get(1)).to({_off:true},90).wait(1));

	// Layer_17 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_62 = new cjs.Graphics().p("AtUDmIKnnLIQCAAIAAHLg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(62).to({graphics:mask_2_graphics_62,x:-53.45,y:140.975}).wait(91));

	// Layer_18
	this.instance_10 = new lib.tulip_txt("synched",0);
	this.instance_10.setTransform(-217.9,140.9);
	this.instance_10._off = true;

	var maskedShapeInstanceList = [this.instance_10];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(62).to({_off:false},0).to({x:-66.25},11,cjs.Ease.get(1)).wait(80));

	// lily
	this.instance_11 = new lib.lily();
	this.instance_11.setTransform(-329.35,179.75,0.1,0.1);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(52).to({_off:false},0).to({scaleX:1,scaleY:1},13,cjs.Ease.get(1)).to({_off:true},87).wait(1));

	// Layer_20 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_65 = new cjs.Graphics().p("AlyDhQgbg9hJAMQhdAPgXAAQgXABgZgDQgZgDgcgQIgFgCQgXgOgLgRIgLgSIgDgJIgBgCIAAgBIgDgJQgFgXgOgUIgHgKIgMgWIgCgHQgJgYARgTQAPgSAPgDQAPgDASAEQAMACARAJQANAGAPAKIBEApQAdASAjAAQANAAAWgDQAogIAVgEIAAAAQBCgUAgANQAgAMAGABQAGAAABgDQAFgQgOgLQgOgMgVgHQgVgHgZgBIg7gDQgigDgigTQghgTgrgtQgZgagTgNQgQgLgLgCQgcgHgXADQgWACgMAEQgLADgNAHIgcANQgNAIgPAPQgEgTgIgRQgPgjgdghIbNAAIAAHBg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(65).to({graphics:mask_3_graphics_65,x:-216.175,y:230.9}).wait(88));

	// Layer_21
	this.instance_12 = new lib.lily_txt("synched",0);
	this.instance_12.setTransform(-385.5,231.85);
	this.instance_12._off = true;

	var maskedShapeInstanceList = [this.instance_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(65).to({_off:false},0).to({x:-223.5},10,cjs.Ease.get(1)).wait(78));

	// rose
	this.instance_13 = new lib.rose();
	this.instance_13.setTransform(-315.75,-53.65,0.1,0.1);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(46).to({_off:false},0).to({scaleX:1,scaleY:1},13,cjs.Ease.get(1)).to({_off:true},93).wait(1));

	// Layer_23 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_59 = new cjs.Graphics().p("AtXDiQBihKBfiFQBIhkBNiQIVZAAIAAHDg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(59).to({graphics:mask_4_graphics_59,x:-263.525,y:27.85}).wait(94));

	// Layer_24
	this.instance_14 = new lib.rose_txt("synched",0);
	this.instance_14.setTransform(-425.55,27.8);
	this.instance_14._off = true;

	var maskedShapeInstanceList = [this.instance_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(59).to({_off:false},0).to({x:-275.55},10,cjs.Ease.get(1)).wait(84));

	// HEADING
	this.instance_15 = new lib.heading_("synched",0);
	this.instance_15.setTransform(-672.85,-272.75);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(4).to({_off:false},0).to({x:-342.85},11,cjs.Ease.get(1)).wait(138));

	// heading01
	this.instance_16 = new lib.heading01("single",0);
	this.instance_16.setTransform(835.45,-216.15);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(12).to({_off:false},0).to({x:-44.55},12,cjs.Ease.get(1)).to({x:-34.55,mode:"synched"},5,cjs.Ease.get(1)).wait(124));

	// bg
	this.instance_17 = new lib.gh();
	this.instance_17.setTransform(3.4,4.1);
	this.instance_17.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).to({alpha:1},12).wait(141));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-819.8,-302.9,2156.3,1096.6);


// stage content:
(lib.Interface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
		stage.enableMouseOver(10); 
		this.strFrame = "strFrame1"
		this.nF = 1;
		this.fLaunchProduct = function()
		{
			if(this.mcAttachMovieClip)
			{
				this.removeChild(this.mcAttachMovieClip);
			}
			this.mcAttachMovieClip = new lib["mcMain"+this.nF];
			this.mcAttachMovieClip.x = 488.1;
			this.mcAttachMovieClip.y = 295.05;	
			this.mcAttachMovieClip.gotoAndPlay(this.strFrame);
			this.addChild(this.mcAttachMovieClip);
			this.fbAudio = main.playAudio('instruction');
			//this.nF = this.nF + 1;
		}
		//this.fLaunchProduct();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);
// library properties:
lib.properties = {
	id: 'ECDF1A6AC5E395468828BABD79B3D8C3',
	width: 977,
	height: 588,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Interface_atlas_1.png?1638118451096", id:"Interface_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['ECDF1A6AC5E395468828BABD79B3D8C3'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;