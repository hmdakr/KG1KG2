(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Interface_atlas_1", frames: [[0,0,1954,1210],[0,1212,1203,223],[0,1437,873,223],[1205,1212,301,285],[1508,1429,112,117],[1508,1212,173,215],[1154,1499,112,117],[1268,1499,112,117],[342,1781,112,116],[456,1781,112,116],[1382,1499,112,117],[1622,1460,112,117],[1736,1460,112,117],[875,1437,277,204],[1752,1579,112,117],[1850,1460,112,117],[570,1781,112,116],[684,1781,112,116],[1866,1579,112,117],[0,1662,112,117],[1683,1212,157,190],[875,1643,875,48],[114,1662,112,117],[1683,1404,310,54],[228,1662,112,117],[342,1662,112,117],[912,1693,112,116],[1026,1693,112,116],[456,1662,112,117],[570,1662,112,117],[1643,1693,27,101],[1870,1322,15,71],[1964,1460,67,106],[1154,1437,46,51],[1596,1693,45,112],[1842,1212,134,108],[1496,1594,25,31],[1842,1322,26,76],[1672,1693,26,96],[684,1662,112,117],[798,1693,112,117],[1140,1693,112,116],[1254,1693,112,116],[0,1781,112,117],[1561,1548,44,48],[114,1781,112,117],[1496,1548,63,44],[1368,1693,112,116],[1482,1693,112,116],[228,1781,112,117]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_239 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_238 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_237 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap10 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap12 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap13 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap14 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap15 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap16 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap19 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap20 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap21 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap22 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap23 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap24 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap25 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap26 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap28 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap29 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap3 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap30 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap31 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap32 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap33 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap34 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap35 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap36 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap37 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap38 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap39 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap4 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap40 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap41 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap42 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap43 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap44 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap45 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap46 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap47 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap48 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap49 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap50 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap8 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap9 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.vbncbvc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgOAvIAAAAIgHgJQgKgPAAgWIAAgBQAAgVAKgPIAAAAQAJgQAMAAQANAAAJAQIABAAQAJAPAAAVQAAAWgJAQQgKAPgNAAQgIAAgGgGg");
	mask.setTransform(0,-0.025);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(0.5,1,1).p("AAtA0QgqgXgvAXIAAhnIBZAAg");
	this.shape.setTransform(0.075,-10.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EE9F2B").s().p("AgsAzIAAhlIBZAAIAABlQgqgWgvAWg");
	this.shape_1.setTransform(0.075,-10.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#333333").ss(0.5,1,1).p("AgsgzIBZAAIAABnQgrgJguAJg");
	this.shape_2.setTransform(0.075,-7.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EE9F2B").s().p("AgsAzIAAhmIBZAAIAABmQgrgIguAIg");
	this.shape_3.setTransform(0.075,-7.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#333333").ss(0.5,1,1).p("Agsg0IBZAAIAABmQgsAGgtgGg");
	this.shape_4.setTransform(0.075,-5.4125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EE9F2B").s().p("AgsAyIAAhmIBZAAIAABmQgWADgWAAQgWAAgXgDg");
	this.shape_5.setTransform(0.075,-5.4125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#333333").ss(0.5,1,1).p("Agsg3IBZAAIAABmQgtATgsgTg");
	this.shape_6.setTransform(0.075,-2.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#EE9F2B").s().p("AgsAvIAAhmIBZAAIAABmQgWAJgXAAQgVAAgXgJg");
	this.shape_7.setTransform(0.075,-2.725);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#333333").ss(0.5,1,1).p("AgsArIAAhmIBZAAIAABmQgtAhgsghg");
	this.shape_8.setTransform(0.075,-0.0298);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#EE9F2B").s().p("AgsArIAAhmIBZAAIAABmQgXARgWAAQgWAAgWgRg");
	this.shape_9.setTransform(0.075,-0.0298);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#333333").ss(0.5,1,1).p("Agsg7IBZAAIAABmQgtAhgsghg");
	this.shape_10.setTransform(0.075,-0.025);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},14).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).to({state:[{t:this.shape_7},{t:this.shape_6}]},1).to({state:[{t:this.shape_9,p:{y:-0.0298}},{t:this.shape_8}]},1).to({state:[{t:this.shape_9,p:{y:-0.025}},{t:this.shape_10}]},1).to({state:[{t:this.shape_9,p:{y:-0.025}},{t:this.shape_10}]},1).to({state:[{t:this.shape_9,p:{y:-0.0298}},{t:this.shape_8}]},1).to({state:[{t:this.shape_7},{t:this.shape_6}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_1},{t:this.shape}]},1).to({state:[]},1).wait(75));

	// Layer_1
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgNARIgCgFQAAAAABAAQAAAAABAAQAAAAABgBQAAAAABAAQALgLgPgGQgBgFADgEQAGgIAHAAQAGAAAGAIQAFAHAAAIQAAAJgFAIQgGAGgGAAQgHAAgGgGg");
	this.shape_11.setTransform(1.3476,-0.6792,1.1912,1.1912,-4.7962);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#C57C10").ss(0.5,1,1).p("AAAg2QgOAAgKAQQgKAQAAAWQAAABAAAAQAAAWAKAQQAEAGAEAEQAHAGAJAAQAPAAAKgQQAKgQAAgXQAAgWgKgQQgKgQgPAAg");
	this.shape_12.setTransform(0,-0.025);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgQAxIgHgKQgKgQAAgWIAAgBQAAgWAKgQQAKgQANAAQAOAAAKAQQAKAQAAAWQAAAXgKAQQgKAQgOAAQgIAAgIgGg");
	this.shape_13.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11}]}).wait(101));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.4,-6.5,8.9,13);


(lib.vbnbcvbcvb = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap43();
	this.instance.setTransform(-13,-38);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-13,-38,26,76);


(lib.umbrella = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap1();
	this.instance.setTransform(-150,-143);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-143,301,285);


(lib.trx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_239();
	this.instance.setTransform(-488.5,-302.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-488.5,-302.4,977,605);


(lib.text01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap29();
	this.instance.setTransform(-438,-24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-438,-24,875,48);


(lib.right_wrong = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// Layer_1
	this.instance = new lib.Bitmap4();
	this.instance.setTransform(-26,-24);

	this.instance_1 = new lib.Bitmap5();
	this.instance_1.setTransform(-25,-22);

	this.instance_2 = new lib.Bitmap6();
	this.instance_2.setTransform(-28,-22);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28,-24,63,51);


(lib.nvnfgvbnv = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap42();
	this.instance.setTransform(-13,-15);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-13,-15,25,31);


(lib.nvcbcn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap37();
	this.instance.setTransform(-14,-50);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14,-50,27,101);


(lib.mcRank = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {rank1:9,rank1_1:125,rank2:225};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* stop();
		this.blnPlay = false;*/
	}
	this.frame_1 = function() {
		/* this.blnPlay = true;
		//MovieClip(parent).play();*/
	}
	this.frame_9 = function() {
		/* MovieClip(parent).blnClapping = false;
		MovieClip(parent).play();
		this.blnPlay = true;
		*/
	}
	this.frame_120 = function() {
		/* stop();
		this.blnPlay = false;*/
	}
	this.frame_125 = function() {
		/* MovieClip(parent).blnClapping = false;
		MovieClip(parent).play();
		this.blnPlay = true;
		*/
	}
	this.frame_221 = function() {
		/* stop();
		this.blnPlay = false;*/
	}
	this.frame_225 = function() {
		/* MovieClip(parent).blnClapping = false;
		MovieClip(parent).play();
		this.blnPlay = true;
		//trace("rank2---2");*/
	}
	this.frame_325 = function() {
		/* stop();
		this.blnPlay = false;*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(8).call(this.frame_9).wait(111).call(this.frame_120).wait(5).call(this.frame_125).wait(96).call(this.frame_221).wait(4).call(this.frame_225).wait(100).call(this.frame_325).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(182,83,50,0)").s().p("AkwDSIAAmjIJhAAIAAGjg");
	this.shape.setTransform(30.5,21);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(326));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,61,42);


(lib.kite = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap11();
	this.instance.setTransform(-86,-107);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-86,-107,173,215);


(lib.heading_ = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap30();
	this.instance.setTransform(-147,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-147,-28,310,54);


(lib.hcvcvvbnvn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap41();
	this.instance.setTransform(-63,-86);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63,-86,134,108);


(lib.egg_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap20();
	this.instance.setTransform(-116,-101);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.egg_2, new cjs.Rectangle(-116,-101,277,204), null);


(lib.doll01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap28();
	this.instance.setTransform(-79,-95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79,-95,157,190);


(lib.cvbcbvncvb = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap44();
	this.instance.setTransform(-13,-45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-13,-45,26,96);


(lib.comp = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_238();
	this.instance.setTransform(-300.85,-53.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-300.8,-53.5,601.5,111.5);


(lib.cir___ = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,204,255,0.102)").s().p("EgbrCgcMAVIigSIAAAJMAAAChXQq1AAqThOgAmjATIAEAAMAp2CcRQqJClqrBTgEhEoCV1MA+CiVuIABAAMgp8CcbQqVirpykCgAmfAMIAHAJMBQ1CMDQpNFapwEDgEhpBCAaMBibiATMhQ9CMRQpClXocmngAmFAvIAGgGMBxsBxuQnqHpoKGagEh44ByTQnonomboKMCAVhidIABACIgBABMhyQByOgAmhAGIAAgCIAGACIAGAEIABgEMCcSAp3QirKXkEJzMiVjg98MCMFBQ4QlVJBmqIegEibGBBCIAAjhMCUcg9hIACAAIAAACMiMSBRBQkmn0jmoNgEibGATiMCUUgTiMiUTAAAIgBzjMCUUATiIAAABIACACMiUWAnygAmYAAMChfAAAQAAK1hOKUgECV+gp7QCnKHBSKrMigUAVIgAmmgBMhQ/iMTQJLldJykDMA+CCVuMgp5icbQKIimKshSMAVGCgTIgBAAIABADIAAACgEibGgnyIAA1tMCUYA9egAmfgEMBQ9iMQQJAFUIhGrMhicCASgEh45hyQQAAgBAAAAQAAAAAAgBQAAAAABgBQAAAAAAAAQHpnpIImZMBibCARIAAABgECFxhRBQFcJLEEJyMiVqA+AgAmjgGMAp6icbQKXCqJyEDMg+BCVwgEgGjihqQK0ABKUBQMgVICgTgEiS6hQ/QFUpAGpofMCAIBiUIgCACgAmJgXMBx6hx7QHpHoGaIMMh/5BiJg");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-992.6,-1034.6,1985.3000000000002,2069.3);


(lib.bvcbcb = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap40();
	this.instance.setTransform(-23,-56);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23,-56,45,112);


(lib.btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("EgjAAHeIAAu7MBGBAAAIAAO7g");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-224.1,-47.8,448.2,95.6), null);


(lib.bcvbvnvbc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap38();
	this.instance.setTransform(-8,-36);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-36,15,71);


(lib.act = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_237();
	this.instance.setTransform(-218.15,-53.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-218.1,-53.5,436.5,111.5);


(lib.nvnvvnfgbcb = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.vbncbvc();
	this.instance.setTransform(9.05,-0.35);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.Bitmap39();
	this.instance_1.setTransform(-33,-56);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-33,-56,67,106);


(lib.Goat = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// nvcbcn
	this.instance = new lib.nvcbcn("single",0);
	this.instance.setTransform(3.9,99.35,1,1,0,0,0,3.5,42.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleY:1.0131,y:99.25},19).to({scaleY:1,y:99.35},23).wait(1).to({startPosition:0},0).to({scaleY:1.0131,y:99.25},19).to({scaleY:1,y:99.35},23).wait(5).to({startPosition:0},0).to({scaleY:1.0131,y:99.25},19).to({scaleY:1,y:99.35},23).wait(27));

	// bcvbvnvbc
	this.instance_1 = new lib.bcvbvnvbc("single",0);
	this.instance_1.setTransform(49.35,-64.35,1,1,0,0,0,0.5,-34.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:0.6,scaleX:0.9991,scaleY:0.9991,rotation:-0.6327,x:47.15,y:-68.25},19).to({regX:0.5,scaleX:1,scaleY:1,rotation:0,x:49.35,y:-64.35},23).wait(1).to({startPosition:0},0).to({regX:0.6,scaleX:0.9991,scaleY:0.9991,rotation:-0.6327,x:47.15,y:-68.25},19).to({regX:0.5,scaleX:1,scaleY:1,rotation:0,x:49.35,y:-64.35},23).wait(5).to({startPosition:0},0).to({regX:0.6,scaleX:0.9991,scaleY:0.9991,rotation:-0.6327,x:47.15,y:-68.25},19).to({regX:0.5,scaleX:1,scaleY:1,rotation:0,x:49.35,y:-64.35},23).wait(27));

	// nvnvvnfgbcb
	this.instance_2 = new lib.nvnvvnfgbcb("single",0);
	this.instance_2.setTransform(42.35,-59.85,1,1,0,0,0,-16,-8.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({scaleX:0.9994,scaleY:0.9994,rotation:-9.614,x:41.05,y:-62.65},19).to({scaleX:1,scaleY:1,rotation:0,x:42.35,y:-59.85},23).wait(1).to({startPosition:0},0).to({scaleX:0.9994,scaleY:0.9994,rotation:-9.614,x:41.05,y:-62.65},19).to({scaleX:1,scaleY:1,rotation:0,x:42.35,y:-59.85},23).wait(5).to({startPosition:0},0).to({scaleX:0.9994,scaleY:0.9994,rotation:-9.614,x:41.05,y:-62.65},19).to({scaleX:1,scaleY:1,rotation:0,x:42.35,y:-59.85},23).wait(27));

	// bv_cbcb
	this.instance_3 = new lib.bvcbcb("single",0);
	this.instance_3.setTransform(-61.5,98.6,1,1,0,0,0,7.2,47.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({startPosition:0},19).to({startPosition:0},23).wait(1).to({startPosition:0},0).to({startPosition:0},19).to({startPosition:0},23).wait(5).to({startPosition:0},0).to({startPosition:0},19).to({startPosition:0},23).wait(27));

	// hcvcvvbnvn
	this.instance_4 = new lib.hcvcvvbnvn("single",0);
	this.instance_4.setTransform(-20.7,21,1,1,0,0,0,-0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({regX:0,scaleX:0.9999,scaleY:0.9999,rotation:-1.2985,x:-20.15,y:19.6},19).to({regX:-0.1,scaleX:1,scaleY:1,rotation:0,x:-20.7,y:21},23).wait(1).to({startPosition:0},0).to({regX:0,scaleX:0.9999,scaleY:0.9999,rotation:-1.2985,x:-20.15,y:19.6},19).to({regX:-0.1,scaleX:1,scaleY:1,rotation:0,x:-20.7,y:21},23).wait(5).to({startPosition:0},0).to({regX:0,scaleX:0.9999,scaleY:0.9999,rotation:-1.2985,x:-20.15,y:19.6},19).to({regX:-0.1,scaleX:1,scaleY:1,rotation:0,x:-20.7,y:21},23).wait(27));

	// nvnfgvbnv
	this.instance_5 = new lib.nvnfgvbnv("single",0);
	this.instance_5.setTransform(-74.1,-19.35,1,1,0,0,0,4.3,12.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({regX:4.2,scaleX:0.9999,scaleY:0.9999,rotation:14.475,x:-74.35,y:-19.4},9).to({rotation:-1.2985,x:-74.55,y:-19.5},10).to({rotation:14.4824,x:-74.3,y:-19.35},12).to({regX:4.3,scaleX:1,scaleY:1,rotation:0,x:-74.1},11).wait(1).to({startPosition:0},0).to({regX:4.2,scaleX:0.9999,scaleY:0.9999,rotation:14.475,x:-74.35,y:-19.4},9).to({rotation:-1.2985,x:-74.55,y:-19.5},10).to({rotation:14.4824,x:-74.3,y:-19.35},12).to({regX:4.3,scaleX:1,scaleY:1,rotation:0,x:-74.1},11).wait(5).to({startPosition:0},0).to({regX:4.2,scaleX:0.9999,scaleY:0.9999,rotation:14.475,x:-74.35,y:-19.4},9).to({rotation:-1.2985,x:-74.55,y:-19.5},10).to({rotation:14.4824,x:-74.3,y:-19.35},12).to({regX:4.3,scaleX:1,scaleY:1,rotation:0,x:-74.1},11).wait(27));

	// vbnbcvbcvb
	this.instance_6 = new lib.vbnbcvbcvb("single",0);
	this.instance_6.setTransform(-29.85,95.6,1,1,0,0,0,1.4,32);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({startPosition:0},19).to({startPosition:0},23).wait(1).to({startPosition:0},0).to({startPosition:0},19).to({startPosition:0},23).wait(5).to({startPosition:0},0).to({startPosition:0},19).to({startPosition:0},23).wait(27));

	// cvbcbvncvb
	this.instance_7 = new lib.cvbcbvncvb("single",0);
	this.instance_7.setTransform(19.95,88.7,1,1,0,0,0,4.4,41.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({scaleY:1.0131,y:88.45},19).to({scaleY:1,y:88.7},23).wait(1).to({startPosition:0},0).to({scaleY:1.0131,y:88.45},19).to({scaleY:1,y:88.7},23).wait(5).to({startPosition:0},0).to({scaleY:1.0131,y:88.45},19).to({scaleY:1,y:88.7},23).wait(27));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-92.3,-118,192.3,226.4);


(lib.gh = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.trx();
	this.instance.setTransform(-3.4,-4.1);
	this.instance.alpha = 0.4805;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gh, new cjs.Rectangle(-491.9,-306.5,977,605), null);


(lib.circle = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.cir___("synched",0);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:360},1414).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1076.4,-1076.4,2152.8,2152.8);


(lib.box3_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap49();
	this.instance.setTransform(-54,-61);

	this.instance_1 = new lib.Bitmap50();
	this.instance_1.setTransform(-54,-61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-61,114,117);


(lib.box3_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap35();
	this.instance.setTransform(-54,-61);

	this.instance_1 = new lib.Bitmap36();
	this.instance_1.setTransform(-54,-61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-61,114,117);


(lib.box3_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap25();
	this.instance.setTransform(-54,-61);

	this.instance_1 = new lib.Bitmap26();
	this.instance_1.setTransform(-54,-61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-61,114,117);


(lib.box3_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap16();
	this.instance.setTransform(-54,-61);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-54,-61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-61,114,117);


(lib.box3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap9();
	this.instance.setTransform(-54,-61);

	this.instance_1 = new lib.Bitmap10();
	this.instance_1.setTransform(-54,-61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-61,114,117);


(lib.box2_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap47();
	this.instance.setTransform(-54,-60);

	this.instance_1 = new lib.Bitmap48();
	this.instance_1.setTransform(-54,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-60,114,116);


(lib.box2_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap33();
	this.instance.setTransform(-54,-60);

	this.instance_1 = new lib.Bitmap34();
	this.instance_1.setTransform(-54,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-60,114,116);


(lib.box2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap23();
	this.instance.setTransform(-54,-60);

	this.instance_1 = new lib.Bitmap24();
	this.instance_1.setTransform(-54,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-60,114,116);


(lib.box2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap14();
	this.instance.setTransform(-54,-60);

	this.instance_1 = new lib.Bitmap15();
	this.instance_1.setTransform(-54,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-60,114,116);


(lib.box2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap7();
	this.instance.setTransform(-54,-60);

	this.instance_1 = new lib.Bitmap8();
	this.instance_1.setTransform(-54,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-60,114,116);


(lib.box_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap45();
	this.instance.setTransform(-54,-61);

	this.instance_1 = new lib.Bitmap46();
	this.instance_1.setTransform(-54,-61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-61,114,117);


(lib.box_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap31();
	this.instance.setTransform(-54,-61);

	this.instance_1 = new lib.Bitmap32();
	this.instance_1.setTransform(-54,-61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-61,114,117);


(lib.box_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap21();
	this.instance.setTransform(-54,-61);

	this.instance_1 = new lib.Bitmap22();
	this.instance_1.setTransform(-54,-61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-61,114,117);


(lib.box_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap12();
	this.instance.setTransform(-54,-61);

	this.instance_1 = new lib.Bitmap13();
	this.instance_1.setTransform(-54,-61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-61,114,117);


(lib.box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_3
	this.instance = new lib.Bitmap2();
	this.instance.setTransform(-54,-61);

	this.instance_1 = new lib.Bitmap3();
	this.instance_1.setTransform(-54,-61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-61,114,117);


(lib.actt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Eg4PARaMAAAgi0MBwfAAAMAAAAi0g");
	var mask_graphics_91 = new cjs.Graphics().p("Eg4PARaMAAAgi0MBwfAAAMAAAAi0g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-14.8,y:-9.75}).wait(91).to({graphics:mask_graphics_91,x:-14.8,y:-9.75}).wait(1).to({graphics:null,x:0,y:0}).wait(294));

	// comp
	this.instance = new lib.comp("synched",0);
	this.instance.setTransform(810,43.5);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-45},15,cjs.Ease.get(1)).to({x:0},5,cjs.Ease.get(1)).wait(71).to({startPosition:0},0).to({_off:true},1).wait(294));

	// act
	this.instance_1 = new lib.act("synched",0);
	this.instance_1.setTransform(-787.5,-43.5);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:45},15,cjs.Ease.get(1)).to({x:0},5,cjs.Ease.get(1)).wait(71).to({startPosition:0},0).to({_off:true},1).wait(294));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-374.8,-97,720,198.5);


(lib.mcMain5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_102 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 3;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();
			//objRef.mcFish.gotoAndPlay(2);
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					//this.parent.fLaunchProduct();
					this.play();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{		
				this.play();
				//this.parent.fLaunchProduct();		
			}.bind(this), 5000);
		}
		this.init();
	}
	this.frame_103 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_142 = function() {
		/* stop();
		this.blnPlay = false;
		fCalculateScore();
		function fCalculateScore() {
			mcNext.mcBlinker.gotoAndStop(2);
			var nPercentage = (__nScore/5)*100;
			nPercentage = Math.ceil(nPercentage);
			trace(nPercentage + "---------------------");
			if (nPercentage < 70) {
				mcFinal.mcRank.gotoAndPlay("rank2");		
			} else {
				mcFinal.mcRank.gotoAndPlay("rank1_1");
			}
		}*/
		
		this.stop();
		//alert("finalScreen");
		main.showRestartBtn();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(102).call(this.frame_102).wait(1).call(this.frame_103).wait(39).call(this.frame_142).wait(1));

	// Layer_5
	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-186.55,207.35,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(91.45,207.35,1.728,1.728);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(357.45,207.35,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_3},{t:this.mcTick_2},{t:this.mcTick_1}]},102).wait(41));

	// right_wrong_txt
	this.mc_3 = new lib.box3_5();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(247,208.65);

	this.mc_2 = new lib.box2_5();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(-18,208.65);

	this.mc_1 = new lib.box_5();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-293,208.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3}]},102).to({state:[]},1).wait(40));

	// box3
	this.instance = new lib.box3_5();
	this.instance.setTransform(1087,208.65);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(77).to({_off:false},0).to({x:237},13,cjs.Ease.get(1)).to({x:247},5,cjs.Ease.get(1)).to({_off:true},7).wait(1).to({_off:false},0).wait(40));

	// box2
	this.instance_1 = new lib.box2_5();
	this.instance_1.setTransform(822,208.65);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(74).to({_off:false},0).to({x:-28},13,cjs.Ease.get(1)).to({x:-18},5,cjs.Ease.get(1)).to({_off:true},10).wait(1).to({_off:false},0).wait(40));

	// box
	this.instance_2 = new lib.box_5();
	this.instance_2.setTransform(547,208.65);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(71).to({_off:false},0).to({x:-303},13,cjs.Ease.get(1)).to({x:-293},5,cjs.Ease.get(1)).to({_off:true},13).wait(1).to({_off:false},0).wait(40));

	// _
	this.instance_3 = new lib.Goat();
	this.instance_3.setTransform(-626,-20.7,1.4,1.4);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(51).to({_off:false},0).to({x:10},12,cjs.Ease.get(1)).to({x:0},6,cjs.Ease.get(1)).wait(74));

	// box3
	this.instance_4 = new lib.box3_4();
	this.instance_4.setTransform(247,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(19).to({x:257},5,cjs.Ease.get(1)).to({x:-553},10,cjs.Ease.get(1)).to({_off:true},1).wait(108));

	// box2
	this.instance_5 = new lib.box2_4();
	this.instance_5.setTransform(-18,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(17).to({x:-8},5,cjs.Ease.get(1)).to({x:-818},10,cjs.Ease.get(1)).to({_off:true},1).wait(110));

	// box
	this.instance_6 = new lib.box_4();
	this.instance_6.setTransform(-293,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(15).to({x:-283},5,cjs.Ease.get(1)).to({x:-1093},10,cjs.Ease.get(1)).to({_off:true},1).wait(112));

	// doll01
	this.instance_7 = new lib.doll01("synched",0);
	this.instance_7.setTransform(-344.05,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(17).to({startPosition:0},0).to({x:-354.05},6,cjs.Ease.get(1)).to({x:575.95},13,cjs.Ease.get(1)).to({_off:true},1).wait(106));

	// doll01
	this.instance_8 = new lib.doll01("synched",0);
	this.instance_8.setTransform(-187.55,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(15).to({startPosition:0},0).to({x:-197.55},6,cjs.Ease.get(1)).to({x:732.45},13,cjs.Ease.get(1)).to({_off:true},1).wait(108));

	// doll01
	this.instance_9 = new lib.doll01("synched",0);
	this.instance_9.setTransform(-31.05,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(13).to({startPosition:0},0).to({x:-41.05},6,cjs.Ease.get(1)).to({x:888.95},13,cjs.Ease.get(1)).to({_off:true},1).wait(110));

	// doll01
	this.instance_10 = new lib.doll01("synched",0);
	this.instance_10.setTransform(125.45,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(11).to({startPosition:0},0).to({x:115.45},6,cjs.Ease.get(1)).to({x:1045.45},13,cjs.Ease.get(1)).to({_off:true},1).wait(112));

	// doll01
	this.instance_11 = new lib.doll01("synched",0);
	this.instance_11.setTransform(281.95,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(9).to({startPosition:0},0).to({x:271.95},6,cjs.Ease.get(1)).to({x:1201.95},13,cjs.Ease.get(1)).to({_off:true},1).wait(114));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1151,-171.4,2431,451.1);


(lib.mcMain4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_92 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 1;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();
			//objRef.mcFish.gotoAndPlay(2);
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(92).call(this.frame_92).wait(1));

	// right_wrong_txt
	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-186.55,207.35,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(91.45,207.35,1.728,1.728);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(357.45,207.35,1.728,1.728);

	this.mc_3 = new lib.box3_4();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(247,208.65);
	this.mc_3.shadow = new cjs.Shadow("#890A2E",0,0,10);

	this.mc_2 = new lib.box2_4();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(-18,208.65);

	this.mc_1 = new lib.box_4();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-293,208.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mcTick_3},{t:this.mcTick_2},{t:this.mcTick_1}]},92).wait(1));

	// HEADING
	this.instance = new lib.heading_("synched",0);
	this.instance.setTransform(-342.85,-272.75);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},92).wait(1));

	// box3
	this.instance_1 = new lib.box3_4();
	this.instance_1.setTransform(1087,208.65);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(69).to({_off:false},0).to({x:237},13,cjs.Ease.get(1)).to({x:247},5,cjs.Ease.get(1)).to({_off:true},5).wait(1));

	// box2
	this.instance_2 = new lib.box2_4();
	this.instance_2.setTransform(822,208.65);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(66).to({_off:false},0).to({x:-28},13,cjs.Ease.get(1)).to({x:-18},5,cjs.Ease.get(1)).to({_off:true},8).wait(1));

	// box
	this.instance_3 = new lib.box_4();
	this.instance_3.setTransform(547,208.65);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(63).to({_off:false},0).to({x:-303},13,cjs.Ease.get(1)).to({x:-293},5,cjs.Ease.get(1)).to({_off:true},11).wait(1));

	// doll01
	this.instance_4 = new lib.doll01("synched",0);
	this.instance_4.setTransform(-1194.05,-9.5);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(51).to({_off:false},0).to({x:-334.05},12,cjs.Ease.get(1)).to({x:-344.05},5,cjs.Ease.get(1)).wait(25));

	// doll01
	this.instance_5 = new lib.doll01("synched",0);
	this.instance_5.setTransform(-1037.55,-9.5);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(47).to({_off:false},0).to({x:-177.55},12,cjs.Ease.get(1)).to({x:-187.55},5,cjs.Ease.get(1)).wait(29));

	// doll01
	this.instance_6 = new lib.doll01("synched",0);
	this.instance_6.setTransform(-881.05,-9.5);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(44).to({_off:false},0).to({x:-21.05},12,cjs.Ease.get(1)).to({x:-31.05},5,cjs.Ease.get(1)).wait(32));

	// doll01
	this.instance_7 = new lib.doll01("synched",0);
	this.instance_7.setTransform(-724.55,-9.5);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(41).to({_off:false},0).to({x:135.45},12,cjs.Ease.get(1)).to({x:125.45},5,cjs.Ease.get(1)).wait(35));

	// doll01
	this.instance_8 = new lib.doll01("synched",0);
	this.instance_8.setTransform(-568.05,-9.5);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(36).to({_off:false},0).to({x:291.95},12,cjs.Ease.get(1)).to({x:281.95},5,cjs.Ease.get(1)).wait(40));

	// box3
	this.instance_9 = new lib.box3_3();
	this.instance_9.setTransform(247,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(12).to({x:257},5,cjs.Ease.get(1)).to({x:-553},10,cjs.Ease.get(1)).to({_off:true},1).wait(65));

	// box2
	this.instance_10 = new lib.box2_3("single",0);
	this.instance_10.setTransform(-18,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(10).to({startPosition:0},0).to({x:-8},5,cjs.Ease.get(1)).to({x:-818,mode:"independent"},10,cjs.Ease.get(1)).to({_off:true},1).wait(67));

	// box
	this.instance_11 = new lib.box_3();
	this.instance_11.setTransform(-293,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(8).to({x:-283},5,cjs.Ease.get(1)).to({x:-1093},10,cjs.Ease.get(1)).to({_off:true},1).wait(69));

	// egg_2
	this.instance_12 = new lib.egg_2();
	this.instance_12.setTransform(-242.8,15.5,0.735,0.735,0,0,0,50.1,64.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(10).to({x:-252.8},5).to({x:617.2},12).to({_off:true},1).wait(65));

	// egg_2
	this.instance_13 = new lib.egg_2();
	this.instance_13.setTransform(-2.8,15.5,0.735,0.735,0,0,0,50.1,64.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(8).to({x:-12.8},5).to({x:857.2},12).to({_off:true},1).wait(67));

	// egg_2
	this.instance_14 = new lib.egg_2();
	this.instance_14.setTransform(237.2,15.5,0.735,0.735,0,0,0,50.1,64.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(6).to({x:227.2},5).to({x:1097.2},12).to({_off:true},1).wait(69));

	// Layer_44
	this.instance_15 = new lib.text01("synched",0);
	this.instance_15.setTransform(-12,-223.95);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).to({_off:true},92).wait(1));

	// bg
	this.instance_16 = new lib.gh();
	this.instance_16.setTransform(3.4,4.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_16).to({_off:true},92).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1273,-302.4,2451.7,605);


(lib.mcMain3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_94 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 2;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();
			//objRef.mcFish.gotoAndPlay(2);
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(94).call(this.frame_94).wait(1));

	// right_wrong_txt
	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-186.55,207.35,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(91.45,207.35,1.728,1.728);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(357.45,207.35,1.728,1.728);

	this.mc_3 = new lib.box3_3();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(247,208.65);

	this.mc_2 = new lib.box2_3();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(-18,208.65);

	this.mc_1 = new lib.box_3();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-293,208.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mcTick_3},{t:this.mcTick_2},{t:this.mcTick_1}]},94).wait(1));

	// HEADING
	this.instance = new lib.heading_("synched",0);
	this.instance.setTransform(-342.85,-272.75);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},94).wait(1));

	// box3
	this.instance_1 = new lib.box3_3();
	this.instance_1.setTransform(1087,208.65);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(67).to({_off:false},0).to({x:237},13,cjs.Ease.get(1)).to({x:247},5,cjs.Ease.get(1)).to({_off:true},9).wait(1));

	// box2
	this.instance_2 = new lib.box2_3();
	this.instance_2.setTransform(822,208.65);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(64).to({_off:false},0).to({x:-28},13,cjs.Ease.get(1)).to({x:-18},5,cjs.Ease.get(1)).to({_off:true},12).wait(1));

	// box
	this.instance_3 = new lib.box_3();
	this.instance_3.setTransform(547,208.65);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(61).to({_off:false},0).to({x:-303},13,cjs.Ease.get(1)).to({x:-293},5,cjs.Ease.get(1)).to({_off:true},15).wait(1));

	// egg_2
	this.instance_4 = new lib.egg_2();
	this.instance_4.setTransform(-1062.8,15.5,0.735,0.735,0,0,0,50.1,64.3);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(47).to({_off:false},0).to({x:-232.8},13,cjs.Ease.get(1)).to({x:-242.8},6,cjs.Ease.get(1)).wait(29));

	// egg_2
	this.instance_5 = new lib.egg_2();
	this.instance_5.setTransform(-822.8,15.5,0.735,0.735,0,0,0,50.1,64.3);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(44).to({_off:false},0).to({x:7.2},13,cjs.Ease.get(1)).to({x:-2.8},6,cjs.Ease.get(1)).wait(32));

	// egg_2
	this.instance_6 = new lib.egg_2();
	this.instance_6.setTransform(-582.8,15.5,0.735,0.735,0,0,0,50.1,64.3);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(40).to({_off:false},0).to({x:247.2},13,cjs.Ease.get(1)).to({x:237.2},6,cjs.Ease.get(1)).wait(36));

	// box3
	this.instance_7 = new lib.box3_2();
	this.instance_7.setTransform(247,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(9).to({x:257},5,cjs.Ease.get(1)).to({x:-553},10,cjs.Ease.get(1)).to({_off:true},1).wait(70));

	// box2
	this.instance_8 = new lib.box2_2();
	this.instance_8.setTransform(-18,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(7).to({x:-8},5,cjs.Ease.get(1)).to({x:-818},10,cjs.Ease.get(1)).to({_off:true},1).wait(72));

	// box
	this.instance_9 = new lib.box_2();
	this.instance_9.setTransform(-293,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(5).to({x:-283},5,cjs.Ease.get(1)).to({x:-1093},10,cjs.Ease.get(1)).to({_off:true},1).wait(74));

	// kite
	this.instance_10 = new lib.kite("synched",0);
	this.instance_10.setTransform(-289.5,-7.1,1,1,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(9).to({startPosition:0},0).to({x:-299.5},5,cjs.Ease.get(1)).to({x:580.5},10,cjs.Ease.get(1)).to({_off:true},1).wait(70));

	// kite
	this.instance_11 = new lib.kite("synched",0);
	this.instance_11.setTransform(-106.85,-7.1,1,1,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(7).to({startPosition:0},0).to({x:-116.85},5,cjs.Ease.get(1)).to({x:763.15},10,cjs.Ease.get(1)).to({_off:true},1).wait(72));

	// kite
	this.instance_12 = new lib.kite("synched",0);
	this.instance_12.setTransform(75.8,-7.1,1,1,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(5).to({startPosition:0},0).to({x:65.8},5,cjs.Ease.get(1)).to({x:945.8},10,cjs.Ease.get(1)).to({_off:true},1).wait(74));

	// kite
	this.instance_13 = new lib.kite("synched",0);
	this.instance_13.setTransform(258.5,-7.1,1,1,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(3).to({startPosition:0},0).to({x:248.5},5,cjs.Ease.get(1)).to({x:1128.5},10,cjs.Ease.get(1)).to({_off:true},1).wait(76));

	// Layer_44
	this.instance_14 = new lib.text01("synched",0);
	this.instance_14.setTransform(-12,-223.95);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({_off:true},94).wait(1));

	// bg
	this.instance_15 = new lib.gh();
	this.instance_15.setTransform(3.4,4.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).to({_off:true},94).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1184.9,-302.4,2400.3,605);


(lib.mcMain2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_94 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 3;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();
			//objRef.mcFish.gotoAndPlay(2);
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(94).call(this.frame_94).wait(1));

	// right_wrong_txt
	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-186.55,207.35,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(91.45,207.35,1.728,1.728);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(357.45,207.35,1.728,1.728);

	this.mc_3 = new lib.box3_2();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(247,208.65);

	this.mc_2 = new lib.box2_2();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(-18,208.65);

	this.mc_1 = new lib.box_2();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-293,208.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mcTick_3},{t:this.mcTick_2},{t:this.mcTick_1}]},94).wait(1));

	// HEADING
	this.instance = new lib.heading_("synched",0);
	this.instance.setTransform(-342.85,-272.75);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},94).wait(1));

	// box3
	this.instance_1 = new lib.box3_2();
	this.instance_1.setTransform(1087,208.65);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(70).to({_off:false},0).to({x:237},13,cjs.Ease.get(1)).to({x:247},5,cjs.Ease.get(1)).to({_off:true},6).wait(1));

	// box2
	this.instance_2 = new lib.box2_2();
	this.instance_2.setTransform(822,208.65);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(67).to({_off:false},0).to({x:-28},13,cjs.Ease.get(1)).to({x:-18},5,cjs.Ease.get(1)).to({_off:true},9).wait(1));

	// box
	this.instance_3 = new lib.box_2();
	this.instance_3.setTransform(547,208.65);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(64).to({_off:false},0).to({x:-303},13,cjs.Ease.get(1)).to({x:-293},5,cjs.Ease.get(1)).to({_off:true},12).wait(1));

	// kite
	this.instance_4 = new lib.kite("synched",0);
	this.instance_4.setTransform(-1149.5,-7.1,1,1,0,0,0,0.1,0);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(49).to({_off:false},0).to({x:-269.5},11,cjs.Ease.get(1)).to({x:-289.5},5,cjs.Ease.get(1)).wait(30));

	// kite
	this.instance_5 = new lib.kite("synched",0);
	this.instance_5.setTransform(-966.85,-7.1,1,1,0,0,0,0.1,0);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(46).to({_off:false},0).to({x:-86.85},11,cjs.Ease.get(1)).to({x:-106.85},5,cjs.Ease.get(1)).wait(33));

	// kite
	this.instance_6 = new lib.kite("synched",0);
	this.instance_6.setTransform(-784.2,-7.1,1,1,0,0,0,0.1,0);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(42).to({_off:false},0).to({x:95.8},11,cjs.Ease.get(1)).to({x:75.8},5,cjs.Ease.get(1)).wait(37));

	// kite
	this.instance_7 = new lib.kite("synched",0);
	this.instance_7.setTransform(-601.5,-7.1,1,1,0,0,0,0.1,0);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(38).to({_off:false},0).to({x:278.5},11,cjs.Ease.get(1)).to({x:258.5},5,cjs.Ease.get(1)).wait(41));

	// box3
	this.instance_8 = new lib.box3();
	this.instance_8.setTransform(247,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(17).to({x:257},5,cjs.Ease.get(1)).to({x:-553},10,cjs.Ease.get(1)).to({_off:true},1).wait(62));

	// box2
	this.instance_9 = new lib.box2();
	this.instance_9.setTransform(-18,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(15).to({x:-8},5,cjs.Ease.get(1)).to({x:-818},10,cjs.Ease.get(1)).to({_off:true},1).wait(64));

	// box
	this.instance_10 = new lib.box("single",0);
	this.instance_10.setTransform(-293,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(13).to({startPosition:0},0).to({x:-283},5,cjs.Ease.get(1)).to({x:-1093,mode:"independent"},10,cjs.Ease.get(1)).to({_off:true},1).wait(66));

	// umbrella
	this.instance_11 = new lib.umbrella("synched",0);
	this.instance_11.setTransform(-169.85,-21.85,1,1,0,0,0,0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(15).to({startPosition:0},0).to({x:-179.85},5,cjs.Ease.get(1)).to({x:645.15},10,cjs.Ease.get(1)).to({_off:true},1).wait(64));

	// umbrella
	this.instance_12 = new lib.umbrella("synched",0);
	this.instance_12.setTransform(180.15,-21.85,1,1,0,0,0,0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(13).to({startPosition:0},0).to({x:170.15},5,cjs.Ease.get(1)).to({x:995.15},10,cjs.Ease.get(1)).to({_off:true},1).wait(66));

	// Layer_44
	this.instance_13 = new lib.text01("synched",0);
	this.instance_13.setTransform(-12,-223.95);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({_off:true},94).wait(1));

	// bg
	this.instance_14 = new lib.gh();
	this.instance_14.setTransform(3.4,4.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({_off:true},94).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1235.6,-302.4,2381.7,605);


(lib.mcMain1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;
		var objRef = this;
		var __nCorrectAnswer = 0;
		var blnLastQuestion = false;
		var __nScore = 0;
		var blnEnd = false;
		function init() {
			for (var i:Number = 1; objRef["mc_"+i] != null; i++) {
				objRef["mc_"+i].id = i;
				objRef["mc_" + i].addEventListener(MouseEvent.CLICK, fClickEvent);
				objRef["mc_"+i].buttonMode = true;
			}
		}
		function fClickEvent(e) {
			//mcFish.gotoAndPlay(2);
			fRemoveListeners();
			if (e.currentTarget.id == __nCorrectAnswer) {
				e.currentTarget.gotoAndStop(2);
				__nScore++;
				//setTimeout(fChangeQuestion, 3000);
				var mcRight = new Right();
				objRef.addChild(mcRight);
				objRef["mcTick_" + e.currentTarget.id].gotoAndStop(3);
				return;
			}
			//setTimeout(fChangeQuestion, 5000);
			var mcWrong = new ShowAnswer();
			objRef.addChild(mcWrong);
			objRef["mcTick_" + e.currentTarget.id].gotoAndStop(2);
		}
		function fShowCorrectAnswer() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(2);
			//e.currentTarget.gotoAndStop(2);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(3);
		}
		function fChangeQuestion() {
			fRemoveListeners();
			play();
		}
		function fRemoveListeners() {
			for (var i:Number = 1; objRef["mc_"+i] != null; i++) {
				objRef["mc_" + i].removeEventListener(MouseEvent.CLICK, fClickEvent);
				objRef["mc_"+i].buttonMode = false;
				if (!blnEnd) {
					objRef["mc_" + i].gotoAndStop(1);
				}
			}
		}*/
	}
	this.frame_145 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 1;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();
			//objRef.mcFish.gotoAndPlay(2);
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(145).call(this.frame_145).wait(1));

	// right_wrong_txt
	this.mc_3 = new lib.box3();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(247,208.65);

	this.mc_2 = new lib.box2();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(-18,208.65);

	this.mc_1 = new lib.box();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-293,208.65);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-186.55,207.35,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(91.45,207.35,1.728,1.728);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(357.45,207.35,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_3},{t:this.mcTick_2},{t:this.mcTick_1},{t:this.mc_1},{t:this.mc_2},{t:this.mc_3}]},145).wait(1));

	// box3
	this.instance = new lib.box3();
	this.instance.setTransform(1087,208.65);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(54).to({_off:false},0).to({x:237},13,cjs.Ease.get(1)).to({x:247},5,cjs.Ease.get(1)).to({_off:true},73).wait(1));

	// box2
	this.instance_1 = new lib.box2();
	this.instance_1.setTransform(822,208.65);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(51).to({_off:false},0).to({x:-28},13,cjs.Ease.get(1)).to({x:-18},5,cjs.Ease.get(1)).to({_off:true},76).wait(1));

	// box
	this.instance_2 = new lib.box();
	this.instance_2.setTransform(547,208.65);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(48).to({_off:false},0).to({x:-303},13,cjs.Ease.get(1)).to({x:-293},5,cjs.Ease.get(1)).to({_off:true},79).wait(1));

	// umbrella
	this.instance_3 = new lib.umbrella("synched",0);
	this.instance_3.setTransform(-1009.85,-21.85,1,1,0,0,0,0.1,-0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(35).to({_off:false},0).to({x:-159.85},13,cjs.Ease.get(1)).to({x:-169.85},6,cjs.Ease.get(1)).wait(92));

	// umbrella
	this.instance_4 = new lib.umbrella("synched",0);
	this.instance_4.setTransform(-659.85,-21.85,1,1,0,0,0,0.1,-0.1);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(30).to({_off:false},0).to({x:190.15},13,cjs.Ease.get(1)).to({x:180.15},6,cjs.Ease.get(1)).wait(97));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1159.9,-164.7,2304.9,429.4);


(lib.mcFinal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* stop();
		this.blnPlay = false;
		var blnClapping = true;*/
	}
	this.frame_1 = function() {
		/* this.blnPlay = true;
		
		if (MovieClip(parent.parent.parent.parent).mcFileSound.currentFrame > 25)
		{
			MovieClip(parent.parent.parent.parent).mcFileSound.gotoAndStop(MovieClip(parent.parent.parent.parent).mcFileSound.currentFrame+1);
		}*/
	}
	this.frame_9 = function() {
		/* MovieClip(parent.parent.parent.parent).mcFileSound.gotoAndStop(7);*/
	}
	this.frame_15 = function() {
		///*if(MovieClip(root.parent.parent) != null && blnClapping)
		//{
		//	MovieClip(root.parent.parent).fClickSound("final");
		//}*/
	}
	this.frame_92 = function() {
		//stop();
		//this.blnPlay = false;
		///*if (MovieClip(parent.parent.parent.parent).blnNext)
		//{
		//	MovieClip(parent.parent.parent.parent).mcForward.mcGlow.gotoAndPlay(6);
		//	MovieClip(parent.parent.parent.parent).blnNext = false;
		//}
		//if (MovieClip(parent.parent.parent.parent).blnHome)
		//{
		//	MovieClip(parent.parent.parent.parent).mcHome.mcGlow.gotoAndPlay(6);
		//	MovieClip(parent.parent.parent.parent).blnHome = false;
		//}
		//if (MovieClip(parent.parent.parent.parent).blnBack)
		//{
		//	MovieClip(parent.parent.parent.parent).mcBack.mcGlow.gotoAndPlay(6);
		//	MovieClip(parent.parent.parent.parent).blnBack = false;
		//}*/
		//
		///*if (MovieClip(parent.parent.parent.parent).mcForward.alpha < 1 && MovieClip(parent.parent.parent.parent).mcFForward.alpha < 1)
		//{
		//	MovieClip(parent.parent.parent.parent).mcHome.mcGlow.gotoAndPlay(6);
		//	return;	
		//}
		//if (MovieClip(parent.parent.parent.parent).mcForward.alpha < 1)
		//{
		//	MovieClip(parent.parent.parent.parent).mcBack.mcGlow.gotoAndPlay(6);	
		//	return;
		//}
		//MovieClip(parent.parent.parent.parent).mcForward.mcGlow.gotoAndPlay(6);	*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(8).call(this.frame_9).wait(6).call(this.frame_15).wait(77).call(this.frame_92).wait(1));

	// rank
	this.mcRank = new lib.mcRank();
	this.mcRank.name = "mcRank";
	this.mcRank.setTransform(-458,-279,1,1,0,0,0,30.5,21);

	this.timeline.addTween(cjs.Tween.get(this.mcRank).wait(93));

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("EhMUAt8MAAAhb3MCYpAAAMAAABb3g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:-0.025,y:0.025}).wait(92));

	// Layer_2
	this.instance = new lib.actt("synched",0,false);
	this.instance.setTransform(0,18.9);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(92));

	// Layer_3
	this.instance_1 = new lib.circle();
	this.instance_1.setTransform(36,330.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.071)").s().p("EAFSA8iIBSgiIAADiQgrhggnhggAlTTmIL3hkIAAURIn+CJQioqKhRqsgAmjhfQAAq1BQqTIL3BkIAATkgEgBagrbQCoqVEEpxIBSAiIAAVtg");
	this.shape.setTransform(-998.6,310.175);

	var maskedShapeInstanceList = [this.instance_1,this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape},{t:this.instance_1}]},1).wait(92));

	// Layer_4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(9,87,204,0)","rgba(40,120,240,0)"],[0,1],0.1,296,0,-295.9).s().p("EhMUAt8MAAAhb3MCYpAAAMAAABb3g");
	this.shape_1.setTransform(0,-0.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(25,99,207,0.059)","rgba(54,129,241,0.059)"],[0,1],0.1,296,0,-295.9).s().p("EhMUAt8MAAAhb3MCYpAAAMAAABb3g");
	this.shape_2.setTransform(0,-0.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["rgba(41,110,211,0.114)","rgba(67,139,242,0.114)"],[0,1],0.1,296,0,-295.9).s().p("EhMUAt8MAAAhb3MCYpAAAMAAABb3g");
	this.shape_3.setTransform(0,-0.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(57,122,214,0.173)","rgba(81,148,243,0.173)"],[0,1],0.1,296,0,-295.9).s().p("EhMUAt8MAAAhb3MCYpAAAMAAABb3g");
	this.shape_4.setTransform(0,-0.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["rgba(72,134,218,0.227)","rgba(95,157,244,0.227)"],[0,1],0.1,296,0,-295.9).s().p("EhMUAt8MAAAhb3MCYpAAAMAAABb3g");
	this.shape_5.setTransform(0,-0.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(88,145,222,0.286)","rgba(108,166,245,0.286)"],[0,1],0.1,296,0,-295.9).s().p("EhMUAt8MAAAhb3MCYpAAAMAAABb3g");
	this.shape_6.setTransform(0,-0.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["rgba(104,157,225,0.341)","rgba(122,176,246,0.341)"],[0,1],0.1,296,0,-295.9).s().p("EhMUAt8MAAAhb3MCYpAAAMAAABb3g");
	this.shape_7.setTransform(0,-0.05);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(120,169,229,0.4)","rgba(136,185,247,0.4)"],[0,1],0.1,296,0,-295.9).s().p("EhMUAt8MAAAhb3MCYpAAAMAAABb3g");
	this.shape_8.setTransform(0,-0.05);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(136,180,232,0.459)","rgba(149,194,247,0.459)"],[0,1],0.1,296,0,-295.9).s().p("EhMUAt8MAAAhb3MCYpAAAMAAABb3g");
	this.shape_9.setTransform(0,-0.05);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(152,192,235,0.514)","rgba(163,204,248,0.514)"],[0,1],0.1,296,0,-295.9).s().p("EhMUAt8MAAAhb3MCYpAAAMAAABb3g");
	this.shape_10.setTransform(0,-0.05);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(168,203,239,0.573)","rgba(176,213,249,0.573)"],[0,1],0.1,296,0,-295.9).s().p("EhMUAt8MAAAhb3MCYpAAAMAAABb3g");
	this.shape_11.setTransform(0,-0.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(183,215,243,0.627)","rgba(190,222,250,0.627)"],[0,1],0.1,296,0,-295.9).s().p("EhMUAt8MAAAhb3MCYpAAAMAAABb3g");
	this.shape_12.setTransform(0,-0.05);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(199,227,246,0.686)","rgba(204,231,251,0.686)"],[0,1],0.1,296,0,-295.9).s().p("EhMUAt8MAAAhb3MCYpAAAMAAABb3g");
	this.shape_13.setTransform(0,-0.05);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(215,238,250,0.741)","rgba(217,241,252,0.741)"],[0,1],0.1,296,0,-295.9).s().p("EhMUAt8MAAAhb3MCYpAAAMAAABb3g");
	this.shape_14.setTransform(0,-0.05);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(231,250,253,0.8)").s().p("EhMUAt8MAAAhb3MCYpAAAMAAABb3g");
	this.shape_15.setTransform(0,-0.05);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).wait(78));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-488.5,-300,977,594);


// stage content:
(lib.Interface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,31];
	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		stage.enableMouseOver(10); 
		//this.strFrame = "strFrame1"
		this.nF = 1;
		this.fLaunchProduct = function()
		{
			if(this.mcAttachMovieClip)
			{
				this.removeChild(this.mcAttachMovieClip);
			}
			this.mcAttachMovieClip = new lib["mcMain"+this.nF];
			this.mcAttachMovieClip.x = 488.1;
			this.mcAttachMovieClip.y = 295.05;	
			this.mcAttachMovieClip.gotoAndPlay(this.strFrame);
			this.addChild(this.mcAttachMovieClip);	
			if(this.nF == 1)
			{
				this.play();
				this.fbAudio = main.playAudio('instruction');
			}
			this.nF = this.nF + 1;
		}
		//this.fLaunchProduct();
	}
	this.frame_31 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(31).call(this.frame_31).wait(1));

	// HEADING
	this.instance = new lib.heading_("synched",0);
	this.instance.setTransform(-184.35,21.25);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(6).to({_off:false},0).to({x:145.65},11,cjs.Ease.get(1)).wait(15));

	// bg1
	this.instance_1 = new lib.text01("synched",0);
	this.instance_1.setTransform(1426.5,70.05);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(12).to({_off:false},0).to({x:466.5},12,cjs.Ease.get(1)).to({x:476.5},6,cjs.Ease.get(1)).wait(2));

	// bg2
	this.instance_2 = new lib.gh();
	this.instance_2.setTransform(491.9,298.1);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({alpha:1},12).wait(20));

	// bg3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMUAt8MAAAhb3MCYpAAAMAAABb3g");
	this.shape.setTransform(488.5,294);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(32));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(157.1,285.6,1706.4,311);
// library properties:
lib.properties = {
	id: 'ECDF1A6AC5E395468828BABD79B3D8C3',
	width: 977,
	height: 588,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Interface_atlas_1.png?1638118560630", id:"Interface_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['ECDF1A6AC5E395468828BABD79B3D8C3'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;