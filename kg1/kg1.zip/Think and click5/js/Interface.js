(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Interface_atlas_1", frames: [[0,0,1954,1210],[1341,1212,431,377],[864,1659,503,282],[0,1212,812,533],[0,1747,862,179],[1673,1591,297,341],[814,1212,525,445],[1369,1591,302,390]]},
		{name:"Interface_atlas_2", frames: [[750,847,194,46],[510,0,302,54],[242,260,123,119],[510,56,123,119],[572,177,123,119],[635,56,123,119],[572,298,123,119],[572,419,123,119],[697,177,123,119],[814,0,123,119],[0,0,240,406],[0,660,730,78],[697,298,123,119],[697,419,123,119],[732,540,123,119],[732,661,123,119],[760,56,44,48],[939,0,63,44],[760,121,45,52],[822,121,123,119],[822,242,123,119],[822,363,123,119],[857,484,123,119],[242,0,266,258],[387,260,183,341],[857,605,123,119],[857,726,123,119],[0,740,123,119],[125,740,123,119],[572,540,116,84],[750,782,95,58],[0,408,385,250],[250,740,123,119],[375,740,123,119],[500,740,123,119],[625,782,123,119]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_236 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_235 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap10 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap12 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap13 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap14 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap15 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap16 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap17 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap18 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap19 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap20 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap21 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap22 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap23 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap24 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap25 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap26 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap27 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap28 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap29 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap30 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap31 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap32 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap33 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap34 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap35 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap36 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap37 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap38 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap39 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap40 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap41 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap42 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap44 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap45 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap8 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap9 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.trx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_236();
	this.instance.setTransform(-488.5,-302.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-488.5,-302.4,977,605);


(lib.text01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap2();
	this.instance.setTransform(-365,-37);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-365,-37,730,78);


(lib.t6i = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(0.5,1,1).p("ACpgzQgTAAgVAYQgVAZgDARQgDASAAAPQARAHAbAAQAaAAAfgNQAcgPgHgbQgIgUgXgRQgMgJgMgFgACIg7QARABAQAHAiIA2QA3gig1grQgggPgZASQgZARgFAUQgFAVADAQQAsAMArgMg");
	this.shape.setTransform(22.524,5.9875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(70));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjfAyQgDgQAFgVQAFgUAZgRQAZgSAgAPQA1Arg3AiQgWAGgVAAQgWAAgWgGgABmAsQAAgPADgSQADgRAVgZQAVgYATAAQAMAFAMAJQAXARAIAVQAHAagcAPQgfANgaAAQgbAAgRgHg");
	mask.setTransform(22.524,6.387);

	// Layer_6
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#333333").ss(0.5,1,1).p("ABFgPIAAAfQhHgphCApIAAgfg");
	this.shape_1.setTransform(38.2912,-0.945,1.2042,1.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F89129").s().p("AhEAQIAAgfICJAAIAAAfQhHgphCApg");
	this.shape_2.setTransform(38.2912,-0.945,1.2042,1.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#333333").ss(0.5,1,1).p("AhSgXIClAAIAAAtQhVgWhQAYg");
	this.shape_3.setTransform(38.275,-0.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F89129").s().p("AhSgXIClAAIAAAtQhVgWhQAYg");
	this.shape_4.setTransform(38.275,-0.325);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#333333").ss(0.5,1,1).p("AhSgdIClAAIAAA2QhVAAhQAFg");
	this.shape_5.setTransform(38.275,0.325);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F89129").s().p("AhSgdIClAAIAAA2QhVAAhQAFg");
	this.shape_6.setTransform(38.275,0.325);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#333333").ss(0.5,1,1).p("AhSgnIClAAIAABBQhUAWhRgPg");
	this.shape_7.setTransform(38.275,1.2541);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F89129").s().p("AhSAhIAAhIIClAAIAABBQgzAOgwAAQghAAghgHg");
	this.shape_8.setTransform(38.275,1.2541);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#333333").ss(0.5,1,1).p("AhSgxIClAAIAABLQhTAshSgjg");
	this.shape_9.setTransform(38.275,2.3454);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F89129").s().p("AhSAjIAAhUIClAAIAABLQgvAYguAAQgkAAgkgPg");
	this.shape_10.setTransform(38.275,2.3454);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#333333").ss(0.5,1,1).p("AhSg9IClAAIAABWQhTBDhSg4g");
	this.shape_11.setTransform(38.275,3.4572);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F89129").s().p("AhSAkIAAhhIClAAIAABWQguAlgsAAQgmAAglgag");
	this.shape_12.setTransform(38.275,3.4572);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#333333").ss(0.5,1,1).p("AhShIIClAAIAABgQhTBZhShLg");
	this.shape_13.setTransform(38.275,4.5597);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#F89129").s().p("AhSAmIAAhuIClAAIAABgQgtAxgsAAQgmAAgmgjg");
	this.shape_14.setTransform(38.275,4.5597);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#333333").ss(0.5,1,1).p("ABLAVQhLBmhKhXIAAhvICVAAg");
	this.shape_15.setTransform(38.2973,5.6702,1.1,1.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#F89129").s().p("AhKAkIAAhvICVAAIAABgQgoA3goAAQgjAAgigog");
	this.shape_16.setTransform(38.2973,5.6702,1.1,1.1);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},11).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_16},{t:this.shape_15}]},1).to({state:[{t:this.shape_16},{t:this.shape_15}]},4).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).to({state:[]},1).wait(40));

	// Layer_5
	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#333333").ss(0.5,1,1).p("ABFgPIAAAfQhHgphCApIAAgfg");
	this.shape_17.setTransform(6.7283,1.6,1.0947,1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#F89129").s().p("AhEAQIAAgfICJAAIAAAfQhHgphCApg");
	this.shape_18.setTransform(6.7283,1.6,1.0947,1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#333333").ss(0.5,1,1).p("AhKgVICVAAIAAApQhNgUhIAWg");
	this.shape_19.setTransform(6.725,2.175);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#F89129").s().p("AhKgVICVAAIAAApQhNgUhIAWg");
	this.shape_20.setTransform(6.725,2.175);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#333333").ss(0.5,1,1).p("AhKgbICVAAIAAAyQhNAAhIAFg");
	this.shape_21.setTransform(6.725,2.75);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#F89129").s().p("AhKgbICVAAIAAAyQhNAAhIAEg");
	this.shape_22.setTransform(6.725,2.75);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#333333").ss(0.5,1,1).p("AhKgjICVAAIAAA7QhMAUhJgNg");
	this.shape_23.setTransform(6.725,3.597);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#F89129").s().p("AhKAfIAAhCICVAAIAAA7QguAMgsAAQgeAAgdgFg");
	this.shape_24.setTransform(6.725,3.597);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#333333").ss(0.5,1,1).p("AhKgtICVAAIAABFQhLAohKggg");
	this.shape_25.setTransform(6.725,4.5939);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#F89129").s().p("AhKAgIAAhNICVAAIAABFQgrAWgpAAQghAAgggOg");
	this.shape_26.setTransform(6.725,4.5939);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#333333").ss(0.5,1,1).p("AhKg3ICVAAIAABOQhLA8hKgyg");
	this.shape_27.setTransform(6.725,5.6062);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#F89129").s().p("AhKAhIAAhYICVAAIAABOQgpAhgpAAQgiAAghgXg");
	this.shape_28.setTransform(6.725,5.6062);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#333333").ss(0.5,1,1).p("AhKhBICVAAIAABXQhLBRhKhEg");
	this.shape_29.setTransform(6.725,6.6017);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#F89129").s().p("AhKAjIAAhkICVAAIAABXQgpAsgoAAQgiAAgigfg");
	this.shape_30.setTransform(6.725,6.6017);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#333333").ss(0.5,1,1).p("ABLAVQhLBmhKhXIAAhvICVAAg");
	this.shape_31.setTransform(6.725,7.6095);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#F89129").s().p("AhKAkIAAhvICVAAIAABgQgoA3goAAQgjAAgigog");
	this.shape_32.setTransform(6.725,7.6095);

	var maskedShapeInstanceList = [this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29,this.shape_30,this.shape_31,this.shape_32];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_18},{t:this.shape_17}]},11).to({state:[{t:this.shape_20},{t:this.shape_19}]},1).to({state:[{t:this.shape_22},{t:this.shape_21}]},1).to({state:[{t:this.shape_24},{t:this.shape_23}]},1).to({state:[{t:this.shape_26},{t:this.shape_25}]},1).to({state:[{t:this.shape_28},{t:this.shape_27}]},1).to({state:[{t:this.shape_30},{t:this.shape_29}]},1).to({state:[{t:this.shape_32},{t:this.shape_31}]},1).to({state:[{t:this.shape_32},{t:this.shape_31}]},4).to({state:[{t:this.shape_30},{t:this.shape_29}]},1).to({state:[{t:this.shape_28},{t:this.shape_27}]},1).to({state:[{t:this.shape_26},{t:this.shape_25}]},1).to({state:[{t:this.shape_24},{t:this.shape_23}]},1).to({state:[{t:this.shape_22},{t:this.shape_21}]},1).to({state:[{t:this.shape_20},{t:this.shape_19}]},1).to({state:[{t:this.shape_18},{t:this.shape_17}]},1).to({state:[]},1).wait(40));

	// Layer_2
	this.instance = new lib.CachedBmp_235();
	this.instance.setTransform(5.3,2,0.2086,0.2086);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(70));

	// Layer_1
	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AjfAyQgDgQAFgVQAFgUAZgRQAZgSAgAPQA1Arg3AiQgWAGgVAAQgWAAgWgGgABmAsQAAgPADgSQADgRAVgZQAVgYATAAQAMAFAMAJQAXARAIAVQAHAagcAPQgfANgaAAQgbAAgRgHg");
	this.shape_33.setTransform(22.524,6.387);

	this.timeline.addTween(cjs.Tween.get(this.shape_33).wait(70));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,47.1,14);


(lib.right_wrong = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// _
	this.instance = new lib.Bitmap26();
	this.instance.setTransform(-26,-26);

	this.instance_1 = new lib.Bitmap24();
	this.instance_1.setTransform(-25,-22);

	this.instance_2 = new lib.Bitmap25();
	this.instance_2.setTransform(-31,-18);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-26,63,52);


(lib.leg_yak = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap45();
	this.instance.setTransform(-193,-125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-193,-125,385,250);


(lib.heading_ = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap1();
	this.instance.setTransform(-147,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-147,-28,302,54);


(lib.eye_yak = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_5
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(0.5,1,1).p("AAAiDQAxAAAjAmQAjAnAAA2QAAA3gjAmQgjAngxAAQgxAAgjgnQgigmAAg3QAAg2AignQAjgmAxAAg");
	this.shape.setTransform(-0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(71));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhUBdQgignAAg2QAAg1AigoQAjgmAxAAQAxAAAjAmQAjAoAAA1QAAA2gjAnQgjAngxAAQgxAAgjgng");
	mask.setTransform(-0.025,0);

	// Layer_6
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#333333").ss(0.5,1,1).p("Ai1BjIAAjFIFrAAIAADFQjXlWiUFWg");
	this.shape_1.setTransform(4.7882,-5.0725,0.9979,0.9979,40.3622);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#494747").s().p("Ai1BiIAAjDIFrAAIAADDQjXlViUFVg");
	this.shape_2.setTransform(4.7882,-5.0725,0.9979,0.9979,40.3622);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#333333").ss(0.5,1,1).p("AjJgqIB/iWIEUDrIh/CWQAKlOkeBjg");
	this.shape_3.setTransform(4.775,-5.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#494747").s().p("AjJgqIB/iWIEUDrIh/CWQAKlOkeBjg");
	this.shape_4.setTransform(4.775,-5.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#333333").ss(0.5,1,1).p("AjJgqIB/iWIEUDrIh/CWQglkOjvAjg");
	this.shape_5.setTransform(4.775,-5.075);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#494747").s().p("AjJgqIB/iWIEUDrIh/CWQglkOjvAjg");
	this.shape_6.setTransform(4.775,-5.075);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#333333").ss(0.5,1,1).p("AjJgqIB/iWIEUDrIh/CWQhSjNjCgeg");
	this.shape_7.setTransform(4.775,-5.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#494747").s().p("AjJgqIB/iWIEUDrIh/CWQhSjNjCgeg");
	this.shape_8.setTransform(4.775,-5.075);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#333333").ss(0.5,1,1).p("AjJgqIB/iWIEUDrIh/CWQiBiOiThdg");
	this.shape_9.setTransform(4.775,-5.075);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#494747").s().p("AjJgqIB/iWIEUDrIh/CWQiBiOiThdg");
	this.shape_10.setTransform(4.775,-5.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#333333").ss(0.5,1,1).p("AjJgqIB/iWIEUDrIh/CWQiwhOhkidg");
	this.shape_11.setTransform(4.775,-5.075);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#494747").s().p("AjJgqIB/iWIEUDrIh/CWQiwhOhkidg");
	this.shape_12.setTransform(4.775,-5.075);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#333333").ss(0.5,1,1).p("AjJgqIB/iWIEUDrIh/CWQjfgNg1jeg");
	this.shape_13.setTransform(4.775,-5.075);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#494747").s().p("AjJgqIB/iWIEUDrIh/CWQjfgNg1jeg");
	this.shape_14.setTransform(4.775,-5.075);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#333333").ss(0.5,1,1).p("Ai1AtIAAjEIFrAAIAADEQitDWi+jWg");
	this.shape_15.setTransform(1.3207,-0.9929,0.9979,0.9979,40.3622);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#494747").s().p("Ai1AtIAAjEIFrAAIAADEQhWBrhbAAQhbAAhfhrg");
	this.shape_16.setTransform(1.3207,-0.9929,0.9979,0.9979,40.3622);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},5).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_16},{t:this.shape_15}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).wait(52));

	// Layer_2
	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgXAaQgJgLAAgPQAAgOAJgLQAKgLANAAQAOAAAJALQAKALAAAOQAAAPgKALQgJALgOAAQgNAAgKgLg");
	this.shape_17.setTransform(0.675,-6.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AhYBiQglgpAAg5QAAg4AlgqQAlgoAzAAQA0AAAkAoQAlAqAAA4QAAA5glApQgkApg0AAQgzAAglgpg");
	this.shape_18.setTransform(-0.1678,-0.0553,0.5724,0.5724);

	var maskedShapeInstanceList = [this.shape_17,this.shape_18];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17}]}).wait(71));

	// Layer_1
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.rf(["#6A6A6A","#111111"],[0,1],-0.4,-0.6,0,-0.4,-0.6,13.7).s().p("AhUBdQgignAAg2QAAg1AigoQAjgmAxAAQAxAAAjAmQAjAoAAA1QAAA2gjAnQgjAngxAAQgxAAgjgng");
	this.shape_19.setTransform(-0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape_19).wait(71));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12.9,-14.2,25.8,28.4);


(lib.Elephant = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.Bitmap14();
	this.instance.setTransform(-208,-139);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-208,-139,431,377);


(lib.ear2_yak = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap42();
	this.instance.setTransform(-53,-29);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-53,-29,95,58);


(lib.ear1_yak = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap40();
	this.instance.setTransform(-58,-42);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-58,-42,116,84);


(lib.cat_mov = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.Bitmap19();
	this.instance.setTransform(-67,-168);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-67,-168,240,406);


(lib.btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("EgjAAHeIAAu7MBGBAAAIAAO7g");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-224.1,-47.8,448.2,95.6), null);


(lib.boy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_6
	this.instance = new lib.Bitmap27();
	this.instance.setTransform(-237,-110);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,0,0,0.102)").s().p("A7fDuQrZhjAAiLQAAiLLZhjQLZhiQGAAQQHAALZBiQLZBjAACLQAACLrZBjQrZBjwHAAQwGAArZhjg");
	this.shape.setTransform(14.875,164.5265,1,0.687);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-237,-110,503,297.7);


(lib.body_ayak = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap44();
	this.instance.setTransform(-263,-222);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-263,-222,525,445);


(lib.Apple = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap9();
	this.instance.setTransform(-99,-156);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-99,-156,302,390);


(lib.z = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap39();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.x = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap36();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.t = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap37();
	this.instance.setTransform(-62,-60);

	this.instance_1 = new lib.Bitmap38();
	this.instance_1.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.heads_yak = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.eye_yak();
	this.instance.setTransform(-3.85,43.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.Bitmap41();
	this.instance_1.setTransform(-149,-170);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-149,-170,297,341);


(lib.gh = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.trx();
	this.instance.setTransform(-3.4,-4.1);
	this.instance.alpha = 0.4805;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gh, new cjs.Rectangle(-491.9,-306.5,977,605), null);


(lib.box3_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap31();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box3_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap21();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box3_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap16();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box3_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap11();
	this.instance.setTransform(-62,-60);

	this.instance_1 = new lib.Bitmap12();
	this.instance_1.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap7();
	this.instance.setTransform(-62,-60);

	this.instance_1 = new lib.Bitmap8();
	this.instance_1.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box2_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap30();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box2_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap22();
	this.instance.setTransform(-62,-60);

	this.instance_1 = new lib.Bitmap23();
	this.instance_1.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap17();
	this.instance.setTransform(-62,-60);

	this.instance_1 = new lib.Bitmap18();
	this.instance_1.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap13();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap6();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap28();
	this.instance.setTransform(-62,-60);

	this.instance_1 = new lib.Bitmap29();
	this.instance_1.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap20();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap15();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap10();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap5();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.bbfb = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.t6i();
	this.instance.setTransform(67.4,70.5,2.3037,2.3037);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(2));

	// Layer_1
	this.instance_1 = new lib.Bitmap32();

	this.instance_2 = new lib.Bitmap33();
	this.instance_2.setTransform(69,95);

	this.instance_3 = new lib.Bitmap34();
	this.instance_3.setTransform(698,181);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,881,628);


(lib.yak = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// ear1_yak
	this.instance = new lib.ear1_yak("single",0);
	this.instance.setTransform(112.5,-6.25,1,1,0,0,0,43.6,-5.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({startPosition:0},0).to({scaleX:0.9997,scaleY:0.9997,rotation:-5.0569,x:118.8,y:-7.6},10,cjs.Ease.get(0.8)).wait(24).to({startPosition:0},0).to({scaleX:1,scaleY:1,rotation:0,x:112.5,y:-6.25},10,cjs.Ease.get(0.8)).wait(26).to({startPosition:0},0).to({scaleX:0.9994,scaleY:0.9994,rotation:9.8138,x:109.95,y:-4.45},12,cjs.Ease.get(0.8)).wait(28).to({startPosition:0},0).to({scaleX:1,scaleY:1,rotation:0,x:112.5,y:-6.25},12,cjs.Ease.get(0.8)).wait(20));

	// heads_yak
	this.instance_1 = new lib.heads_yak("single",0);
	this.instance_1.setTransform(210.8,-28,1,1,0,0,0,26.1,-19);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4).to({startPosition:0},0).to({regY:-19.1,scaleX:0.9997,scaleY:0.9997,rotation:-5.0569,x:214.8,y:-38},10,cjs.Ease.get(0.8)).wait(24).to({startPosition:0},0).to({regY:-19,scaleX:1,scaleY:1,rotation:0,x:210.8,y:-28},10,cjs.Ease.get(0.8)).wait(26).to({startPosition:0},0).to({scaleX:0.9994,scaleY:0.9994,rotation:9.8138,x:210.5,y:-9.15},12,cjs.Ease.get(0.8)).wait(28).to({startPosition:0},0).to({scaleX:1,scaleY:1,rotation:0,x:210.8,y:-28},12,cjs.Ease.get(0.8)).wait(20));

	// ear2_yak
	this.instance_2 = new lib.ear2_yak("single",0);
	this.instance_2.setTransform(283.5,-20.3,1,1,0,0,0,-33,-2.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(4).to({startPosition:0},0).to({regY:-2.4,scaleX:0.9997,scaleY:0.9997,rotation:-5.0569,x:287.95,y:-36.6},10,cjs.Ease.get(0.8)).wait(24).to({startPosition:0},0).to({regY:-2.5,scaleX:1,scaleY:1,rotation:0,x:283.5,y:-20.3},10,cjs.Ease.get(0.8)).wait(26).to({startPosition:0},0).to({regY:-2.4,scaleX:0.9994,scaleY:0.9994,rotation:9.8138,x:280.75,y:10.9},12,cjs.Ease.get(0.8)).wait(28).to({startPosition:0},0).to({regY:-2.5,scaleX:1,scaleY:1,rotation:0,x:283.5,y:-20.3},12,cjs.Ease.get(0.8)).wait(20));

	// body_ayak
	this.instance_3 = new lib.body_ayak("single",0);
	this.instance_3.setTransform(-77.85,234,1,1,0,0,0,-36.7,204.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({startPosition:0},0).to({scaleX:1.0128,skewY:-0.7199,x:-72.85},10,cjs.Ease.get(0.8)).wait(24).to({startPosition:0},0).to({scaleX:1,skewY:0,x:-77.85},10,cjs.Ease.get(0.8)).wait(26).to({startPosition:0},0).to({skewY:0.4319,x:-76.75,y:235.1},12,cjs.Ease.get(0.8)).wait(28).to({startPosition:0},0).to({skewY:0,x:-77.85,y:234},12,cjs.Ease.get(0.8)).wait(20));

	// leg_yak
	this.instance_4 = new lib.leg_yak("single",0);
	this.instance_4.setTransform(-68.5,331.25,1,1,0,0,0,-2.6,120.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(4).to({startPosition:0},0).to({startPosition:0},10,cjs.Ease.get(0.8)).wait(24).to({startPosition:0},0).to({startPosition:0},10,cjs.Ease.get(0.8)).wait(26).to({startPosition:0},0).to({startPosition:0},12,cjs.Ease.get(0.8)).wait(28).to({startPosition:0},0).to({startPosition:0},12,cjs.Ease.get(0.8)).wait(20));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-304.1,-199,669.5,535.2);


(lib.mcMain5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_75 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 1;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(75).call(this.frame_75).wait(1));

	// _
	this.mc_3 = new lib.box3_5();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,178.45);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_2 = new lib.box2_5();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,54.7);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.box_5();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3},{t:this.mc_1},{t:this.mc_2},{t:this.mc_3}]},75).wait(1));

	// box3
	this.instance = new lib.box3_5();
	this.instance.setTransform(566.5,178.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(59).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},3).wait(1));

	// box2
	this.instance_1 = new lib.box2_5();
	this.instance_1.setTransform(566.5,54.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(55).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},7).wait(1));

	// box
	this.instance_2 = new lib.box_5();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},12).wait(1));

	// elephant
	this.instance_3 = new lib.boy("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(39).to({_off:false},0).to({scaleX:1.05,scaleY:1.05},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(21));

	// box3
	this.instance_4 = new lib.box3_4();
	this.instance_4.setTransform(196.5,54.45);
	this.instance_4.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(10).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(48));

	// box2
	this.instance_5 = new lib.box2_4();
	this.instance_5.setTransform(196.5,178.7);
	this.instance_5.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(13).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(45));

	// box
	this.instance_6 = new lib.box_4();
	this.instance_6.setTransform(196.5,-69.05);
	this.instance_6.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(8).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(50));

	// elephant
	this.instance_7 = new lib.cat_mov("single",0);
	this.instance_7.setTransform(-179.05,9.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(4).to({startPosition:0},0).to({scaleX:1.1,scaleY:1.1},6).to({scaleX:0.1,scaleY:0.1},11,cjs.Ease.get(-1)).to({_off:true},1).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-427.8,-175.3,1086.3,446.6);


(lib.mcMain4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_84 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 3;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(84).call(this.frame_84).wait(1));

	// _
	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.mc_2 = new lib.box3_4();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,54.45);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_3 = new lib.box2_4();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,178.7);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.box_4();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_3},{t:this.mc_2},{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},84).wait(1));

	// box3
	this.instance = new lib.box3_4();
	this.instance.setTransform(566.5,54.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(60).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},11).wait(1));

	// box2
	this.instance_1 = new lib.box2_4();
	this.instance_1.setTransform(566.5,178.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(56).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},15).wait(1));

	// box
	this.instance_2 = new lib.box_4();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(51).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},20).wait(1));

	// elephant
	this.instance_3 = new lib.cat_mov("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(40).to({_off:false},0).to({scaleX:1.05,scaleY:1.05},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(29));

	// box3
	this.instance_4 = new lib.box3_3();
	this.instance_4.setTransform(196.5,55.45);
	this.instance_4.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(11).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(56));

	// box2
	this.instance_5 = new lib.box2_3();
	this.instance_5.setTransform(196.5,180.7);
	this.instance_5.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(14).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(53));

	// box
	this.instance_6 = new lib.box_3();
	this.instance_6.setTransform(196.5,-69.05);
	this.instance_6.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(9).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(58));

	// elephant
	this.instance_7 = new lib.Elephant("single",0);
	this.instance_7.setTransform(-179.05,9.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(5).to({startPosition:0},0).to({scaleX:1.1,scaleY:1.1},6).to({scaleX:0.1,scaleY:0.1},11,cjs.Ease.get(-1)).to({_off:true},1).wait(62));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-407.8,-166.9,1066.3,438.20000000000005);


(lib.mcMain3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_80 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 3;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(80).call(this.frame_80).wait(1));

	// _
	this.mc_2 = new lib.box3_3();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,55.45);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.mc_3 = new lib.box2_3();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,180.7);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.box_3();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_3},{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3},{t:this.mc_2}]},80).wait(1));

	// box3
	this.instance = new lib.box3_3();
	this.instance.setTransform(566.5,55.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(59).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},8).wait(1));

	// box2
	this.instance_1 = new lib.box2_3();
	this.instance_1.setTransform(566.5,180.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(54).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},13).wait(1));

	// box
	this.instance_2 = new lib.box_3();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(49).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},18).wait(1));

	// elephant
	this.instance_3 = new lib.Elephant("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(38).to({_off:false},0).to({scaleX:1.05,scaleY:1.05,alpha:1},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(27));

	// box3
	this.instance_4 = new lib.box3_2();
	this.instance_4.setTransform(196.5,54.45);
	this.instance_4.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(8).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(55));

	// box2
	this.instance_5 = new lib.box2_2();
	this.instance_5.setTransform(196.5,178.7);
	this.instance_5.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(11).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(52));

	// box
	this.instance_6 = new lib.box_2();
	this.instance_6.setTransform(196.5,-69.05);
	this.instance_6.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(6).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(57));

	// ani
	this.instance_7 = new lib.Apple("single",0);
	this.instance_7.setTransform(-179.05,9.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(2).to({startPosition:0},0).to({scaleX:1.1,scaleY:1.1},6).to({scaleX:0.1,scaleY:0.1},11,cjs.Ease.get(-1)).to({_off:true},1).wait(61));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-397.4,-162.1,1055.9,432.79999999999995);


(lib.Doll = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.yak();
	this.instance.setTransform(19.5,4.15,0.7179,0.7179);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-198.8,-134.3,475.7,379.8);


(lib.bhbf = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(58));

	// bbfb
	this.instance = new lib.bbfb("single",0);
	this.instance.setTransform(203.8,173.1,1,1,0,0,0,203.8,173.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleY:0.9724,rotation:-15.0003,y:185.55},9).to({scaleY:1,rotation:15,x:212.4,y:155.8},14).to({rotation:0,x:203.8,y:173.1},10).wait(25));

	// bbfb
	this.instance_1 = new lib.bbfb("single",1);
	this.instance_1.setTransform(474.1,624.6,1,1,0,0,0,474.1,624.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleY:0.9724},9).to({scaleY:1.0405,skewX:1.7168},14).to({scaleY:1,skewX:0},10).wait(25));

	// bbfb
	this.instance_2 = new lib.bbfb("single",2);
	this.instance_2.setTransform(697.4,180.8,1,1,0,0,0,697.4,180.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regY:180.7,scaleY:0.9724,rotation:-15.0003,x:690.9,y:202.95},9).to({regY:180.8,scaleX:0.9997,scaleY:0.9997,rotation:4.7707,x:697.4,y:180.75},14).to({scaleX:1,scaleY:1,rotation:0,y:180.8},10).to({regY:180.7,scaleY:0.9724,rotation:-15.0003,x:690.9,y:202.95},8).to({regY:180.8,scaleX:0.9997,scaleY:0.9997,rotation:4.7707,x:697.4,y:180.75},8).to({scaleX:1,scaleY:1,rotation:0,y:180.8},8).wait(1));

	// Layer_5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,0,0,0.149)").s().p("EgvmAJ4QzukIABlwQgBlwTukHQTtkIb5AAQb6AATtEIQTtEHAAFwQAAFwztEIQztEI76AAQ75AAztkIg");
	this.shape.setTransform(475.65,553.875);

	this.instance_3 = new lib.Bitmap35();
	this.instance_3.setTransform(45,464);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_3}]},18).wait(40));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.6,-64.1,990.7,707.6);


(lib.tiger = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_6
	this.mcTiger = new lib.bhbf();
	this.mcTiger.name = "mcTiger";
	this.mcTiger.setTransform(-209.15,-146.95,0.5115,0.5115);

	this.timeline.addTween(cjs.Tween.get(this.mcTiger).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-209.1,-146.9,463.6,329.1);


(lib.mcMain6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_70 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 2;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					//this.parent.fLaunchProduct();
					this.play();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				//this.parent.fLaunchProduct();
				this.play();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}
	this.frame_71 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_90 = function() {
		/* stop();
		this.blnPlay = false;
		mcTiger.mcTiger.stop();
		mcTiger.mcTiger.blnPlay = false;
		fCalculateScore();
		function fCalculateScore() {
			var nPercentage = (__nScore/6)*100;
			nPercentage = Math.ceil(nPercentage);
			trace(nPercentage + "---------------------");
			if (nPercentage < 70) {
				MovieClip(parent.parent.parent).mcFinal.mcRank.gotoAndPlay("rank2");		
			} else {
				MovieClip(parent.parent.parent).mcFinal.mcRank.gotoAndPlay("rank1_1");
			}
		}*/
		
		this.stop();
		//alert("endSlide");
		main.showRestartBtn();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(70).call(this.frame_70).wait(1).call(this.frame_71).wait(19).call(this.frame_90).wait(1));

	// _
	this.mc_3 = new lib.z();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,178.45);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_2 = new lib.t();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,54.7);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.x();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3},{t:this.mc_1},{t:this.mc_2},{t:this.mc_3}]},70).wait(21));

	// box3
	this.instance = new lib.z();
	this.instance.setTransform(566.5,178.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(54).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},3).wait(1).to({_off:false},0).wait(20));

	// box2
	this.instance_1 = new lib.t();
	this.instance_1.setTransform(566.5,54.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(50).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},7).wait(1).to({_off:false},0).wait(20));

	// box
	this.instance_2 = new lib.x();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(45).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},12).wait(1).to({_off:false},0).wait(20));

	// elephant
	this.instance_3 = new lib.tiger("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3._off = true;

	this.mcTiger = new lib.tiger();
	this.mcTiger.name = "mcTiger";
	this.mcTiger.setTransform(-179.05,9.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},34).to({state:[{t:this.instance_3}]},11).to({state:[{t:this.instance_3}]},5).to({state:[{t:this.mcTiger}]},1).wait(40));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(34).to({_off:false},0).to({scaleX:1.05,scaleY:1.05},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).to({_off:true},1).wait(40));

	// box3
	this.instance_4 = new lib.box3_5();
	this.instance_4.setTransform(196.5,178.45);
	this.instance_4.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(13).to({x:179.6},5).to({x:586.5},13,cjs.Ease.get(-1)).to({_off:true},1).wait(59));

	// box2
	this.instance_5 = new lib.box2_5();
	this.instance_5.setTransform(196.5,54.7);
	this.instance_5.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(10).to({x:179.6},5).to({x:586.5},13,cjs.Ease.get(-1)).to({_off:true},1).wait(62));

	// box
	this.instance_6 = new lib.box_5();
	this.instance_6.setTransform(196.5,-69.05);
	this.instance_6.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(7).to({x:179.6},5).to({x:586.5},13,cjs.Ease.get(-1)).to({_off:true},1).wait(65));

	// elephant
	this.instance_7 = new lib.boy("single",0);
	this.instance_7.setTransform(-179.05,9.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(4).to({startPosition:0},0).to({scaleX:1.1,scaleY:1.1},6).to({scaleX:0.1,scaleY:0.1},13,cjs.Ease.get(-1)).to({_off:true},1).wait(67));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-439.7,-151,1103.2,418.5);


(lib.mcMain2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_73 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 2;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(73).call(this.frame_73).wait(1));

	// _
	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.mc_3 = new lib.box2_2();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,178.7);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_2 = new lib.box3_2();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,54.7);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.box_2();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},73).wait(1));

	// box3
	this.instance = new lib.box3_2();
	this.instance.setTransform(566.5,49.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(52).to({_off:false},0).to({x:186.5,y:54.45},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},8).wait(1));

	// box2
	this.instance_1 = new lib.box2_2();
	this.instance_1.setTransform(566.5,171.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(56).to({_off:false},0).to({x:186.5,y:178.7},8,cjs.Ease.get(1)).to({x:196.5,y:178.45},5,cjs.Ease.get(1)).to({_off:true},4).wait(1));

	// box
	this.instance_2 = new lib.box_2();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(47).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},13).wait(1));

	// ani
	this.instance_3 = new lib.Apple("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(36).to({_off:false},0).to({scaleX:1.05,scaleY:1.05},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(22));

	// box3
	this.instance_4 = new lib.box3();
	this.instance_4.setTransform(196.5,178.45);
	this.instance_4.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(14).to({x:186.5},6,cjs.Ease.get(1)).to({x:576.5},13,cjs.Ease.get(1)).to({_off:true},1).wait(40));

	// box2
	this.instance_5 = new lib.box2();
	this.instance_5.setTransform(196.5,54.7);
	this.instance_5.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(9).to({x:186.5},6,cjs.Ease.get(1)).to({x:576.5},13,cjs.Ease.get(1)).to({_off:true},1).wait(45));

	// box
	this.instance_6 = new lib.box();
	this.instance_6.setTransform(196.5,-69.05);
	this.instance_6.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(5).to({x:186.5},6,cjs.Ease.get(1)).to({x:576.5},13,cjs.Ease.get(1)).to({_off:true},1).wait(49));

	// ani
	this.instance_7 = new lib.Doll("single",0);
	this.instance_7.setTransform(-179.05,9.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(2).to({startPosition:0},0).to({scaleX:1.1,scaleY:1.1},4,cjs.Ease.get(1)).to({scaleX:0.1,scaleY:0.1},10,cjs.Ease.get(1)).to({_off:true},1).wait(57));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-397.7,-154.3,1056.2,433.7);


(lib.mcMain1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;
		var objRef = this;
		var __nCorrectAnswer = 0;
		var blnLastQuestion = false;
		var blnOk = false;
		var __nScore = 0;
		var blnEnd = false;
		function init() {
			for (var i:Number = 1; objRef["mc_"+i] != null; i++) {
				objRef["mc_"+i].id = i;
				objRef["mc_" + i].addEventListener(MouseEvent.CLICK, fClickEvent);
				objRef["mc_"+i].buttonMode = true;
			}
		}
		
		function fClickEvent(e) {
			mcFish.gotoAndPlay(2);
			fRemoveListeners();
			if (e.currentTarget.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.gotoAndStop(2);
				blnOk = true;
				var mcRight = new Right();
				objRef.addChild(mcRight);
				objRef["mcTick_" + e.currentTarget.id].gotoAndStop(3);
				return;
			}
			blnOk = false;
			var mcWrong = new ShowAnswer();
			objRef.addChild(mcWrong);
			objRef["mcTick_" + e.currentTarget.id].gotoAndStop(2);
		}
		function fShowCorrectAnswer() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(2);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(3);
		}
		function fChangeQuestion() {
			if (!blnLastQuestion) {
		
			}
			fRemoveListeners();
			play();
		}
		function fRemoveListeners() {
			for (var i:Number = 1; objRef["mc_"+i] != null; i++) {
				if (!blnEnd) {
					objRef["mc_" + i].gotoAndStop(1);
				}
				objRef["mc_" + i].removeEventListener(MouseEvent.CLICK, fClickEvent);
				objRef["mc_"+i].buttonMode = false;
			}
		}*/
	}
	this.frame_59 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 1;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(59).call(this.frame_59).wait(1));

	// _
	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.mc_3 = new lib.box3();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,178.45);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_2 = new lib.box2();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,54.7);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.box();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},59).wait(1));

	// box3
	this.instance = new lib.box3();
	this.instance.setTransform(566.5,178.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(41).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},5).wait(1));

	// box2
	this.instance_1 = new lib.box2();
	this.instance_1.setTransform(566.5,54.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(37).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},9).wait(1));

	// box
	this.instance_2 = new lib.box();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(32).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},14).wait(1));

	// ani
	this.instance_3 = new lib.Doll("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(21).to({_off:false},0).to({scaleX:1.05,scaleY:1.05},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(23));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-387.8,-151,1046.3,418.5);


// stage content:
(lib.Interface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
		stage.enableMouseOver(10); 
		//this.strFrame = "strFrame1"
		this.nF = 1;
		this.fLaunchProduct = function()
		{
			if(this.mcAttachMovieClip)
			{
				this.removeChild(this.mcAttachMovieClip);
			}
			this.mcAttachMovieClip = new lib["mcMain"+this.nF];
			this.mcAttachMovieClip.x = 488.1;
			this.mcAttachMovieClip.y = 295.05;	
			this.mcAttachMovieClip.gotoAndPlay(this.strFrame);
			this.addChild(this.mcAttachMovieClip);	
			if(this.nF == 1)
			{
				//this.play();
				this.fbAudio = main.playAudio('instruction');
			}
			this.nF = this.nF + 1;
		}
		//this.fLaunchProduct();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// HEADING
	this.instance = new lib.heading_("synched",0);
	this.instance.setTransform(145.65,21.25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.text01("synched",0);
	this.instance_1.setTransform(472.45,83.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// bg
	this.instance_2 = new lib.gh();
	this.instance_2.setTransform(491.9,298.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(487.2,285.6,489.8,311);
// library properties:
lib.properties = {
	id: 'ECDF1A6AC5E395468828BABD79B3D8C3',
	width: 977,
	height: 588,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Interface_atlas_1.png?1638118537355", id:"Interface_atlas_1"},
		{src:"images/Interface_atlas_2.png?1638118537356", id:"Interface_atlas_2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['ECDF1A6AC5E395468828BABD79B3D8C3'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;