(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Interface_atlas_1", frames: [[925,596,31,31],[925,684,298,377],[1225,684,375,257],[1489,0,533,306],[216,1173,155,173],[2024,0,18,24],[990,0,497,497],[1992,611,52,11],[925,642,33,11],[1451,943,129,117],[1834,890,169,210],[1937,842,65,37],[794,1126,214,138],[1442,1176,163,144],[1992,624,52,11],[1992,650,33,11],[0,1313,129,117],[1834,1102,169,210],[1105,1063,65,37],[1010,1129,214,138],[1607,1176,163,144],[925,629,52,11],[925,655,33,11],[1772,1314,129,117],[452,1126,169,210],[373,1173,65,37],[1226,1129,214,138],[794,1266,163,144],[1937,783,86,57],[1602,684,333,204],[452,987,86,57],[0,781,333,204],[373,1212,65,37],[0,1173,214,138],[959,1269,163,144],[540,987,86,57],[1242,1269,186,110],[335,781,333,204],[1992,637,52,11],[1992,663,33,11],[1903,1314,129,117],[623,1126,169,210],[1451,1076,381,98],[2024,26,13,13],[2016,308,29,38],[990,499,923,183],[1489,308,224,184],[670,781,218,274],[1124,1269,116,197],[1941,308,73,301],[1937,611,53,170],[0,0,988,594],[1715,308,224,184],[1602,890,224,184],[1225,943,224,184],[452,1063,651,61],[1430,1322,235,54],[0,596,923,183],[0,987,224,184],[226,987,224,184]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_212 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_211 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_210 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_209 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_208 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_207 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_206 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_205 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_204 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_203 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_228 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_227 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_200 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_199 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_198 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_197 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_196 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_226 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_225 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_193 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_192 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_191 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_190 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_189 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_224 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_223 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_186 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_185 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_184 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_182 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_181 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_179 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_222 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_177 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_176 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_175 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_183 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_173 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_172 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_171 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_170 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_221 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_168 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_167 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_166 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap10 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap12 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap13 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap14 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap15 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap3 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap4 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap8 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap9 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.vbcbcbcv = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap14();
	this.instance.setTransform(-26,-85);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-85,53,170);


(lib.torleg4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#E8BD84").ss(0.5,1,1).p("ABIgyQAIgXAZgWQAZgWAjAGQAjAFAWA1QAEAKADAMABIgyQADAIADAKQAWBGgLBGQhDAFhIAAQgZAAgZgBADngcQANAvAABCQghAIguAGQgOACgOADQgYABgYADAhbggQg5g/gpATQgqASgIArQgFAXACAiQABAaAFAfQAVAFAaADQAmADAvACQACAAACAAQAOg4gCg0QgBgRgCgTQAGgzA4gXQA3gaAuBS");
	this.shape.setTransform(-3.7687,-11.3393);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#517924").ss(0.5,1,1).p("ADogoQAFgyAYgrQAAgDADgCQADAGAFAJQADAIAFAJADOHZQBOgTALgcQAVgzgRhSQgIgsgmhzQgZhOABhAQAAgQADgQACdnhQB8B5A8BzQAcA5AHA0QATCTijgzAkSHnQhggTgDgpQgZmlCJlWQAMgjAPggQASgqAWgpAg0neQC/B2B9De");
	this.shape_1.setTransform(0.0065,-50.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F2DBBB").s().p("AhdBwQAOg4gCg0IgDgkIADAkQghgbgcAAQgVAAgIAOQgOAUAAA9QAAAOADAVQgagDgVgFQgFgfgBgaQgCgiAFgXQAIgrAqgSQApgTA5A/QAGgzA4gXQA3gaAuBSIAGASIgGgSQAIgXAZgWQAZgWAjAGQAjAFAWA1QAEAKADAMQgEgLgSgGQgRgIgRAAQgVAAgMATQgQAWAAAmQAAAjANAuQgYABgYADQALhGgWhGQgOgKgegIQgYgGgMAAQgNAAgNAOQgcAdAABHQAAAeAGAZQgZAAgZgBg");
	this.shape_2.setTransform(-4.4937,-11.3393);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F8EBDA").s().p("AhSAeQAAhHAdgdQAMgOAOAAQANAAAXAGQAeAIAOAJQAWBGgLBHQhDAFhIAAQgHgaAAgdgAiBBTQgvgBgmgDQgDgVAAgOQAAg8AOgVQAIgOAUAAQAdAAAhAcQABAzgOA3IgDAAgABigEQAAgnAQgWQANgTAUAAQASAAARAHQARAHAFALQAAAAAAABQAAAAAAAAQABABAAAAQAAABABAAQAMAvAABBQghAJguAGIgcAEQgNgtAAgig");
	this.shape_3.setTransform(-1.225,-8.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6FA532").s().p("Ak8GrQgZmlCJlWQAMgjAPggQASgqAWgpQBAAHBNABQDAB2B9DeQgDACAAADQgHgEgGgKIgWgeIgvgxQgQgQgUgZQgWgZglgeQgkgegxgtQgygwgnAAQhhAAgkB2IgPAxIgDADQgIAIAAALQAAAGADAHIAAACQhFDSgFBVQgGBTgFBmQgGBmADAaQAIBEAbAAIATgFQABAaAFAfQhggTgDgpg");
	this.shape_4.setTransform(-5.6929,-50.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#517924").s().p("AhADsQgDgFAAgGQAAgEADgFQAFgFAGAAQAHAAADAFQAEAFAAAEQAAAGgEAFQgDAFgHAAQgGAAgFgFgAiwB2QgGgFAAgHQAAgHAGgGQAFgFAIABQAIgBAFAFQAEAGAAAHQAAAHgEAFQgFAGgIABQgIgBgFgGgAA5BlQgHgFAAgHQAAgHAHgHQAEgEAIAAQAIAAAFAEQAEAHAAAHQAAAHgEAFQgFAGgIAAQgIAAgEgGgAhQArQgHgHAAgLQAAgJAHgIQAIgIAKAAQALAAAGAIQAIAIAAAJQAAALgIAHQgGAHgLABQgKgBgIgHgAB5gfQgJgJAAgPQAAgPAJgLQALgJAOAAQAQAAAKAJQALALAAAPQAAAPgLAJQgKAMgQAAQgOAAgLgMgAgCgbQgHgHAAgJQAAgKAHgGQAFgGAJAAQAKAAAGAGQAIAGAAAKQAAAJgIAHQgGAHgKABQgJgBgFgHgAiTgmIgFgGIAAgCQgDgHAAgGQAAgLAIgIIADgDQAIgFAJAAQALABAIAHQAKAIAAALQAAANgKAIQgIAHgLAAQgMAAgIgHgAg9ikQgMgNAAgTQAAgRAMgOQANgNATAAQARAAAMANQAOAOAAARQAAATgOANQgMAOgRAAQgTAAgNgOg");
	this.shape_5.setTransform(-9.325,-69.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#88C641").s().p("ADQFaQgBgBAAAAQAAAAgBgBQAAAAAAAAQAAgBAAAAQgDgNgFgJQgWg2gjgFQgigGgZAWQgaAWgIAYQgthSg4AZQg3AYgGAyQg5g/gpATQgrATgIArQgEAXABAjIgTAFQgaAAgIhEQgDgbAGhlQAFhmAGhUQAFhUBFjTIAFAGQAIAIAMAAQALAAAIgIQAKgHAAgNQAAgLgKgIQgIgIgLAAQgJAAgIAFIAOgxQAkh2BiAAQAnAAAyAvQAxAuAkAeQAkAeAWAZQAVAZAPAQIAwAxIAWAeQAGAJAGAFQgXAqgFAzQgDAQAAAPQgCBBAZBOQAmBzAIAsQARBSgUAyQgLAchPATQAAhCgMgvgAiPAGQgDAEAAAFQAAAGADAFQAFAFAGAAQAHAAADgFQAEgFAAgGQAAgFgEgEQgDgFgHAAQgGAAgFAFgAj/h0QgGAGAAAGQAAAIAGAFQAFAGAIAAQAIAAAFgGQAEgFAAgIQAAgGgEgGQgFgFgIAAQgIAAgFAFgAgViGQgHAHAAAGQAAAIAHAFQAEAGAIAAQAIAAAEgGQAEgFAAgIQAAgGgEgHQgEgEgIAAQgIAAgEAEgAifjJQgHAIAAAJQAAALAHAGQAIAIAKAAQALAAAGgIQAIgGAAgLQAAgJgIgIQgGgIgLAAQgKAAgIAIgAAqkjQgJALAAAOQAAAQAJAJQALALAOAAQAQAAAKgLQALgJAAgQQAAgOgLgLQgKgKgQAAQgOAAgLAKgAhRkNQgHAGAAAKQAAAJAHAGQAGAIAJAAQAKAAAGgIQAIgGAAgJQAAgKgIgGQgGgGgKAAQgJAAgGAGgAiMm2QgMAPAAARQAAATAMAMQANAPATAAQARAAANgPQAOgMAAgTQAAgRgOgPQgNgMgRAAQgTAAgNAMg");
	this.shape_6.setTransform(-1.4397,-48.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F1C256").s().p("Ag3CQQAFgyAXgrQAAgDADgBIAIAOIAIARQgWhRgQgZQgTgcgHgQQgQgeAAgYQAAgfAWAAQAjAAAkApQATARAdAnQAcA5AGAzQAOBuhVAAQgdAAgqgOg");
	this.shape_7.setTransform(28.8744,-68.649);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E1A413").s().p("AB/CqIgIgOQh7jdjAh3IBYAAIAQAAIBogCQB9B4A8ByQgdgmgSgRQgmgpgjAAQgWAAAAAgQAAAWAQAeQAHAQAUAcQAPAZAWBSIgIgRg");
	this.shape_8.setTransform(14.45,-79.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-38.8,-99.8,77.6,100.8);


(lib.torleg3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D09711").ss(0.5,1,1).p("ADKDLQgDABAAADADKDLQADAGAFAIQADAIAFAJAkZhgQgohFAIg8QAIg7AzgUQA4gWBVAkQBgApBwBtQB/B8A5BvQAcA5AHA0QATCUijg0Ajti8QgGgDgGgCAjti8QEmCCCREF");
	this.shape.setTransform(6.2338,-84.2162);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#E8BD84").ss(0.5,1,1).p("ABIgyQAIgXAZgWQAZgWAjAGQAjAFAWA1QAEAKADAMABIgyQADAIADAKQAWBGgLBGQhDAFhIAAQgZAAgZgBADngcQANAvAABCQghAIguAGQgOACgOADQgYABgYADAhbggQg5g/gpATQgqASgIArQgFAXACAiQABAaAFAfQAVAFAaADQAmADAvACQACAAACAAQAOg4gCg0QgBgRgCgTQAGgzA4gXQA3gaAuBS");
	this.shape_1.setTransform(-3.7687,-11.3393);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#517924").ss(0.5,1,1).p("ADyHuQBOgTALgcQAVgygRhSQgIgsgmhzQgZhOABhCQAAgOADgQQAFgzAYgqAjuH9QhggTgDgpQgZmlCJlWQAMgjAPggQAHgRAIgRQAMgYAehAQABgCABgD");
	this.shape_2.setTransform(-3.5576,-52.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F2DBBB").s().p("AhdBwQAOg4gCg0IgDgkIADAkQghgbgcAAQgVAAgIAOQgOAUAAA9QAAAOADAVQgagDgVgFQgFgfgBgaQgCgiAFgXQAIgrAqgSQApgTA5A/QAGgzA4gXQA3gaAuBSIAGASIgGgSQAIgXAZgWQAZgWAjAGQAjAFAWA1QAEAKADAMQgEgLgSgGQgRgIgRAAQgVAAgMATQgQAWAAAmQAAAjANAuQgYABgYADQALhGgWhGQgOgKgegIQgYgGgMAAQgNAAgNAOQgcAdAABHQAAAeAGAZQgZAAgZgBg");
	this.shape_3.setTransform(-4.4937,-11.3393);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F8EBDA").s().p("AhSAeQAAhHAdgdQAMgOAOAAQANAAAXAGQAeAIAOAJQAWBGgLBHQhDAFhIAAQgHgaAAgdgAiBBTQgvgBgmgDQgDgVAAgOQAAg8AOgVQAIgOAUAAQAdAAAhAcQABAzgOA3IgDAAgABigEQAAgnAQgWQANgTAUAAQASAAARAHQARAHAFALQAAAAAAABQAAAAAAAAQABABAAAAQAAABABAAQAMAvAABBQghAJguAGIgcAEQgNgtAAgig");
	this.shape_4.setTransform(-1.225,-8.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#517924").s().p("AhADsQgDgFAAgGQAAgEADgFQAFgFAGAAQAHAAADAFQAEAFAAAEQAAAGgEAFQgDAFgHAAQgGAAgFgFgAiwB2QgGgFAAgHQAAgHAGgGQAFgFAIABQAIgBAFAFQAEAGAAAHQAAAHgEAFQgFAGgIABQgIgBgFgGgAA5BlQgHgFAAgHQAAgHAHgHQAEgEAIAAQAIAAAFAEQAEAHAAAHQAAAHgEAFQgFAGgIAAQgIAAgEgGgAhQArQgHgHAAgLQAAgJAHgIQAIgIAKAAQALAAAGAIQAIAIAAAJQAAALgIAHQgGAHgLABQgKgBgIgHgAB5gfQgJgJAAgPQAAgPAJgLQALgJAOAAQAQAAAKAJQALALAAAPQAAAPgLAJQgKAMgQAAQgOAAgLgMgAgCgbQgHgHAAgJQAAgKAHgGQAFgGAJAAQAKAAAGAGQAIAGAAAKQAAAJgIAHQgGAHgKABQgJgBgFgHgAiTgmIgFgGIAAgCQgDgHAAgGQAAgLAIgIIADgDQAIgFAJAAQALABAIAHQAKAIAAALQAAANgKAIQgIAHgLAAQgMAAgIgHgAg9ikQgMgNAAgTQAAgRAMgOQANgNATAAQARAAAMANQAOAOAAARQAAATgOANQgMAOgRAAQgTAAgNgOg");
	this.shape_5.setTransform(-9.325,-69.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#6FA532").s().p("Ak8HBQgZmlCJlWQAMgjAPggIAQgiIAphYIACgFIAAABQEnCCCQEFQgDACAAADQgHgFgGgJIgWgeIgvgxQgQgQgUgZQgWgZglgeQgkgegxguQgygvgnAAQhhAAgkB2IgPAxIgDADQgIAIAAALQAAAGADAHIAAABQhFDTgFBUQgGBUgFBmQgGBlADAbQAIBEAbAAIATgFQABAZAFAgQhggTgDgpg");
	this.shape_6.setTransform(-5.6929,-52.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#88C641").s().p("ADQFaQgBgBAAAAQAAAAgBgBQAAAAAAAAQAAgBAAAAQgDgNgFgJQgWg2gjgFQgigGgZAWQgaAWgIAYQgthSg4AZQg3AYgGAyQg5g/gpATQgrATgIArQgEAXABAjIgTAFQgaAAgIhEQgDgbAGhlQAFhmAGhUQAFhUBFjTIAFAGQAIAIAMAAQALAAAIgIQAKgHAAgNQAAgLgKgIQgIgIgLAAQgJAAgIAFIAOgxQAkh2BiAAQAnAAAyAvQAxAuAkAeQAkAeAWAZQAVAZAPAQIAwAxIAWAeQAGAJAGAFQgXAqgFAzQgDAQAAAPQgCBBAZBOQAmBzAIAsQARBSgUAyQgLAchPATQAAhCgMgvgAiPAGQgDAEAAAFQAAAGADAFQAFAFAGAAQAHAAADgFQAEgFAAgGQAAgFgEgEQgDgFgHAAQgGAAgFAFgAj/h0QgGAGAAAGQAAAIAGAFQAFAGAIAAQAIAAAFgGQAEgFAAgIQAAgGgEgGQgFgFgIAAQgIAAgFAFgAgViGQgHAHAAAGQAAAIAHAFQAEAGAIAAQAIAAAEgGQAEgFAAgIQAAgGgEgHQgEgEgIAAQgIAAgEAEgAifjJQgHAIAAAJQAAALAHAGQAIAIAKAAQALAAAGgIQAIgGAAgLQAAgJgIgIQgGgIgLAAQgKAAgIAIgAAqkjQgJALAAAOQAAAQAJAJQALALAOAAQAQAAAKgLQALgJAAgQQAAgOgLgLQgKgKgQAAQgOAAgLAKgAhRkNQgHAGAAAKQAAAJAHAGQAGAIAJAAQAKAAAGgIQAIgGAAgJQAAgKgIgGQgGgGgKAAQgJAAgGAGgAiMm2QgMAPAAARQAAATAMAMQANAPATAAQARAAANgPQAOgMAAgTQAAgRgOgPQgNgMgRAAQgTAAgNAMg");
	this.shape_7.setTransform(-1.4397,-48.775);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F1C256").s().p("Ag3CQQAFgyAXgrQAAgDADgBIAIAOIAIARQgWhRgQgZQgTgcgHgQQgQgeAAgYQAAgfAWAAQAjAAAkApQATARAdAnQAcA5AGAzQAOBuhVAAQgdAAgqgOg");
	this.shape_8.setTransform(28.8744,-68.649);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E1A413").s().p("ADkEAIgIgOQiRkEkmiCIAAgBIgMgFIAMAFIgCAFIgpBYQgphFAIg8QAIg7AzgVQA4gWBVAkQBfApBxBuQB/B7A5BwQgcgngTgSQgmgpgjAAQgWAAAAAgQAAAXAQAeQAIAQATAcQAQAaAWBSIgIgSgAjbiVIAAAAg");
	this.shape_9.setTransform(4.4094,-88.1922);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-38.8,-116.6,77.6,117.6);


(lib.torleg2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D09711").ss(0.5,1,1).p("Ak7BwQg1gwgKgwQgIgsAgglQBuiCDzASQBRAGBCAYQCMAtBKByQAkA7gbAtQgZAuhSATAEfBdQk1j3kQCw");
	this.shape.setTransform(1.293,-93.2042);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#E8BD84").ss(0.5,1,1).p("AgUgdQgCgDgCgCQhChehLBQQgCACgBABQgNANgLARQgjBAATBHQAWABAYAAQBSAABLgLACYBJQhBAUhFANQgNABgKADQAFhLgUhAQA3htBZBGQAHgkAbgQQATAUANAYQAhA5gKBEQgGACgFADQgXAJgaAIgAB8hEQAdBEgBBCQAAADAAAE");
	this.shape_1.setTransform(11.5188,-12.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#517924").ss(0.5,1,1).p("AFal4QgMAogLApQgNAxgLAyQgFARgDASQghCbgLCeQgTgMgWgLAD3CYQAsAdAeAhAgtHHQgMAAgNgCQjhgOgrhQQgUjCAnjnQADgOANg5QADgQAFgTQAOhIAbh3QAHglAKgoQACgHABgG");
	this.shape_2.setTransform(-4.7502,-45.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F2DBBB").s().p("AjJB4QgThHAihAQALgRANgNIADgDQBMhQBCBeQgIgEgTgHQgWgHgIAAQhTAAAAB2IABA3QgXAAgWgBgAgOgdQA4htBYBGQAIgkAbgQQATAUAMAYQgFADgBAFQgFAIAAATQAAAhAKAdIAOAhQgYAJgZAIIgCACIAAgHIAAgGQAAg/gchBQAcBBAAA/IAAAGQgRg8gIgVQgMgkgjAAQgnAAgNAKQgOALAAAhQAAALAGAbQAFAbAAAMQAAAPgHALQgMABgLADQAFhLgUhAg");
	this.shape_3.setTransform(10.8626,-12.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F8EBDA").s().p("Ai9AsQAAh2BTAAQAIAAAWAHQATAHAIAEIADAFQAVBAgFBLQhMALhSAAgAAAA6QAAgMgFgbQgGgaAAgLQAAgiANgLQANgKAnAAQAjAAAMAkQAIAWARA7IAAAHQhAAUhFANQAHgLAAgPgACjAAQgKgeAAghQAAgTAFgIQABgFAFgDQAhA5gJBEIgLAFIgOggg");
	this.shape_4.setTransform(14.0562,-9.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6FA532").s().p("AhHHqQjhgOgrhRQgUjCAnjmIAQhHIAIgjQAOhIAbh4IARhMIADgOQEQiwE2D3Iicg1QhlgjhEAAQgsAAg7ARIgHgJQgNgNgRAAQgTAAgNANQgMAOAAARQAAAFABAFQgQAIgLAIQgWAPgWBdQgOBEgGA8IgeD7QgLBVAABSQAAAfABAHQAEAMABAPQACAMARAVQAQATAXAOQAWAMAjAHQARABA4AAQARAAAbg0QAZgvAYgNIAAACQgNANgLARQgjBAATBHIgZgBg");
	this.shape_5.setTransform(-4.6752,-49.2736);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#517924").s().p("AinC1QgGgEAAgJQAAgGAGgGQAFgFAIAAQAHAAAFAFQAFAGAAAGQAAAJgFAEQgFAHgHAAQgIAAgFgHgAgaCUQgEgFAAgFQAAgFAEgEQAEgFAFABQAGgBADAFQAFAEAAAFQAAAFgFAFQgDADgGAAQgFAAgEgDgAAuBWQgGgEAAgIQAAgGAGgGQAFgGAIAAQAIAAAFAGQAEAGAAAGQAAAIgEAEQgFAHgIAAQgIAAgFgHgAhXAmQgHgIgBgMQABgMAHgGQAJgIAMAAQALAAAIAIQAKAGAAAMQAAAMgKAIQgIAIgLAAQgMAAgJgIgAAaggQgGgFgBgHQABgHAGgHQAFgEAHAAQAJAAAEAEQAFAHAAAHQAAAHgFAFQgEAGgJAAQgHAAgFgGgAiagjQgEgFAAgEQAAgHAEgDQAFgFAEAAQAHAAADAFQAEADAAAHQAAAEgEAFQgDADgHAAQgEAAgFgDgABwhMQgJgJAAgRQAAgOAJgKQAMgKAOAAQAQAAAJAKQALAKAAAOQAAARgLAJQgJALgQAAQgOAAgMgLgAhYhvQgKgKgBgMQgBgFAAgEQAAgRAMgPQAMgMAUAAQARAAANAMIAHAJQAHAKgBANQAAASgNANQgNAPgRAAQgUAAgMgPg");
	this.shape_6.setTransform(-10.85,-74.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#88C641").s().p("AjGGyQgjgGgWgNQgYgOgPgTQgSgUgBgNQgCgOgDgNQgBgGgBggQABhRAKhWIAfj7QAGg7AOhEQAWhdAWgQQALgIAQgIQABANAKAJQAMAPAUAAQARAAANgPQANgMAAgTQABgNgHgJQA7gSAtAAQBDAABlAjICbA2QgBADAAADQgNApgKApIgYBiQgFARgDATQghCZgLCfQgTgMgWgLQAWALATAMQAsAdAeAhQgbAQgHAkQhZhGg5BtIgDgFQhChehLBQIgDADIAAgBQgYAMgYAwQgbA0gRAAQg4AAgRgCgAj/hgQgGAGAAAHQAAAIAGAEQAFAHAIAAQAHAAAFgHQAFgEAAgIQAAgHgFgGQgFgFgHAAQgIAAgFAFgAhyh7QgEAEAAAGQAAAFAEAEQAEADAFAAQAGAAADgDQAFgEAAgFQAAgGgFgEQgDgEgGAAQgFAAgEAEgAgpi+QgGAGAAAGQAAAIAGAFQAFAGAIAAQAIAAAFgGQAEgFAAgIQAAgGgEgGQgFgFgIAAQgIAAgFAFgAivj9QgHAIgBALQABAMAHAIQAJAIAMAAQALAAAIgIQAKgIAAgMQAAgLgKgIQgIgIgLAAQgMAAgJAIgAg9k2QgGAGgBAHQABAHAGAFQAFAGAHAAQAJAAAEgGQAFgFAAgHQAAgHgFgGQgEgFgJAAQgHAAgFAFgAjykzQgEADAAAHQAAAEAEAFQAFADAEAAQAHAAADgDQAEgFAAgEQAAgHgEgDQgDgFgHAAQgEAAgFAFgAAYl7QgJALAAAOQAAAQAJAJQAMALAOAAQAQAAAJgLQALgJAAgQQAAgOgLgLQgJgKgQAAQgOAAgMAKg");
	this.shape_7.setTransform(-2.05,-49.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F1C256").s().p("ADWBaQAAgDACgDQgbgmgtgmQg2gthJgaQhHgdhCgDQhEgDhSAZQgeAKgGgVQgIgUAYgWQAXgWBcgQQBagQCfAYQCMAtBKByQAlA7gbAtQgZAuhSATQALgpAMgpg");
	this.shape_8.setTransform(8.4333,-92.308);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E1A413").s().p("AlLAyQgIgsAfglQBuiBDyARQBSAHBCAXQiggXhZAPQhcAQgXAWQgYAWAIAVQAGAUAegJQBSgaBEAEQBBADBIAcQBJAaA2AuQAtAlAbAmQk2j2kQCvIgDAOIgRBMQg2gvgJgxg");
	this.shape_9.setTransform(-3.381,-96.6542);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40.3,-112.2,80.69999999999999,113.2);


(lib.torleg1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#E8BD84").ss(0.5,1,1).p("AC1A8QAQgMALgQQAOgYAAgbQAAgbgTgxQgDgGgDgHQgCgBAAgCQgHgRgFgSQhNBLAsBVAi5AoQgpAvAFA5QAfADAiAAQAoAAArgFQAsgFAygMQASgFATgGQAdgIAegLQAngOAZgVAi2AjQAVgVAUgOQA7goA1BGQAZAjAZA6QgfiHA1gdQApgXA3BCQAEAFAHAHQAPATAQAb");
	this.shape.setTransform(9.2027,-14.65);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#517924").ss(0.5,1,1).p("AETCKQgQgvAAg6QAAg6AViHQAaioAjhkAlFjxQAuDsgTBPQgTBPgMAxQgOAvAEA8QAEA8BIAcQArAQBNAMQAGACAIAC");
	this.shape_1.setTransform(0.0203,-43.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F2DBBB").s().p("AjWCQQgFg6ApgvIADgEQAVgVAUgOQA7goA1BGQgLgCgUgKQgQgJgOABQgbgBgOAUQgYAfgBBXQgiAAgfgDgAAcB7QgfiHA1geQApgWA3BCQgOgIgKgBIgZAAQgZAAgFADQgRAJAAAqQAAAdAPAlIglAMgACdAOQgshWBNhKQAFASAHARIACAEIgDgDQgIABgGAWQgHAWAAAgQAAAxAjAPQgLAQgQANQgQgbgPgTg");
	this.shape_2.setTransform(8.5027,-14.65);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F8EBDA").s().p("AikALQAOgTAbABQAOgBAQAIQAVAKALACQAZAjAZA6IAAACQgyAMgsAFQgrAEgpABQAChXAXgfgAAKAdQAAgpARgKQAFgDAZAAIAaAAQAJABAOAJIALAMQAQASAQAbQgZAUgoAOQgeAMgcAHQgQglAAgdgACNgzQAAggAGgWQAGgWAIgBIAEADIAGAMQATAwAAAbQAAAdgOAWQgjgOAAgyg");
	this.shape_3.setTransform(12.475,-12.85);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#517924").s().p("AgvCPQgDgDAAgEQAAgFADgDQAFgEAEAAQAFAAADAEQADADAAAFQAAAEgDADQgDAEgFAAQgEAAgFgEgAAtBiQgDgFAAgGQAAgFADgFQAFgEAGAAQAGAAADAEQAFAFAAAFQAAAGgFAFQgDAEgGABQgGgBgFgEgAgZAwQgGgGAAgHQAAgHAGgGQAFgFAIAAQAHAAAFAFQAEAGAAAHQAAAHgEAGQgFAFgHAAQgIAAgFgFgAAzAOQgGgGAAgJQAAgJAGgGQAGgGAKAAQAJAAAHAGQAIAGAAAJQAAAJgIAGQgHAIgJAAQgKAAgGgIgAhoARQgDgEAAgHQAAgEADgEQAFgFAGAAQAHAAADAFQAEAEAAAEQAAAHgEAEQgDAFgHAAQgGAAgFgFgAgyg5QgIgIAAgMQAAgMAIgHQAIgJAMABQALgBAIAJQAKAHAAAMQAAAMgKAIQgIAHgLABQgMgBgIgHgAAuhVQgJgKAAgQQAAgOAJgLQALgKAPAAQAPAAAKAKQALALAAAOQAAAQgLAKQgKALgPgBQgPABgLgLg");
	this.shape_4.setTransform(13.725,-46.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6FA532").s().p("AiAGoQhNgMgrgQQhIgcgEg8QgEg8AOgvIAfiAQAThPgujrQBygPCOgRQCMgQBihDQBihDAsgEQh2DmkmB9QhFAcgbAYQgfAbgHAxQgBAOgbBdQgYBXAAAPQAAAoAlAnQAkAmAkAAQAQAAAfghQATgTATgGQgpAvAFA5IgOgEg");
	this.shape_5.setTransform(-1.4547,-43.075);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#88C641").s().p("AAkFGQg1hHg6ApQgVAOgUAUIgDAFQgTAGgTATQggAhgPAAQglAAgkglQgkgoAAgnQAAgQAYhXQAahdACgOQAGgxAggbQAagYBGgcQElh8B3jmIANgCQAIgCAIACQgiBjgbCpQgUCHAAA6QAAA6APAvQhNBKAsBXIgLgNQg3hCgpAWQg1AeAfCIQgZg7gZgigAA+BmQgDADAAAFQAAAFADADQAFADAFAAQAFAAADgDQADgDAAgFQAAgFgDgDQgDgDgFAAQgFAAgFADgACbA0QgDAEAAAFQAAAGADAFQAFAFAGAAQAHAAADgFQAFgFAAgGQAAgFgFgEQgDgFgHAAQgGAAgFAFgABUgDQgGAGAAAGQAAAIAGAFQAFAGAIAAQAIAAAFgGQAEgFAAgIQAAgGgEgGQgFgEgIAAQgIAAgFAEgACigqQgHAGAAAKQAAAJAHAHQAGAHAJAAQAKAAAGgHQAIgHAAgJQAAgKgIgGQgGgGgKAAQgJAAgGAGgAAGgcQgDAFAAAFQAAAGADAFQAEAEAHAAQAGAAADgEQAFgFAAgGQAAgFgFgFQgDgFgGAAQgHAAgEAFgAA7h6QgIAIAAALQAAAMAIAIQAIAIANAAQALAAAIgIQAJgIAAgMQAAgLgJgIQgIgIgLAAQgNAAgIAIgACdiiQgKALAAAPQAAAPAKAKQALALAOAAQAQAAAJgLQALgKAAgPQAAgPgLgLQgJgJgQAAQgOAAgLAJg");
	this.shape_6.setTransform(2.675,-44.2286);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-35,-87,70.1,88);


(lib.torgrd = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_210();
	this.instance.setTransform(-98.45,-150.15,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_209();
	this.instance_1.setTransform(-133.2,-152.25,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-133.2,-152.2,266.5,153);


(lib.torbase = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D09711").ss(0.5,1,1).p("AChCmQhgg9gmhYQgOgfgQgXQgKgNgLgLQgbgcgkgPQgigPgtgCQhgAZheAYQC6gbBVCxQATAnAUAgQA+BfBYAdQAQAHATADQANgLAOgKQARgPATgQQAKgKAJgJQAFgFAGgEQBGhtAeiDQACgEAAgEQAAABgBABQAch3gFhxQAAgEAAgDAChCmQAKAHAMAGAChCmQBYhzBUhe");
	this.shape.setTransform(98.0549,-65.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#E8A746").ss(0.5,1,1).p("AK+DoQgJADgIADIgCAAQgMAEgNAEQgJADgIAEQk+Bek4gUQgFAAgDAAQgCAAgBAAQgHgCgGAAQgCAAgCAAQgwgFgwgGQiRgRh+goQing1iEhdQgDgDgDgCIAAgCQgFgDgDgBQhghJhOhcQgRgWgJgTQgHgJgEgKALADoQADgCAbgLQEJhTDeirQADgDAFgDAvYk7IACABQAEAFAIAGAvYk7QgCgDgBgFQgCgDgBgDQkOCJAlA3QAiA1EZgpQgLgUgIgVQgOghgihYg");
	this.shape_1.setTransform(-10.8677,-33.0173);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#6FA532").s().p("AiaBRQglg3ENiIQguAaACACQgrApgVARQgnAjAAAeQAAAeBSAAQAcAAA2gJQAbgFATgFQAIAVALAUQh6AShKAAQhjAAgTgeg");
	this.shape_2.setTransform(-117.7677,-54.9356);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#88C641").s().p("AhpA9QAAgeAogjQAVgRAsgpQgCgCAtgaIACAGIAEAIIAJAcQAhBXAPAhQgUAFgaAFQg2AJgbAAQhUAAAAgeg");
	this.shape_3.setTransform(-114.25,-56.925);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F1C256").s().p("ABoETQhYgeg+heQgUgggTgnQhVixi6AaIC+gwQAtABAiAQQAkAOAbAcQALALAKANQAQAYAOAeQAmBYBgA+QAKAGAMAGQgMgGgKgGQBYhzBUhfQhUBfhYBzQhgg+gmhYQgOgegQgYQgKgNgLgLQgbgcgkgOQgigQgtgBQDVhyBcgdQBcgdB9ALIAAAGQAFBygcB2IABgCIgCAJQgeCDhGBsIgLAKIgTASIgkAgQgOAJgNALQgTgDgQgGgAimh3IAAAAg");
	this.shape_4.setTransform(98.0549,-65.6761);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FAD69C").s().p("AkECwQjtgZjXhyQhAAugaBFIgGgEQAUhiBMgeQDwBrDzAmQglB0ByBKQh2gsAKiHgAieC5IAVAAQEYgDEQhHIAGAAIgCATQAAA2AhAyQAdAxA7AFIgSAGQhjgsghhoQkUA/j6gCQgPA/AeBRQg4hPAThXgAJHESQg3gmgJgTQggg6AHgdQAEgeB0g1IC+hYQBNgiAgAAQACAAA4AiQA5AjALAAQAOAAAWgDQAQAGATADIgIAGIgfAAIgUADQgiAAgxglQgzgmgPADQgQAEhLAnQhOAmg4AYQg5AYg5AWQg5AWAOA0QANA0BSAvIgeANgAs+gPQirhUhkitQAEAFAJAGQB1ClDABKQg9BLATBKQglhEAchKgAibBrQhMi5BmjqIADgGIgCAFQg4DYA6CnQDgAeDtg/QhkisBii8QhdDMCPCmQjgA+jeAAQguAAgugCgAqygqQgLhzAxhFIAhguQg3BtATBoQCiBdDeAnQgzjbCniRQiYDeBMCwQkTg5i4hcgAFNlDIACAAQgNBOA/B+QA9B9ArADQApADCghMQCghPADgLQADgLgggxQgggygZgWQgagYgYgNQgVgMhWgTQDPgCBIDTQjCB1jiBDQiYiPAQjbgAxSkaIgDgGQCcBtC1BHQAaibCOgiQgCABgCADQiSA0AECvQiLg/jZiZg");
	this.shape_5.setTransform(1,-37.1755);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFE3BB").s().p("AhnFoIgOgSQgehQAPg/QD6ABEUg/QAhBoBjAtQkFBOkCAAQg2AAg4gEgAjjFbQiSgRh9goQiog1iEhdQAahGBAgtQDXBxDtAZQgKCIB2AsIAQALQgwgFgvgGgAIMCZQgOg0A5gWQA5gWA5gYQA4gXBOgnQBLgnAQgDQAPgDAzAmQAxAkAiAAIAUgCIAfAAQjeCrkJBTQhSgvgNg0gAvZggQgSgWgJgTQgGgJgFgKQgLgUgIgVQgOghgihYIgJgcIACABQBkCuCrBTQgcBLAlBEIAFAOQhghJhNhcgAh6A+Qg6ioA4jYIACgFIAAgBIADAAIADAAICugJIEcgNQCigIBEACIAKAAIAdgHIADAAQBWATAVANQAYANAaAXQAZAWAgAzQAgAwgDAMQgDALigBOQigBNgpgEQgrgCg9h+Qg/h+ANhNIgCAAQhiC7BkCtQigAribAAQhJAAhJgKgAqLhEQgThoA3htIASgXIgDgCIADAAIHRgUIgTAaQinCRAzDcQjegniihegAHXA5IAAgBIACABgAxRkoQBIAHGugRIADAAQiOAjgaCaQi1hHichsg");
	this.shape_6.setTransform(0.6,-36.3423);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#EDBE78").s().p("AhjFsIgDAAQgIgCgGAAIgEAAIgQgLQhyhKAlh0QjzgmjwhrQhMAegUBiIAAgCIgIgFIgFgOQgThKA9hLQjAhKh1ilQgJgGgEgFIgCgCIgDgIQDZCZCLA/QgEivCSg0QACgDACgBIADABIgSAYIghAuQgxBFALBzQC4BcETA5QhMiwCYjeIATgbIAKgBIAAAAIgDAHQhmDqBMC5QELAPEPhLQiPimBdjMQgQDbCYCPQDihDDCh1QhIjTjPACIgDAAIAHgCQC6gaBVCyQASAnAVAgQA/BeBYAeQgWADgOAAQgLAAg5gjQg4gigCAAQggAAhNAiIi+BYQh0A1gEAeQgHAdAgA6QAJATA3AmIgQAGIgDAAIgYAIQg7gFgdgxQghgyAAg2IACgTIgGAAQkQBHkYADIgVAAQgTBXA4BPIAOARIgIAAgAHjA+IACAAIgCgCg");
	this.shape_7.setTransform(-0.6,-36.7717);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-134.7,-94.8,269.5,95.8);


(lib.Tail = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#A46715").ss(0.3,1,1).p("ADTgpQAdgqANgyQAAABABAAQAAABAAAAIABAAIgBABIAAAAQAAABAAAAQgVA6gWAeQgLAPgLAIQgkAZgvAGQgwAHgugGQgUgCgVgBQgZgBgZAAQgBAAgBAAQguAChMATQhMAUhXAJQgBAAgBAAQAAABABAAQAZANAuAIQAdAEAlACQBiAGAqAEQApAFBHASQBHASBLgIQBZgKA0guQAegbARgpQABgCABgDQAKgUABgUQABgIgBgHQAAgBAAgBQhIgcgqgwAFkAHQAJgUAEgZ");
	this.shape.setTransform(0.2952,1.3051);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E8A64F").s().p("ACwB0Qg/gBgdgLQgcgKgigIQghgIg2gBQg2gBhHAHQhGAIhBgOQBYgJBMgUQBLgTAugCIABABIABgBQAZAAAYABIAqADQAuAGAwgHQAwgGAjgZQALgIALgPQAWgeAVg6QAHgBATBGQATBGgzAtQgxAtg9AAIgDgBgAEmh0IABAEQgVA6gWAeQAdgqANgygAEnhwIAAAAg");
	this.shape_1.setTransform(-3.8256,-0.3982);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DE8529").s().p("AAZB5QhHgSgpgFQgqgEhigGQglgCgdgEQgugIgZgNIgBgBIACAAQBBAOBGgIQBGgHA3ABQA2ABAiAIQAhAIAcAKQAdALA+ABQA/ACAzguQAzgtgThGQgUhGgGABIAAgBIAAAAIABgBQAqAwBIAcIAAACIAAAPQgEAZgJAUQgRApgeAbQg0AuhZAKQgXADgXAAQgzAAgxgNgAlzA7IAIABIgCAAIABABIgHgCgAlrA8IAAAAgAhOAKIACAAIgBABIgBgBgAFnAHIAAAAgAF0gmQgBAUgKAUIgCAFQAJgUAEgZgAEBiBIAAAAgAEAiFIABABIAAABIABAAIgBABIAAAAIAAABIgBgEg");
	this.shape_2.setTransform(-0.0048,1.3051);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-37.6,-13,75.9,28.7);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* stop();
		this.blnPlay = false;*/
	}
	this.frame_1 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_134 = function() {
		/* MovieClip(parent).fChangeQuestion();
		this.blnPlay = false;
		gotoAndStop(1);
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(133).call(this.frame_134).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_208();
	this.instance.setTransform(-22.45,-25,0.2894,0.2894);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.4,-25,44.8,50.1);


(lib.separater = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(205,179,159,0)","#CDB39F","#CDB39F","rgba(205,179,159,0)"],[0,0.282,0.816,1],0,-77.7,0,77.7).s().p("AgnMMIAA4XIBPAAIAAYXg");
	this.shape.setTransform(-0.0062,0,0.3125,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.2,-78,2.5,156);


(lib.patch1_2_T1_T3_4_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFBF3").s().p("AuEOEQjIAAAAjIIAA13QAAjIDIAAIcJAAQDIAAAADIIAAV3QAADIjIAAg");
	this.shape.setTransform(-350.025,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-460.1,-90,220.20000000000002,180);


(lib.patch1_2_T1_T3_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFBF3").s().p("AuEOEQjIAAAAjIIAA13QAAjIDIAAIcJAAQDIAAAADIIAAV3QAADIjIAAg");
	this.shape.setTransform(-350.025,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-460.1,-90,220.20000000000002,180);


(lib.patch1_2_T1_T3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFBF3").s().p("AuEOEQjIAAAAjIIAA13QAAjIDIAAIcJAAQDIAAAADIIAAV3QAADIjIAAg");
	this.shape.setTransform(-350.025,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-460.1,-90,220.20000000000002,180);


(lib.patch_2_T1_T3_4_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFBF3").s().p("EhEwAOEQjIAAAAjIIAA13QAAjIDIAAMCJhAAAQDIAAAADIIAAV3QAADIjIAAg");
	this.shape.setTransform(-0.025,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-460.1,-90,920.2,180);


(lib.patch_2_T1_T3_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFBF3").s().p("EhEwAOEQjIAAAAjIIAA13QAAjIDIAAMCJhAAAQDIAAAADIIAAV3QAADIjIAAg");
	this.shape.setTransform(-0.025,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-460.1,-90,920.2,180);


(lib.patch_2_T1_T3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFBF3").s().p("EhEwAOEQjIAAAAjIIAA13QAAjIDIAAMCJhAAAQDIAAAADIIAAV3QAADIjIAAg");
	this.shape.setTransform(-0.025,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-460.1,-90,920.2,180);


(lib.ncvvbcvb = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap13();
	this.instance.setTransform(-36,-150);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36,-150,73,301);


(lib.lioneye = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(0.3,1,1).p("ABIAAQAAApgVAcQgVAdgeAAQgdAAgVgdQgVgcAAgpQAAgoAVgcQAVgdAdAAQAeAAAVAdQAVAcAAAog");
	this.shape.setTransform(0,-9.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(70));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgxBFQgWgcABgpQgBgnAWgdQAUgdAdAAQAeAAAUAdQAWAdgBAnQABApgWAcQgUAcgeABQgdgBgUgcg");
	mask.setTransform(0,-9.75);

	// Layer_5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#333333").ss(0.3,1,1).p("AB2AkQh6hPhxBPIAAhHIDrAAg");
	this.shape_1.setTransform(0.95,-20.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EFAD00").s().p("Ah1AkIAAhHIDrAAIAABHQh6hPhxBPg");
	this.shape_2.setTransform(0.95,-20.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#333333").ss(0.3,1,1).p("Ah1gvIDrAAIAABfQh6grhxArg");
	this.shape_3.setTransform(0.95,-18.85);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#EFAD00").s().p("Ah1AwIAAhfIDrAAIAABfQh6grhxArg");
	this.shape_4.setTransform(0.95,-18.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#333333").ss(0.3,1,1).p("Ah1g7IDrAAIAAB3Qh6gGhxAGg");
	this.shape_5.setTransform(0.95,-17.425);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#EFAD00").s().p("Ah1A8IAAh3IDrAAIAAB3Qh5gGhyAGg");
	this.shape_6.setTransform(0.95,-17.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#333333").ss(0.3,1,1).p("Ah1hPIDrAAIAACQQh6Afhxgfg");
	this.shape_7.setTransform(0.95,-15.2125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EFAD00").s().p("Ah1BBIAAiQIDrAAIAACQQg9APg6AAQg7AAg5gPg");
	this.shape_8.setTransform(0.95,-15.2125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#333333").ss(0.3,1,1).p("Ah1hlIDrAAIAACpQh5BEhyhEg");
	this.shape_9.setTransform(0.95,-12.8625);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#EFAD00").s().p("Ah1BEIAAipIDrAAIAACpQg9Aig6AAQg7AAg5gig");
	this.shape_10.setTransform(0.95,-12.8625);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#333333").ss(0.3,1,1).p("AB2BNQh5ByhyhyIAAjSIDrAAg");
	this.shape_11.setTransform(0.95,-10.5089,1,0.9238);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#EFAD00").s().p("Ah1BNIAAjSIDrAAIAADSQg9A5g6AAQg7AAg5g5g");
	this.shape_12.setTransform(0.95,-10.5089,1,0.9238);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},14).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},2).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).to({state:[]},1).wait(43));

	// Layer_1
	this.instance = new lib.CachedBmp_207();
	this.instance.setTransform(-5.35,-12.65,0.4899,0.4899);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(70));

	// Layer_2
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgxBFQgWgcABgpQgBgnAWgdQAUgdAdAAQAeAAAUAdQAWAdgBAnQABApgWAcQgUAcgeABQgdgBgUgcg");
	this.shape_13.setTransform(0,-9.75);

	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(70));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.1,-20.5,16.299999999999997,21.5);


(lib.Leg2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#A46715").ss(0.3,1,1).p("AigCFIgBgBQgIgGgig9QgZgvAFgxQAAgDABgEQABgEABgEQARgyA2g5QA2g5A6gIQAngGAcAGQALACAJAFQAfAPAQAXQAQAXAAAiQAAAjgXAlQgWAmggAjQggAkhTBGQAkAFAxABQA0AAA3gQQAhgKAVAHQANADAIAKQAVAZAJATQgrg8gkAXADaCzQAIATgBARQgDAKikgDQgEgBhagEQg7gDgegCQgQgBgHAAQgWgBgNgGQgNgGACgFQgCgOAUgPQAEgDAFgDQALgJgEgQIAKAIAhPCHQgHAFgGAF");
	this.shape.setTransform(0.0393,-0.0062);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E8A64F").s().p("AA6DeIhegFIhZgFIgmgJQgbgHAVgPQAUgPAHgMQAGgNgXgYQgXgYgYg0QgVgvAEggIADgIQAQgyA2g5QA2g5A6gIQAogGAbAGQAQAPAHAPQALAWAAAlQAABHhbBmIg/BDQgdAeAAAIQAAAGAJAFQAHAEAYgCIBUgJQA9gIAogOQAcgJAiAAQANADAIAKQAVAZAIATQAJATgBARQgDAHhdAAIhHAAgADZCzIgCgDIgBgBIgBgBQgdgngZAAIAAAAIgBAAQgJAAgJAFIAAABIgBABIABgBIAAgBQAJgFAJAAIABAAIAAAAQAZAAAdAnIABABIABABIACADIAAAAg");
	this.shape_1.setTransform(0.0983,-0.0062);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DE8529").s().p("Ah3DXQgWgCgNgFQgNgGACgGQgCgNAUgPIAJgHQALgJgEgPIAKAIIgKgIIgBgBQgIgHgig9QgZguAFgxIABgHQgEAgAVAuQAXA1AYAYQAXAXgHANQgGANgVAOQgUAPAaAHIAmAKIgXgBgAhSCjQgJgEAAgGQAAgIAdgfIA/hDQBchmAAhHQAAgkgLgXQgHgOgQgQQALADAJAEQAfAQAQAXQAQAXAAAiQAAAigXAmQgWAlggAkQggAkhTBFIgNAKIANgKQAkAGAxAAQA0AAA3gPQAhgKAVAGQgiAAgbAKQgpAOg9AHIhTAJIgPABQgMAAgFgDg");
	this.shape_2.setTransform(-2.866,-0.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[]},1).wait(9));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.5,-23.2,47.1,46.5);


(lib.Leg1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#A46715").ss(0.3,1,1).p("Ah/jFQAegcAdgNQAAAAABAAIABgBQANgFAOgDQABAAACAAIABAAQADgBAEAAQAIgBAJABQAGAAAFABQAHACAGADQAEABADACQABABABAAQAFADAFAEQAFADAFAFQAaAZANAwQALAoABA5QAAADAAADQAAAdgLAlQgLAlgSAWQgTAWgMAJQgBAAAAAAQgaAYglATIgqAVIgOAEAiuCaQAHAEAIADAiuCaQAAAAgBAAQgNgHgLgIQgdgXgPglQgIgTgDgXQgCgHgBgIAC5DoQAAAEAAAEQgPABgOABQlYASAAgYQgFgaATgYQAMgRgMgPAhUCtQAPgBAgAFQAkAFAhgEQAYgEAdgKQAMgEAMgGQAagLAVgBQAOgBALAEQARAEANAIQAdATAJASQAHAOACASIgqAAQgBgDAAgDQgEgTgQgRADYDiQAAADAAADIgfAAQAAgDgBgDQgGgLgWgPQgFgEgFgD");
	this.shape.setTransform(0,0.0355);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E8A64F").s().p("ABNDxQgFgCguAAIhaABQgcAAgkgCQglgDACgOQACgOAJgPQAKgQAPgNQhDgIgnhFQgIgTgDgXIgDgPQAviKBThRQAegcAdgNIABAAIABgBQANgFAOgDQANAAANAIQAWAPAWAuQAGAMAEANIABADQATA6gRBGQgVBVg8AyQg9AxgWANQgWAMAgAAQAfAAAmAEQAmADAmgMIAygSIgBAAIAYgKQAbgLAUgBQAOgBALAEQARAEANAIQAPALAFAJQAIARAAAHQAAATgYAAQgEgTgQgRIAGAOQAFAMAAAFIAAAEQgCAGgHABIgNAAQgGgLgWgPIgKgHQAJAOABAJIAAAEQgBANgaABQgrgBgSABgABIDxIAFAAIABAAg");
	this.shape_1.setTransform(-0.95,-0.6507);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DE8529").s().p("AjDDsQgFgaATgYQAMgRgMgPIAQAHIgQgHIgBAAQgNgHgLgIQgcgXgQglQAoBFBCAIQgPANgJAQQgJAPgDAOQgCAOAlADQAlACAbAAIBagBQAvAAAFACQARgBAsABQAZgBACgNIAAgEQgBgJgJgOIAKAHQAWAPAGALIABAGIgBgGIAMAAQAIgBABgGIAAgEQABgFgFgMIgHgOQAQARAEATQAZAAAAgTQgBgHgIgRQgEgJgPgLQAdATAJASQAHAOABASIgqAAIgBgGIABAGIAAAGIgeAAIgBAIIgcACQiUAIhUAAQhwAAAAgOgAA3DqIAGAAIAAAAIgGAAgADQDiIAAAAgAgvC/QgngEgfAAQggAAAWgMQAWgNA9gxQA9gyAUhVQARhGgTg6IgBgDQgEgNgGgMQgVgtgXgQQgNgIgNAAIADAAIABAAIAHgBIARAAIAMABIAMAFIAHADIACABIAKAHIAJAIQAbAZANAwQALAoABA5IAAAGQgBAdgKAlQgLAlgTAWQgSAWgMAJIgBAAQgaAYglATIgqAVIgOAEIAOgEQAPgBAgAFQAkAFAhgEQAYgEAdgKIABAAIgzASQgcAJgeAAIgRAAg");
	this.shape_2.setTransform(0.7,0.0355);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[]},1).wait(9));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.7,-25.9,53.5,51.9);


(lib.house_shadow_2_T1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.Bitmap7();
	this.instance.setTransform(-482,-149);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-482,-149,923,183);


(lib.house_shadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.Bitmap1();
	this.instance.setTransform(-482,-149);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-482,-149,923,183);


(lib.heading_txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap5();
	this.instance.setTransform(-318,-30);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-318,-30,651,61);


(lib.heading_ = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.CachedBmp_168();
	this.instance.setTransform(-136.4,-23.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.Bitmap6();
	this.instance_1.setTransform(-147,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-147,-28,235,54);


(lib.Hand3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#A46715").ss(0.3,1,1).p("AAYgKQADAEADAGQAEAGABAJQABAGAAAFQABAEgBAFQgCAKgFAGIAAABIgDADQgEADgFABQgGAAgEgDQgCgCgFgFQAAgBAAgBQgFADgFACQgOAHgKgDQgOgFAHgNQAHgMASgDQgQgTgCgeAgPg6QAPAJATARQASARAEANQADAIAAAGQAAADgBADQgCAHgFABAADgGQAJANADAIQACAIgBAGQgCAFgMAKQgBABgBABQAAAAAAAB");
	this.shape.setTransform(0.0192,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DE8529").s().p("AAHArIgHgHIAAgCIAAgBIACgBQAMgKACgGQABgGgCgHQgDgHgJgOQASASAAAMQAAAMgDADQgCADgBAIQgBAIALgEIABAAQgEAEgFAAQgGAAgEgDgAgiAsQgOgFAHgNQAHgNASgCQgQgTgCgeIAAgHQAGABABALQABAKACAGIAFAMIAIALQADAFADABIgRAHQgNAFAAAKQAAAKAZgEQgJAFgJAAIgGgBgAAjADQgBgIgEgHQgDgGgDgEQAHAEAEAJQAGAJABAAIACAAIgBAGQgCAGgFABIgBgKg");
	this.shape_1.setTransform(0.0192,1.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E8A64F").s().p("AALA0QAAgIADgDQACgEAAgMQAAgMgQgRQAIAMADAIQACAIgBAGQgCAFgMAKIgCACIAAABIgKAFQgZAEAAgJQAAgLAMgEIARgHQgCgBgDgGIgIgLIgFgLQgCgGgBgLQgBgLgHgBQAJgTALgFQAQAJARARQATARAEANQADAHAAAGIgCABQgBAAgGgLQgFgHgGgFQADAEADAGQADAGACAJIABALIAAAJQgCAKgGAGIAAABIgCADIgBgBIgHACQgEAAABgFg");
	this.shape_2.setTransform(0.45,-0.144);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.4,-6.8,10.9,13.7);


(lib.Hand2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#A46715").ss(0.3,1,1).p("Ah7gaQAGgNASgHQAhgOAiAMQAgAJAhAVQAgAUAwATQAAAAAEACQAOAIgEALIAAAAQgDALgLABQgBABgRAAQgIAAgIAAQiugEgfgzQgEgPAHgLg");
	this.shape.setTransform(0.0006,0.0366);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DE8529").s().p("ABgApIgRAAQiugEgegyQgFgQAIgLQAHAZAWAMQAZAMAXAFQAXAFA1AHQA2AGAQAAQAZABACgFIAAAAQgEALgLABIgIABIgJAAg");
	this.shape_1.setTransform(-0.0344,1.4083);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E8A64F").s().p("ABjAyQgRAAg2gGQg1gHgXgFQgXgFgYgNQgWgMgIgYQAGgNASgHQAhgOAiAMQAgAJAhAVQAgAUAwATIAEACQAOAIgEALQgBAEgVAAIgEAAg");
	this.shape_2.setTransform(0.235,-0.3944);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-13.8,-6.4,27.6,12.9);


(lib.hand1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#A46715").ss(0.3,1,1).p("AA+AxIgBAAQADhKgLhJAggBjQgYhGgFhn");
	this.shape.setTransform(0.031,0.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DE8529").s().p("AAABSQgYhGgEhmIAAAAIAUBbIAJAvQAGAcAWAOIgKABQgNAAgGgJg");
	this.shape_1.setTransform(-3.225,2.0944);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E8A64F").s().p("AgfBFIgKgvIgThbIgBAAIABgBQAKgeArgIQArgJARAXQALBKgDBKIABAAQgCAUgWASQgZAPgPAEQgWgOgHgcg");
	this.shape_2.setTransform(0.031,-0.0397);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.1,-11.2,14.3,22.5);


(lib.Eyevv = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgZAuQgOgIABgUQADgnAjgdQATAEAOAaQAOAYgWAcQgPATgQAAQgJAAgKgFg");
	mask.setTransform(-0.1978,0.2823);

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(0.3,1,1).p("ABagJQhghXguCpIglg/ICOhSg");
	this.shape.setTransform(-0.625,-2.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E8A64F").s().p("AhZAKICOhSIAlA/QhghXguCpg");
	this.shape_1.setTransform(-0.625,-2.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#333333").ss(0.3,1,1).p("AhZAKICOhSIAlA/QhWgvg4CBg");
	this.shape_2.setTransform(-0.625,-2.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E8A64F").s().p("AhZAKICOhSIAlA/QhWgvg4CBg");
	this.shape_3.setTransform(-0.625,-2.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#333333").ss(0.3,1,1).p("AhZAKICOhSIAlA/QhLgGhDBYg");
	this.shape_4.setTransform(-0.625,-2.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E8A64F").s().p("AhZAKICOhSIAlA/QhLgGhDBYg");
	this.shape_5.setTransform(-0.625,-2.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#333333").ss(0.3,1,1).p("AhZAKICOhSIAlA/QhBAihNAwg");
	this.shape_6.setTransform(-0.625,-2.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E8A64F").s().p("AhZAKICOhSIAlA/QhBAihNAwg");
	this.shape_7.setTransform(-0.625,-2.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#333333").ss(0.3,1,1).p("AhZAKICOhSIAlA/Qg2BKhYAIg");
	this.shape_8.setTransform(-0.625,-2.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E8A64F").s().p("AhZAKICOhSIAlA/Qg2BKhYAIg");
	this.shape_9.setTransform(-0.625,-2.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#333333").ss(0.3,1,1).p("ABagMQgrByhjghIglg/ICOhRg");
	this.shape_10.setTransform(-0.625,-1.8565);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#E8A64F").s().p("Ag0BFIglg/ICOhRIAlA/QgiBYhDAAQgTAAgWgHg");
	this.shape_11.setTransform(-0.625,-1.8565);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#333333").ss(0.3,1,1).p("AhZAKICOhSIAlA/QgzBWhbgEg");
	this.shape_12.setTransform(-0.625,-2.2162);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#E8A64F").s().p("Ag0BJIglg/ICOhSIAlA/QgxBShVAAIgIAAg");
	this.shape_13.setTransform(-0.625,-2.2162);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#333333").ss(0.3,1,1).p("AhZAKICOhSIAlA/Qg7A5hTAZg");
	this.shape_14.setTransform(-0.625,-2.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#E8A64F").s().p("AhZAKICOhSIAlA/Qg7A5hTAZg");
	this.shape_15.setTransform(-0.625,-2.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#333333").ss(0.3,1,1).p("AhZAKICOhSIAlA/QhCAchMA2g");
	this.shape_16.setTransform(-0.625,-2.225);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#E8A64F").s().p("AhZAKICOhSIAlA/QhCAchMA2g");
	this.shape_17.setTransform(-0.625,-2.225);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#333333").ss(0.3,1,1).p("AhZAKICOhSIAlA/QhKAAhEBSg");
	this.shape_18.setTransform(-0.625,-2.225);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#E8A64F").s().p("AhZAKICOhSIAlA/QhKAAhEBSg");
	this.shape_19.setTransform(-0.625,-2.225);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#333333").ss(0.3,1,1).p("AhZAKICOhSIAlA/QhRgdg9Bvg");
	this.shape_20.setTransform(-0.625,-2.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#E8A64F").s().p("AhZAKICOhSIAlA/QhRgdg9Bvg");
	this.shape_21.setTransform(-0.625,-2.225);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#333333").ss(0.3,1,1).p("AhZAKICOhSIAlA/QhZg6g1CMg");
	this.shape_22.setTransform(-0.625,-2.225);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#E8A64F").s().p("AhZAKICOhSIAlA/QhZg6g1CMg");
	this.shape_23.setTransform(-0.625,-2.225);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22,this.shape_23];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},39).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).to({state:[{t:this.shape_7},{t:this.shape_6}]},1).to({state:[{t:this.shape_9},{t:this.shape_8}]},1).to({state:[{t:this.shape_11},{t:this.shape_10}]},1).to({state:[{t:this.shape_11},{t:this.shape_10}]},5).to({state:[{t:this.shape_13},{t:this.shape_12}]},1).to({state:[{t:this.shape_15},{t:this.shape_14}]},1).to({state:[{t:this.shape_17},{t:this.shape_16}]},1).to({state:[{t:this.shape_19},{t:this.shape_18}]},1).to({state:[{t:this.shape_21},{t:this.shape_20}]},1).to({state:[{t:this.shape_23},{t:this.shape_22}]},1).to({state:[{t:this.shape_1},{t:this.shape}]},1).to({state:[]},1).wait(32));

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgZAuQgOgIABgUQADgnAjgdQATAEAOAaQAOAYgWAcQgPATgQAAQgJAAgKgFg");
	mask_1.setTransform(-0.1978,0.2823);

	// Layer_3
	this.instance = new lib.CachedBmp_167();
	this.instance.setTransform(-2.35,-1.3,0.5,0.5);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(89));

	// Layer_1
	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#A46715").ss(0.3,1,1).p("AAAgxQglAegCAoQgBAVAOAIQAdAPAXgdQAXgdgPgZQgOgbgUgEQACgDAEgC");
	this.shape_24.setTransform(-0.1979,0.0057);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgaAvQgOgIABgVQACgoAlgdQAUAEAOAaQAPAZgXAdQgPATgRAAQgJAAgLgFg");
	this.shape_25.setTransform(-0.1979,0.2807);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25},{t:this.shape_24}]}).wait(89));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.2,-6.5,10,13);


(lib.eyeboy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#E09F3F").ss(0.5,1,1).p("ABABJQgaAegmAAQglAAgbgeQgageAAgrQAAgqAageQAbgeAlAAQAmAAAaAeQAbAeAAAqQAAArgbAeg");
	this.shape.setTransform(0.025,-10.325);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(75));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhABJQgageAAgrQAAgqAageQAbgeAlAAQAmAAAaAeQAbAeAAAqQAAArgbAeQgaAegmAAQglAAgbgeg");
	mask.setTransform(0.025,-10.325);

	// Layer_5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#333333").ss(0.5,1,1).p("AB5AiQh6hUh3BUIAAhDIDxAAg");
	this.shape_1.setTransform(0.575,-21.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F8D8A9").s().p("Ah4AiIAAhDIDxAAIAABDQh6hUh3BUg");
	this.shape_2.setTransform(0.575,-21.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4grIDxAAIAABXQh7gmh2Amg");
	this.shape_3.setTransform(0.575,-20.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F8D8A9").s().p("Ah4AsIAAhXIDxAAIAABXQh7gmh2Amg");
	this.shape_4.setTransform(0.575,-20.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4g4IDxAAIAABtQh7AIh2gIg");
	this.shape_5.setTransform(0.575,-19.425);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F8D8A9").s().p("Ah4A1IAAhtIDxAAIAABtQg+AEg8AAQg8AAg7gEg");
	this.shape_6.setTransform(0.575,-19.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4hOIDxAAIAACCQh8A2h1g2g");
	this.shape_7.setTransform(0.575,-17.2125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F8D8A9").s().p("Ah4A0IAAiCIDxAAIAACCQg/Abg7AAQg8AAg7gbg");
	this.shape_8.setTransform(0.575,-17.2125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4hkIDxAAIAACWQh9Blh0hlg");
	this.shape_9.setTransform(0.575,-15.025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F8D8A9").s().p("Ah4AyIAAiWIDxAAIAACWQg/Azg7AAQg9AAg6gzg");
	this.shape_10.setTransform(0.575,-15.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4h6IDxAAIAACrQh9CUh0iUg");
	this.shape_11.setTransform(0.575,-12.8125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F8D8A9").s().p("Ah4AxIAAirIDxAAIAACrQg/BKg8AAQg8AAg6hKg");
	this.shape_12.setTransform(0.575,-12.8125);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#333333").ss(0.5,1,1).p("AB5AwQh+DChzjCIAAjAIDxAAg");
	this.shape_13.setTransform(0.575,-10.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#F8D8A9").s().p("Ah4AwIAAjAIDxAAIAADAQhABhg7AAQg8AAg6hhg");
	this.shape_14.setTransform(0.575,-10.6);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},15).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},3).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).to({state:[]},1).wait(44));

	// Layer_3
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgNAOQgGgGAAgIQAAgHAGgGQAGgGAHAAQAJAAAFAGQAGAGAAAHQAAAIgGAGQgFAGgJAAQgHAAgGgGg");
	this.shape_15.setTransform(-3.1417,-6.7457,0.8313,0.8313);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#333333").ss(0.5,1,1).p("AAlgkQAPAPAAAVQAAAVgPAPQgPAPgWAAQgUAAgPgPQgPgPAAgVQAAgVAPgPQAPgPAUAAQAWAAAPAPg");
	this.shape_16.setTransform(0.1564,-5.0263,0.8314,0.8314);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgjAkQgPgPgBgVQABgVAPgPQAPgPAUAAQAWAAAPAPQAPAPAAAVQAAAVgPAPQgPAPgWABQgUgBgPgPg");
	this.shape_17.setTransform(0.1564,-5.0263,0.8314,0.8314);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15}]}).wait(75));

	// Layer_1
	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#E09F3F").ss(0.5,1,1).p("ABAhIQAbAeAAAqQAAArgbAeQgaAegmAAQglAAgbgeQgageAAgrQAAgqAageQAbgeAlAAQAmAAAaAeg");
	this.shape_18.setTransform(0.025,-10.325);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AhABJQgageAAgrQAAgqAageQAbgeAlAAQAmAAAaAeQAbAeAAAqQAAArgbAeQgaAegmAAQglAAgbgeg");
	this.shape_19.setTransform(0.025,-10.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18}]}).wait(75));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,-21.6,20.1,22.6);


(lib.eye = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#517924").ss(0.5,1,1).p("ABnhtQApAtAABAQAABBgpApQgpAtg+AAQg7AAgrgtQgpgpAAhBQAAhAApgtQArgpA7AAQA+AAApApg");
	this.shape.setTransform(0,-15.125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(75));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhmBqQgogpAAhBQAAhAAogtQArgpA7AAQA+AAApApQAoAtAABAQAABBgoApQgpAtg+AAQg7AAgrgtg");
	mask.setTransform(0,-15.125);

	// Layer_5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#333333").ss(0.5,1,1).p("AClAvQiliSikCSIAAhdIFJAAg");
	this.shape_1.setTransform(0.175,-29.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#88C641").s().p("AikAvIAAhdIFJAAIAABdQiliSikCSg");
	this.shape_2.setTransform(0.175,-29.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#333333").ss(0.5,1,1).p("Aikg8IFJAAIAAB5QikhTilBTg");
	this.shape_3.setTransform(0.175,-28);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#88C641").s().p("AikA9IAAh5IFJAAIAAB5QikhTilBTg");
	this.shape_4.setTransform(0.175,-28);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#333333").ss(0.5,1,1).p("AikhLIFJAAIAACXQikgVilAVg");
	this.shape_5.setTransform(0.175,-26.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#88C641").s().p("AikBMIAAiXIFJAAIAACXQikgVilAVg");
	this.shape_6.setTransform(0.175,-26.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#333333").ss(0.5,1,1).p("AikhkIFJAAIAAC1QijApimgpg");
	this.shape_7.setTransform(0.175,-23.875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#88C641").s().p("AikBRIAAi1IFJAAIAAC1QhSAUhSAAQhSAAhTgUg");
	this.shape_8.setTransform(0.175,-23.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#333333").ss(0.5,1,1).p("AikiDIFJAAIAADTQijBoimhog");
	this.shape_9.setTransform(0.175,-20.75);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#88C641").s().p("AikBQIAAjTIFJAAIAADTQhSAzhSAAQhSAAhTgzg");
	this.shape_10.setTransform(0.175,-20.75);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#333333").ss(0.5,1,1).p("AikihIFJAAIAADvQijCniming");
	this.shape_11.setTransform(0.175,-17.65);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#88C641").s().p("AikBOIAAjvIFJAAIAADvQhSBUhSAAQhRAAhUhUg");
	this.shape_12.setTransform(0.175,-17.65);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#333333").ss(0.5,1,1).p("AClBOQiiDlinjlIAAkNIFJAAg");
	this.shape_13.setTransform(0.175,-14.5075);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#88C641").s().p("AikBOIAAkNIFJAAIAAENQhRByhTAAQhRAAhUhyg");
	this.shape_14.setTransform(0.175,-14.5075);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},9).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},3).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).wait(51));

	// Layer_1
	this.instance = new lib.CachedBmp_166();
	this.instance.setTransform(-11.35,-22.05,0.5,0.5);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(75));

	// Layer_3
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AhmBqQgogpAAhBQAAhAAogtQArgpA7AAQA+AAApApQAoAtAABAQAABBgoApQgpAtg+AAQg7AAgrgtg");
	this.shape_15.setTransform(0,-15.125);

	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(75));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-15.3,-31.2,30.700000000000003,32.2);


(lib.DIps = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EB7688").s().p("AgNAhQgOgOAAgTQAAgTAOgNQANgOATAAIADAAIAEAOQADAMgBAYQgCAYgKATQgSgDgLgLg");
	this.shape.setTransform(42.7225,-13.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFA4A6").s().p("AggAhQgOgOAAgTQAAgSAOgOQANgOATAAQATAAAPAOQANAOAAASQAAATgNAOQgPAOgTAAQgTAAgNgOg");
	this.shape_1.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.DIps, new cjs.Rectangle(-4.7,-18.2,50.300000000000004,22.9), null);


(lib.dfbzeye = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(0.5,1,1).p("AAAg9QAXAAAQATQAQASAAAYQAAAagQASQgQASgXAAQgWAAgQgSQgQgSAAgaQAAgYAQgSQAQgTAWAAg");
	this.shape.setTransform(-0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(85));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgmArQgQgRAAgaQAAgYAQgSQAQgSAWAAQAXAAAQASQAQASAAAYQAAAagQARQgQATgXgBQgWABgQgTg");
	mask.setTransform(-0.025,0);

	// Layer_5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#333333").ss(0.5,1,1).p("AhHAtIAAhZICPAAIAABZQhIighHCgg");
	this.shape_1.setTransform(0.1146,-3.675,1.1457,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#404042").s().p("AhHAtIAAhZICPAAIAABZQhIighHCgg");
	this.shape_2.setTransform(0.1146,-3.675,1.1457,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#333333").ss(0.5,1,1).p("AhSgsIClAAIAABZQhThvhSBvg");
	this.shape_3.setTransform(0.1,-3.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#404042").s().p("AhSAtIAAhZIClAAIAABZQhThvhSBvg");
	this.shape_4.setTransform(0.1,-3.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#333333").ss(0.5,1,1).p("AhSgsIClAAIAABZQhTg/hSA/g");
	this.shape_5.setTransform(0.1,-3.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#404042").s().p("AhSAtIAAhZIClAAIAABZQhTg/hSA/g");
	this.shape_6.setTransform(0.1,-3.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#333333").ss(0.5,1,1).p("AhSgsIClAAIAABZQhTgPhSAPg");
	this.shape_7.setTransform(0.1,-3.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#404042").s().p("AhSAtIAAhZIClAAIAABZQhTgPhSAPg");
	this.shape_8.setTransform(0.1,-3.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#333333").ss(0.5,1,1).p("AhSg1IClAAIAABaQhTAhhSghg");
	this.shape_9.setTransform(0.1,-2.85);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#404042").s().p("AhSAlIAAhZIClAAIAABZQgqAQgpAAQgoAAgqgQg");
	this.shape_10.setTransform(0.1,-2.85);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#333333").ss(0.5,1,1).p("AhShBIClAAIAABaQhTBRhShRg");
	this.shape_11.setTransform(0.1,-1.6375);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#404042").s().p("AhSAZIAAhaIClAAIAABaQgqApgpAAQgoAAgqgpg");
	this.shape_12.setTransform(0.1,-1.6375);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#333333").ss(0.5,1,1).p("AhHANIAAhaICPAAIAABaQhHCChIiCg");
	this.shape_13.setTransform(0.1146,-0.4306,1.1457,1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#404042").s().p("AhHANIAAhaICPAAIAABaQgkBBgkAAQgjAAgkhBg");
	this.shape_14.setTransform(0.1146,-0.4306,1.1457,1);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},15).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},4).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).wait(54));

	// Layer_2
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgGAIQgCgDAAgFQAAgDACgDQADgDADAAQAEAAACADQADADAAADQAAAFgDADQgCACgEAAQgDAAgDgCg");
	this.shape_15.setTransform(0.325,2.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgTAWQgIgJAAgNQAAgMAIgJQAJgJAKAAQALAAAJAJQAIAJAAAMQAAANgIAJQgJAJgLAAQgKAAgJgJg");
	this.shape_16.setTransform(1.85,1.675);

	var maskedShapeInstanceList = [this.shape_15,this.shape_16];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15}]}).wait(85));

	// Layer_3
	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgmArQgQgRAAgaQAAgYAQgSQAQgSAWAAQAXAAAQASQAQASAAAYQAAAagQARQgQATgXgBQgWABgQgTg");
	this.shape_17.setTransform(-0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape_17).wait(85));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6.5,-7.1,13,14.3);


(lib.btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("EgjAAHeIAAu7MBGBAAAIAAO7g");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-224.1,-47.8,448.2,95.6), null);


(lib.broadCastInterface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_1 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_599 = function() {
		/* stop();
		this.blnPlay = false;
		MovieClip(parent.parent.parent.parent).mcForward.mcGlow.gotoAndPlay(6);*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(598).call(this.frame_599).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Body = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#A46715").ss(0.3,1,1).p("ABwltQgIg0gRgvQgKgeglgLQgEgBgEgBQgDgBgDAAQgEgBgFAAQgQgDgRABQhZAAApBTQAlAnAJB0QgCAGgDAFQgJAVgIAWQgbBLgIBUQhqBYg3BnQgJAQgHARQgwBsASB4QABADAAADQABAHACAGAETB0QAEhsgWhMQgXhOgshDQgCgDgBgDQgqhBgdhFIgDgMAETB0QAQAcgEAMQgCAIgKABQgEABgEAAIAAAAIAAAAAETB0QgBAMgCANQgBACAAACQgCAKgCAKQAAAAAAABQgZAAglgTQgVgLgTgPQgMgKgMgLQgEgDgDgDAi7HvQAFACAFACQAEABAFACQAGABAGACQAKADAKABQAlAGAlgGQAlgGAkgTQAYgNAagRIAAAAQABgBABgBQAGgEAGgFQAEgEAFgDQAMgLAMgKQAGgHAHgGQAEgEAEgDQB4huAhhsQADgKACgL");
	this.shape.setTransform(-0.0173,-3.9792);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DE8529").s().p("Ah4C6QAGgGAHgDIgNAKIAAgBgAhmCrIAMgJIgMAKIgEAEIAEgFgAhdCiQATgTAQgTQA4hEAVg+QAXhEgrhIQgMgTgRgUIAGAFQAJAHAPAKIAAAEIgYgVIAYAVQASAPAVALQAlATAZAAIAAABIAAgBIAIgBQAKgBACgIIgFAWQghBqh3BuIgIAIIgNAMIgYAVIgJAHIgMAJIAJgJg");
	this.shape_1.setTransform(16.575,24.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F0AF88").s().p("AgNAFQgUgKgTgPIAAgDIAMAHQAiATAYACQAXACANgHIgBAEIgEATIgBABQgZAAgkgTg");
	this.shape_2.setTransform(21.8,10.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#BA5B17").s().p("AgJAYIADgUIABgEIAEgYQAPAbgEAMQgDAIgJABIgHABg");
	this.shape_3.setTransform(27.74,10.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E8A64F").s().p("ACGIoIAFAAIAAAAgAhZHVIgTgEIgMgDIgJgDIgKgEIgUgIQgYgMgRgPQgSgSgJgWIgDgJIgDgNIgBgGQgTh4AwhsQAHgRAJgQQA3hmBqhZQAIhUAbhLQAHgWAKgVIAFgLQgKh0gkgnQgohTBXAAQATgBAQADQAHAFAEABQAjAvAOBQQAPBPAHASIAVAtIAJAPQAlBAALBLQANBVgJAwQgKAxgGAPQgQgKgIgHIgHgGQARAUANAUQArBIgXBEQgVA/g5BDQgQAUgTATIgIAJIgCACIAAAAIAAAAIACgCIgFAFIADgDQgaARgZANQglATgjAGQgTADgTAAQgSAAgTgDgABvGcIAAAAg");
	this.shape_4.setTransform(-4.7846,0.0208);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F9D5B1").s().p("ABZFIQgYgCgigUIgMgHQAGgQAKgwQAJgxgNhVQgLhMgkg/IgJgPIgVgtQgHgRgPhQQgOhQgjgvQgEAAgHgGIAJACIAFABIAIACQAmALAKAdQAQAwAJAzIAAABIADALQAeBGAoBAIAEAGQAsBCAWBOQAWBOgDBrIgEAZQgKAHgRAAIgJgBg");
	this.shape_5.setTransform(14.624,-22.13);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.8,-56.2,59.6,111.5);


(lib.bg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.Bitmap15();
	this.instance.setTransform(-494,-297);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-494,-297,988,594);


(lib.tortoisehead = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.eye();
	this.instance.setTransform(42,-132.8);

	this.instance_1 = new lib.CachedBmp_212();
	this.instance_1.setTransform(48.6,-172.1,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_211();
	this.instance_2.setTransform(-74.45,-187.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74.4,-187.8,149,188.5);


(lib.tortoiseanim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// tortoise_head
	this.instance = new lib.tortoisehead("single",0);
	this.instance.setTransform(42.7,-128.25,1,1,0,0,0,-73,-21.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:0.9997,scaleY:0.9997,rotation:3.0325,y:-124.05},14).to({scaleX:1,scaleY:1,rotation:0,y:-128.25},15).wait(11));

	// Layer_3
	this.instance_1 = new lib.torgrd("single",0);
	this.instance_1.setTransform(-40.6,-187.9,1,1,0,0,0,0,-75.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({y:-183.7},14).to({y:-187.9},15).wait(11));

	// Layer_5
	this.instance_2 = new lib.torleg2("single",0);
	this.instance_2.setTransform(-35.55,-0.35,0.9992,0.9992,-0.3465,0,0,1.3,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({scaleY:0.9677,rotation:-0.346},14).to({scaleY:0.9992,rotation:-0.3465},15).wait(11));

	// Layer_4
	this.instance_3 = new lib.torleg3("single",0);
	this.instance_3.setTransform(-132.75,-7.1,0.9989,0.9989,0.7545,0,0,1.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({scaleY:0.9483,rotation:0.7542},14).to({scaleY:0.9989,rotation:0.7545},15).wait(11));

	// Layer_6
	this.instance_4 = new lib.torbase("single",0);
	this.instance_4.setTransform(-56,-104.55,1,1,0,0,0,-0.1,-46.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({y:-100.35},14).to({y:-104.55},15).wait(11));

	// Layer_7
	this.instance_5 = new lib.torleg4("single",0);
	this.instance_5.setTransform(-95.1,-26.7,0.999,0.999,4.5654,0,0,3,1);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({regY:1.1,scaleY:0.9309,rotation:4.5652,y:-26.65},14).to({regY:1,scaleY:0.999,rotation:4.5654,y:-26.7},15).wait(11));

	// Layer_8
	this.instance_6 = new lib.torleg1("single",0);
	this.instance_6.setTransform(35.7,-16.9,1.0028,0.9967,0,0.0272,-0.1142,3,1.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({scaleY:0.9531,skewX:0.0284},14).to({scaleY:0.9967,skewX:0.0272},15).wait(11));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-190.6,-294.4,389.4,295.29999999999995);


(lib.right_wrong = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// Layer_1
	this.instance = new lib.Symbol1("synched",0);
	this.instance.setTransform(-3.45,1.75);
	this.instance.alpha = 0.0117;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0.251)").s().p("AsuryIAKgKQAxgyBHAAQBGAAAyAyIIhIgIIgogQAxgyBHAAQBGAAAyAyQAyAyAABGQAABHgyAxIohIgIIhIhQAyAxAABHQAABGgyAzIgKAJg");
	this.shape.setTransform(-2.7088,0.9623,0.2531,0.2749);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().ls(["#C80000","#7E0101"],[0,1],-84.6,-0.2,84.3,-0.2).ss(2,1,1).p("AqYtCQhHAAgxAyQgFAEgFAGQgZAdgKAkQgFAVAAAYQAABGAyAyIIgIgIogIhQgyAxAABHQAABHAyAyQAxAxBHAAQBGAAAygxIIgohIIhIhQAxAxBHAAQAXAAAWgGQAkgJAdgZQAFgFAFgEQAygyAAhHQAAhHgygxIohohIIhogQAygyAAhGQAAhHgygxQgygyhGAAQhHAAgxAyIohIgIogogQgygyhGAAg");
	this.shape_1.setTransform(-3.1668,1.5329,0.2532,0.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#C80000").s().p("AIhMSIohoiIogIiQgxAxhHAAQhHAAgxgxQgygzAAhGQAAhHAygxIIgohIogogQgygxAAhHQAAgXAGgWQAJgkAagdIAJgKQAxgyBHAAQBHAAAxAyIIgIgIIhogQAygyBGAAQBHAAAxAyQAyAyAABGQAABHgyAxIogIgIIgIhQAyAxAABHQAABGgyAzIgKAJQgdAZgkAKQgVAFgYAAQhGAAgygxg");
	this.shape_2.setTransform(-3.1668,1.5329,0.2532,0.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(224,254,103,0.251)").s().p("As9D+QgygxAAhHQAAhGAygyQAxgxBHAAQBGAAAzAxIEEEEIl7BmgAJOlFQAxgyBHAAQBHAAAyAyQAxAxAABHQAABGgxAzIhCBBIqSCvg");
	this.shape_3.setTransform(3.4074,-7.6853,0.3453,0.3453);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().ls(["#95C801","#667E01"],[0,1],-60.6,-41.6,23.3,42.2).ss(2,1,1).p("AM+ovQgygyhGAAQhHAAgxAyIr3L2ImkmiQgygyhGAAQhHAAgxAyQgyAxAABHQAABGAyAxIIcIcQAxAyBHAAQBGAAAygyINvtvQAygyAAhGQAAhHgygxg");
	this.shape_4.setTransform(3.4509,0.4017,0.3454,0.3454);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#95C801").s().p("AkhIwIococQgygwAAhHQAAhGAygyQAxgyBHAAQBGAAAzAyIGjGiIL3r2QAxgyBHAAQBHAAAyAyQAxAxAABHQAABGgxAzItvNuQgzAyhGAAQhHAAgxgyg");
	this.shape_5.setTransform(3.4509,0.4017,0.3454,0.3454);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.9,-23.2,62.8,50);


(lib.lionhead = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.lioneye();
	this.instance.setTransform(-49.25,-186.2,0.7737,0.7737,0,0,0,0,-10);

	this.instance_1 = new lib.lioneye();
	this.instance_1.setTransform(-8.5,-183.25,1.0206,1.0206,0,0,0,0,-9.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_2 = new lib.Bitmap11();
	this.instance_2.setTransform(-120,-272);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.lionhead, new cjs.Rectangle(-120,-272,218,274), null);


(lib.lionanim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.lionhead();
	this.instance.setTransform(-72.4,-247.05,1,1,0,0,0,-6,-119.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:-119.4,scaleX:0.9997,scaleY:0.9997,rotation:-3.7817,x:-75.45,y:-238.8},12,cjs.Ease.get(1)).wait(6).to({regY:-119.5,scaleX:1,scaleY:1,rotation:0,x:-72.4,y:-247.05},15).wait(21).to({regY:-119.4,scaleX:0.9997,scaleY:0.9997,rotation:-3.7817,x:-75.45,y:-238.8},12,cjs.Ease.get(1)).wait(6).to({regY:-119.5,scaleX:1,scaleY:1,rotation:0,x:-72.4,y:-247.05},15).wait(19));

	// Layer_1
	this.instance_1 = new lib.Bitmap12();
	this.instance_1.setTransform(-108,-196);

	this.instance_2 = new lib.CachedBmp_206();
	this.instance_2.setTransform(-124.7,-258.6,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1}]}).wait(106));

	// ncvvbcvb
	this.instance_3 = new lib.ncvvbcvb("synched",0);
	this.instance_3.setTransform(117.9,-80.15,1,1,0,0,0,7.9,123.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regY:124,scaleX:0.9998,scaleY:0.9998,rotation:2.7607,x:117.7,y:-80.25},9,cjs.Ease.get(0.5)).wait(3).to({startPosition:0},0).to({regY:123.9,scaleX:1,scaleY:1,rotation:0,x:117.9,y:-80.15},10).wait(4).to({startPosition:0},0).to({regY:124,scaleX:0.9998,scaleY:0.9998,rotation:2.7607,x:117.7,y:-80.25},9,cjs.Ease.get(0.5)).wait(3).to({startPosition:0},0).to({regY:123.9,scaleX:1,scaleY:1,rotation:0,x:117.9,y:-80.15},10).wait(5).to({startPosition:0},0).to({regY:124,scaleX:0.9998,scaleY:0.9998,rotation:2.7607,x:117.7,y:-80.25},9,cjs.Ease.get(0.5)).wait(3).to({startPosition:0},0).to({regY:123.9,scaleX:1,scaleY:1,rotation:0,x:117.9,y:-80.15},10).wait(5).to({startPosition:0},0).to({regY:124,scaleX:0.9998,scaleY:0.9998,rotation:2.7607,x:117.7,y:-80.25},9,cjs.Ease.get(0.5)).wait(3).to({startPosition:0},0).to({regY:123.9,scaleX:1,scaleY:1,rotation:0,x:117.9,y:-80.15},10).wait(4));

	// vbcbcbcv
	this.instance_4 = new lib.vbcbcbcv("synched",0);
	this.instance_4.setTransform(110.95,-352.15,1,1,0,0,0,-25.2,-82.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({regX:-25.1,scaleX:0.999,scaleY:0.999,rotation:-0.7448,x:124.75,y:-351.85},9,cjs.Ease.get(0.5)).wait(3).to({startPosition:0},0).to({regX:-25.2,scaleX:1,scaleY:1,rotation:0,x:110.95,y:-352.15},10).wait(4).to({startPosition:0},0).to({regX:-25.1,scaleX:0.999,scaleY:0.999,rotation:-0.7448,x:124.75,y:-351.85},9,cjs.Ease.get(0.5)).wait(3).to({startPosition:0},0).to({regX:-25.2,scaleX:1,scaleY:1,rotation:0,x:110.95,y:-352.15},10).wait(5).to({startPosition:0},0).to({regX:-25.1,scaleX:0.999,scaleY:0.999,rotation:-0.7448,x:124.75,y:-351.85},9,cjs.Ease.get(0.5)).wait(3).to({startPosition:0},0).to({regX:-25.2,scaleX:1,scaleY:1,rotation:0,x:110.95,y:-352.15},10).wait(5).to({startPosition:0},0).to({regX:-25.1,scaleX:0.999,scaleY:0.999,rotation:-0.7448,x:124.75,y:-351.85},9,cjs.Ease.get(0.5)).wait(3).to({startPosition:0},0).to({regX:-25.2,scaleX:1,scaleY:1,rotation:0,x:110.95,y:-352.15},10).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-199.2,-399.5,378.2,400.5);


(lib.house_shadow_2_T1_T3_4_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.separater("synched",0);
	this.instance.setTransform(-314.45,-59.7);

	this.instance_1 = new lib.separater("synched",0);
	this.instance_1.setTransform(-172.45,-59.7);

	this.instance_2 = new lib.separater("synched",0);
	this.instance_2.setTransform(-8.45,-59.7);

	this.instance_3 = new lib.separater("synched",0);
	this.instance_3.setTransform(131.55,-59.7);

	this.instance_4 = new lib.separater("synched",0);
	this.instance_4.setTransform(297.55,-59.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_5 = new lib.CachedBmp_205();
	this.instance_5.setTransform(357,-110.6,0.5,0.5);

	this.instance_6 = new lib.eyeboy();
	this.instance_6.setTransform(362.75,-95.7,0.3498,0.3498,0,0,0,0.1,0);

	this.instance_7 = new lib.eyeboy();
	this.instance_7.setTransform(377.75,-95.4,0.3498,0.3498,0,0,0,0.1,0);

	this.instance_8 = new lib.CachedBmp_204();
	this.instance_8.setTransform(361.7,-88.7,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_203();
	this.instance_9.setTransform(338.65,-136.35,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_228();
	this.instance_10.setTransform(326.95,-83,0.5,0.5);

	this.instance_11 = new lib.DIps();
	this.instance_11.setTransform(221.2,-68.2,0.7891,0.7891,0,0,180,-0.2,0);
	this.instance_11.filters = [new cjs.BlurFilter(7, 7, 2)];
	this.instance_11.cache(-7,-20,54,27);

	this.instance_12 = new lib.CachedBmp_227();
	this.instance_12.setTransform(190.05,-93.65,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_200();
	this.instance_13.setTransform(163.6,-124.15,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_199();
	this.instance_14.setTransform(159.85,-62.1,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_198();
	this.instance_15.setTransform(49.1,-110.6,0.5,0.5);

	this.instance_16 = new lib.eyeboy();
	this.instance_16.setTransform(54.85,-95.7,0.3498,0.3498,0,0,0,0.8,0);

	this.instance_17 = new lib.eyeboy();
	this.instance_17.setTransform(69.85,-95.4,0.3498,0.3498,0,0,0,0.8,0);

	this.instance_18 = new lib.CachedBmp_197();
	this.instance_18.setTransform(53.8,-88.7,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_196();
	this.instance_19.setTransform(30.75,-136.35,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_226();
	this.instance_20.setTransform(19.05,-83,0.5,0.5);

	this.instance_21 = new lib.DIps();
	this.instance_21.setTransform(-86.7,-68.2,0.7891,0.7891,0,0,180,0.2,0);
	this.instance_21.filters = [new cjs.BlurFilter(7, 7, 2)];
	this.instance_21.cache(-7,-20,54,27);

	this.instance_22 = new lib.CachedBmp_225();
	this.instance_22.setTransform(-117.85,-93.65,0.5,0.5);

	this.instance_23 = new lib.CachedBmp_193();
	this.instance_23.setTransform(-144.25,-124.15,0.5,0.5);

	this.instance_24 = new lib.CachedBmp_192();
	this.instance_24.setTransform(-148,-62.1,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_191();
	this.instance_25.setTransform(-258.75,-110.6,0.5,0.5);

	this.instance_26 = new lib.eyeboy();
	this.instance_26.setTransform(-253.05,-95.7,0.3498,0.3498);

	this.instance_27 = new lib.eyeboy();
	this.instance_27.setTransform(-238.05,-95.4,0.3498,0.3498);

	this.instance_28 = new lib.CachedBmp_190();
	this.instance_28.setTransform(-254.05,-88.7,0.5,0.5);

	this.instance_29 = new lib.CachedBmp_189();
	this.instance_29.setTransform(-277.15,-136.35,0.5,0.5);

	this.instance_30 = new lib.CachedBmp_224();
	this.instance_30.setTransform(-288.85,-83,0.5,0.5);

	this.instance_31 = new lib.DIps();
	this.instance_31.setTransform(-394.55,-68.2,0.7891,0.7891,0,0,180);
	this.instance_31.filters = [new cjs.BlurFilter(7, 7, 2)];
	this.instance_31.cache(-7,-20,54,27);

	this.instance_32 = new lib.CachedBmp_223();
	this.instance_32.setTransform(-425.6,-93.65,0.5,0.5);

	this.instance_33 = new lib.CachedBmp_186();
	this.instance_33.setTransform(-452,-124.15,0.5,0.5);

	this.instance_34 = new lib.CachedBmp_185();
	this.instance_34.setTransform(-455.75,-62.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5}]}).wait(1));

	// Layer_2
	this.instance_35 = new lib.patch_2_T1_T3_4_5();
	this.instance_35.setTransform(-21.55,-58.6);
	this.instance_35.shadow = new cjs.Shadow("rgba(147,92,57,1)",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_35).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-492.7,-159.6,945,205);


(lib.house_shadow_2_T1_T3_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.separater("synched",0);
	this.instance.setTransform(-272.45,-59.7);

	this.instance_1 = new lib.separater("synched",0);
	this.instance_1.setTransform(262.55,-59.7);

	this.instance_2 = new lib.separater("synched",0);
	this.instance_2.setTransform(64.55,-59.7);

	this.instance_3 = new lib.separater("synched",0);
	this.instance_3.setTransform(-105.45,-59.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_4 = new lib.CachedBmp_184();
	this.instance_4.setTransform(98.15,-105.45,0.5,0.5);

	this.instance_5 = new lib.dfbzeye();
	this.instance_5.setTransform(109.75,-99.05);

	this.instance_6 = new lib.CachedBmp_183();
	this.instance_6.setTransform(71.45,-126.15,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_182();
	this.instance_7.setTransform(87.05,-88.3,0.5,0.5);

	this.instance_8 = new lib.tortoiseanim();
	this.instance_8.setTransform(345.65,8.75,0.4028,0.4028,0,0,180);

	this.instance_9 = new lib.tortoiseanim();
	this.instance_9.setTransform(-20.6,8.75,0.4028,0.4028,0,0,180);

	this.instance_10 = new lib.tortoiseanim();
	this.instance_10.setTransform(-189.55,8.75,0.4028,0.4028,0,0,180);

	this.instance_11 = new lib.CachedBmp_181();
	this.instance_11.setTransform(-437.05,-105.45,0.5,0.5);

	this.instance_12 = new lib.dfbzeye();
	this.instance_12.setTransform(-425.45,-99.05);

	this.instance_13 = new lib.CachedBmp_183();
	this.instance_13.setTransform(-463.75,-126.15,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_179();
	this.instance_14.setTransform(-448.15,-88.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4}]}).wait(1));

	// Layer_2
	this.instance_15 = new lib.patch_2_T1_T3_4();
	this.instance_15.setTransform(-21.55,-58.6);
	this.instance_15.shadow = new cjs.Shadow("#935C39",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-492.7,-159.6,945,205);


(lib.Headv = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Eyevv();
	this.instance.setTransform(1.65,4.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(2));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#741F00").s().p("AgVAWQgDgCANgSQALgSAJgDQAKgEADAHQACAIgGACQgHACgIAFQgHAFgHAJQgHAHgCAAIgBAAg");
	this.shape.setTransform(-2.0361,-2.4577);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(2));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#671C07").ss(0.3,1,1).p("AgFgfQgMABgKANQgDAFgBAFQAAAAAAABQAAADAAADQAAABABABQABAHAFAIQAMAVAegJQAJgIAEgKQAAgBAAAAQAAgDABgEQAAgDAAgEQgBgBAAgCQgFgZgYABQgCAAgBAAQgCAAgBAAQAAAAgBAAg");
	this.shape_1.setTransform(29.425,15.0596);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#A46715").ss(0.3,1,1).p("AA6hlQgQgHgRgDQgQgEgPgBQgGAAgFAAQgPABgPADIAAAAQgLgigKgzQgJgoABgVQAAgGABgFQADgUALANQALAOAiArQAhAqAPAcQAQAbAKAVQAMAEAMAHQADACAEACQgigIgNAKQAnACAhAdQgYgHgSAHQAhAaAOAVQAHALABALQABALAAAPQgBAOAJAQQATAlA4AJQAoAGAtAAAjjikQACADACAEQABABABACQAMASAgAiQAoAqADACQAAAAABgBQAKgNALgJQgsgigRgRQgLgKgOgMQgKgJgLgJQgagVARAcAingLQhPhIgnhHQgLgVgIgUQgHgRgEgSQAAAAAAgBQgZhiDFCvQAbAYAgAeQABAAABgBQALgFANgDQAFgCAGgBAingLQAGAFAGAGAhmDpQgPgNgBgBQgCgBgCgCQAAAAgBgBQgsgigWg5QgXg5AthOAE/C5QgDACgDACQgUAOgVAJQgCABgCABQgfAPghAHQgUAEgVACAAgDmQAIgNAEgGQABAAAAgBQACgDACgCAAkDhIABAAQAJADAKADQAAAAAAAAQAdAHAdADIAAAAQAGAAAHABQAIAAAHAAQADAAACAAQAEAAAEAAQAEAAAEAAQgBAAAAAAQAAABgBABQgBABAAACQgJAOgOAJQgJAGgMADQgEABgFABQgCAAgDABQgRABgUgDQgKgCgLgDQgIgDgEgCIgDgBIAAgBAAsEVQgPAGgMgCQgCAAgCAA");
	this.shape_2.setTransform(-0.7108,-0.4644);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFC1B4").s().p("AADAIQgfgggNgTIgCgCIgEgHIAFAAQAIAEAoAqQAqArAAAGIgBAJIgCABIgqgtg");
	this.shape_3.setTransform(-18.775,-11.65);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F7C18C").s().p("AAAACIAAgDIAAADg");
	this.shape_4.setTransform(0.475,27.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F9D5B1").s().p("AgIALIgBgDIAAgEQAAgKABgEIAPAKIADABIgDgBIAAAAIAAAAQAAAHgLADIgEABg");
	this.shape_5.setTransform(1.475,26.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F0AF88").s().p("ABwDnIAAgBQAMgDAAgIIAEABIAMAFQgBAAAAAAQgBAAAAAAQAAABABAAQAAAAABABQgMAFgKAAIgGgBgAgkh2QAAgGgqgrQgpgrgIgEIgFAAIAAgBQgRgcAZAVIAVASIAZAWQASARAsAiQgLAJgKANIABgJg");
	this.shape_6.setTransform(-10.29,4.5068);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#30201B").s().p("AAdAFIAAAAIAAAAIAAAAgAgcgEIAAAAIAAABg");
	this.shape_7.setTransform(7.7762,23.0993);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#671C07").s().p("AgYAFQgFgHgBgHIAAgDIAAgHIAAADIABACIABABQADAFAHAGQAMAKARgDQASgEACgCQgDAKgKAIQgJADgHAAQgRAAgJgPg");
	this.shape_8.setTransform(29.3625,16.31);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#B76649").s().p("AgMAHQgDgBgBgDIgBgDQAAgEAFgDQAFgEAHAAQAIAAAFAEQAFADAAAEIgBADQgBADgDABQgFAFgIAAQgHAAgFgFg");
	this.shape_9.setTransform(29.7,13.95);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#812C03").s().p("AgTARQgHgHgDgEIAAgBIgBgCIgBgDIAAAAQABgFADgFQAKgNAMgBIABAAIADAAIADAAQAYgBAFAZIABACIAAAIIgBAHIAAABQgCADgSADIgIABQgNAAgJgIgAgJgMQgFAEAAAFIAAADQABABAEACQAFAEAHAAQAHAAAFgEQAEgCABgBIABgDQAAgFgGgEQgFgDgHAAQgHAAgFADg");
	this.shape_10.setTransform(29.4375,14.3579);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#E8A64F").s().p("ABLEMQAVAEARgCIAFgBIgEABQgHABgKAAQgKAAgMgDgAASEMIgDgBIgXgFIgYgJIgUgJIgOgHQgVgMgEgEIgRgOIgDgDIgCAAQgsgjgWg4QgWg5AshOIAMAKIgMgKQhPhIgnhIQgKgUgJgVQgHgRgEgSIAAgBQAAgLAIgIQAGgGAKAAQAPAABQBHQBLBEAeAjQAAAAAAAAQAAAAABAAQAAABAAAAQAAAAAAABQA7gdA9AHIAEABQAYADAYAIIAHAEQgigIgMALQAmABAiAdQgZgHgSAHQAhAbAOAUQAHAMABAKQABALAAAPQgBAPAJAPQATAlA5AJQAnAHAtgBQgMAAgKAOQgDAFgBAEIAAABIAAAHIgBADIAAAHQACAHAFAJQAGAJAJADQgdATgtAKQgsAKgugCQgtgBglgSIAEgFIgEAFIAAAAIAAAAIgMATIAMgTIgJAOIAAAAIABAAIATAGIAAABIAAgBQAdAHAdADIABAAIAMABIAQABIAFAAIAIgBIAHAAIgBABQgKABgCgBQgmA4hpguIAHAGQgCAEAAAKIAAAFIAAABIABACIgFgBgAjZiwIAAABIAEAGIACADQANASAfAiIArAsIABgBQALgMALgJQgtgjgRgRIgZgWIgVgSQgLgJgDAAQgEAAAKARgAADiAIgKAAQgPABgPADIAAAAQgLgigKgzQgJgoABgVIADgBQATAABPCUQgPgDgRgCg");
	this.shape_11.setTransform(-1.75,0.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#DE8529").s().p("ABBEYIgVgFIgMgFIgDgCIgQgKIgHgFQBpAuAng5QACACAKgCIgBACIABgCIADAAIgEACIgBADQgJAOgOAJQgJAGgMADIgJACIgFABIgLAAQgNAAgNgCgACODyIgPAAIgNgBIAAgBIAAAAIAAABQgdgDgdgHIAAAAIgTgGIgBAAIAIgOIABgBIAAAAQAlASAtACQAuABAsgJQAtgKAdgTQgKgDgFgJQgGgJgBgHIAAgHIABgDIAAADQABAHAFAIQANAVAegJIgGAEQgUAOgVAJIgEACQgfAPghAHQgUAEgVACIgIAAIgIAAIgFAAgAAsDTIABgBIgBABgAAkDhIAAAAIABAAgAAkDhgAhchSQgdgkhLhDQhQhHgPAAQgKAAgHAGQgHAHAAAMQgZhiDFCvIA7A2IACgBQALgFANgDIALgDQAPgDAPgBIALAAQAPABAQAEQhPiUgUAAIgCABIABgLQADgUALANIAtA5QAhAqAPAcQAQAbAKAVQgQgHgRgDQARADAQAHQAMAEAMAHQgZgJgYgDIgDAAQg9gHg7AcQAAAAAAgBQgBAAAAAAQAAAAAAAAQgBAAAAAAg");
	this.shape_12.setTransform(-0.7108,-0.4644);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).to({state:[]},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-33.6,-29.7,67.2,58.5);


(lib.heading02_2_T1_T3_4_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-80,-41.6,0.4997,1.7875,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.DIps();
	this.instance.setTransform(-73.1,-53,0.789,0.789,0,0,180,0.3,0);
	this.instance.filters = [new cjs.BlurFilter(7, 7, 2)];
	this.instance.cache(-7,-20,54,27);

	this.instance_1 = new lib.CachedBmp_222();
	this.instance_1.setTransform(-104.3,-78.45,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_177();
	this.instance_2.setTransform(-130.75,-108.95,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_176();
	this.instance_3.setTransform(-134.5,-46.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(2));

	// Layer_1
	this.instance_4 = new lib.patch1_2_T1_T3_4_5();
	this.instance_4.setTransform(-83.95,-47.95,1,1,0,0,0,-352.1,-4);
	this.instance_4.shadow = new cjs.Shadow("rgba(147,92,57,1)",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-203,-145,246,206);


(lib.heading02_2_T1_T3_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-80,-45.6,0.4997,1.7875,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.CachedBmp_175();
	this.instance.setTransform(-144.65,-91.65,0.5,0.5);

	this.instance_1 = new lib.dfbzeye();
	this.instance_1.setTransform(-133.05,-85.25);

	this.instance_2 = new lib.CachedBmp_183();
	this.instance_2.setTransform(-171.35,-112.35,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_173();
	this.instance_3.setTransform(-155.75,-74.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_4 = new lib.patch1_2_T1_T3_4();
	this.instance_4.setTransform(-83.95,-47.95,1,1,0,0,0,-352.1,-4);
	this.instance_4.shadow = new cjs.Shadow("rgba(147,92,57,1)",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-203,-145,246,206);


(lib.heading02_2_T1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-80,-45.6,0.4997,1.7875,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap9();
	this.instance.setTransform(-192,-134);

	this.instance_1 = new lib.Bitmap10();
	this.instance_1.setTransform(-192,-134);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-192,-134,224,184);


(lib.heading02 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-80,-45.6,0.4997,1.7875,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap3();
	this.instance.setTransform(-192,-134);

	this.instance_1 = new lib.Bitmap4();
	this.instance_1.setTransform(-192,-134);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-192,-134,224,184);


(lib.heading01_2_T1_T3_4_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(90,-37.6,0.4997,1.7875,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.CachedBmp_172();
	this.instance.setTransform(73.35,-95.4,0.5,0.5);

	this.instance_1 = new lib.eyeboy();
	this.instance_1.setTransform(79.1,-80.5,0.3497,0.3497,0,0,0,1.2,0);

	this.instance_2 = new lib.eyeboy();
	this.instance_2.setTransform(94.1,-80.2,0.3497,0.3497,0,0,0,1.2,0);

	this.instance_3 = new lib.CachedBmp_171();
	this.instance_3.setTransform(78.05,-73.5,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_170();
	this.instance_4.setTransform(54.95,-121.15,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_221();
	this.instance_5.setTransform(43.3,-67.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_6 = new lib.patch1_2_T1_T3_4_5();
	this.instance_6.setTransform(85.05,-43.95,1,1,0,0,0,-352.1,-4);
	this.instance_6.shadow = new cjs.Shadow("rgba(147,92,57,1)",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34,-141,246,206);


(lib.heading01_2_T1_T3_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(88,-41.6,0.4997,1.7875,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.tortoiseanim();
	this.instance.setTransform(86.2,14.55,0.4028,0.4028,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

	// Layer_1
	this.instance_1 = new lib.patch1_2_T1_T3_4();
	this.instance_1.setTransform(85.05,-43.95,1,1,0,0,0,-352.1,-4);
	this.instance_1.shadow = new cjs.Shadow("rgba(147,92,57,1)",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34,-141,246,206);


(lib.heading01_2_T1_T3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(88,-39.6,0.4997,1.7875,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.lionanim();
	this.instance.setTransform(92.25,-44.1,0.398,0.398,0,0,0,0,-199.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.patch1_2_T1_T3();
	this.instance_1.setTransform(85.05,-43.95,1,1,0,0,0,-352.1,-4);
	this.instance_1.shadow = new cjs.Shadow("rgba(147,92,57,1)",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34,-141,246,206);


(lib.heading01_2_T1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(88,-37.6,0.4997,1.7875,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap8();
	this.instance.setTransform(-23,-130);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-24,-130,225,184);


(lib.heading01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(86,-41.6,0.4997,1.7875,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap2();
	this.instance.setTransform(-23,-130);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-130,227,184);


(lib.mcMain5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_116 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 2;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					//this.parent.fLaunchProduct();
					this.play();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				//this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
				this.play();
			}.bind(this), 5000);
		}
		this.init();
	}
	this.frame_117 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_125 = function() {
		/* stop();
		this.blnPlay = false;
		fCalculateScore();
		function fCalculateScore() {
			var nP = Math.floor((__nScore/5)*100);
			trace(__nScore + "---------------------"+5+"---------"+nP);
			if (nP < 70) {
				MovieClip(parent.parent.parent).mcFinal.mcRank.gotoAndPlay("rank2");
			} else {
				MovieClip(parent.parent.parent).mcFinal.mcRank.gotoAndPlay("rank1_1");
			}
		}*/
		
		this.stop();
		//alert("End slide");
		main.showRestartBtn();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(116).call(this.frame_116).wait(1).call(this.frame_117).wait(8).call(this.frame_125).wait(1));

	// _
	this.mcFish = new lib.Symbol2();
	this.mcFish.name = "mcFish";
	this.mcFish.setTransform(-460.5,-189);

	this.timeline.addTween(cjs.Tween.get(this.mcFish).wait(126));

	// Layer_3
	this.mcInterfaceBlinker = new lib.broadCastInterface();
	this.mcInterfaceBlinker.name = "mcInterfaceBlinker";
	this.mcInterfaceBlinker.setTransform(-453,-389,1,1,0,0,0,11.5,8);
	this.mcInterfaceBlinker._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mcInterfaceBlinker).wait(116).to({_off:false},0).to({_off:true},1).wait(9));

	// right_wrong_audio
	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(391.6,160.85,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-45.85,160.85,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2}]},116).wait(10));

	// audio
	this.mc_2 = new lib.heading02_2_T1_T3_4_5();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(299.35,213.9);

	this.mc_1 = new lib.heading01_2_T1_T3_4_5();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-308.9,209.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2}]},116).wait(10));

	// heading02
	this.instance = new lib.heading02_2_T1_T3_4_5("single",0);
	this.instance.setTransform(299.35,413.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(86).to({_off:false},0).to({y:213.9},10,cjs.Ease.get(1)).to({startPosition:0},5).to({_off:true},15).wait(10));

	// heading01
	this.instance_1 = new lib.heading01_2_T1_T3_4_5("synched",0);
	this.instance_1.setTransform(-308.9,413.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(81).to({_off:false},0).to({y:209.9},10,cjs.Ease.get(1)).to({startPosition:0},5).to({_off:true},20).wait(10));

	// house_shadow
	this.instance_2 = new lib.house_shadow_2_T1_T3_4_5("synched",0);
	this.instance_2.setTransform(689,8.5,1,1,0,0,0,-0.2,-0.2);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(64).to({_off:false},0).to({x:9},12,cjs.Ease.get(1)).to({x:19},5,cjs.Ease.get(1)).wait(45));

	// heading02
	this.instance_3 = new lib.heading02_2_T1_T3_4("single",0);
	this.instance_3.setTransform(239.35,209.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(44).to({startPosition:0},0).to({y:199.9},6).to({y:469.9},13,cjs.Ease.get(-1)).to({_off:true},1).wait(62));

	// heading01
	this.instance_4 = new lib.heading01_2_T1_T3_4("single",0);
	this.instance_4.setTransform(-308.9,209.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(41).to({startPosition:0},0).to({startPosition:0},6).to({y:453.9},13,cjs.Ease.get(-1)).to({_off:true},1).wait(65));

	// house_shadow
	this.instance_5 = new lib.house_shadow_2_T1_T3_4("synched",0);
	this.instance_5.setTransform(19,8.5,1,1,0,0,0,-0.2,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(31).to({startPosition:0},0).to({x:29},6,cjs.Ease.get(1)).to({x:-991},13,cjs.Ease.get(1)).to({_off:true},1).wait(75));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1483.5,-150.9,2626,681.8);


(lib.mcMain2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_117 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 2;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(117).call(this.frame_117).wait(1));

	// _
	this.mcFish = new lib.Symbol2();
	this.mcFish.name = "mcFish";
	this.mcFish.setTransform(-460.5,-189);

	this.timeline.addTween(cjs.Tween.get(this.mcFish).wait(118));

	// right_wrong_audio
	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(391.6,160.85,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-45.85,160.85,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2}]},117).wait(1));

	// audio
	this.mc_2 = new lib.heading02_2_T1();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(299.35,213.9);

	this.mc_1 = new lib.heading01_2_T1();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-308.9,209.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2}]},117).wait(1));

	// heading02
	this.instance = new lib.heading02_2_T1("single",0);
	this.instance.setTransform(299.35,413.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(87).to({_off:false},0).to({y:213.9},10,cjs.Ease.get(1)).to({startPosition:0},5).to({_off:true},15).wait(1));

	// heading01
	this.instance_1 = new lib.heading01_2_T1("synched",0);
	this.instance_1.setTransform(-308.9,413.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(82).to({_off:false},0).to({y:209.9},10,cjs.Ease.get(1)).to({startPosition:0},5).to({_off:true},20).wait(1));

	// house_shadow
	this.instance_2 = new lib.house_shadow_2_T1("synched",0);
	this.instance_2.setTransform(689,8.5,1,1,0,0,0,-0.2,-0.2);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(65).to({_off:false},0).to({x:9},12,cjs.Ease.get(1)).to({x:19},5,cjs.Ease.get(1)).wait(36));

	// heading02
	this.instance_3 = new lib.heading02("single",0);
	this.instance_3.setTransform(299.35,213.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(44).to({startPosition:0},0).to({startPosition:0},6).to({y:459.9},13,cjs.Ease.get(-1)).to({_off:true},1).wait(54));

	// heading01
	this.instance_4 = new lib.heading01("synched",0);
	this.instance_4.setTransform(-308.9,209.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(41).to({startPosition:0},0).to({startPosition:0},6).to({y:449.9},13,cjs.Ease.get(-1)).to({_off:true},1).wait(57));

	// house_shadow
	this.instance_5 = new lib.house_shadow("synched",0);
	this.instance_5.setTransform(19,8.5,1,1,0,0,0,-0.2,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(31).to({startPosition:0},0).to({x:29},6,cjs.Ease.get(1)).to({x:-1071},13,cjs.Ease.get(1)).to({_off:true},1).wait(67));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1552.8,-140.3,2683,650.2);


(lib.mcMain1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;
		var objRef = this;
		var __nCorrectAnswer = 0;
		var blnLastQuestion = false;
		var __nScore = 0;
		function init() {
			for (var i:Number = 1; objRef["mc_"+i] != null; i++) {
				objRef["mc_"+i].id = i;
				objRef["mc_" + i].addEventListener(MouseEvent.CLICK, fClickEvent);
				objRef["mc_"+i].buttonMode = true;
			}
		}
		
		function fClickEvent(e) {
			fRemoveListeners();	
			mcFish.gotoAndPlay(2);
			if (e.currentTarget.id == __nCorrectAnswer) {
				e.currentTarget.gotoAndStop(2);
				__nScore++;
				var mcRight = new Right();
				objRef.addChild(mcRight);
				objRef["mcTick_"+e.currentTarget.id].gotoAndStop(3);
				return;
			}
			var mcWrong = new ShowAnswer();
			objRef.addChild(mcWrong);
			objRef["mcTick_"+e.currentTarget.id].gotoAndStop(2);
		}
		function fChangeQuestion() {		
			play();
		}
		function fRemoveListeners() {
			for (var i:Number = 1; objRef["mc_"+i] != null; i++) {
				objRef["mc_" + i].removeEventListener(MouseEvent.CLICK, fClickEvent);
				objRef["mc_"+i].buttonMode = false;
			}
		}
		function fShowCorrectAnswer() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(2);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(3);
		}*/
	}
	this.frame_94 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 2;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(94).call(this.frame_94).wait(1));

	// right_wrong_audio
	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(391.6,160.85,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-45.85,160.85,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2}]},94).wait(1));

	// audio
	this.mc_2 = new lib.heading02();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(299.35,213.9);

	this.mc_1 = new lib.heading01();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-308.9,209.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2}]},94).wait(1));

	// heading02
	this.instance = new lib.heading02("single",0);
	this.instance.setTransform(299.35,399.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(55).to({_off:false},0).to({y:213.9},10,cjs.Ease.get(1)).to({startPosition:0},5).to({_off:true},24).wait(1));

	// heading01
	this.instance_1 = new lib.heading01("synched",0);
	this.instance_1.setTransform(-308.9,399.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(50).to({_off:false},0).to({y:209.9},10,cjs.Ease.get(1)).to({startPosition:0},5).to({_off:true},29).wait(1));

	// house_shadow
	this.instance_2 = new lib.house_shadow("synched",0);
	this.instance_2.setTransform(689,8.5,1,1,0,0,0,-0.2,-0.2);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(33).to({_off:false},0).to({x:9},12,cjs.Ease.get(1)).to({x:19},5,cjs.Ease.get(1)).wait(45));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-472.8,-140.3,1603,594.2);


(lib.Kangaroo_Wrong_B = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// l1
	this.instance = new lib.Hand3("single",0);
	this.instance.setTransform(40.2,22.1,1,1,0,0,0,-2.8,-4.5);

	this.instance_1 = new lib.hand1("single",0);
	this.instance_1.setTransform(19.8,-0.9,1,1,0,0,0,-0.8,-9.2);

	this.instance_2 = new lib.Hand2("single",0);
	this.instance_2.setTransform(22.5,15.45,1,1,0,0,0,-7.5,-3.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// hand_1
	this.instance_3 = new lib.Headv("single",0);
	this.instance_3.setTransform(16,-23.05,1,1,0,0,0,-6,23.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// Head
	this.instance_4 = new lib.Leg1("single",0);
	this.instance_4.setTransform(1,39.75,1,1,0,0,0,-17.6,-14.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// Bdy
	this.instance_5 = new lib.Body("single",0);
	this.instance_5.setTransform(16.25,22.35);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// Tail
	this.instance_6 = new lib.Tail("single",0);
	this.instance_6.setTransform(-1.3,52.65,1,1,0,0,0,32,-8.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1));

	// Hand_2
	this.instance_7 = new lib.Hand3("single",0);
	this.instance_7.setTransform(46.95,17.8,0.8998,0.8998,-4.5532,0,0,-2.8,-4.5);

	this.instance_8 = new lib.hand1("single",0);
	this.instance_8.setTransform(27,-1.35,0.8998,0.8998,-4.5532,0,0,-0.8,-9.2);

	this.instance_9 = new lib.Hand2("single",0);
	this.instance_9.setTransform(30.55,13.1,0.8998,0.8998,-4.5532,0,0,-7.6,-3.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7}]}).wait(1));

	// l2
	this.instance_10 = new lib.Leg2("single",0);
	this.instance_10.setTransform(24.95,37,1,1,0,0,0,-6,-17.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Kangaroo_Wrong_B, new cjs.Rectangle(-70.9,-75.9,126.5,156.10000000000002), null);


(lib.house_shadow_2_T1_T3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.separater("synched",0);
	this.instance.setTransform(-289.45,-59.7);

	this.instance_1 = new lib.separater("synched",0);
	this.instance_1.setTransform(-99.45,-59.7);

	this.instance_2 = new lib.separater("synched",0);
	this.instance_2.setTransform(253.55,-59.7);

	this.instance_3 = new lib.separater("synched",0);
	this.instance_3.setTransform(73.55,-59.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_4 = new lib.lionanim();
	this.instance_4.setTransform(345.85,-58.75,0.398,0.398,0,0,0,0,-199.8);

	this.instance_5 = new lib.lionanim();
	this.instance_5.setTransform(160.1,-58.75,0.398,0.398,0,0,0,0,-199.8);

	this.instance_6 = new lib.lionanim();
	this.instance_6.setTransform(-194.4,-58.75,0.398,0.398,0,0,0,0,-199.8);

	this.instance_7 = new lib.Kangaroo_Wrong_B("single",0);
	this.instance_7.setTransform(-13.05,6.4,0.9732,0.9732,0,0,180,3.4,68.9);

	this.instance_8 = new lib.lionanim();
	this.instance_8.setTransform(-380.15,-58.75,0.398,0.398,0,0,0,0,-199.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4}]}).wait(1));

	// Layer_2
	this.instance_9 = new lib.patch_2_T1_T3();
	this.instance_9.setTransform(-21.55,-58.6);
	this.instance_9.shadow = new cjs.Shadow("rgba(147,92,57,1)",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-492.7,-159.6,945,205);


(lib.heading02_2_T1_T3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-80,-45.6,0.4997,1.7875,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Kangaroo_Wrong_B("single",0);
	this.instance.setTransform(-76.1,21,0.9732,0.9732,0,0,180,3.4,68.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

	// Layer_1
	this.instance_1 = new lib.patch1_2_T1_T3();
	this.instance_1.setTransform(-83.95,-47.95,1,1,0,0,0,-352.1,-4);
	this.instance_1.shadow = new cjs.Shadow("rgba(147,92,57,1)",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-203,-145,246,206);


(lib.mcMain4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_117 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 1;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(117).call(this.frame_117).wait(1));

	// _
	this.mcFish = new lib.Symbol2();
	this.mcFish.name = "mcFish";
	this.mcFish.setTransform(-460.5,-189);

	this.timeline.addTween(cjs.Tween.get(this.mcFish).wait(118));

	// right_wrong_audio
	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(391.6,160.85,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-45.85,160.85,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2}]},117).wait(1));

	// audio
	this.mc_2 = new lib.heading02_2_T1_T3_4();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(239.35,209.9);

	this.mc_1 = new lib.heading01_2_T1_T3_4();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-308.9,209.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2}]},117).wait(1));

	// heading02
	this.instance = new lib.heading02_2_T1_T3_4("single",0);
	this.instance.setTransform(239.35,399.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(87).to({_off:false},0).to({y:199.9},10,cjs.Ease.get(1)).to({y:209.9},5).to({_off:true},15).wait(1));

	// heading01
	this.instance_1 = new lib.heading01_2_T1_T3_4("single",0);
	this.instance_1.setTransform(-308.9,413.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(82).to({_off:false},0).to({y:209.9},10,cjs.Ease.get(1)).to({startPosition:0},5).to({_off:true},20).wait(1));

	// house_shadow
	this.instance_2 = new lib.house_shadow_2_T1_T3_4("synched",0);
	this.instance_2.setTransform(689,8.5,1,1,0,0,0,-0.2,-0.2);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(65).to({_off:false},0).to({x:9},12,cjs.Ease.get(1)).to({x:19},5,cjs.Ease.get(1)).wait(36));

	// heading02
	this.instance_3 = new lib.heading02_2_T1_T3("single",0);
	this.instance_3.setTransform(299.35,213.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(44).to({startPosition:0},0).to({startPosition:0},6).to({y:483.9},13,cjs.Ease.get(-1)).to({_off:true},1).wait(54));

	// heading01
	this.instance_4 = new lib.heading01_2_T1_T3("synched",0);
	this.instance_4.setTransform(-308.9,209.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(41).to({startPosition:0},0).to({startPosition:0},6).to({y:453.9},13,cjs.Ease.get(-1)).to({_off:true},1).wait(57));

	// house_shadow
	this.instance_5 = new lib.house_shadow_2_T1_T3("synched",0);
	this.instance_5.setTransform(19,8.5,1,1,0,0,0,-0.2,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(31).to({startPosition:0},0).to({x:29},6,cjs.Ease.get(1)).to({x:-961},13,cjs.Ease.get(1)).to({_off:true},1).wait(67));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1453.5,-150.9,2596,695.8);


(lib.mcMain3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay =  true;*/
	}
	this.frame_117 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 2;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(117).call(this.frame_117).wait(1));

	// _
	this.mcFish = new lib.Symbol2();
	this.mcFish.name = "mcFish";
	this.mcFish.setTransform(-460.5,-189);

	this.timeline.addTween(cjs.Tween.get(this.mcFish).wait(118));

	// right_wrong_audio
	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(391.6,160.85,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-45.85,160.85,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2}]},117).wait(1));

	// audio
	this.mc_2 = new lib.heading02_2_T1_T3();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(299.35,213.9);

	this.mc_1 = new lib.heading01_2_T1_T3();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-308.9,209.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2}]},117).wait(1));

	// heading02
	this.instance = new lib.heading02_2_T1_T3("single",0);
	this.instance.setTransform(299.35,413.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(87).to({_off:false},0).to({y:213.9},10,cjs.Ease.get(1)).to({startPosition:0},5).to({_off:true},15).wait(1));

	// heading01
	this.instance_1 = new lib.heading01_2_T1_T3("synched",0);
	this.instance_1.setTransform(-308.9,413.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(82).to({_off:false},0).to({y:209.9},10,cjs.Ease.get(1)).to({startPosition:0},5).to({_off:true},20).wait(1));

	// house_shadow
	this.instance_2 = new lib.house_shadow_2_T1_T3("synched",0);
	this.instance_2.setTransform(689,8.5,1,1,0,0,0,-0.2,-0.2);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(65).to({_off:false},0).to({x:9},12,cjs.Ease.get(1)).to({x:19},5,cjs.Ease.get(1)).wait(36));

	// heading02
	this.instance_3 = new lib.heading02_2_T1("single",0);
	this.instance_3.setTransform(299.35,213.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(44).to({startPosition:0},0).to({startPosition:0},6).to({y:463.9},13,cjs.Ease.get(-1)).to({_off:true},1).wait(54));

	// heading01
	this.instance_4 = new lib.heading01_2_T1("synched",0);
	this.instance_4.setTransform(-308.9,209.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(41).to({startPosition:0},0).to({startPosition:0},6).to({y:453.9},13,cjs.Ease.get(-1)).to({_off:true},1).wait(57));

	// house_shadow
	this.instance_5 = new lib.house_shadow_2_T1("synched",0);
	this.instance_5.setTransform(19,8.5,1,1,0,0,0,-0.2,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(31).to({startPosition:0},0).to({x:29},6,cjs.Ease.get(1)).to({x:-951},13,cjs.Ease.get(1)).to({_off:true},1).wait(67));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1432.8,-150.9,2575.3,664.8);


// stage content:
(lib.Interface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,25];
	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		stage.enableMouseOver(10); 
		//this.strFrame = "strFrame1"
		this.nF = 1;
		this.fLaunchProduct = function()
		{
			if(this.mcAttachMovieClip)
			{
				this.removeChild(this.mcAttachMovieClip);
			}
			this.mcAttachMovieClip = new lib["mcMain"+this.nF];
			this.mcAttachMovieClip.x = 488.1;
			this.mcAttachMovieClip.y = 295.05;	
			this.mcAttachMovieClip.gotoAndPlay(this.strFrame);
			this.addChild(this.mcAttachMovieClip);	
			if(this.nF == 1)
			{
				this.play();
				this.fbAudio = main.playAudio('instruction');
			}
			this.nF = this.nF + 1;
		}
		//this.fLaunchProduct();
	}
	this.frame_25 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(25).call(this.frame_25).wait(1));

	// HEADING
	this.instance = new lib.heading_("synched",0);
	this.instance.setTransform(-184.35,21.25);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).to({x:145.65},11,cjs.Ease.get(1)).wait(11));

	// heading_txt
	this.instance_1 = new lib.heading_txt("synched",0);
	this.instance_1.setTransform(1228.5,81.85);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(7).to({_off:false},0).to({x:478.5},12,cjs.Ease.get(1)).to({x:488.5},6,cjs.Ease.get(1)).wait(1));

	// bg
	this.instance_2 = new lib.bg();
	this.instance_2.setTransform(488.5,294);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({alpha:1},11).wait(15));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(157.1,287.3,1404.4,303.7);
// library properties:
lib.properties = {
	id: 'ECDF1A6AC5E395468828BABD79B3D8C3',
	width: 977,
	height: 588,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Interface_atlas_1.png?1638118468375", id:"Interface_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['ECDF1A6AC5E395468828BABD79B3D8C3'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;