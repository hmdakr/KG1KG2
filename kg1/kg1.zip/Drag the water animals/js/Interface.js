(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Interface_atlas_1", frames: [[2008,0,29,38],[2008,80,16,13],[1395,616,70,82],[358,613,132,154],[2008,40,29,38],[0,0,998,611],[579,613,71,177],[1627,0,201,247],[492,613,85,194],[1907,569,108,216],[1768,569,137,176],[1161,462,150,189],[1830,0,176,183],[1736,370,159,186],[1000,462,159,186],[1313,560,453,54],[1897,370,128,197],[1830,185,176,183],[1466,249,268,154],[652,613,81,113],[1736,249,78,118],[1586,405,99,118],[1313,462,270,96],[840,613,78,101],[1577,191,42,46],[920,613,70,88],[1000,407,584,53],[0,613,177,132],[1000,0,242,355],[735,613,103,81],[179,613,177,132],[1244,191,220,214],[1531,191,44,48],[1466,191,63,44],[1467,616,64,88],[1313,616,80,74],[1244,0,381,189]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_244 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_243 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_242 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_241 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_240 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap12 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap13 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap14 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap15 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap16 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap17 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap18 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap19 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap20 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap21 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap22 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap23 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap24 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap25 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap26 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap27 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap28 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap29 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap3 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap30 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap31 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap32 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap33 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap34 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap35 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap36 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap4 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.vcvbcvb = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap13();
	this.instance.setTransform(39,-85);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(39,-85,85,194);


(lib.torleg4c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap27();
	this.instance.setTransform(-39,-100);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-100,78,101);


(lib.torleg3c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap24();
	this.instance.setTransform(-39,-117);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-117,78,118);


(lib.torleg2c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap23();
	this.instance.setTransform(-40,-112);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40,-112,81,113);


(lib.torleg1c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap29();
	this.instance.setTransform(-35,-87);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-35,-87,70,88);


(lib.torgrdc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap22();
	this.instance.setTransform(-134,-153);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-134,-153,268,154);


(lib.torbasec = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap26();
	this.instance.setTransform(-135,-95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-95,270,96);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap3();
	this.instance.setTransform(-286,-25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-286,-25,584,53);


(lib.right_wrong = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// Layer_3
	this.instance = new lib.Bitmap35();
	this.instance.setTransform(-25,-22);

	this.instance_1 = new lib.Bitmap36();
	this.instance_1.setTransform(-31,-26);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).wait(1));

	// Layer_1
	this.instance_2 = new lib.Bitmap28();
	this.instance_2.setTransform(-24,-21);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-26,63,52);


(lib.heading_ = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap2();
	this.instance.setTransform(-147,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-147,-28,453,54);


(lib.fd = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D9205D").ss(0.5,1,1).p("AAAhRQAiAAAXAYQAZAYAAAiQAAAhgZAYQgXAYgiAAQghAAgYgYQgYgYAAghQAAgiAYgYQAYgYAhAAg");
	this.shape.setTransform(-0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(90));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag5A6QgYgYAAghQAAgiAYgYQAYgYAhAAQAiAAAXAYQAZAYAAAiQAAAhgZAYQgXAYgiAAQghAAgYgYg");
	mask.setTransform(-0.025,0);

	// Layer_5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#D9205D").ss(0.5,1,1).p("Ah2A+IAAh7IDtAAIAAB7Qh2jdh3Ddg");
	this.shape_1.setTransform(-0.2483,-4.789,0.9997,0.9997,-5.8349);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF4280").s().p("Ah2A+IAAh7IDtAAIAAB7Qh2jdh3Ddg");
	this.shape_2.setTransform(-0.2483,-4.789,0.9997,0.9997,-5.8349);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#D9205D").ss(0.5,1,1).p("Ah8gxIDsgYIANB7QiEiRhoCpg");
	this.shape_3.setTransform(-0.25,-4.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FF4280").s().p("Ah8gxIDsgYIANB7QiDiRhpCpg");
	this.shape_4.setTransform(-0.25,-4.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#D9205D").ss(0.5,1,1).p("Ah8gxIDsgYIANB7Qh8hRhwBpg");
	this.shape_5.setTransform(-0.25,-4.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF4280").s().p("Ah8gxIDsgYIANB7Qh8hRhwBpg");
	this.shape_6.setTransform(-0.25,-4.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#D9205D").ss(0.5,1,1).p("Ah8gxIDsgYIANB7Qh0gSh4Aqg");
	this.shape_7.setTransform(-0.25,-4.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF4280").s().p("Ah8gxIDsgYIANB7Qh0gSh4Aqg");
	this.shape_8.setTransform(-0.25,-4.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#D9205D").ss(0.5,1,1).p("Ah8g0IDsgYIANB7QhsAtiAgVg");
	this.shape_9.setTransform(-0.25,-4.455);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FF4280").s().p("AhvBHIgNh7IDsgYIANB7QhJAehSAAQgoAAgpgGg");
	this.shape_10.setTransform(-0.25,-4.455);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#D9205D").ss(0.5,1,1).p("Ah8hEIDsgYIANB7QhjBtiJhVg");
	this.shape_11.setTransform(-0.25,-2.9379);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FF4280").s().p("AhvA3IgNh7IDsgYIANB7Qg4A+hEAAQg0AAg8gmg");
	this.shape_12.setTransform(-0.25,-2.9379);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#D9205D").ss(0.5,1,1).p("Ah2AVIAAh7IDtAAIAAB7QhsCkiBikg");
	this.shape_13.setTransform(0.1663,-0.7319,0.9997,0.9997,-5.8349);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FF4280").s().p("Ah2AVIAAh7IDtAAIAAB7Qg2BSg8AAQg6AAhBhSg");
	this.shape_14.setTransform(0.1663,-0.7319,0.9997,0.9997,-5.8349);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},18).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},5).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).wait(55));

	// Layer_2
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#FFFFFF").ss(0.5,1,1).p("AAPAAQAAAGgFAEQgEAFgGAAQgFAAgEgFQgFgEAAgGQAAgFAFgFQAEgEAFAAQAGAAAEAEQAFAFAAAFg");
	this.shape_15.setTransform(0.1803,-0.4353,1.2417,1.2417);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgKALQgEgFAAgGQAAgFAEgFQAFgEAFAAQAGAAAEAEQAFAFAAAFQAAAGgFAFQgEAEgGAAQgFAAgFgEg");
	this.shape_16.setTransform(0.1803,-0.4353,1.2417,1.2417);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(0.5,1,1).p("AAAgjQAPAAALALQAKAKAAAOQAAAPgKALQgLAKgPAAQgOAAgKgKQgLgLAAgPQAAgOALgKQAKgLAOAAg");
	this.shape_17.setTransform(-3.35,2.375);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgYAaQgLgLAAgPQAAgOALgKQAKgLAOAAQAPAAAKALQALAKAAAOQAAAPgLALQgKAKgPAAQgOAAgKgKg");
	this.shape_18.setTransform(-3.35,2.375);

	var maskedShapeInstanceList = [this.shape_15,this.shape_16,this.shape_17,this.shape_18];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15}]}).wait(90));

	// Layer_3
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Ag5A6QgYgYAAghQAAgiAYgYQAYgYAhAAQAiAAAXAYQAZAYAAAiQAAAhgZAYQgXAYgiAAQghAAgYgYg");
	this.shape_19.setTransform(-0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape_19).wait(90));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-9.1,18.4,18.299999999999997);


(lib.eye_fish = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AggAgQgNgNAAgTQAAgSANgOQAOgNASAAQATAAAOANQANAOAAASQAAATgNANQgOAOgTAAQgSAAgOgOg");

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CE940B").ss(0.5,1,1).p("AhLAhIAAhBICXAAIAABBQhPhphIBpg");
	this.shape.setTransform(0.15,-3.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF00").s().p("AhKAgIAAg/ICWAAIAAA/QhPhohHBog");
	this.shape_1.setTransform(0.15,-3.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#CE940B").ss(0.5,1,1).p("AhLggICXAAIAABBQhPhHhIBHg");
	this.shape_2.setTransform(0.15,-3.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFF00").s().p("AhKAgIAAg/ICWAAIAAA/QhPhGhHBGg");
	this.shape_3.setTransform(0.15,-3.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#CE940B").ss(0.5,1,1).p("AhLggICXAAIAABBQhQglhHAlg");
	this.shape_4.setTransform(0.15,-3.15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFF00").s().p("AhKAgIAAg/ICWAAIAAA/QhQglhGAlg");
	this.shape_5.setTransform(0.15,-3.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#CE940B").ss(0.5,1,1).p("AhLggICXAAIAABBQhRgEhGAEg");
	this.shape_6.setTransform(0.15,-3.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFF00").s().p("AhKAgIAAg/ICWAAIAAA/QhRgDhFADg");
	this.shape_7.setTransform(0.15,-3.15);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#CE940B").ss(0.5,1,1).p("AhLgnICXAAIAABAQhSAehFgeg");
	this.shape_8.setTransform(0.15,-2.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFF00").s().p("AhKAZIAAhAICWAAIAABAQgqAPglAAQglAAgigPg");
	this.shape_9.setTransform(0.15,-2.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#CE940B").ss(0.5,1,1).p("AhLgvICXAAIAABAQhSA/hFg/g");
	this.shape_10.setTransform(0.15,-1.5625);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFF00").s().p("AhKARIAAhAICWAAIAABAQgqAfglAAQglAAgigfg");
	this.shape_11.setTransform(0.15,-1.5625);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#CE940B").ss(0.5,1,1).p("AhLAIIAAhAICXAAIAABAQhUBihDhig");
	this.shape_12.setTransform(0.15,-0.7075);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFF00").s().p("AhKAIIAAhAICWAAIAABAQgrAxgkAAQgmAAghgxg");
	this.shape_13.setTransform(0.15,-0.7075);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape}]},15).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).to({state:[{t:this.shape_7},{t:this.shape_6}]},1).to({state:[{t:this.shape_9},{t:this.shape_8}]},1).to({state:[{t:this.shape_11},{t:this.shape_10}]},1).to({state:[{t:this.shape_13},{t:this.shape_12}]},1).to({state:[{t:this.shape_11},{t:this.shape_10}]},1).to({state:[{t:this.shape_9},{t:this.shape_8}]},1).to({state:[{t:this.shape_7},{t:this.shape_6}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_1},{t:this.shape}]},1).wait(9));

	// Layer_2
	this.instance = new lib.CachedBmp_243();
	this.instance.setTransform(-4.25,-2.65,0.4572,0.4572);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(36));

	// Layer_1
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#CE940B").ss(0.5,1,1).p("AAhggQANAOAAASQAAATgNANQgOAOgTAAQgSAAgOgOQgNgNAAgTQAAgSANgOQAOgNASAAQATAAAOANg");

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AggAgQgNgNAAgTQAAgSANgOQAOgNASAAQATAAAOANQANAOAAASQAAATgNANQgOAOgTAAQgSAAgOgOg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14}]}).wait(36));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.6,-5.6,11.2,11.2);


(lib.eye__ = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhfFrIgWgIIAAAAIgPgIIAAAAQg1gcgsgzIAAAAQhfhvAAidIAAAAQAAicBfhvIAAAAQAJgLAKgIIAAAAQAngnAmgUIAAAAQARgJATgHIAAAAQAugRAzAAIAAAAQCHAABeBvIAAAAQBgBvAACcIAAAAQAACdhgBvIAAAAQheBviHAAIAAAAQgyAAgtgQgADtjbQBSBfAACGIAAAAQAAiGhShfIAAAAQhRhfh0AAIAAAAQgrAAgoAOIAAAAQgQAGgPAIIAAAAQggARgiAhIAAAAQgJAIgHAJIAAAAQhRBfAACGIAAAAQAAiGBRhfIAAAAQAHgJAJgIIAAAAQAighAggRIAAAAQAPgIAQgGIAAAAQAogOArAAIAAAAQB0AABRBfg");
	mask.setTransform(0.0247,0.0247);

	// Layer_5
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(0.5,1,1).p("AkPgrQhrCEgzDqIgZovIN0hWIAZIvQhkjUiGhtQiAhoiCAKQiEALhmB8g");
	this.shape.setTransform(0.65,-22.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FE562C").s().p("AnGjsIN0hWIAZIvQhkjUiHhtQh/hoiDAKQiDALhmB8QhsCEgyDqg");
	this.shape_1.setTransform(0.65,-22.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#333333").ss(0.5,1,1).p("AnGjsIN0hWIAZIvQhfidiDhPQh9hLiCALQiDALhpBfQhvBmg4Cyg");
	this.shape_2.setTransform(0.65,-22.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FE562C").s().p("AnGjsIN0hWIAZIvQhfidiEhPQh9hLiBALQiDALhpBfQhuBmg5Cyg");
	this.shape_3.setTransform(0.65,-22.925);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#333333").ss(0.5,1,1).p("AnGjsIN0hWIAZIvQhahmiAgxQh6gviCAMQiDALhsBEQhxBIg+B5g");
	this.shape_4.setTransform(0.65,-22.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FE562C").s().p("AnGjsIN0hWIAZIvQhahmiBgxQh5gviCAMQiDALhsBEQhwBIg/B5g");
	this.shape_5.setTransform(0.65,-22.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#333333").ss(0.5,1,1).p("AnGjsIN0hWIAZIvQhVguh9gTQh3gSiCAMQiDALhtAnQh1AqhEBBg");
	this.shape_6.setTransform(0.65,-22.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FE562C").s().p("AnGjsIN0hWIAZIvQhVguh9gTQh4gSiBAMQiCALhvAnQhzAqhFBBg");
	this.shape_7.setTransform(0.65,-22.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#333333").ss(0.5,1,1).p("AnGjsIN0hWIAZIvQhQAJh6ALQh1ALiBAMQiCAMhxALQh3AMhKAIg");
	this.shape_8.setTransform(0.65,-22.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FE562C").s().p("AnGjsIN0hWIAZIvIjKAUIj3AXIjyAXIjBAUg");
	this.shape_9.setTransform(0.65,-22.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#333333").ss(0.5,1,1).p("AnGkTIN0hWIAZIwQhLBAh3ApQhyAoiBANQiBAMh0gSQh6gShQgwg");
	this.shape_10.setTransform(0.65,-19.085);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FE562C").s().p("AjjFfQh6gShQgwIgZowIN0hWIAZIwQhMBAh2ApQhyAoiBANQg0AFgxAAQhLAAhFgLg");
	this.shape_11.setTransform(0.65,-19.085);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#333333").ss(0.5,1,1).p("AnGlLIN0hWIAZIwQhGB3h0BIQhvBEiBANQiBANh3guQh8gxhWhog");
	this.shape_12.setTransform(0.65,-13.458);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FE562C").s().p("AjbF+Qh8gxhWhoIgZowIN0hWIAZIwQhGB3h0BIQhvBEiBANQgcADgbAAQhkAAhdgkg");
	this.shape_13.setTransform(0.65,-13.458);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#333333").ss(0.5,1,1).p("AmtCsIgZowIN0hWIAZIwQhBCuhxBmQhsBiiBANQiBANh4hLQiAhOhcihg");
	this.shape_14.setTransform(0.65,-7.754);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FE562C").s().p("AjSGbQh/hOhcihIgZowIN0hWIAZIwQhBCuhyBmQhrBiiBANQgTACgTAAQhsAAhohAg");
	this.shape_15.setTransform(0.65,-7.754);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape}]},3).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).to({state:[{t:this.shape_7},{t:this.shape_6}]},1).to({state:[{t:this.shape_9},{t:this.shape_8}]},1).to({state:[{t:this.shape_11},{t:this.shape_10}]},1).to({state:[{t:this.shape_13},{t:this.shape_12}]},1).to({state:[{t:this.shape_15},{t:this.shape_14}]},1).to({state:[{t:this.shape_13},{t:this.shape_12}]},1).to({state:[{t:this.shape_11},{t:this.shape_10}]},1).to({state:[{t:this.shape_9},{t:this.shape_8}]},1).to({state:[{t:this.shape_7},{t:this.shape_6}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_1},{t:this.shape}]},1).wait(24));

	// Layer_4
	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.702)").s().p("AgPA8IgDgBIgDgBQgJgFgIgJQgPgRAAgbQAAgZAPgTIAEgDQAHgGAFgDIAHgDQAIgDAHAAQAXAAAPASQAQATAAAZQAAAbgQARQgPATgXAAQgHAAgIgDg");
	this.shape_16.setTransform(9.85,-5.65,1,1,0,0,180);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#090C17").s().p("AgfB7IgIgDIgFgCQgSgJgPgSQggglAAg2QAAg0AggmIAHgGQANgOANgGIAMgGQAQgFARgBQAtAAAgAmQAgAmAAA0QAAA2ggAlQggAlgtABQgRAAgPgGg");
	this.shape_17.setTransform(18.875,-2.55,1,1,0,0,180);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#1205E9").s().p("AgyDEIgMgFIgIgEQgdgPgYgbQgzg9AAhUQAAhUAzg7IAKgLQAWgVAUgLQAJgEALgEQAZgJAbAAQBIAAAyA8QA0A7AABUQAABUg0A9QgyA7hIAAQgbAAgYgIgAhNh1IgMAFQgNAHgNANIgHAGQghAmAAA0QAAA2AhAlQAPASASAJIAFADIAHADQAPAFATAAQAsAAAggmQAgglAAg2QAAg0gggmQggglgsAAQgTAAgPAGg");
	this.shape_18.setTransform(14.35,-3,1,1,0,0,180);

	var maskedShapeInstanceList = [this.shape_16,this.shape_17,this.shape_18];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16}]}).wait(41));

	// Layer_1
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#A1100B").ss(0.5,1,1).p("ADlkLQBgBvAACcQAACdhgBvQheBviHAAQgyAAgtgQQgLgEgLgEQgHgEgIgEQg1gcgsgzQhfhvAAidQAAicBfhvQAJgLAKgIQAngnAmgUQARgJATgHQAugRAzAAQCHAABeBvg");
	this.shape_19.setTransform(0.025,0.025);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AhSE4IgSgIIgNgGQgugYglgsQhRhfAAiHQAAiFBRhfQAHgKAJgHQAhghAhgRQAPgIAQgGQAogPArAAQB0AABQBgQBSBfAACFQAACHhSBfQhQBfh0AAQgrAAgngNg");
	this.shape_20.setTransform(4.05,0.975);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#D6D6D6").s().p("AhfFrIgWgIIgPgIQg1gcgsgzQhfhvAAidQAAicBfhvQAJgLAKgIQAngnAmgUQARgJATgHQAugRAzAAQCHAABeBvQBgBvAACcQAACdhgBvQheBviHAAQgyAAgtgQgAgrksQgQAGgPAIQggARgiAhQgJAIgHAJQhRBfAACGQAACGBRBfQAmAsAtAYIANAHIATAHQAmANArAAQB0AABRhfQBShfAAiGQAAiGhShfQhRhfh0AAQgrAAgoAOg");
	this.shape_21.setTransform(0.025,0.025);

	this.instance = new lib.CachedBmp_242();
	this.instance.setTransform(-3.15,-23.4,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_241();
	this.instance_1.setTransform(-32.95,-38.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_19}]}).to({state:[{t:this.instance_1},{t:this.instance}]},39).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-33.4,-38.8,66.9,77.69999999999999);


(lib.eye = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#527A25").ss(0.5,1,1).p("ABnhtQApAtAABAQAABBgpApQgpAtg+AAQg7AAgrgtQgpgpAAhBQAAhAApgtQArgpA7AAQA+AAApApg");
	this.shape.setTransform(0,-15.125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(75));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhmBqQgogpAAhBQAAhAAogtQArgpA7AAQA+AAApApQAoAtAABAQAABBgoApQgpAtg+AAQg7AAgrgtg");
	mask.setTransform(0,-15.125);

	// Layer_5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#333333").ss(0.5,1,1).p("AClAvQiliSikCSIAAhdIFJAAg");
	this.shape_1.setTransform(0.175,-29.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#88C641").s().p("AikAvIAAhdIFJAAIAABdQiliSikCSg");
	this.shape_2.setTransform(0.175,-29.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#333333").ss(0.5,1,1).p("Aikg8IFJAAIAAB5QikhTilBTg");
	this.shape_3.setTransform(0.175,-28);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#88C641").s().p("AikA9IAAh5IFJAAIAAB5QikhTilBTg");
	this.shape_4.setTransform(0.175,-28);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#333333").ss(0.5,1,1).p("AikhLIFJAAIAACXQikgVilAVg");
	this.shape_5.setTransform(0.175,-26.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#88C641").s().p("AikBMIAAiXIFJAAIAACXQikgVilAVg");
	this.shape_6.setTransform(0.175,-26.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#333333").ss(0.5,1,1).p("AikhkIFJAAIAAC1QijApimgpg");
	this.shape_7.setTransform(0.175,-23.875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#88C641").s().p("AikBRIAAi1IFJAAIAAC1QhSAUhSAAQhSAAhTgUg");
	this.shape_8.setTransform(0.175,-23.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#333333").ss(0.5,1,1).p("AikiDIFJAAIAADTQijBoimhog");
	this.shape_9.setTransform(0.175,-20.75);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#88C641").s().p("AikBQIAAjTIFJAAIAADTQhSAzhSAAQhSAAhTgzg");
	this.shape_10.setTransform(0.175,-20.75);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#333333").ss(0.5,1,1).p("AikihIFJAAIAADvQijCniming");
	this.shape_11.setTransform(0.175,-17.65);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#88C641").s().p("AikBOIAAjvIFJAAIAADvQhSBUhSAAQhRAAhUhUg");
	this.shape_12.setTransform(0.175,-17.65);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#333333").ss(0.5,1,1).p("AClBOQiiDlinjlIAAkNIFJAAg");
	this.shape_13.setTransform(0.175,-14.5075);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#88C641").s().p("AikBOIAAkNIFJAAIAAENQhRByhTAAQhRAAhUhyg");
	this.shape_14.setTransform(0.175,-14.5075);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},9).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},3).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).wait(51));

	// Layer_1
	this.instance = new lib.CachedBmp_240();
	this.instance.setTransform(-11.35,-22.05,0.5,0.5);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(75));

	// Layer_3
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#527A25").ss(0.5,1,1).p("ABnhtQApAtAABAQAABBgpApQgpAtg+AAQg7AAgrgtQgpgpAAhBQAAhAApgtQArgpA7AAQA+AAApApg");
	this.shape_15.setTransform(0,-15.125);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AhmBqQgogpAAhBQAAhAAogtQArgpA7AAQA+AAApApQAoAtAABAQAABBgoApQgpAtg+AAQg7AAgrgtg");
	this.shape_16.setTransform(0,-15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15}]}).wait(75));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-15.3,-31.2,30.700000000000003,32.2);


(lib.dogtail = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap15();
	this.instance.setTransform(-66,-175);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-66,-175,137,176);


(lib.dogeye = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#925B01").ss(0.5,1,1).p("ACgAAQACBGgtAxQgtAxhCAAQhBAAgxgxQgwgxgDhGQgChFAtgxQAtgxBDAAQBBAAAwAxQAxAxACBFg");
	this.shape.setTransform(0.0273,-16.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(80));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhsB3QgwgygDhFQgChEAtgyQAtgwBDAAQBBAAAwAwQAxAyACBEQACBFgtAyQgtAwhCABQhBgBgxgwg");
	mask.setTransform(0.0273,-16.75);

	// Layer_5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#333333").ss(0.5,1,1).p("AD0BQQjnjzkADzIAAifIHnAAg");
	this.shape_1.setTransform(-0.4,-31);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DE8E03").s().p("AjzBQIAAigIHnAAIAACgQjnjzkADzg");
	this.shape_2.setTransform(-0.4,-31);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#333333").ss(0.5,1,1).p("AjzhZIHnAAIAACzQjlickCCcg");
	this.shape_3.setTransform(-0.4,-29.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#DE8E03").s().p("AjzBaIAAizIHnAAIAACzQjlickCCcg");
	this.shape_4.setTransform(-0.4,-29.975);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#333333").ss(0.5,1,1).p("AjzhjIHnAAIAADHQjjhGkEBGg");
	this.shape_5.setTransform(-0.4,-28.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#DE8E03").s().p("AjzBkIAAjHIHnAAIAADHQjjhGkEBGg");
	this.shape_6.setTransform(-0.4,-28.975);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#333333").ss(0.5,1,1).p("AjzhxIHnAAIAADaQjgASkHgSg");
	this.shape_7.setTransform(-0.4,-27.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#DE8E03").s().p("AjzBpIAAjaIHnAAIAADaQhwAJh6AAQh5AAiEgJg");
	this.shape_8.setTransform(-0.4,-27.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#333333").ss(0.5,1,1).p("AjziRIHnAAIAADuQjeBpkJhpg");
	this.shape_9.setTransform(-0.4,-24.325);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#DE8E03").s().p("AjzBdIAAjuIHnAAIAADuQhvA1h6AAQh5AAiFg1g");
	this.shape_10.setTransform(-0.4,-24.325);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#333333").ss(0.5,1,1).p("AjziwIHnAAIAAEBQjcDAkLjAg");
	this.shape_11.setTransform(-0.4,-21.1375);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#DE8E03").s().p("AjzBRIAAkBIHnAAIAAEBQhuBgh6AAQh5AAiGhgg");
	this.shape_12.setTransform(-0.4,-21.1375);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#333333").ss(0.5,1,1).p("AD0BNQjZE4kOk4IAAk1IHnAAg");
	this.shape_13.setTransform(-0.4,-17.9413,1,0.896);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#DE8E03").s().p("AjzBNIAAk1IHnAAIAAE1QhtCch6AAQh5AAiHicg");
	this.shape_14.setTransform(-0.4,-17.9413,1,0.896);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},9).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},3).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).to({state:[]},1).wait(55));

	// Layer_2
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ah2B3QgxgyABhFQgBhFAxgwQAygyBEAAQBGAAAwAyQAyAwAABFQAABFgyAyQgwAxhGgBQhEABgygxg");
	this.shape_15.setTransform(2.3297,-16.8002,0.2707,0.2838,0,-1.9289,0);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("Ah2B3QgxgyABhFQgBhFAxgwQAygyBEAAQBGAAAwAyQAyAwAABFQAABFgyAyQgwAxhGgBQhEABgygxg");
	this.shape_16.setTransform(-1.2367,-11.0937,0.5957,0.6246,0,-1.9293,0);

	var maskedShapeInstanceList = [this.shape_15,this.shape_16];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15}]}).wait(80));

	// Layer_1
	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AhsB3QgwgygDhFQgChEAtgyQAtgwBDAAQBBAAAwAwQAxAyACBEQACBFgtAyQgtAwhCABQhBgBgxgwg");
	this.shape_17.setTransform(0.0273,-16.75);

	this.timeline.addTween(cjs.Tween.get(this.shape_17).wait(80));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.9,-34.5,33.9,35.5);


(lib.C_eye_ = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D1830E").ss(0.5,1,1).p("AAqgpQASARAAAYQAAAJgDAJQgEANgLALQgSASgYAAQgYAAgSgSQgEgEgDgFQAAgBgBgBQgEgGgCgHQgDgJAAgJQAAgQAJgOQADgGAFgFQAEgEAEgDQAPgLATAAQAYAAASASg");
	this.shape.setTransform(0.825,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(87));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgqAqIgHgJIgBgCQgEgGgCgHQgDgJAAgJQAAgQAJgOQADgGAFgFIAIgHQAPgLATAAQAYAAASASQASARAAAYQAAAJgDAJQgEANgLALQgSASgYAAQgYAAgSgSg");
	mask.setTransform(0.825,-0.025);

	// Layer_5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#D1830E").ss(0.5,1,1).p("AhWApIAAhRICtAAIAABRQhXiRhWCRg");
	this.shape_1.setTransform(0.564,-3.8486,0.9828,0.9996,-6.5483);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F09917").s().p("AhVApIAAhRICrAAIAABRQhWiRhVCRg");
	this.shape_2.setTransform(0.564,-3.8486,0.9828,0.9996,-6.5483);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#D1830E").ss(0.5,1,1).p("AhYgeICogTIAJBQQhdhNhLBgg");
	this.shape_3.setTransform(0.575,-3.85);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F09917").s().p("AhYgeICogTIAJBQQhdhMhLBfg");
	this.shape_4.setTransform(0.575,-3.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#D1830E").ss(0.5,1,1).p("AhYgeICogTIAJBQQhVgVhTAog");
	this.shape_5.setTransform(0.575,-3.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F09917").s().p("AhYgeICogTIAJBQQhVgVhTAog");
	this.shape_6.setTransform(0.575,-3.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#D1830E").ss(0.5,1,1).p("AhYghICogTIAJBQQhNAlhbgSg");
	this.shape_7.setTransform(0.575,-3.5555);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F09917").s().p("AhPAvIgJhQICogTIAJBQQg0AZg5AAQgdAAgegGg");
	this.shape_8.setTransform(0.575,-3.5555);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#D1830E").ss(0.5,1,1).p("AhYgvICogTIAJBQQhFBehjhLg");
	this.shape_9.setTransform(0.575,-2.1858);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F09917").s().p("AhPAhIgJhQICogTIAJBQQgmA1gwAAQglAAgtgig");
	this.shape_10.setTransform(0.575,-2.1858);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#D1830E").ss(0.5,1,1).p("AhWAFIAAhRICtAAIAABRQhPCQheiQg");
	this.shape_11.setTransform(0.9744,-0.2734,0.9828,0.9996,-6.5483);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F09917").s().p("AhVAFIAAhRICrAAIAABRQgnBIgrAAQgqAAgvhIg");
	this.shape_12.setTransform(0.9744,-0.2734,0.9828,0.9996,-6.5483);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},15).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},5).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).wait(57));

	// Layer_2
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgJAJQgDgEAAgFQAAgFADgEQAEgDAFAAQAFAAAEADQAEAEAAAFQAAAFgEAEQgEAEgFAAQgFAAgEgEg");
	this.shape_13.setTransform(-0.025,-2.075);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgcAdQgMgMAAgRQAAgQAMgMQAMgLAQAAQARAAAMALQAMAMAAAQQAAARgMAMQgMAMgRAAQgQAAgMgMg");
	this.shape_14.setTransform(-2.75,-0.65);

	var maskedShapeInstanceList = [this.shape_13,this.shape_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13}]}).wait(87));

	// Layer_3
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgqAqIgHgJIgBgCQgEgGgCgHQgDgJAAgJQAAgQAJgOQADgGAFgFIAIgHQAPgLATAAQAYAAASASQASARAAAYQAAAJgDAJQgEANgLALQgSASgYAAQgYAAgSgSg");
	this.shape_15.setTransform(0.825,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(87));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6.1,-7,13.899999999999999,14);


(lib.btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("EgjAAHeIAAu7MBGBAAAIAAO7g");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-224.1,-47.8,448.2,95.6), null);


(lib.bgg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap1();
	this.instance.setTransform(-499,-304);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bgg, new cjs.Rectangle(-499,-304,998,611), null);


(lib.bccvbcvb = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap11();
	this.instance.setTransform(-124,-38);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-124,-38,71,177);


(lib.tub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-0.65,0.35,0.8499,1.9759,0,0,0,-0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap6();
	this.instance.setTransform(-191,-95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tub, new cjs.Rectangle(-191,-95,381,189), null);


(lib.tortoisehead = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.eye();
	this.instance.setTransform(64.95,-114.95,0.755,0.846,0,10.0916,-169.9077);

	this.instance_1 = new lib.eye();
	this.instance_1.setTransform(1.6,-126.45,0.8389,0.94,0,10.092,-169.9092);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1},{t:this.instance}]},2).to({state:[]},1).wait(2));

	// Layer_1
	this.instance_2 = new lib.Bitmap18();
	this.instance_2.setTransform(-75,-185);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2).to({_off:false},0).to({_off:true},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-75,-185,159,186);


(lib.Symbol3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.fd();
	this.instance.setTransform(40.9,-41.35,0.8725,0.8725);

	this.instance_1 = new lib.fd();
	this.instance_1.setTransform(-5.55,-36.35);

	this.instance_2 = new lib.Bitmap34();
	this.instance_2.setTransform(-110,-107);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(-110,-107,220,214), null);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* stop();
		this.blnPlay = false;*/
	}
	this.frame_1 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_132 = function() {
		/* MovieClip(parent).fChangeQuestion();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(131).call(this.frame_132).wait(1));

	// Layer_1
	this.instance = new lib.Symbol3();
	this.instance.setTransform(999.2,576.1);
	this.instance.alpha = 0.0117;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({_off:true},131).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1109.2,683.1);


(lib.doghead = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.dogeye();
	this.instance.setTransform(63.1,-130.1,0.88,0.88);

	this.instance_1 = new lib.dogeye();
	this.instance_1.setTransform(-3.05,-123.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_2 = new lib.Bitmap12();
	this.instance_2.setTransform(-106,-277);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-106,-277,201,247);


(lib.dog = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.bccvbcvb("synched",0);
	this.instance.setTransform(-3.95,-386.3,1,1,0,0,0,-84,-38.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({startPosition:0},0).to({scaleX:0.9995,scaleY:0.9995,rotation:1.0016,x:10.35,y:-394.85},14).to({scaleX:1,scaleY:1,rotation:0,x:-3.95,y:-386.3},15).wait(16));

	// Layer_2
	this.instance_1 = new lib.doghead("single",0);
	this.instance_1.setTransform(53.95,-259.75,1,1,0,0,0,-26.1,-49.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({startPosition:0},0).to({regY:-49.9,scaleX:0.9996,scaleY:0.9996,rotation:7.805,x:53.9,y:-259.8},14).to({regY:-49.8,scaleX:1,scaleY:1,rotation:0,x:53.95,y:-259.75},15).wait(16));

	// Layer_5
	this.instance_2 = new lib.vcvbcvb("synched",0);
	this.instance_2.setTransform(145.65,-426.1,1,1,0,0,0,65.6,-78.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(5).to({startPosition:0},0).to({x:160.95,y:-414.9},14).to({x:145.65,y:-426.1},15).wait(16));

	// Layer_1
	this.instance_3 = new lib.Bitmap14();
	this.instance_3.setTransform(47,-215);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(0.5,1,1).p("AgQADQAQgCARgD");
	this.shape.setTransform(21.075,-34.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#E1B448").ss(0.5,1,1).p("AEHvMQAOgoAXgiQAXgjAggeQACgCABgBQAUgSAWgNQAKAFAKAFQAXANAXAPQAVANAVAPIAAAAQAYAzATA0QBoEWgkEfQgrFVigDTQgYAfgXAgQgTAagTAaIAAAAQhYB6hRB7QgYAkgWAjQhIBxhlBuQg2A7g+A5QgvAsg0AsQgTAPgTAPQgfAWgfAUQhAAohEAdQgIADgHADQgoACgogPQgOgGgOgHAEFvIQgWA9AABJQgCCpgQDqQgQDiiJC0QgZAhgcAfQh2CFihBTQhkA0hRBIQgEADgDADQgPANgOAN");
	this.shape_1.setTransform(71.3879,-149.1382);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#925B01").ss(0.5,1,1).p("AOvzlQgEgCgEgCQgWgLgVgJQgrgTgsgNQiIgqiOAOQghADggAGQgsAIgsAiQgMAJgLALQgGAFgGAGQg1A2g0BdQhwDGiOEBQhEB5hQBZQhdBohtA6QjJBqiLB7QgGAFgFAFQiDB6g7EEQgLAugHAuQgBAGgBAGQgEAZgCAZQgEAlgBAkQAAABAAABQgECOAkCDQAAACABACQADANAFANQADAGACAHQAAAAABABQAnBbBgA0QBUAuC7APAjwAdQCnBvBfByQAWAZARAZQA+BYATBXQAwDlkAEdQgJAJgJAKQgIAIgKAKAA5QJQABAAABAAQALgDAMgFQAQgGARgJQAagOAXgJQAkgNAdABQAYABAUALQA6AgAnA0QAFAHAFAGQAcAnAXAmQADAFADAGQAAABgBACQgEAIgLAGIAAAAQgCABgDABQgQAHgVgBQAEALAEAMQAAADABAEQAAABABABQgJATgbAIQgNAEgSABQgFAAgEAAQgQABgUgCQgPhbhhg8QgOgIgQgIQgIgEgHgDAEVTsQACALABALQAAAGAAAHQgMAVg7AKQgJACgJABQgMACgOABQhHAEh5gPQhrgNhjAJQgiADggAGQgWAEgTADQhhAOgygJQg7gMgQgVQgRgVAFghQAEghAggfQAWgWAbhLADLQTQAvASAjAXQBEAtAaBEAnAREIgpgC");
	this.shape_2.setTransform(17.0547,-138.3636);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F7E5A5").s().p("AoWP5QgIgDAAgTQAAgCA5iBQA5iCAAhGQAAg7gMg2QgNg2AAgiQAAhEA/g1ICIhZIH0gmQhYB6hRB7IguBHQhHBxhmBuQg2A6g+A6QgvAsg0AsIgmAdQhLAegrAAIgNABIgIgBgAE7gOQAAhWgGg7QgFg7gXhIQgXhIgfiXQgYh1AAhkIgChLQgBgrAFgYQAOhBBOgFQAqgDARgDQAmgJANgTQAJgNAkgUIAOgIQBoEVgkEgQgrFUigDUIgvA/IgmAzQBFiPAAhVg");
	this.shape_3.setTransform(79.8879,-145);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#ECCE8A").s().p("AoxRtQgOgGgOgHIATgUQEAkcgwjmQgShXg+hYIAcgaIAHgGQBShIBjg0QChhTB3iFQAbgfAaghQCIi0AQjiQARjqABipQABhJAWg9IABgEQAPgoAXgiQAXgjAggeIADgDQATgSAWgNIAUAKIAvAcIApAcIAAAAQAYAzAUA0IgPAJQgkATgJANQgNAUgmAIQgRADgqADQhNAFgOBCQgGAXABArIADBLQAABlAYB0QAfCXAXBJQAXBIAFA6QAFA7ABBVQAABWhGCQIAAAAInzAmIiJBaQg/A0AABEQAAAiANA2QANA2AAA8QAABGg5CBQg6CBAAADQAAATAJACQAFACAQgCQAqAABLgdQgeAWgfAUQhAAohFAdIgOAGIgKAAQgjAAgkgNg");
	this.shape_4.setTransform(67.525,-149.1382);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#DE8E03").s().p("AmfS3Qg8gMgQgVIgCgDQgBgKABgLQAEghAggfQARgQATgtIALgdIgpgCIAAgCQgxgGgqgOQg+gVgxgkQhAgwgrhKQhvi6AojeQAojeBFiOQBEiNC7hjQC7hjCuipQCsipBWjAQBWjAAvhQQAvhQAugIQAugIB3AeQB4AeBYgFQBKgDARgHQgWA9AABJQgCCpgQDqQgQDiiJC0QgZAigcAfQh3CFihBSQhkA0hRBIIgHAGIgdAaQgRgZgWgZQhfhxinhuQCnBuBfBxQAWAZARAZQA+BYATBXQAwDmkAEcIgSAUIgSARQgEADgKALIgOAOIAAABIAggOQATgGAQAAQAJAAAdAFQAeAEAKAAQALAAAXgLIAIgDIAAAAIACgBIAXgHQAQgGARgJQAagPAXgIQAkgNAdABQAYABAUALQA6AgAnA0IAKANQAcAnAXAlIAGALIgBAEQgJAEgJAAQgYAAgagkIgjgxIgMgKQg4grg0AAQgEAAgGACQAvARAjAYQBEAtAaBDIAIAYIABAGIgZAHQgcAIgJAAQgiAAgLgbQgSgtgPgQQgcgcgRgNQgUgOgSgEQgJgDgJAAIgMABIgPgHIAPAHIAeARQBhA7APBcQACAKABALQgWAIghAEQgaAEgiAAQhAAAhfgMQiQgSiAAXQhWAPg3AAQgbAAgTgDg");
	this.shape_5.setTransform(13.2684,-128.8382);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#B07002").s().p("AnnU6Qg7gMgQgVQgRgVAFghQAEghAggfQAWgWAbhLIApACIgLAdQgTAsgRAQQggAfgEAiQgBALABAJIACAEQAQAVA8ALQA7ALCAgWQCAgYCQATQBfALBAAAQAiAAAagDQAhgFAWgHIAAANQgMAVg7AKIgSADIgaADQhHAEh5gPQhrgNhjAJQgiADggAGIgpAHQg7AIgpAAQgbAAgUgDgAEVTsQgPhbhhg8IgegQIAMgBQAJAAAJACQASAFAUAOQARAMAcAdQAPAQASAtQALAaAiAAQAJAAAcgHIAZgHIABACQgJATgbAIQgNAEgSABIgJAAIgIAAIgcgBgAF7StQgahEhEgtQgjgXgvgSQAGgCAEAAQA0AAA4ArIAMAKIAjAxQAaAkAYAAQAJAAAJgEQgEAIgLAGIAAAAIgFACQgOAGgSAAIgFAAgAr4QFQhgg0gnhbIgBgBIgFgNQgFgNgDgNIgBgEQgkiDAEiOIAAgCQABgkAEglQACgZAEgZIACgMQAHguALguQA7kECDh6IALgKQCLh7DJhqQBtg6BdhoQBQhZBEh5QCOkBBwjGQA0hdA1g2IAMgLQALgLAMgJQAsgiAsgIQAggGAhgDQCOgOCIAqQAsANArATQAVAJAWALIAIAEQgWANgUASIgDADQggAegXAjQgXAjgOAnIgCAEQgRAHhKAEQhYAEh4geQh3geguAJQguAHgvBQQgvBQhWDAQhWDBisCpQiuCoi7BkQi7BihECNQhFCOgoDeQgoDeBvC6QArBLBAAvQAxAlA+AUQAqAOAxAHIAAACQi7gPhUgugAiCQhIAOgOQAKgLAEgCIASgSQAOAIAOAFQAoAPAngCQARgBARgEIAAABIgIADQgXALgLAAQgKAAgdgFQgegEgJAAQgQAAgTAGIggANg");
	this.shape_6.setTransform(17.0547,-138.3636);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#925B01").ss(0.5,1,1).p("AHPPCQAzgGAMgWQAAgBAAgBQABgCABgDQg7jAh0AOQhzAOhHgpQgJgRgIgRQhKiZghi2QgjjJAUlNQAFg9AFhBQAlmni9lSAiTN6Qg7hDgphVQgkhHghhIQhSi4g2jFIgPA9QgCgMgCgLQgBgLAAgLQgCgPAAgOQAAgcADgcQABgOACgOQgkAXgTA2QAIhbAVhLQAJggAMgeIg2AgQAYgpATgqQAMgbAQguQARgvgDhKQgEhLgcg6AiEOLQgHgIgIgJQAIB/BRgHQAgAAAmAJQAmAIAsAQQBIAaBWAAQATAAASgBQAjgDAhgUQAOgIgBgLQgBgDgBgEQALAAAKgBQAmgFAagSQAKgHABgLQACgHgDgIQgXhwhtgYAFwP7Qgyh0h6gP");
	this.shape_7.setTransform(121,-125.65);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#B07002").s().p("ABfQTQgsgQgngIQglgJggAAQhRAHgIh/IAPAQIgPgQQg6hEgrhUQgjhHgghJQhTi3g2jGIgPA+IgDgXIgDgWQgBgPAAgOQABgcACgcIADgcQgjAXgTA2QAHhbAVhLQAJggAMgeIg2AfQAYgoATgqQALgbARguQARgvgDhLQgDhKgdg5IFnqRQC+FSglGnIgKB+QgcBAghA0QgYAmgnA1QgeAugNArQgPA3AABXQAABbAtDAQAeCDAiBvQAZBQAuAdQAvAcA4gEQA5gEAZAMQAaAMAQAMQARALAbAoQAZAoAagGQAKgCAMgEQABALgOAIQggAUgkADIglABQhWAAhIgagADFN3IACAAIATgBQAOAAAvAMQANADAOALIAVAUIAhAnQARAYAPAAQAMAAAJgDIAWgIIAYgGIAHgBQgCALgKAHQgaARgmAFIgVACQgxh0h7gQgAFMM5IAPgCQAbAAAXAOQATAMAWAXQARATATAjQAIAPAYAAQAJAAAKgIIABAAQgLAXgzAFQgXhvhtgZgAiSN6IAAAAg");
	this.shape_8.setTransform(120.9,-125.65);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#DE8E03").s().p("ABuI9QgagogRgMQgQgMgagMQgZgMg4AFQg4AEgvgdQgwgdgYhQQgihvgeiCQgtjAAAhbQAAhXAPg3QANgrAegtQAng3AYglQAig1Acg/QgVFNAkDJQAhC1BKCZIARAiQBGApBzgOQB0gOA6DAIgBAFIgBACIgBgBQgKAJgJAAQgYAAgIgPQgUgkgQgTQgWgXgTgMQgXgOgbAAIgQADQBuAYAXBwQACAIgBAHIgHACIgXAFIgXAIQgIADgMAAQgPAAgSgXIgggoIgVgUQgOgKgNgEQgvgMgOAAIgUABIgCABQB7APAyB0IACAHQgMAFgKACIgGAAQgXAAgXgig");
	this.shape_9.setTransform(139.625,-83.0664);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_3}]}).wait(50));

	// Layer_3
	this.instance_4 = new lib.dogtail("single",0);
	this.instance_4.setTransform(-72.6,-49.9,1,1,0,0,0,65.2,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(5).to({startPosition:0},0).to({regY:0.1,scaleX:0.9989,scaleY:0.9989,rotation:-20.5726,x:-69.25,y:-49.85},14).to({regY:0,scaleX:1,scaleY:1,rotation:0,x:-72.6,y:-49.9},15).wait(16));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-253.4,-495.5,472.8,496.5);


(lib.crabbcopy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ArrHwQgHhdgxiQQg3ihhJiAQgmhBADhbIAGhXQACgmgBgiIALgLQAogqAOgHQBlgzAQgFQAEgBBRAAIAJgCQBEgKBMAbQA6AVBVA0QBxBFAXALQBJAmA3AAQAGAABogRQBogQA5AAQAVAAAyAIIAyAIQBFAAAlgnQANgOAphIQAhg8AsgbQA9gmBsgBIAGAAQC8AaA9BEQAuA0AACCQAACJgqBVQgiBEhxB5QhhBng9AdQhFAfh5ggQgIARiLCEQhWBSl7AAQjlAAlQgdg");
	mask.setTransform(6.7389,-15.0017);

	// Layer_1
	this.instance = new lib.eye__();
	this.instance.setTransform(-32.8,0.85,0.3779,0.3779);

	this.instance_1 = new lib.eye__();
	this.instance_1.setTransform(15,-1.15,0.3779,0.3779);

	this.instance_2 = new lib.Bitmap33();
	this.instance_2.setTransform(-89,-66);

	var maskedShapeInstanceList = [this.instance,this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-89,-66,177,103.6);


(lib.crabb = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-3.55,0.55,0.408,1.3788,0,0,0,-0.4,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.eye__();
	this.instance.setTransform(-32.8,0.85,0.3779,0.3779);

	this.instance_1 = new lib.eye__();
	this.instance_1.setTransform(15,-1.15,0.3779,0.3779);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_2 = new lib.Bitmap30();
	this.instance_2.setTransform(-89,-66);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-94.8,-66,182.8,132);


(lib.C_body = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap31();
	this.instance.setTransform(-147,-164);

	this.instance_1 = new lib.C_eye_();
	this.instance_1.setTransform(89.4,-163.2,1,1,0,0,0,0.1,-0.1);

	this.instance_2 = new lib.Bitmap32();
	this.instance_2.setTransform(44,-190);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-147,-190,294,381);


(lib.c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// C_body
	this.instance = new lib.C_body("single",1);
	this.instance.setTransform(67.6,-123.5,1,1,0,0,0,67.6,-123.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:0.9997,scaleY:0.9997,rotation:-5.5348},9,cjs.Ease.get(0.66)).wait(6).to({startPosition:1},0).to({scaleX:1,scaleY:1,rotation:0},9,cjs.Ease.get(0.78)).wait(20));

	// C_body
	this.instance_1 = new lib.C_body("single",0);
	this.instance_1.setTransform(-51.6,174.2,1,1,0,0,0,-51.6,174.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleY:1.0001,skewX:-0.4564},9,cjs.Ease.get(0.66)).wait(6).to({startPosition:0},0).to({scaleY:1,skewX:0},9,cjs.Ease.get(0.78)).wait(20));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-149.7,-197.3,297.79999999999995,388.4);


(lib.body_fish = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.eye_fish();
	this.instance.setTransform(2.35,13.65,0.9982,0.9982,110.793);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.Bitmap4();
	this.instance_1.setTransform(-32,-44);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32,-44,64,88);


(lib.bananacopy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.Symbol3();
	this.instance.setTransform(-48.65,-1.35);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleY:1.0001,skewX:0.9328,x:-46.9,y:-5.25},14).to({scaleY:1,skewX:0,x:-48.65,y:-1.35},15).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-158.6,-112.2,223.5,217.9);


(lib.tortoiseheadjumpc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.tortoisehead("single",2);
	this.instance.setTransform(-0.1,-93.55,1,1,0,0,0,0,-93.7);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-75.1,-184.8,159,186);


(lib.rhwr_girlcautfish = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// body_fish
	this.instance = new lib.body_fish("synched",0);
	this.instance.setTransform(-3.85,-21.2,1,1,0,0,0,-1.1,-36.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// f3_fish
	this.instance_1 = new lib.Bitmap5();
	this.instance_1.setTransform(-40,-59);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40,-59,80,118.4);


(lib.pumpkin = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-0.05,1.5,0.4725,2.4382,0,0,0,-0.1,0.7);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.dog();
	this.instance.setTransform(-0.05,92.9,0.3824,0.3824);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-105.9,-116.8,211.8,233.2);


(lib.potatorcopy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AoVIHQjAiSAAlaQAAibBqhrQAhgjBKg5QBThBAlgjQBghZCDgkQBwgeCrgBQBvABASADQA4AMBTA8QAFAEAPAkQAQAnAiAtIAOAUIACACIgOgXQACADBUBWQBVBWA3B4QA4B3gSCAQgRCBgIBaQgIBZgUAcQgoA4gTAiQo5gPo+gygAHKmAIAAAAIAAAAg");
	mask.setTransform(148.4463,-36.4);

	// Layer_1
	this.instance = new lib.bananacopy();
	this.instance.setTransform(196.3,19.2,0.9922,0.9922);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(75.8,-88.3,145.3,110.3);


(lib.potator = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,1.25,0.487,2.2963,0,0,0,0.1,0.5);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.bananacopy();
	this.instance.setTransform(48.3,1.35,0.9922,0.9922);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.1,-109.8,218.3,219.7);


(lib.grapes = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-0.1,1.1,0.415,2.5021,0,0,0,-0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.c();
	this.instance.setTransform(0,-0.3,0.6075,0.6075);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-93,-119.6,186,239.3);


(lib.tortoisedrinkjumpc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// tortoise_head
	this.instance = new lib.tortoiseheadjumpc("single",1);
	this.instance.setTransform(890.4,745.95,0.9969,0.9969,2.4714,0,0,-70.5,-12);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:-11.9,scaleX:0.9961,scaleY:0.9961,rotation:8.0594,x:888.65,y:751.75},13,cjs.Ease.get(0.8)).wait(20).to({startPosition:1},0).to({regY:-12,scaleX:0.9969,scaleY:0.9969,rotation:2.4714,x:890.4,y:745.95},11,cjs.Ease.get(0.8)).wait(43).to({startPosition:1},0).to({regY:-11.9,scaleX:0.9961,scaleY:0.9961,rotation:8.0594,x:888.65,y:751.75},13,cjs.Ease.get(0.8)).wait(20).to({startPosition:1},0).to({regY:-12,scaleX:0.9969,scaleY:0.9969,rotation:2.4714,x:890.4,y:745.95},11,cjs.Ease.get(0.8)).wait(58));

	// Layer_3
	this.instance_1 = new lib.torgrdc("single",0);
	this.instance_1.setTransform(808.85,671.5,0.9996,0.9996,3.5025,0,0,0,-75.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regY:-75.9,scaleX:0.9992,scaleY:0.9992,rotation:4.5624,x:810.4,y:677.1},13,cjs.Ease.get(0.8)).wait(20).to({startPosition:0},0).to({regY:-75.8,scaleX:0.9996,scaleY:0.9996,rotation:3.5025,x:808.85,y:671.5},11,cjs.Ease.get(0.8)).wait(43).to({startPosition:0},0).to({regY:-75.9,scaleX:0.9992,scaleY:0.9992,rotation:4.5624,x:810.4,y:677.1},13,cjs.Ease.get(0.8)).wait(20).to({startPosition:0},0).to({regY:-75.8,scaleX:0.9996,scaleY:0.9996,rotation:3.5025,x:808.85,y:671.5},11,cjs.Ease.get(0.8)).wait(58));

	// Layer_5
	this.instance_2 = new lib.torleg2c("single",0);
	this.instance_2.setTransform(811.2,856.3,0.999,1.0021,0,0.0009,-4.257,-7.2,-1.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regX:-7.1,regY:-1.5,scaleX:0.9988,scaleY:0.9549,skewX:0,skewY:-4.2528,x:811.25,y:856.35},13,cjs.Ease.get(0.8)).wait(20).to({startPosition:0},0).to({regX:-7.2,regY:-1.6,scaleX:0.999,scaleY:1.0021,skewX:0.0009,skewY:-4.257,x:811.2,y:856.3},11,cjs.Ease.get(0.8)).wait(43).to({startPosition:0},0).to({regX:-7.1,regY:-1.5,scaleX:0.9988,scaleY:0.9549,skewX:0,skewY:-4.2528,x:811.25,y:856.35},13,cjs.Ease.get(0.8)).wait(20).to({startPosition:0},0).to({regX:-7.2,regY:-1.6,scaleX:0.999,scaleY:1.0021,skewX:0.0009,skewY:-4.257,x:811.2,y:856.3},11,cjs.Ease.get(0.8)).wait(58));

	// Layer_4
	this.instance_3 = new lib.torleg3c("single",0);
	this.instance_3.setTransform(691.05,842.25,0.9987,1.0018,0,6.5422,2.0016,-9.1,-2.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regX:-9,regY:-2.6,scaleX:0.9986,scaleY:0.9662,skewX:6.514,skewY:2.0018,x:691.1,y:842.35},13,cjs.Ease.get(0.8)).wait(20).to({startPosition:0},0).to({regX:-9.1,regY:-2.7,scaleX:0.9987,scaleY:1.0018,skewX:6.5422,skewY:2.0016,x:691.05,y:842.25},11,cjs.Ease.get(0.8)).wait(43).to({startPosition:0},0).to({regX:-9,regY:-2.6,scaleX:0.9986,scaleY:0.9662,skewX:6.514,skewY:2.0018,x:691.1,y:842.35},13,cjs.Ease.get(0.8)).wait(20).to({startPosition:0},0).to({regX:-9.1,regY:-2.7,scaleX:0.9987,scaleY:1.0018,skewX:6.5422,skewY:2.0016,x:691.05,y:842.25},11,cjs.Ease.get(0.8)).wait(58));

	// Layer_6
	this.instance_4 = new lib.torbasec("single",0);
	this.instance_4.setTransform(788.35,753.65,0.9996,0.9996,3.5025,0,0,-0.1,-46.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({regY:-46.8,scaleX:0.9992,scaleY:0.9992,rotation:4.5624,x:788,y:759},13,cjs.Ease.get(0.8)).wait(20).to({startPosition:0},0).to({regY:-46.9,scaleX:0.9996,scaleY:0.9996,rotation:3.5025,x:788.35,y:753.65},11,cjs.Ease.get(0.8)).wait(43).to({startPosition:0},0).to({regY:-46.8,scaleX:0.9992,scaleY:0.9992,rotation:4.5624,x:788,y:759},13,cjs.Ease.get(0.8)).wait(20).to({startPosition:0},0).to({regY:-46.9,scaleX:0.9996,scaleY:0.9996,rotation:3.5025,x:788.35,y:753.65},11,cjs.Ease.get(0.8)).wait(58));

	// Layer_7
	this.instance_5 = new lib.torleg4c("single",0);
	this.instance_5.setTransform(754.75,834.65,0.9977,0.9991,0,8.5571,5.5161);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({scaleX:0.9974,scaleY:0.95,skewX:8.5197,skewY:5.5063,y:834.6},13,cjs.Ease.get(0.8)).wait(20).to({startPosition:0},0).to({scaleX:0.9977,scaleY:0.9991,skewX:8.5571,skewY:5.5161,y:834.65},11,cjs.Ease.get(0.8)).wait(43).to({startPosition:0},0).to({scaleX:0.9974,scaleY:0.95,skewX:8.5197,skewY:5.5063,y:834.6},13,cjs.Ease.get(0.8)).wait(20).to({startPosition:0},0).to({scaleX:0.9977,scaleY:0.9991,skewX:8.5571,skewY:5.5161,y:834.65},11,cjs.Ease.get(0.8)).wait(58));

	// Layer_8
	this.instance_6 = new lib.torleg1c("single",0);
	this.instance_6.setTransform(872.4,840.85,0.9989,1.0059,0,-1.023,3.7655);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({scaleX:0.9987,scaleY:0.9594,skewX:-1.007,skewY:3.7549},13,cjs.Ease.get(0.8)).wait(20).to({startPosition:0},0).to({scaleX:0.9989,scaleY:1.0059,skewX:-1.023,skewY:3.7655},11,cjs.Ease.get(0.8)).wait(43).to({startPosition:0},0).to({scaleX:0.9987,scaleY:0.9594,skewX:-1.007,skewY:3.7549},13,cjs.Ease.get(0.8)).wait(20).to({startPosition:0},0).to({scaleX:0.9989,scaleY:1.0059,skewX:-1.023,skewY:3.7655},11,cjs.Ease.get(0.8)).wait(58));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(649.8,573.6,415.29999999999995,287.69999999999993);


(lib.strawberrycopy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ap1FBQAIjuCTi6QCsjZFbAAQA8gBAZABQApABAiALQA0ARAuAdQAtAcAIATQALAZAEApQADAuADAUQAJBKA7AMQgEAEgFAAIAJAAQAZgBAQgGQATgJAWAAQBEAAAWAcQANAQAAAnQAAA4giAhQgeAdgwAAQgDAAgLgDQgMgEgIgFQmMCOqAAAIhNgBg");
	mask.setTransform(-32.2625,-24.2751);

	// Layer_1
	this.instance = new lib.rhwr_girlcautfish("single",0);
	this.instance.setTransform(-10,-1.95,0.9958,0.9958,0,88.0734,-91.9266,-4.8,-22.3);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-92.4,-47.8,120.10000000000001,55.699999999999996);


(lib.strawberry = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.5,0.2849,0.9759,0,0,0,0,0.5);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.rhwr_girlcautfish("single",0);
	this.instance.setTransform(22.55,4.05,0.9958,0.9958,0,88.0734,-91.9266,-4.8,-22.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63.8,-46.7,127.69999999999999,93.4);


(lib.brinjalcopy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnYFTQsDiDDWkbQDWkbEQgeQERgfFeBTQFfBSEBCbQEACahIAdQhJAeDTARQDUASnOCgQj/BYlcAAQkbAAlag6g");
	mask.setTransform(353.5695,-242.7712);

	// Layer_1
	this.instance = new lib.tortoisedrinkjumpc();
	this.instance.setTransform(739,-488.85,0.4265,0.4265,0,3.2715,-176.7285);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(276,-267.2,166.60000000000002,64.19999999999999);


(lib.brinjal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.6,0.3803,1.4302,0,0,0,0,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.tortoisedrinkjumpc();
	this.instance.setTransform(379.9,-284.8,0.4265,0.4265,0,3.2715,-176.7285);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-85.2,-68.4,170.5,136.8);


(lib.mcMain1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_125 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var num = 1;
		var currentClip;
		var __nCurrentIndex = 0;
		var __nDrops = 0;
		var __nHit = 0;
		var startX;
		var startY;
		//var arrAnswerArray = new Array(2,4,5);
		var __nScore = 0;
		var __nWrong = 0;
		var __nButtonPush = 0;
		var __nCurrentNIndex = 0;
		this.init = function() {
			for (var i = 1; objRef["mcDrag_" + i] != undefined; i++) {
				this["mcDrag_"+i].btn.addEventListener("mousedown", this["mcDrag_" + i].listener = this.item_onMouseDown.bind(this));
				this["mcDrag_"+i].btn.cursor = "pointer";
				//this["mcDrag_"+i].buttonMode = true;
				//this["mcDrag_" + i].addEventListener(MouseEvent.MOUSE_DOWN, item_onMouseDown);
				this["mcDrag_" + i].id = i;
				this["mcDrag_" + i].n = i;
				this["mcDrag_" + i].xx = this["mcDrag_" + i].x;
				this["mcDrag_" + i].yy = this["mcDrag_" + i].y;
			}
			this["mcDrag_" + 1].id = 1;
			this["mcDrag_" + 3].id = 1;
			this["mcDrag_" + 4].id = 1;
			this["mcDrag_" + 6].id = 1;	
			
			this["mcD_" + 1].visible = false;
			this["mcD_" + 3].visible = false;
			this["mcD_" + 4].visible = false;
			this["mcD_" + 6].visible = false;	
		}
		this.item_onMouseDown = function(event) {
			__nCurrentIndex = event.currentTarget.parent.id;
			__nCurrentNIndex = event.currentTarget.parent.n;
			currentClip = event.currentTarget.parent;
			startX = currentClip.x;
			startY = currentClip.y;
			objRef.addChild(currentClip);
			//currentClip.startDrag(false);
			//stage.addEventListener(MouseEvent.MOUSE_UP, stage_onMouseUp);
			stage.addEventListener("stagemousemove", this.stageMouseMove = this.fMouseMoveFunction.bind(this));
			stage.addEventListener("stagemouseup", this.stageMouseUp = this.stage_onMouseUp.bind(this));	
		}
		this.fMouseMoveFunction = function(e)
		{
			this.pt = this.globalToLocal(stage.mouseX, stage.mouseY);
		    currentClip.x = this.pt.x;
		    currentClip.y = this.pt.y;
			this.addChild(currentClip);
			stage.update();
		}
		this.stage_onMouseUp = function(event) {
			//stage.removeEventListener(MouseEvent.MOUSE_UP, stage_onMouseUp);
			//currentClip.stopDrag();
			this.myDisplayObject = objRef["mcDrop"].btn;
			this.pt = this.myDisplayObject.globalToLocal(stage.mouseX, stage.mouseY);	
			if (currentClip.btn.hitTest(this.pt.x, this.pt.y)){
			//if (currentClip.hitTestObject(objRef["mcDrop"])) {
				__nButtonPush++;
				this.fSetInteraction(false);
				if (__nCurrentIndex == 1) {
					this["mcD_" + __nCurrentNIndex].visible = true;
					currentClip.visible = false;
					//var mcRight = new Right();
					//objRef.addChild(mcRight);
					this.nRandom = Math.floor(Math.random()*3);
					this.nRandom = this.nRandom + 1;	
					this.fbAudio = main.playAudio('right'+this.nRandom);
					this.fbAudio.addEventListener('complete', this.instAudEnt = function()
					{ 
						//this.fSetInteraction(true);
						this.fChangeQuestion();
						this.fbAudio.removeEventListener('complete', this.instAudEnt);					
					}.bind(this));			
					//-----------				
					objRef["mcTick"].gotoAndStop(2);
					//currentClip.removeEventListener(MouseEvent.MOUSE_DOWN, item_onMouseDown);
					//currentClip.buttonMode = false;
					currentClip.btn.removeEventListener("mousedown", currentClip.listener = this.item_onMouseDown.bind(this));
					currentClip.btn.cursor = null;
					__nScore++;
					stage.removeEventListener("stagemousemove", this.stageMouseMove, false);
					stage.removeEventListener("stagemouseup", this.stageMouseUp, false);
					return;
				}
				__nWrong++;
				//var mcWrong = new Wrong();
				//objRef.addChild(mcWrong);
				this.fbAudio = main.playAudio('incorrect');
				this.fbAudio.addEventListener('complete', this.instAudEnt = function()
				{ 
					this.fSetInteraction(true);
					//this.fRefresh();
					this.fbAudio.removeEventListener('complete', this.instAudEnt);					
				}.bind(this));			
				objRef["mcTick"].gotoAndStop(1);
				//return;
			}
			currentClip.x = currentClip.xx;
			currentClip.y = currentClip.yy;
			stage.removeEventListener("stagemousemove", this.stageMouseMove, false);
			stage.removeEventListener("stagemouseup", this.stageMouseUp, false);
			//setTimeout(fChangeQuestion, 5000);
			
		}
		function containsM(inArray, item) {
			var l = inArray.length;
			var t = 0;
			while (l--) {
				if (inArray[l] == item) {
					t++;
				}
			}
			return t;
		}
		this.fSetInteraction = function(b) {
			for (var i = 1; objRef["mcDrag_" + i] != undefined; i++) {
				if (this["mcDrag_"+i].visible) {
					this["mcDrag_"+i].btn.mouseEnabled = b;
				}
			}
		}
		this.fChangeQuestion = function() {
			if (__nScore > 3) {
				//MovieClip(parent.parent.parent).mcFinal.gotoAndPlay(2);
				this.fSetInteraction(false);
				this.fCalculateScore();
				return;
			}
			this.fSetInteraction(true);
			this.mcTick.gotoAndStop(0);	
		}
		this.init();
		this.fCalculateScore = function() {
			var nP = Math.floor((__nScore/__nButtonPush)*100);	
			//alert(__nScore + "---------------------endSlide----");
			main.showRestartBtn();
			if (nP < 70) {
				//MovieClip(parent.parent.parent).mcFinal.mcRank.gotoAndPlay("rank2");		
			} else {
				//MovieClip(parent.parent.parent).mcFinal.mcRank.gotoAndPlay("rank1_1");
			}
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(125).call(this.frame_125).wait(1));

	// _
	this.mcFish = new lib.Symbol2();
	this.mcFish.name = "mcFish";
	this.mcFish.setTransform(-989.05,-616.95);
	this.mcFish._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mcFish).wait(125).to({_off:false},0).wait(1));

	// _
	this.mcTick = new lib.right_wrong();
	this.mcTick.name = "mcTick";
	this.mcTick.setTransform(-16.1,51.2,1.0032,1.0032);
	this.mcTick._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mcTick).wait(125).to({_off:false},0).wait(1));

	// clips
	this.mcDrag_6 = new lib.potator();
	this.mcDrag_6.name = "mcDrag_6";
	this.mcDrag_6.setTransform(298.5,128.45);

	this.mcDrag_5 = new lib.grapes();
	this.mcDrag_5.name = "mcDrag_5";
	this.mcDrag_5.setTransform(-326.55,134.05);

	this.mcDrag_2 = new lib.pumpkin();
	this.mcDrag_2.name = "mcDrag_2";
	this.mcDrag_2.setTransform(-186.55,-111.95);

	this.mcDrag_3 = new lib.brinjal();
	this.mcDrag_3.name = "mcDrag_3";
	this.mcDrag_3.setTransform(67,-102.9,1,1,0,0,0,-0.1,0.1);

	this.mcDrag_4 = new lib.crabb();
	this.mcDrag_4.name = "mcDrag_4";
	this.mcDrag_4.setTransform(308.05,-70.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcDrag_4},{t:this.mcDrag_3},{t:this.mcDrag_2},{t:this.mcDrag_5},{t:this.mcDrag_6}]},125).wait(1));

	// _
	this.mcDrag_1 = new lib.strawberry();
	this.mcDrag_1.name = "mcDrag_1";
	this.mcDrag_1.setTransform(-363,-108.35);

	this.mcD_4 = new lib.crabbcopy();
	this.mcD_4.name = "mcD_4";
	this.mcD_4.setTransform(92.45,125.25,0.5184,0.5184);

	this.mcD_6 = new lib.potatorcopy();
	this.mcD_6.name = "mcD_6";
	this.mcD_6.setTransform(-60.35,127.4,0.45,0.45);

	this.mcD_3 = new lib.brinjalcopy();
	this.mcD_3.name = "mcD_3";
	this.mcD_3.setTransform(-267.25,274.8,0.5832,0.5832);

	this.mcD_1 = new lib.strawberrycopy();
	this.mcD_1.name = "mcD_1";
	this.mcD_1.setTransform(-119.05,136.1,0.45,0.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcD_1},{t:this.mcD_3},{t:this.mcD_6},{t:this.mcD_4},{t:this.mcDrag_1}]},125).wait(1));

	// HEADING
	this.instance = new lib.heading_("synched",0);
	this.instance.setTransform(-672.85,-272.75);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).to({x:-342.85},11,cjs.Ease.get(1)).wait(111));

	// Layer_7
	this.mcDrop = new lib.tub();
	this.mcDrop.name = "mcDrop";
	this.mcDrop.setTransform(-24,182);
	this.mcDrop._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mcDrop).wait(125).to({_off:false},0).wait(1));

	// Layer_8
	this.instance_1 = new lib.tub();
	this.instance_1.setTransform(-14,422);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(67).to({_off:false},0).to({x:-24,y:182},12,cjs.Ease.get(1)).to({_off:true},46).wait(1));

	// Layer_9
	this.instance_2 = new lib.crabb("synched",0);
	this.instance_2.setTransform(308,-70,0.2,0.2);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(53).to({_off:false},0).to({scaleX:0.4,scaleY:0.4},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,x:308.05,y:-70.05},5,cjs.Ease.get(1)).to({_off:true},59).wait(1));

	// grapes
	this.instance_3 = new lib.grapes("synched",0);
	this.instance_3.setTransform(-326.55,134.05,0.2,0.2);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(51).to({_off:false},0).to({scaleX:0.4,scaleY:0.4},9,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(0.5)).wait(16).to({startPosition:0},0).to({_off:true},44).wait(1));

	// potator
	this.instance_4 = new lib.potator("synched",0);
	this.instance_4.setTransform(298.5,128.45,0.2,0.2,0,0,0,0.2,0.2);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(49).to({_off:false},0).to({regX:0.1,regY:0.1,scaleX:0.4,scaleY:0.4},5,cjs.Ease.get(1)).to({regX:0,regY:0,scaleX:1,scaleY:1},9,cjs.Ease.get(0.5)).wait(18).to({startPosition:0},0).to({_off:true},44).wait(1));

	// brinjal
	this.instance_5 = new lib.brinjal("synched",0);
	this.instance_5.setTransform(66.95,-102.85,0.2,0.2);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(46).to({_off:false},0).to({regX:-0.1,regY:0.1,scaleX:1,scaleY:1,x:67,y:-102.9},9,cjs.Ease.get(1)).to({startPosition:0},5,cjs.Ease.get(0.5)).wait(21).to({startPosition:0},0).to({_off:true},44).wait(1));

	// pumpkin
	this.instance_6 = new lib.pumpkin("synched",0);
	this.instance_6.setTransform(-186.55,-111.95,0.2,0.2,0,0,0,0,-0.2);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(57).to({_off:false},0).to({regY:-0.1,scaleX:0.4,scaleY:0.4},9,cjs.Ease.get(1)).to({regY:0,scaleX:1,scaleY:1},5,cjs.Ease.get(0.5)).wait(10).to({startPosition:0},0).to({_off:true},44).wait(1));

	// strawberry
	this.instance_7 = new lib.strawberry("synched",0);
	this.instance_7.setTransform(-363,-108.35,0.1,0.1);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(38).to({_off:false},0).to({scaleX:1.1,scaleY:1.1},9,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(0.5)).to({_off:true},73).wait(1));

	// ani
	this.instance_8 = new lib.Symbol1("synched",0);
	this.instance_8.setTransform(713,-225.25);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(11).to({_off:false},0).to({x:-24.5},15,cjs.Ease.get(1)).to({x:-12},5,cjs.Ease.get(1)).wait(94).to({startPosition:0},0).wait(1));

	// bg
	this.instance_9 = new lib.bgg();
	this.instance_9.setTransform(1.45,-0.5);
	this.instance_9.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({alpha:1},11).wait(115));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-819.8,-304.5,1830.8,820.5);


// stage content:
(lib.Interface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
		stage.enableMouseOver(10); 
		//this.strFrame = "strFrame1"
		this.nF = 1;
		this.fLaunchProduct = function()
		{
			if(this.mcAttachMovieClip)
			{
				this.removeChild(this.mcAttachMovieClip);
			}
			this.mcAttachMovieClip = new lib["mcMain"+this.nF];
			this.mcAttachMovieClip.x = 488.1;
			this.mcAttachMovieClip.y = 295.05;	
			this.mcAttachMovieClip.gotoAndPlay(this.strFrame);
			this.addChild(this.mcAttachMovieClip);	
			if(this.nF == 1)
			{
				//this.play();
				this.fbAudio = main.playAudio('instruction');
			}
			this.nF = this.nF + 1;
		}
		//this.fLaunchProduct();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);
// library properties:
lib.properties = {
	id: 'ECDF1A6AC5E395468828BABD79B3D8C3',
	width: 977,
	height: 588,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Interface_atlas_1.png?1638118587106", id:"Interface_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['ECDF1A6AC5E395468828BABD79B3D8C3'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;