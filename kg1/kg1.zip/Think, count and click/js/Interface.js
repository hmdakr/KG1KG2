(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Interface_atlas_1", frames: [[725,403,71,153],[951,235,286,140],[1938,151,74,153],[1239,235,286,140],[1587,455,71,153],[1527,235,286,140],[0,324,425,54],[1815,306,143,77],[862,324,36,39],[900,324,36,39],[798,403,51,36],[1297,377,143,76],[427,324,143,77],[572,324,143,77],[717,324,143,77],[0,380,143,77],[1442,377,143,76],[951,0,1081,149],[145,380,143,77],[862,377,143,77],[290,403,143,77],[1587,377,143,76],[1732,385,143,76],[0,459,143,77],[145,459,143,77],[1877,385,143,76],[1297,455,143,76],[435,403,143,77],[951,151,985,82],[580,403,143,77],[0,0,949,322],[1660,463,80,80],[1442,455,143,76],[1007,377,143,77],[1152,377,143,77]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_257 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_256 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_255 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_254 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_253 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_252 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap10 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap12 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap13 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap14 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap15 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap16 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap17 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap18 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap19 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap20 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap21 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap22 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap23 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap24 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap25 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap26 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap27 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap28 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap29 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap3 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap30 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap8 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap9 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt022_3_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(4,1,1).p("ABik1QAlgRApABQAVABAXAHQBGATASBSQAUBZhfBWQhMBGg4BaQgKAOgIAPQgrBKgnBoQgohogrhKQgIgPgKgOQg5hahMhGQhehWAUhZQAShSBGgTQAXgHAVgBQAogBAmARQA5AeAoBBQAphBA5geg");
	this.shape.setTransform(-396.5405,70.7673,1.1486,1.1486);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#9966CC").s().p("AhSCUIgSgdQg5hahMhGQhehWAUhZQAShSBGgTQAXgHAVgBQAogBAmARQA5AeAoBBQAphBA5geQAlgRApABQAVABAXAHQBGATASBSQAUBZhfBWQhMBGg4BaIgSAdQgrBKgnBoQgohogrhKg");
	this.shape_1.setTransform(-396.5405,70.7673,1.1486,1.1486);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-434.3,31.3,75.60000000000002,79);


(lib.txt022_3_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(4,1,1).p("AGuD+ItbAAIAAn7INbAAg");
	this.shape.setTransform(-368.5537,70.1795,1.425,1.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#008888").s().p("AmtD+IAAn7INbAAIAAH7g");
	this.shape_1.setTransform(-368.5537,70.1795,1.425,1.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-431.8,32,126.60000000000002,76.4);


(lib.txt022_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(4,1,1).p("AF0AAQAACZhuBtQhsBtiaAAQiZAAhthtQhshtAAiZQAAiZBshtQBthtCZAAQCaAABsBtQBuBtAACZg");
	this.shape.setTransform(-392.5729,70.7703,0.9922,0.9922);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#8F5973").s().p("AkGEGQhthsABiaQgBiZBthtQBthtCZAAQCaAABsBtQBtBtAACZQAACahtBsQhsBtiaAAQiZAAhthtg");
	this.shape_1.setTransform(-392.5729,70.7703,0.9922,0.9922);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-431.4,31.9,77.69999999999999,77.80000000000001);


(lib.txt022 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(4,1,1).p("AFsE0IlypnIllJng");
	this.shape.setTransform(-383.8669,68.135,1.296,1.296);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#99CC33").s().p("AlrE0IFlpnIFyJng");
	this.shape_1.setTransform(-383.8669,68.135,1.296,1.296);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-433,26.2,98.30000000000001,83.89999999999999);


(lib.txt022_3_4_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(4,1,1).p("AD1FlIjvieIjpCnIBNkUIjnipIEegNIBakRIBkENIEfACIjgCyg");
	this.shape.setTransform(-392.7423,72.2996,0.9845,0.9845);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FBA61C").s().p("AiWBaIjnipIEegOIBakQIBkENIEfACIjgCyIBXERIjvieIjpCng");
	this.shape_1.setTransform(-392.7423,72.2996,0.9845,0.9845);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-432.3,34.3,79.19999999999999,76.10000000000001);


(lib.txt02 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap6();
	this.instance.setTransform(-488,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-488,24,80,80);


(lib.txt01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap3();
	this.instance.setTransform(-475,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.instance_1 = new lib.Bitmap2();
	this.instance_1.setTransform(-535,-74);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-535,-74,1081,149);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* stop();
		this.blnPlay = false;*/
	}
	this.frame_1 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_135 = function() {
		/* MovieClip(parent).fChangeQuestion();
		this.blnPlay = false;
		gotoAndStop(1);*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(134).call(this.frame_135).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.right_wrong99 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// _
	this.instance = new lib.Bitmap11();
	this.instance.setTransform(-29,-18);

	this.instance_1 = new lib.Bitmap12();
	this.instance_1.setTransform(-29,-18);

	this.instance_2 = new lib.Bitmap13();
	this.instance_2.setTransform(-31,-17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-18,51,39);


(lib.ost = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.6)").s().p("EhRSALcQhTAAg7g7QgYgYgUoEQgOmHAAihIAAhwQAAhTA6g6QA7g7BTAAMCilAAAQBTAAA7A7QA6A6AABTIAABwQAAChgOGHQgUIEgYAYQg7A7hTAAg");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-540.3,-73.2,1080.6999999999998,146.4);


(lib.number032_3_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_253();
	this.instance.setTransform(-17.75,-38.4,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_252();
	this.instance_1.setTransform(-71.45,-31.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-71.4,-38.4,143,76.9);


(lib.number022_3_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_255();
	this.instance.setTransform(-20.55,-38.4,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_254();
	this.instance_1.setTransform(-71.45,-31.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-71.4,-38.4,143,76.9);


(lib.number012_3_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_257();
	this.instance.setTransform(-20.5,-38.15,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_256();
	this.instance_1.setTransform(-71.45,-32.4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-71.4,-38.1,143,76.5);


(lib.heading_ = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap1();
	this.instance.setTransform(-147,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-147,-28,425,54);


(lib.btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("EgjAAHeIAAu7MBGBAAAIAAO7g");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-224.1,-47.8,448.2,95.6), null);


(lib.broadCastInterface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_1 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_599 = function() {
		/* stop();
		this.blnPlay = false;
		MovieClip(parent.parent.parent.parent).mcForward.mcGlow.gotoAndPlay(6);*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(598).call(this.frame_599).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.bgg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8AB6DD").s().p("EgB2AvgMADAhe/IAtAAMAAABe/g");
	this.shape.setTransform(485.95,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#A2DAF3").s().p("EBHVAvgMABFhe/IFCAAMgDBBe/gEBCHAvgMAAAhe/ID8AAMgAnBe/gEASiAvgMgCVhe/IF4AAMAAABe/gEAFEAvgMAAAhe/IGRAAMgDNBe/gEgDFAvgMAAAhe/IFtAAMgCgBe/gEgJ6AvgMABFhe/ICsAAMgArBe/gEgPIAvgMAAAhe/ID8AAMgAnBe/gEg+tAvgMgCVhe/IF4AAMAAABe/gEhNbAvgMAAAhe/IHhAAMgDNBe/g");
	this.shape_1.setTransform(-2.275,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#BDE3F6").s().p("EAuaAvgMgCQhe/IE/AAMAAABe/gEAgHAvgMAAAhe/IDzAAMAAABe/gEADNAvgMAArhe/IDDAAMAAABe/gEgi1AvgMgCQhe/IE/AAMAAABe/gEgxIAvgMAAAhe/ID0AAMAAABe/g");
	this.shape_2.setTransform(-66.45,0);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#BDDDF2").s().p("EA88AvgMgAghe/IE7AAMgBFBe/gEA1iAvgMAAAhe/IE6AAMgCzBe/gEAtEAvgMACxhe/ICoAAMAAABe/gEAf+AvgMAAAhe/IE/AAMACQBe/gEAQzAvgMgA6he/IDIAAMACVBe/gEAC8AvgMAChhe/ICbAAMAAABe/gEgUTAvgMgAghe/IE7AAMgBFBe/gEgbtAvgMAAAhe/IE6AAMgCzBe/gEgkLAvgMACxhe/ICoAAMAAABe/gEgxRAvgMAAAhe/IE/AAMACQBe/gEhAcAvgMgA6he/IDIAAMACVBe/g");
	this.shape_3.setTransform(-20.325,0);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D5ECFA").s().p("EBFyAvgMAAnhe/ICYAAMgBFBe/gEA90AvgMABFhe/IDkAAMAAABe/gEA1LAvgMAC0he/IB/AAMAAhBe/gEAv/AvgMAAAhe/IDFAAMAAABe/gEAneAvgMAAAhe/IF5AAMgCxBe/gEAaPAvgMAAAhe/IDSAAMAAABe/gEAIfAvgMADNhe/IBvAAMAA7Be/gEgLdAvgMAAohe/ICXAAMgBFBe/gEgTaAvgMABEhe/IDlAAMAAABe/gEgcEAvgMACzhe/ICAAAMAAhBe/gEghQAvgMAAAhe/IDFAAMAAABe/gEgpxAvgMAAAhe/IF6AAMgCyBe/gEg2/AvgMAAAhe/IDRAAMAAABe/gEhIwAvgMADMhe/IBwAAMAA6Be/g");
	this.shape_4.setTransform(-4.55,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bgg, new cjs.Rectangle(-497.9,-304,995.8,608), null);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.bgg();
	this.instance.setTransform(31.6,-66.45,0.5376,0.5376);
	this.instance.alpha = 0.3203;
	this.instance.filters = [new cjs.ColorMatrixFilter(new cjs.ColorMatrix(0, 8, 0, 168))];
	this.instance.cache(-500,-306,1000,612);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-236,-229.8,539,329);


(lib.number032_3_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,1.1,0.3791,0.7542,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap30();
	this.instance.setTransform(-71,-38);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.9,-38,169.9,77);


(lib.number032_3_4_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,1.1,0.3791,0.7542,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_1
	this.instance = new lib.Bitmap17();
	this.instance.setTransform(-71,-38);

	this.instance_1 = new lib.Bitmap18();
	this.instance_1.setTransform(-71,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.9,-38,169.9,77);


(lib.number032_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,1.1,0.3791,0.7542,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap26();
	this.instance.setTransform(-71,-38);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.9,-38,169.9,77);


(lib.number032 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,1.1,0.3791,0.7542,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_1
	this.instance = new lib.Bitmap21();
	this.instance.setTransform(-71,-38);

	this.instance_1 = new lib.Bitmap22();
	this.instance_1.setTransform(-71,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.9,-38,169.9,77);


(lib.number03 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,1.1,0.3791,0.7542,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap10();
	this.instance.setTransform(-71,-38);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.9,-38,169.9,77);


(lib.number022_3_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,1.1,0.3791,0.7542,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap29();
	this.instance.setTransform(-71,-38);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.9,-38,169.9,77);


(lib.number022_3_4_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,1.1,0.3791,0.7542,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_1
	this.instance = new lib.Bitmap15();
	this.instance.setTransform(-71,-38);

	this.instance_1 = new lib.Bitmap16();
	this.instance_1.setTransform(-71,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.9,-38,169.9,77);


(lib.number022_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,1.1,0.3791,0.7542,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap25();
	this.instance.setTransform(-71,-38);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.9,-38,169.9,77);


(lib.number022 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,1.1,0.3791,0.7542,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap20();
	this.instance.setTransform(-71,-38);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.9,-38,169.9,77);


(lib.number02 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,1.1,0.3791,0.7542,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_1
	this.instance = new lib.Bitmap8();
	this.instance.setTransform(-71,-38);

	this.instance_1 = new lib.Bitmap9();
	this.instance_1.setTransform(-71,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.9,-38,169.9,77);


(lib.number012_3_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,1.1,0.3791,0.7542,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_1
	this.instance = new lib.Bitmap27();
	this.instance.setTransform(-71,-38);

	this.instance_1 = new lib.Bitmap28();
	this.instance_1.setTransform(-71,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.9,-38,169.9,76);


(lib.number012_3_4_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,1.1,0.3791,0.7542,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap14();
	this.instance.setTransform(-71,-38);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.9,-38,169.9,76);


(lib.number012_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,1.1,0.3791,0.7542,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_1
	this.instance = new lib.Bitmap23();
	this.instance.setTransform(-71,-38);

	this.instance_1 = new lib.Bitmap24();
	this.instance_1.setTransform(-71,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.9,-38,169.9,76);


(lib.number012 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,1.1,0.3791,0.7542,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap19();
	this.instance.setTransform(-71,-38);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.9,-38,169.9,76);


(lib.number01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,1.1,0.3791,0.7542,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap7();
	this.instance.setTransform(-71,-38);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.9,-38,169.9,76);


(lib.band2_3_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ost("synched",0);
	this.instance.setTransform(7,94.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-533.3,21.2,1080.6999999999998,146.4);


(lib.band2_3_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ost("synched",0);
	this.instance.setTransform(7,94.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-533.3,21.2,1080.6999999999998,146.4);


(lib.band2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ost("synched",0);
	this.instance.setTransform(7,94.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-533.3,21.2,1080.6999999999998,146.4);


(lib.band2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ost("synched",0);
	this.instance.setTransform(7,94.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-533.3,21.2,1080.6999999999998,146.4);


(lib.band2_3_4_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ost("synched",0);
	this.instance.setTransform(7,94.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-533.3,21.2,1080.6999999999998,146.4);


(lib.band = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ost("synched",0);
	this.instance.setTransform(7,94.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-533.3,21.2,1080.6999999999998,146.4);


(lib.mcMain6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_93 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 1;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					//this.parent.fLaunchProduct();
					this.play();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				//this.parent.fLaunchProduct();
				this.play();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}
	this.frame_94 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_138 = function() {
		/* stop();
		this.blnPlay = false;
		fCalculateScore();
		function fCalculateScore() {
			var nP = Math.floor((__nScore/6)*100);
			trace(__nScore + "---------------------"+6+"---------"+nP);
			if (nP < 70) {
				MovieClip(parent.parent.parent).mcFinal.mcRank.gotoAndPlay("rank2");
			} else {
				MovieClip(parent.parent.parent).mcFinal.mcRank.gotoAndPlay("rank1_1");
			}
		}*/
		
		this.stop();
		//alert("------End Slide---");
		main.showRestartBtn();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(93).call(this.frame_93).wait(1).call(this.frame_94).wait(44).call(this.frame_138).wait(1));

	// _
	this.mcFish = new lib.Symbol2();
	this.mcFish.name = "mcFish";
	this.mcFish.setTransform(-542.5,-401.2);

	this.timeline.addTween(cjs.Tween.get(this.mcFish).wait(139));

	// Layer_3
	this.mcInterfaceBlinker = new lib.broadCastInterface();
	this.mcInterfaceBlinker.name = "mcInterfaceBlinker";
	this.mcInterfaceBlinker.setTransform(-453,-389,1,1,0,0,0,11.5,8);
	this.mcInterfaceBlinker._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mcInterfaceBlinker).wait(93).to({_off:false},0).to({_off:true},1).wait(45));

	// _
	this.mcTick_3 = new lib.right_wrong99();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(431.9,246.45,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong99();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(181.9,246.45,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong99();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-67.05,246.45,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},93).wait(46));

	// _
	this.mc_3 = new lib.number032_3_5();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(307.55,245.85);

	this.mc_2 = new lib.number022_3_5();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(55.3,245.85);

	this.mc_1 = new lib.number012_3_5();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-196.9,246.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3}]},93).wait(46));

	// number03
	this.instance = new lib.number032_3_5("synched",0);
	this.instance.setTransform(1147.55,245.85);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(71).to({_off:false},0).to({x:297.55},10,cjs.Ease.get(1)).to({x:307.55},5,cjs.Ease.get(1)).to({_off:true},7).wait(1).to({_off:false},0).wait(45));

	// number02
	this.instance_1 = new lib.number022_3_5("synched",0);
	this.instance_1.setTransform(895.3,245.85);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(68).to({_off:false},0).to({x:45.3},10,cjs.Ease.get(1)).to({x:55.3},5,cjs.Ease.get(1)).to({_off:true},10).wait(1).to({_off:false},0).wait(45));

	// number01
	this.instance_2 = new lib.number012_3_5("single",0);
	this.instance_2.setTransform(643.1,246.7);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(65).to({_off:false},0).to({x:-206.9},10,cjs.Ease.get(1)).to({x:-196.9},5,cjs.Ease.get(1)).to({_off:true},13).wait(1).to({_off:false},0).wait(45));

	// txt02
	this.instance_3 = new lib.txt022_3_5("synched",0);
	this.instance_3.setTransform(0,352.8);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(48).to({_off:false},0).to({y:163.8},10,cjs.Ease.get(1)).to({y:173.8},6,cjs.Ease.get(1)).wait(75));

	// band
	this.instance_4 = new lib.band2_3_5("synched",0);
	this.instance_4.setTransform(1.2,353.55);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(48).to({_off:false},0).to({y:163.55},10,cjs.Ease.get(1)).to({y:173.55},6,cjs.Ease.get(1)).wait(75));

	// number03
	this.instance_5 = new lib.number032_3_4("single",0);
	this.instance_5.setTransform(307.55,245.85);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(27).to({startPosition:0},0).to({y:235.85},5,cjs.Ease.get(-1)).to({y:725.85,mode:"synched"},10,cjs.Ease.get(-1)).to({_off:true},1).wait(96));

	// number02
	this.instance_6 = new lib.number022_3_4("single",0);
	this.instance_6.setTransform(55.3,245.85);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(27).to({mode:"synched"},0).to({y:235.85},5,cjs.Ease.get(-1)).to({y:725.85},10,cjs.Ease.get(-1)).to({_off:true},1).wait(96));

	// number01
	this.instance_7 = new lib.number012_3_4("synched",0);
	this.instance_7.setTransform(-196.9,246.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(27).to({startPosition:0},0).to({y:236.7},5,cjs.Ease.get(-1)).to({y:726.7},10,cjs.Ease.get(-1)).to({_off:true},1).wait(96));

	// txt02
	this.instance_8 = new lib.txt022_3_4_1("synched",0);
	this.instance_8.setTransform(0,173.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(30).to({startPosition:0},0).to({y:163.8},5,cjs.Ease.get(-1)).to({y:653.8},10,cjs.Ease.get(-1)).to({_off:true},1).wait(93));

	// band
	this.instance_9 = new lib.band2_3_4_1("synched",0);
	this.instance_9.setTransform(1.2,173.55);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(30).to({startPosition:0},0).to({y:163.55},5,cjs.Ease.get(-1)).to({y:653.55},10,cjs.Ease.get(-1)).to({_off:true},1).wait(93));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-532.1,0,1764.6,821.2);


(lib.mcMain5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_101 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 3;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(101).call(this.frame_101).wait(1));

	// _
	this.mcFish = new lib.Symbol2();
	this.mcFish.name = "mcFish";
	this.mcFish.setTransform(-542.5,-401.2);

	this.timeline.addTween(cjs.Tween.get(this.mcFish).wait(102));

	// _
	this.mcTick_3 = new lib.right_wrong99();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(431.9,246.45,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong99();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(181.9,246.45,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong99();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-67.05,246.45,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},101).wait(1));

	// _
	this.mc_3 = new lib.number032_3_4_1();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(307.55,245.85);

	this.mc_2 = new lib.number022_3_4_1();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(55.3,245.85);

	this.mc_1 = new lib.number012_3_4_1();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-196.9,246.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3}]},101).wait(1));

	// number03
	this.instance = new lib.number032_3_4("single",0);
	this.instance.setTransform(1147.55,245.85);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(63).to({_off:false},0).to({x:297.55},10,cjs.Ease.get(1)).to({x:307.55},5,cjs.Ease.get(1)).to({_off:true},23).wait(1));

	// number02
	this.instance_1 = new lib.number022_3_4("single",0);
	this.instance_1.setTransform(895.3,245.85);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(60).to({_off:false},0).to({x:45.3},10,cjs.Ease.get(1)).to({x:55.3},5,cjs.Ease.get(1)).to({_off:true},26).wait(1));

	// number01
	this.instance_2 = new lib.number012_3_4("synched",0);
	this.instance_2.setTransform(643.1,246.7);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(57).to({_off:false},0).to({x:-206.9},10,cjs.Ease.get(1)).to({x:-196.9},5,cjs.Ease.get(1)).to({_off:true},29).wait(1));

	// txt02
	this.instance_3 = new lib.txt022_3_4_1("synched",0);
	this.instance_3.setTransform(0,352.8);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(40).to({_off:false},0).to({y:163.8},10,cjs.Ease.get(1)).to({y:173.8},6,cjs.Ease.get(1)).wait(46));

	// band
	this.instance_4 = new lib.band2_3_4_1("synched",0);
	this.instance_4.setTransform(1.2,353.55);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(40).to({_off:false},0).to({y:163.55},10,cjs.Ease.get(1)).to({y:173.55},6,cjs.Ease.get(1)).wait(46));

	// number03
	this.instance_5 = new lib.number032_3_4_1("single",0);
	this.instance_5.setTransform(307.55,245.85);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(21).to({startPosition:0},0).to({y:235.85},5,cjs.Ease.get(-1)).to({y:725.85},10,cjs.Ease.get(-1)).to({_off:true},1).wait(65));

	// number02
	this.instance_6 = new lib.number022_3_4_1("single",0);
	this.instance_6.setTransform(55.3,245.85);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(21).to({startPosition:0},0).to({y:235.85},5,cjs.Ease.get(-1)).to({y:725.85},10,cjs.Ease.get(-1)).to({_off:true},1).wait(65));

	// number01
	this.instance_7 = new lib.number012_3_4_1("synched",0);
	this.instance_7.setTransform(-196.9,246.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(21).to({startPosition:0},0).to({y:236.7},5,cjs.Ease.get(-1)).to({y:726.7},10,cjs.Ease.get(-1)).to({_off:true},1).wait(65));

	// txt02
	this.instance_8 = new lib.txt022_3_4("synched",0);
	this.instance_8.setTransform(0,173.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(24).to({startPosition:0},0).to({y:163.8},5,cjs.Ease.get(-1)).to({y:653.8},10,cjs.Ease.get(-1)).to({_off:true},1).wait(62));

	// band
	this.instance_9 = new lib.band2_3_4("synched",0);
	this.instance_9.setTransform(1.2,173.55);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(24).to({startPosition:0},0).to({y:163.55},5,cjs.Ease.get(-1)).to({y:653.55},10,cjs.Ease.get(-1)).to({_off:true},1).wait(62));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-532.1,184.8,1751.1999999999998,636.4000000000001);


(lib.mcMain4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_123 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 2;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(123).call(this.frame_123).wait(1));

	// _
	this.mcFish = new lib.Symbol2();
	this.mcFish.name = "mcFish";
	this.mcFish.setTransform(-542.5,-401.2);

	this.timeline.addTween(cjs.Tween.get(this.mcFish).wait(124));

	// _
	this.mcTick_3 = new lib.right_wrong99();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(431.9,246.45,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong99();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(181.9,246.45,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong99();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-67.05,246.45,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},123).wait(1));

	// _
	this.mc_3 = new lib.number032_3_4_1();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(307.55,245.85);

	this.mc_2 = new lib.number022_3_4_1();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(55.3,245.85);

	this.mc_1 = new lib.number012_3_4_1();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-196.9,246.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3}]},123).wait(1));

	// number03
	this.instance = new lib.number032_3_4_1("single",0);
	this.instance.setTransform(1147.55,245.85);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(88).to({_off:false},0).to({x:297.55},10,cjs.Ease.get(1)).to({x:307.55},5,cjs.Ease.get(1)).to({_off:true},20).wait(1));

	// number02
	this.instance_1 = new lib.number022_3_4_1("single",0);
	this.instance_1.setTransform(895.3,245.85);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(85).to({_off:false},0).to({x:45.3},10,cjs.Ease.get(1)).to({x:55.3},5,cjs.Ease.get(1)).to({_off:true},23).wait(1));

	// number01
	this.instance_2 = new lib.number012_3_4_1("synched",0);
	this.instance_2.setTransform(643.1,246.7);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(82).to({_off:false},0).to({x:-206.9},10,cjs.Ease.get(1)).to({x:-196.9},5,cjs.Ease.get(1)).to({_off:true},26).wait(1));

	// txt02
	this.instance_3 = new lib.txt022_3_4("synched",0);
	this.instance_3.setTransform(0,352.8);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(65).to({_off:false},0).to({y:163.8},10,cjs.Ease.get(1)).to({y:173.8},6,cjs.Ease.get(1)).wait(43));

	// band
	this.instance_4 = new lib.band2_3_4("synched",0);
	this.instance_4.setTransform(1.2,353.55);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(65).to({_off:false},0).to({y:163.55},10,cjs.Ease.get(1)).to({y:173.55},6,cjs.Ease.get(1)).wait(43));

	// number03
	this.instance_5 = new lib.number032_3("synched",0);
	this.instance_5.setTransform(307.55,245.85);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(29).to({startPosition:0},0).to({y:235.85},5,cjs.Ease.get(-1)).to({y:725.85},10,cjs.Ease.get(-1)).to({_off:true},1).wait(79));

	// number02
	this.instance_6 = new lib.number022_3("synched",0);
	this.instance_6.setTransform(55.3,245.85);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(29).to({startPosition:0},0).to({y:235.85},5,cjs.Ease.get(-1)).to({y:725.85},10,cjs.Ease.get(-1)).to({_off:true},1).wait(79));

	// number01
	this.instance_7 = new lib.number012_3("single",0);
	this.instance_7.setTransform(-196.9,246.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(29).to({startPosition:0},0).to({y:236.7},5,cjs.Ease.get(-1)).to({y:726.7,mode:"synched"},10,cjs.Ease.get(-1)).to({_off:true},1).wait(79));

	// txt02
	this.instance_8 = new lib.txt022_3("synched",0);
	this.instance_8.setTransform(0,173.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(32).to({startPosition:0},0).to({y:163.8},5,cjs.Ease.get(-1)).to({y:653.8},10,cjs.Ease.get(-1)).to({_off:true},1).wait(76));

	// band
	this.instance_9 = new lib.band2_3("synched",0);
	this.instance_9.setTransform(1.2,173.55);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(32).to({startPosition:0},0).to({y:163.55},5,cjs.Ease.get(-1)).to({y:653.55},10,cjs.Ease.get(-1)).to({_off:true},1).wait(76));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-532.1,0,1764.6,821.2);


(lib.mcMain3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_125 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 1;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(125).call(this.frame_125).wait(1));

	// _
	this.mcFish = new lib.Symbol2();
	this.mcFish.name = "mcFish";
	this.mcFish.setTransform(-542.5,-401.2);

	this.timeline.addTween(cjs.Tween.get(this.mcFish).wait(126));

	// _
	this.mcTick_3 = new lib.right_wrong99();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(431.9,246.45,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong99();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(181.9,246.45,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong99();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-67.05,246.45,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},125).wait(1));

	// _
	this.mc_3 = new lib.number032_3();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(307.55,245.85);

	this.mc_2 = new lib.number022_3();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(55.3,245.85);

	this.mc_1 = new lib.number012_3();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-196.9,246.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3}]},125).wait(1));

	// number03
	this.instance = new lib.number032_3("synched",0);
	this.instance.setTransform(1147.55,245.85);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(84).to({_off:false},0).to({x:297.55},10,cjs.Ease.get(1)).to({x:307.55},5,cjs.Ease.get(1)).to({_off:true},26).wait(1));

	// number02
	this.instance_1 = new lib.number022_3("synched",0);
	this.instance_1.setTransform(895.3,245.85);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(81).to({_off:false},0).to({x:45.3},10,cjs.Ease.get(1)).to({x:55.3},5,cjs.Ease.get(1)).to({_off:true},29).wait(1));

	// number01
	this.instance_2 = new lib.number012_3("single",0);
	this.instance_2.setTransform(643.1,246.7);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(78).to({_off:false},0).to({x:-206.9},10,cjs.Ease.get(1)).to({x:-196.9},5,cjs.Ease.get(1)).to({_off:true},32).wait(1));

	// txt02
	this.instance_3 = new lib.txt022_3("synched",0);
	this.instance_3.setTransform(0,352.8);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(61).to({_off:false},0).to({y:163.8},10,cjs.Ease.get(1)).to({y:173.8},6,cjs.Ease.get(1)).wait(49));

	// band
	this.instance_4 = new lib.band2_3("synched",0);
	this.instance_4.setTransform(1.2,353.55);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(61).to({_off:false},0).to({y:163.55},10,cjs.Ease.get(1)).to({y:173.55},6,cjs.Ease.get(1)).wait(49));

	// band
	this.instance_5 = new lib.number032("single",0);
	this.instance_5.setTransform(307.55,245.85);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(28).to({startPosition:0},0).to({y:235.85},5,cjs.Ease.get(-1)).to({y:725.85,mode:"synched"},10,cjs.Ease.get(-1)).to({_off:true},1).wait(82));

	// number02
	this.instance_6 = new lib.number022("synched",0);
	this.instance_6.setTransform(55.3,245.85);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(28).to({startPosition:0},0).to({y:235.85},5,cjs.Ease.get(-1)).to({y:725.85},10,cjs.Ease.get(-1)).to({_off:true},1).wait(82));

	// number01
	this.instance_7 = new lib.number012("synched",0);
	this.instance_7.setTransform(-196.9,246.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(28).to({startPosition:0},0).to({y:236.7},5,cjs.Ease.get(-1)).to({y:726.7},10,cjs.Ease.get(-1)).to({_off:true},1).wait(82));

	// txt02
	this.instance_8 = new lib.txt022("synched",0);
	this.instance_8.setTransform(0,173.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(31).to({startPosition:0},0).to({y:163.8},5,cjs.Ease.get(-1)).to({y:653.8},10,cjs.Ease.get(-1)).to({_off:true},1).wait(79));

	// band
	this.instance_9 = new lib.band2("synched",0);
	this.instance_9.setTransform(1.2,173.55);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(31).to({startPosition:0},0).to({y:163.55},5,cjs.Ease.get(-1)).to({y:653.55},10,cjs.Ease.get(-1)).to({_off:true},1).wait(79));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-532.1,0,1764.6,821.2);


(lib.mcMain2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_88 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 3;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(88).call(this.frame_88).wait(1));

	// code
	this.mcFish = new lib.Symbol2();
	this.mcFish.name = "mcFish";
	this.mcFish.setTransform(-542.5,-401.2);

	this.timeline.addTween(cjs.Tween.get(this.mcFish).wait(89));

	// _
	this.mcTick_3 = new lib.right_wrong99();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(431.9,246.45,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong99();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(181.9,246.45,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong99();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-67.05,246.45,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},88).wait(1));

	// _
	this.mc_3 = new lib.number032();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(307.55,245.85);

	this.mc_2 = new lib.number022();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(55.3,245.85);

	this.mc_1 = new lib.number012();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-196.9,246.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3}]},88).wait(1));

	// band
	this.instance = new lib.number032("single",0);
	this.instance.setTransform(1147.55,245.85);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(73).to({_off:false},0).to({x:297.55},10,cjs.Ease.get(1)).to({x:307.55,mode:"synched"},4,cjs.Ease.get(1)).to({_off:true},1).wait(1));

	// number02
	this.instance_1 = new lib.number022("synched",0);
	this.instance_1.setTransform(895.3,245.85);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(70).to({_off:false},0).to({x:45.3},10,cjs.Ease.get(1)).to({x:55.3},5,cjs.Ease.get(1)).to({_off:true},3).wait(1));

	// number01
	this.instance_2 = new lib.number012("synched",0);
	this.instance_2.setTransform(643.1,246.7);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(67).to({_off:false},0).to({x:-206.9},10,cjs.Ease.get(1)).to({x:-196.9},5,cjs.Ease.get(1)).to({_off:true},6).wait(1));

	// txt02
	this.instance_3 = new lib.txt022("synched",0);
	this.instance_3.setTransform(0,352.8);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(50).to({_off:false},0).to({y:163.8},10,cjs.Ease.get(1)).to({y:173.8},6,cjs.Ease.get(1)).wait(23));

	// band
	this.instance_4 = new lib.band2("synched",0);
	this.instance_4.setTransform(1.2,353.55);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(50).to({_off:false},0).to({y:163.55},10,cjs.Ease.get(1)).to({y:173.55},6,cjs.Ease.get(1)).wait(23));

	// number03
	this.instance_5 = new lib.number03("synched",0);
	this.instance_5.setTransform(307.55,245.85);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(16).to({startPosition:0},0).to({y:235.85},5,cjs.Ease.get(-1)).to({y:725.85},10,cjs.Ease.get(-1)).to({_off:true},1).wait(57));

	// number02
	this.instance_6 = new lib.number02("single",0);
	this.instance_6.setTransform(55.3,245.85);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(16).to({startPosition:0},0).to({y:235.85},5,cjs.Ease.get(-1)).to({y:725.85},10,cjs.Ease.get(-1)).to({_off:true},1).wait(57));

	// number01
	this.instance_7 = new lib.number01("synched",0);
	this.instance_7.setTransform(-196.9,246.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(16).to({startPosition:0},0).to({y:236.7},5,cjs.Ease.get(-1)).to({y:726.7},10,cjs.Ease.get(-1)).to({_off:true},1).wait(57));

	// txt02
	this.instance_8 = new lib.txt02("synched",0);
	this.instance_8.setTransform(56,178.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(19).to({startPosition:0},0).to({y:168.6},5,cjs.Ease.get(-0.5)).to({y:658.6},10,cjs.Ease.get(-0.5)).to({_off:true},1).wait(54));

	// band
	this.instance_9 = new lib.band("synched",0);
	this.instance_9.setTransform(1.2,173.55);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(19).to({startPosition:0},0).to({y:163.55},5,cjs.Ease.get(-0.5)).to({y:653.55},10,cjs.Ease.get(-0.5)).to({_off:true},1).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-532.1,0,1764.6,821.2);


(lib.mcMain1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* function fMenuJumpFunction()
		{
			this.stop();
			this.blnPlay = false;
			var mc = new mcMenuSlide();
			this.addChild(mc);
		}*/
	}
	this.frame_1 = function() {
		/* this.blnPlay = true;
		var objRef = this;
		var __nCorrectAnswer = 0;
		var blnLastQuestion = false;
		var __nScore = 0;
		var blnEnd = false;
		function init() {
			for (var i:Number = 1; objRef["mc_"+i] != null; i++) {
				objRef["mc_" + i].gotoAndStop(1);
				objRef["mc_"+i].id = i;
				objRef["mc_" + i].addEventListener(MouseEvent.CLICK, fClickEvent);
				objRef["mc_"+i].buttonMode = true;
			}
		}
		
		function fClickEvent(e) {
			mcFish.gotoAndPlay(2);
			fRemoveListeners();
			if (e.currentTarget.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.gotoAndStop(2);
				var mcRight = new Right();
				objRef.addChild(mcRight);
				objRef["mcTick_" + e.currentTarget.id].gotoAndStop(3);
				return;
			}
			var mcWrong = new ShowAnswer();
			objRef.addChild(mcWrong);
			objRef["mcTick_" + e.currentTarget.id].gotoAndStop(2);
		}
		function fShowCorrectAnswer() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(2);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(3);
		}
		function fChangeQuestion() {
			fRemoveListeners();
			play();
		}
		function fRemoveListeners() {
			for (var i:Number = 1; objRef["mc_"+i] != null; i++) {
				objRef["mc_" + i].removeEventListener(MouseEvent.CLICK, fClickEvent);
				objRef["mc_"+i].buttonMode = false;
			}
		}*/
	}
	this.frame_245 = function() {
		//this.fbAudio = main.playAudio('instructionpart2');
	}
	this.frame_349 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 2;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(244).call(this.frame_245).wait(104).call(this.frame_349).wait(1));

	// _
	this.mcFish = new lib.Symbol2();
	this.mcFish.name = "mcFish";
	this.mcFish.setTransform(-542.5,-401.2);

	this.timeline.addTween(cjs.Tween.get(this.mcFish).wait(350));

	// _
	this.mcTick_3 = new lib.right_wrong99();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(431.9,246.45,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong99();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(181.9,246.45,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong99();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-67.05,246.45,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},349).wait(1));

	// _
	this.mc_3 = new lib.number03();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(307.55,245.85);

	this.mc_2 = new lib.number02();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(55.3,245.85);

	this.mc_1 = new lib.number01();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-196.9,246.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3}]},349).wait(1));

	// number03
	this.instance = new lib.number03("synched",0);
	this.instance.setTransform(1147.55,245.85);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(73).to({_off:false},0).to({x:297.55},10,cjs.Ease.get(1)).to({x:307.55},5,cjs.Ease.get(1)).to({_off:true},261).wait(1));

	// number02
	this.instance_1 = new lib.number02("single",0);
	this.instance_1.setTransform(895.3,245.85);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(70).to({_off:false},0).to({x:45.3},10,cjs.Ease.get(1)).to({x:55.3},5,cjs.Ease.get(1)).to({_off:true},264).wait(1));

	// number01
	this.instance_2 = new lib.number01("synched",0);
	this.instance_2.setTransform(643.1,246.7);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(67).to({_off:false},0).to({x:-206.9},10,cjs.Ease.get(1)).to({x:-196.9},5,cjs.Ease.get(1)).to({_off:true},267).wait(1));

	// txt02
	this.instance_3 = new lib.txt02("synched",0);
	this.instance_3.setTransform(56,357.6);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(50).to({_off:false},0).to({y:168.6},10,cjs.Ease.get(1)).to({y:178.6},6,cjs.Ease.get(1)).wait(284));

	// band
	this.instance_4 = new lib.band("synched",0);
	this.instance_4.setTransform(1.2,353.55);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(50).to({_off:false},0).to({y:163.55},10,cjs.Ease.get(1)).to({y:173.55},6,cjs.Ease.get(1)).wait(284));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-532.1,0,1764.6,521.2);


// stage content:
(lib.Interface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,51];
	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		stage.enableMouseOver(10); 
		//this.strFrame = "strFrame1"
		this.nF = 1;
		this.fLaunchProduct = function()
		{
			if(this.mcAttachMovieClip)
			{
				this.removeChild(this.mcAttachMovieClip);
			}
			this.mcAttachMovieClip = new lib["mcMain"+this.nF];
			this.mcAttachMovieClip.x = 488.1;
			this.mcAttachMovieClip.y = 295.05;	
			this.mcAttachMovieClip.gotoAndPlay(this.strFrame);
			this.addChild(this.mcAttachMovieClip);	
			if(this.nF == 1)
			{
				this.play();
				this.fbAudio = main.playAudio('instruction');
				this.fbAudio.addEventListener('complete', this.instAudEnt = function()
				{	 
					this.fbAudio = main.playAudio('instructionpart2');
				}.bind(this));	
			}
			this.nF = this.nF + 1;
		}
		//this.fLaunchProduct();
	}
	this.frame_51 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(51).call(this.frame_51).wait(1));

	// HEADING
	this.instance = new lib.heading_("synched",0);
	this.instance.setTransform(-184.35,21.25);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).to({x:145.65},11,cjs.Ease.get(1)).wait(37));

	// _
	this.instance_1 = new lib.txt01("synched",0);
	this.instance_1.setTransform(1448.5,69.55);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(21).to({_off:false},0).to({x:478.5,alpha:1},12,cjs.Ease.get(1)).to({x:488.5},6,cjs.Ease.get(1)).wait(13));

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_11 = new cjs.Graphics().p("Ehx5A2LMB+0iLHMBk/AoZIgRArMh/sCA1g");
	var mask_graphics_12 = new cjs.Graphics().p("Eh5FA2LMCG0iLIMBrXAoaIgSArMiHwCA2g");
	var mask_graphics_13 = new cjs.Graphics().p("EiAFA2LMCOniLIMBxkAoaIgTArMiPmCA2g");
	var mask_graphics_14 = new cjs.Graphics().p("EiG5A2LMCWMiLIMB3nAoaIgVArMiXOCA2g");
	var mask_graphics_15 = new cjs.Graphics().p("EiNgA2LMCdjiLIMB9eAoaIgVArMiepCA2g");
	var mask_graphics_16 = new cjs.Graphics().p("EiT7A2LMCktiLIMCDKAoaIgWArMil2CA2g");
	var mask_graphics_17 = new cjs.Graphics().p("EiaKA2LMCrpiLHMCIsAoZIgXArMis1CA1g");
	var mask_graphics_18 = new cjs.Graphics().p("EigNA2LMCyYiLIMCODAoaIgZArMizmCA2g");
	var mask_graphics_19 = new cjs.Graphics().p("EimDA2LMC45iLHMCTOAoZIgZArMi6KCA1g");
	var mask_graphics_20 = new cjs.Graphics().p("EirtA2LMC/MiLHMCYPAoZIgaArMjAfCA2g");
	var mask_graphics_21 = new cjs.Graphics().p("EixLA2LMDFRiLIMCdGAoaIgbArMjGoCA2g");
	var mask_graphics_22 = new cjs.Graphics().p("Ei2cA2LMDLJiLIMChwAoaIgbArMjMiCA2g");
	var mask_graphics_23 = new cjs.Graphics().p("Ei7iA2LMDQ0iLHMCmRAoZIgdArMjSOCA2g");
	var mask_graphics_24 = new cjs.Graphics().p("EjAaA2LMDWPiLHMCqmAoZIgdArMjXtCA1g");
	var mask_graphics_25 = new cjs.Graphics().p("EjFHA2LMDbeiLIMCuxAoaIgeArMjc+CA1g");
	var mask_graphics_26 = new cjs.Graphics().p("EjJoA2LMDggiLHMCyxAoZIgfArMjiCCA2g");
	var mask_graphics_27 = new cjs.Graphics().p("EjN8A2LMDlTiLIMC2mAoaIggArMjm3CA1g");
	var mask_graphics_28 = new cjs.Graphics().p("EjSEA2LMDp5iLHMC6QAoZIggArMjrfCA1g");
	var mask_graphics_29 = new cjs.Graphics().p("EjV/A2LMDuRiLHMC9uAoZIggArMjv5CA1g");
	var mask_graphics_30 = new cjs.Graphics().p("EjZuA2LMDybiLHMDBCAoZIghArMj0FCA1g");
	var mask_graphics_31 = new cjs.Graphics().p("EjdRA2LMD2YiLHMDELAoZIghArMj4ECA1g");
	var mask_graphics_32 = new cjs.Graphics().p("EjgoA2LMD6HiLIMDHKAoaIgiArMj70CA1g");
	var mask_graphics_33 = new cjs.Graphics().p("EjjzA2LMD9piLHMDJ+AoZIgjArMj/XCA2g");
	var mask_graphics_34 = new cjs.Graphics().p("EjmxA2LMEA9iLIMDMmAoaIgjArMkCtCA1g");
	var mask_graphics_35 = new cjs.Graphics().p("EjpjA2LMEEDiLHMDPEAoZIgjArMkF1CA1g");
	var mask_graphics_36 = new cjs.Graphics().p("EjsJA2LMEG8iLIMDRXAoaIgkArMkIuCA2g");
	var mask_graphics_37 = new cjs.Graphics().p("EjuiA2LMEJmiLIMDTfAoaIgkArMkLaCA2g");
	var mask_graphics_38 = new cjs.Graphics().p("EjwvA2LMEMDiLIMDVcAoaIgkArMkN5CA2g");
	var mask_graphics_39 = new cjs.Graphics().p("EjywA2LMEOTiLHMDXOAoZIglArMkQJCA2g");
	var mask_graphics_40 = new cjs.Graphics().p("Ej0lA2LMEQViLHMDY2AoZIgmArMkSLCA1g");
	var mask_graphics_41 = new cjs.Graphics().p("Ej2NA2LMESJiLIMDaSAoaIglArMkUBCA2g");
	var mask_graphics_42 = new cjs.Graphics().p("Ej3pA2LMETviLHMDbkAoZIgmArMkVnCA1g");
	var mask_graphics_43 = new cjs.Graphics().p("Ej45A2LMEVIiLIMDcrAoaIgmArMkXBCA2g");
	var mask_graphics_44 = new cjs.Graphics().p("Ej58A2LMEWTiLIMDdmAoaIgmArMkYMCA2g");
	var mask_graphics_45 = new cjs.Graphics().p("Ej6zA2LMEXQiLIMDeXAoaIgmArMkZKCA1g");
	var mask_graphics_46 = new cjs.Graphics().p("Ej7eA2LMEYAiLIMDe9AoaIgmArMkZ7CA1g");
	var mask_graphics_47 = new cjs.Graphics().p("Ej79A2LMEYiiLIMDfZAoaIgmArMkadCA2g");
	var mask_graphics_48 = new cjs.Graphics().p("Ej8PA2LMEY2iLHMDfpAoZIgmArMkayCA1g");
	var mask_graphics_49 = new cjs.Graphics().p("Ej8WA2LMEY+iLIMDfvAoaIgnArMka4CA1g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(11).to({graphics:mask_graphics_11,x:-209.875,y:-108.725}).wait(1).to({graphics:mask_graphics_12,x:-176.9914,y:-89.0531}).wait(1).to({graphics:mask_graphics_13,x:-144.9846,y:-69.9057}).wait(1).to({graphics:mask_graphics_14,x:-113.8548,y:-51.283}).wait(1).to({graphics:mask_graphics_15,x:-83.6018,y:-33.1848}).wait(1).to({graphics:mask_graphics_16,x:-54.2258,y:-15.6113}).wait(1).to({graphics:mask_graphics_17,x:-25.7266,y:1.4377}).wait(1).to({graphics:mask_graphics_18,x:1.8956,y:17.9622}).wait(1).to({graphics:mask_graphics_19,x:28.641,y:33.962}).wait(1).to({graphics:mask_graphics_20,x:54.5094,y:49.4372}).wait(1).to({graphics:mask_graphics_21,x:79.501,y:64.3879}).wait(1).to({graphics:mask_graphics_22,x:103.6157,y:78.814}).wait(1).to({graphics:mask_graphics_23,x:126.8534,y:92.7154}).wait(1).to({graphics:mask_graphics_24,x:149.2143,y:106.0924}).wait(1).to({graphics:mask_graphics_25,x:170.6983,y:118.9447}).wait(1).to({graphics:mask_graphics_26,x:191.3054,y:131.2724}).wait(1).to({graphics:mask_graphics_27,x:211.0356,y:143.0756}).wait(1).to({graphics:mask_graphics_28,x:229.8888,y:154.3541}).wait(1).to({graphics:mask_graphics_29,x:247.8652,y:165.1081}).wait(1).to({graphics:mask_graphics_30,x:264.9647,y:175.3375}).wait(1).to({graphics:mask_graphics_31,x:281.1873,y:185.0423}).wait(1).to({graphics:mask_graphics_32,x:296.533,y:194.2225}).wait(1).to({graphics:mask_graphics_33,x:311.0018,y:202.8782}).wait(1).to({graphics:mask_graphics_34,x:324.5937,y:211.0093}).wait(1).to({graphics:mask_graphics_35,x:337.3087,y:218.6157}).wait(1).to({graphics:mask_graphics_36,x:349.1468,y:225.6976}).wait(1).to({graphics:mask_graphics_37,x:360.108,y:232.2549}).wait(1).to({graphics:mask_graphics_38,x:370.1923,y:238.2876}).wait(1).to({graphics:mask_graphics_39,x:379.3998,y:243.7958}).wait(1).to({graphics:mask_graphics_40,x:387.7303,y:248.7793}).wait(1).to({graphics:mask_graphics_41,x:395.1839,y:253.2383}).wait(1).to({graphics:mask_graphics_42,x:401.7606,y:257.1727}).wait(1).to({graphics:mask_graphics_43,x:407.4605,y:260.5825}).wait(1).to({graphics:mask_graphics_44,x:412.2834,y:263.4677}).wait(1).to({graphics:mask_graphics_45,x:416.2294,y:265.8283}).wait(1).to({graphics:mask_graphics_46,x:419.2986,y:267.6644}).wait(1).to({graphics:mask_graphics_47,x:421.4908,y:268.9758}).wait(1).to({graphics:mask_graphics_48,x:422.8062,y:269.7627}).wait(1).to({graphics:mask_graphics_49,x:423.2446,y:270.025}).wait(1).to({graphics:null,x:0,y:0}).wait(2));

	// Layer_2
	this.instance_2 = new lib.Bitmap5();
	this.instance_2.setTransform(22,156);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(11).to({_off:false},0).wait(41));

	// bg
	this.instance_3 = new lib.Symbol1("synched",0);
	this.instance_3.setTransform(432.1,418.25,1.8662,1.8662);
	this.instance_3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({alpha:1},11).wait(41));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(157.1,283.3,1837.4,318.99999999999994);
// library properties:
lib.properties = {
	id: 'ECDF1A6AC5E395468828BABD79B3D8C3',
	width: 977,
	height: 588,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Interface_atlas_1.png?1638118671378", id:"Interface_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['ECDF1A6AC5E395468828BABD79B3D8C3'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;