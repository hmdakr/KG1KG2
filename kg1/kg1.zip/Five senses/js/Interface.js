(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Interface_atlas_1", frames: [[0,919,220,54],[950,610,44,48],[856,610,63,44],[982,48,38,38],[222,919,174,68],[398,919,174,68],[574,919,174,68],[806,849,198,68],[750,919,174,68],[0,849,804,38],[0,610,854,47],[0,659,188,188],[0,0,980,608],[190,659,188,188],[380,659,188,188],[570,659,188,188],[760,659,188,188],[982,0,42,46]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Bitmap1 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap10 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap12 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap13 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap14 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap15 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap16 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap17 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap18 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap3 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap4 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap8 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap9 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.tounge01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap6();
	this.instance.setTransform(-92,-92);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-92,-92,188,188);


(lib.tounge_txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap16();
	this.instance.setTransform(-98,-33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-98,-33,198,68);


(lib.skin_txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap13();
	this.instance.setTransform(-85,-33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-85,-33,174,68);


(lib.right_wrong = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}
	this.frame_1 = function() {
		this.stop();
		this.blnPlay = false;
	}
	this.frame_2 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1));

	// Layer_3
	this.instance = new lib.Bitmap10();
	this.instance.setTransform(-25,-22);

	this.instance_1 = new lib.Bitmap11();
	this.instance_1.setTransform(-31,-26);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).wait(1));

	// Layer_1
	this.instance_2 = new lib.Bitmap9();
	this.instance_2.setTransform(-24,-21);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-26,63,52);


(lib.nose01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap8();
	this.instance.setTransform(-92,-92);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-92,-92,188,188);


(lib.nose_txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap15();
	this.instance.setTransform(-85,-33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-85,-33,174,68);


(lib.heading01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap2();
	this.instance.setTransform(-383,-26);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-383,-26,854,47);


(lib.heading_ = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap1();
	this.instance.setTransform(-147,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-147,-28,220,54);


(lib.hand01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap5();
	this.instance.setTransform(-92,-92);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-92,-92,188,188);


(lib.gh = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap4();
	this.instance.setTransform(-489,-302);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gh, new cjs.Rectangle(-489,-302,980,608), null);


(lib.eye01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap7();
	this.instance.setTransform(-92,-92);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-92,-92,188,188);


(lib.eye_txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap17();
	this.instance.setTransform(-85,-33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-85,-33,174,68);


(lib.ears_txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap14();
	this.instance.setTransform(-85,-33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-85,-33,174,68);


(lib.ear01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap3();
	this.instance.setTransform(-92,-92);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-92,-92,188,188);


(lib.btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("EgjAAHeIAAu7MBGBAAAIAAO7g");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-224.1,-47.8,448.2,95.6), null);


(lib.dotsP = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.3,0.0849,0.3978,0,0,0,0,0.7);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19,-19,38,38);


(lib.dots01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.3,0.0849,0.3978,0,0,0,0,0.7);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap12();
	this.instance.setTransform(-19,-19);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19,-19,38,38);


(lib.mcMain1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* function fMenuJumpFunction()
		{
			this.stop();
			this.blnPlay = false;
			var mc = new mcMenuSlide();
			this.addChild(mc);
		}*/
	}
	this.frame_1 = function() {
		/* this.blnPlay = true;
		
		*/
	}
	this.frame_128 = function() {
		this.stop();
		stage.enableMouseOver(10);
		this.blnPlay = false;
		var objRef  = this;
		var initFlag = true;
		var num = 1;
		var totalScene = 2;
		var __mcLine;
		this.blnPlay = false;
		var __nTotal = 0;
		var $strScene;
		var arrAnswerGiven  = new Array();
		var arrSceneAnswer  = new Array();
		var blnSubmit = false;
		var __objRef;
		var __mcCurrentMovieClip;
		var __nCountHit = 0;
		var n = 0;
		var __nScore = 0;
		var arrLines = new Array();
		var arrMc = new Array();
		var __nProgress = 0;
		this.init = function(nTotal) {
			__nTotal = nTotal;
			__objRef = objRef;
			blnSubmit = false;
			for (var i = 1; i <=__nTotal; i++) {		
				this["mc_" + i].btn.addEventListener("mousedown", this["mc_" + i].listener = this.fPressFunction.bind(this));
				this["mc_" + i].btn.cursor = "pointer";
				this["mc_" + i].id = i;
				this["mcH_" + i].id = i;
				this["mcH_"+i].nCorrectID = i;
				this["mc_" + i].__mcLine = new createjs.Shape();	
				this["mc_" + i].mc = this["mc_" + i];
				this["mc_" + i].xx = this["mc_" + i].x;
				this["mc_" + i].yy = this["mc_" + i].y;
				//this["mc_" + i]._mcLine = null;
				//this["mcH_"+i]._mcLine = null;
				this["mc_" + i].blnCorrect=false;		
			}
		}
		this.fPressFunction = function(evt) {	
			__mcCurrentMovieClip = evt.currentTarget.parent;	
			//__mcCurrentMovieClip.__mcLine = new createjs.Shape();
			stage.addEventListener("stagemousemove", this.stageMouseMove = this.fMouseMoveFunction.bind(this));
			stage.addEventListener("stagemouseup", this.stageMouseUp = this.fCheckHitTest.bind(this));	
			if (__mcCurrentMovieClip.__mcLine) {
				__mcCurrentMovieClip.__mcLine.graphics.clear();		
			}
			if (__mcCurrentMovieClip.mcDrop) {
				__mcCurrentMovieClip.mcDrop.__mcLine = null;
				__mcCurrentMovieClip.mcDrop.blnUsed = false;
			}
		}
		this.fMouseMoveFunction = function(evt)
		{
			this.pt = this.globalToLocal(stage.mouseX, stage.mouseY);	
		    __mcCurrentMovieClip.x = this.pt.x;
		    __mcCurrentMovieClip.y = this.pt.y;
			this.addChild(__mcCurrentMovieClip);
			this.fDraw();			
			stage.update();	
		}
		this.fCheckHitTest = function(evt) {	
			for (var i =1; i <=__nTotal; i++) {
				this.myDisplayObject = __objRef["mcH_"+i].btn;
				this.pt = this.myDisplayObject.globalToLocal(stage.mouseX, stage.mouseY);	
				if(this.myDisplayObject.hitTest(this.pt.x, this.pt.y) && !this.myDisplayObject.blnUsed){
				//if (__mcCurrentMovieClip.hitTest(__objRef["mcH_"+i]) && !__objRef["mcH_"+i].blnUsed) {
					if (__objRef["mcH_"+i]._mcLine) {
						__objRef["mcH_" + i]._mcLine.graphics.clear();
						__objRef["mcH_"+i].mcDrag.btn.mouseEnabled = true;
						__objRef["mcH_"+i].mcDrag.x = __objRef["mcH_"+i].mcDrag.xx;
						__objRef["mcH_"+i].mcDrag.y = __objRef["mcH_"+i].mcDrag.yy;
						__objRef["mcH_" + i].__mcLine = null;
						__objRef["mcH_"+i].mcDrag._mcLine = null;
						__objRef["mcH_"+i].mcDrag = null;
					}
					__objRef["mcH_"+i].blnUsed = true;
					__objRef["mcH_"+i].setID = __mcCurrentMovieClip.id;
					__mcCurrentMovieClip.x = __objRef["mcH_"+i].x;
					__mcCurrentMovieClip.y = __objRef["mcH_"+i].y;
				//Line making....
					__mcCurrentMovieClip.__mcLine.graphics.clear();
					__mcCurrentMovieClip.__mcLine.graphics.setStrokeStyle(4, 'round').beginStroke("#003399");
					__mcCurrentMovieClip.__mcLine.graphics.moveTo(__mcCurrentMovieClip.xx, __mcCurrentMovieClip.yy);
					__mcCurrentMovieClip.__mcLine.graphics.lineTo(__objRef["mcH_"+i].x, __objRef["mcH_"+i].y);
					__objRef.addChild(__mcCurrentMovieClip.__mcLine);
					
					//--------------------------			
					__objRef["mcH_"+i].mcDrag = __mcCurrentMovieClip;
					//__mcCurrentMovieClip._mcLine = __mcLine;
					__objRef["mcH_"+i].__mcLine = arrLines;
					__mcCurrentMovieClip.mcDrop = __objRef["mcH_"+i];
					arrLines[i-1] = __mcCurrentMovieClip.__mcLine;
					//__mcLine.graphics.endFill();
					//__objRef.addChild(__mcLine);
					__nCountHit++;
					n = i;
					
					for (var j =1; j <=__nTotal; j++) {
						//this["mc_" + j].btn.removeEventListener("mousedown", this["mc_" + j].listener, false);
						this["mc_" + j].btn.mouseEnabled = false;				
					}
					if (this["mcH_"+i].setID == this["mcH_"+i].id) {
						__mcCurrentMovieClip.btn.removeEventListener("mousedown", __mcCurrentMovieClip.listener, false);
						__mcCurrentMovieClip.btn.cursor = null;			
						//__objRef["mcTick_" + i].gotoAndStop(3);
						__objRef["mcTick_" + i].gotoAndStop(2);
						objRef["mc_" + i].blnCorrect = true;				
						//var mc2 = new right();
						//__objRef.addChild(mc2);
						//--------------------------
						this.nRandom = Math.floor(Math.random()*3);
						this.nRandom = this.nRandom + 1;	
						this.fbAudio = main.playAudio('right'+this.nRandom);
						this.fbAudio.addEventListener('complete', this.instAudEnt = function()
						{ 
							this.remove();
							this.fbAudio.removeEventListener('complete', this.instAudEnt);					
						}.bind(this));	
						//-----------
						__objRef["mcH_"+i].btn.mouseEnabled = false;
						if (!objRef["mc_" + __objRef["mcH_"+i].setID].blnFail) {
							__nScore++;					
						}
						__nProgress++;
					} else {
						__mcCurrentMovieClip.blnFail = true;
						this.fbAudio = main.playAudio('incorrect');
						this.fbAudio.addEventListener('complete', this.instAudEnt = function()
						{ 
							this.fRefresh();
							this.fbAudio.removeEventListener('complete', this.instAudEnt);					
						}.bind(this));				
						__objRef["mcTick_" + i].gotoAndStop(1);
					}
					stage.removeEventListener("stagemousemove", this.stageMouseMove, false);
					stage.removeEventListener("stagemouseup", this.stageMouseUp, false);
					return;
				}
			}
			__mcCurrentMovieClip.__mcLine.graphics.clear();
			__mcCurrentMovieClip.x = __mcCurrentMovieClip.xx;
			__mcCurrentMovieClip.y = __mcCurrentMovieClip.yy;
			stage.removeEventListener("stagemousemove", this.stageMouseMove, false);
			stage.removeEventListener("stagemouseup", this.stageMouseUp, false);
		}
		
		this.fDraw = function() {
			__mcCurrentMovieClip.__mcLine.graphics.clear();	
			__mcCurrentMovieClip.__mcLine.graphics.setStrokeStyle(4, 'round').beginStroke("#003399");
			__mcCurrentMovieClip.__mcLine.graphics.moveTo(__mcCurrentMovieClip.xx, __mcCurrentMovieClip.yy);
			__mcCurrentMovieClip.__mcLine.graphics.lineTo(__mcCurrentMovieClip.x, __mcCurrentMovieClip.y);		
			this.addChild(__mcCurrentMovieClip.__mcLine);
		}
		this.fRefresh = function(){
			__mcCurrentMovieClip.__mcLine.graphics.clear();
			__mcCurrentMovieClip.x = __mcCurrentMovieClip.xx;
			__mcCurrentMovieClip.y = __mcCurrentMovieClip.yy;	
			this["mcTick_" + n].gotoAndStop(0);
			this.remove();
		}
		this.remove = function(){
			for (var i =1; i <=__nTotal; i++) {
				if (!this["mc_" + i].blnCorrect) {			
					this["mcTick_" + i].gotoAndStop(0);
					this["mcH_"+i].setID = undefined;
					this["mcH_"+i].blnUsed = false;			
					//this["mc_" + i].btn.addEventListener("mousedown", __objRef["mc_" + i].listener = this.fPressFunction.bind(this));
					//this["mc_" + i].btn.cursor = "pointer";				
					this["mc_" + i].btn.mouseEnabled = true;
					this["mc_" + i]._mcLine = null;
					this["mcH_"+i]._mcLine = null;
				}
			}
			if (__nProgress > 4) {
				//MovieClip(parent.parent.parent).mcFinal.gotoAndPlay(2);
				this.fCalculateScore();
			}
		}
		this.fOver = function(event) {
			event.currentTarget.parent.gotoAndPlay("fr1");
		}
		this.fOut = function(event) {
			event.currentTarget.parent.gotoAndPlay("fr2");
		}
		this.init(5);
		
		this.fCalculateScore = function() {
			var nPercentage = (__nScore/5)*100;
			nPercentage = Math.ceil(nPercentage);
			main.showRestartBtn();
			//alert(nPercentage + "---------------------EndSlide");
			if (nPercentage < 70) {
				//MovieClip(parent.parent.parent).mcFinal.mcRank.gotoAndPlay("rank2");		
			} else {
				//MovieClip(parent.parent.parent).mcFinal.mcRank.gotoAndPlay("rank1_1");
			}
		}
		
		//https://github.com/hmdakr/Seasonal-Activities/blob/main/PrimerB/html/Primer_B_sem1_p_114/js/Activity.js
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(127).call(this.frame_128).wait(1));

	// mc
	this.mcTick_4 = new lib.right_wrong();
	this.mcTick_4.name = "mcTick_4";
	this.mcTick_4.setTransform(419.25,140.25,1.0032,1.0032);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(200.6,139.05,1.0032,1.0032);

	this.mcTick_5 = new lib.right_wrong();
	this.mcTick_5.name = "mcTick_5";
	this.mcTick_5.setTransform(12.65,139.05,1.0032,1.0032);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-159.35,139.05,1.0032,1.0032);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(-367.3,139.05,1.0032,1.0032);

	this.mcH_4 = new lib.dots01();
	this.mcH_4.name = "mcH_4";
	this.mcH_4.setTransform(381.5,181.55);

	this.mc_5 = new lib.dotsP();
	this.mc_5.name = "mc_5";
	this.mc_5.setTransform(381.5,20.75);

	this.mcH_3 = new lib.dots01();
	this.mcH_3.name = "mcH_3";
	this.mcH_3.setTransform(189.95,182.75);

	this.mc_4 = new lib.dotsP();
	this.mc_4.name = "mc_4";
	this.mc_4.setTransform(189.95,20.75);

	this.mcH_5 = new lib.dots01();
	this.mcH_5.name = "mcH_5";
	this.mcH_5.setTransform(-1.6,182.75);

	this.mc_3 = new lib.dotsP();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(-1.6,20.75);

	this.mcH_1 = new lib.dots01();
	this.mcH_1.name = "mcH_1";
	this.mcH_1.setTransform(-193.15,182.75);

	this.mc_2 = new lib.dotsP();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(-193.15,20.75);

	this.mcH_2 = new lib.dots01();
	this.mcH_2.name = "mcH_2";
	this.mcH_2.setTransform(-384.7,182.75);

	this.mc_1 = new lib.dotsP();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-384.7,20.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mcH_2},{t:this.mc_2},{t:this.mcH_1},{t:this.mc_3},{t:this.mcH_5},{t:this.mc_4},{t:this.mcH_3},{t:this.mc_5},{t:this.mcH_4},{t:this.mcTick_2},{t:this.mcTick_1},{t:this.mcTick_5},{t:this.mcTick_3},{t:this.mcTick_4}]},128).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap18();
	this.instance.setTransform(-404,2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(128).to({_off:false},0).wait(1));

	// HEADING
	this.instance_1 = new lib.heading_("synched",0);
	this.instance_1.setTransform(-672.85,-272.75);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4).to({_off:false},0).to({x:-342.85},11,cjs.Ease.get(1)).wait(114));

	// _
	this.instance_2 = new lib.dots01();
	this.instance_2.setTransform(381.5,20.75);

	this.instance_3 = new lib.dots01();
	this.instance_3.setTransform(189.95,20.75);

	this.instance_4 = new lib.dots01();
	this.instance_4.setTransform(-1.6,20.75);

	this.instance_5 = new lib.dots01();
	this.instance_5.setTransform(-193.15,20.75);

	this.instance_6 = new lib.dots01();
	this.instance_6.setTransform(-384.7,20.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]},128).wait(1));

	// heading01
	this.instance_7 = new lib.heading01("synched",0);
	this.instance_7.setTransform(877.45,-225.15);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(15).to({_off:false},0).to({x:-46.55},12,cjs.Ease.get(1)).to({x:-34.55},6,cjs.Ease.get(1)).wait(95).to({startPosition:0},0).wait(1));

	// dots01
	this.instance_8 = new lib.dots01("synched",0);
	this.instance_8.setTransform(381.5,181.6,2,2);
	this.instance_8.alpha = 0.0117;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(91).to({_off:false},0).to({scaleX:0.8,scaleY:0.8,y:181.55,alpha:1},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,mode:"independent"},5,cjs.Ease.get(1)).to({_off:true},24).wait(1));

	// dots01
	this.instance_9 = new lib.dots01("synched",0);
	this.instance_9.setTransform(381.5,20.8,2,2);
	this.instance_9.alpha = 0.0117;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(89).to({_off:false},0).to({scaleX:0.8,scaleY:0.8,y:20.75,alpha:1},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,mode:"independent"},5,cjs.Ease.get(1)).to({_off:true},26).wait(1));

	// dots01
	this.instance_10 = new lib.dots01("synched",0);
	this.instance_10.setTransform(190,182.8,2,2);
	this.instance_10.alpha = 0.0117;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(87).to({_off:false},0).to({scaleX:0.8,scaleY:0.8,x:189.95,y:182.75,alpha:1},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,mode:"independent"},5,cjs.Ease.get(1)).to({_off:true},28).wait(1));

	// dots01
	this.instance_11 = new lib.dots01("synched",0);
	this.instance_11.setTransform(190,20.8,2,2);
	this.instance_11.alpha = 0.0117;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(85).to({_off:false},0).to({scaleX:0.8,scaleY:0.8,x:189.95,y:20.75,alpha:1},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,mode:"independent"},5,cjs.Ease.get(1)).to({_off:true},30).wait(1));

	// dots01
	this.instance_12 = new lib.dots01("synched",0);
	this.instance_12.setTransform(-1.6,182.8,2,2);
	this.instance_12.alpha = 0.0117;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(83).to({_off:false},0).to({scaleX:0.8,scaleY:0.8,y:182.75,alpha:1},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,mode:"independent"},5,cjs.Ease.get(1)).to({_off:true},32).wait(1));

	// dots01
	this.instance_13 = new lib.dots01("synched",0);
	this.instance_13.setTransform(-1.6,20.8,2,2);
	this.instance_13.alpha = 0.0117;
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(81).to({_off:false},0).to({scaleX:0.8,scaleY:0.8,y:20.75,alpha:1},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,mode:"independent"},5,cjs.Ease.get(1)).to({_off:true},34).wait(1));

	// dots01
	this.instance_14 = new lib.dots01("synched",0);
	this.instance_14.setTransform(-193.1,182.8,2,2);
	this.instance_14.alpha = 0.0117;
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(79).to({_off:false},0).to({scaleX:0.8,scaleY:0.8,x:-193.15,y:182.75,alpha:1},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,mode:"independent"},5,cjs.Ease.get(1)).to({_off:true},36).wait(1));

	// dots01
	this.instance_15 = new lib.dots01("synched",0);
	this.instance_15.setTransform(-193.1,20.8,2.5,2.5);
	this.instance_15.alpha = 0.0117;
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(77).to({_off:false},0).to({scaleX:0.8,scaleY:0.8,x:-193.15,y:20.75,alpha:1},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,mode:"independent"},5,cjs.Ease.get(1)).to({_off:true},38).wait(1));

	// dots01
	this.instance_16 = new lib.dots01("synched",0);
	this.instance_16.setTransform(-384.7,182.8,2,2);
	this.instance_16.alpha = 0.0117;
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(75).to({_off:false},0).to({scaleX:0.8,scaleY:0.8,y:182.75,alpha:1},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,mode:"independent"},5,cjs.Ease.get(1)).to({_off:true},40).wait(1));

	// dots01
	this.instance_17 = new lib.dots01("synched",0);
	this.instance_17.setTransform(-384.7,20.75,2,2);
	this.instance_17.alpha = 0.0117;
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(73).to({_off:false},0).to({scaleX:0.8,scaleY:0.8,alpha:1},8,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,mode:"independent"},5,cjs.Ease.get(1)).to({_off:true},42).wait(1));

	// eye_txt
	this.instance_18 = new lib.eye_txt("synched",0);
	this.instance_18.setTransform(375.3,393.35);
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(43).to({_off:false},0).to({y:225.35},12,cjs.Ease.get(1)).to({y:237.35},6,cjs.Ease.get(1)).wait(67).to({startPosition:0},0).wait(1));

	// tounge_txt
	this.instance_19 = new lib.tounge_txt("synched",0);
	this.instance_19.setTransform(178.85,393.35);
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(40).to({_off:false},0).to({y:225.35},12,cjs.Ease.get(1)).to({y:237.35},6,cjs.Ease.get(1)).wait(70).to({startPosition:0},0).wait(1));

	// nose_txt
	this.instance_20 = new lib.nose_txt("synched",0);
	this.instance_20.setTransform(-17.6,393.35);
	this.instance_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(37).to({_off:false},0).to({y:225.35},12,cjs.Ease.get(1)).to({y:237.35},6,cjs.Ease.get(1)).wait(73).to({startPosition:0},0).wait(1));

	// ears_txt
	this.instance_21 = new lib.ears_txt("synched",0);
	this.instance_21.setTransform(-201.55,393.35);
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(34).to({_off:false},0).to({y:225.35},12,cjs.Ease.get(1)).to({y:237.35},6,cjs.Ease.get(1)).wait(76).to({startPosition:0},0).wait(1));

	// skin_txt
	this.instance_22 = new lib.skin_txt("synched",0);
	this.instance_22.setTransform(-385.5,393.35);
	this.instance_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(31).to({_off:false},0).to({y:225.35},12,cjs.Ease.get(1)).to({y:237.35},6,cjs.Ease.get(1)).wait(79).to({startPosition:0},0).wait(1));

	// nose01
	this.instance_23 = new lib.nose01("synched",0);
	this.instance_23.setTransform(381.5,-101.95,0.1,0.1);
	this.instance_23._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(43).to({_off:false},0).to({scaleX:1.1,scaleY:1.1},12,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},6,cjs.Ease.get(1)).wait(67).to({startPosition:0},0).wait(1));

	// eye01
	this.instance_24 = new lib.eye01("synched",0);
	this.instance_24.setTransform(189.95,-101.95,0.1,0.1);
	this.instance_24._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(40).to({_off:false},0).to({scaleX:1.1,scaleY:1.1},12,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},6,cjs.Ease.get(1)).wait(70).to({startPosition:0},0).wait(1));

	// tounge01
	this.instance_25 = new lib.tounge01("synched",0);
	this.instance_25.setTransform(-1.6,-101.95,0.1,0.1);
	this.instance_25._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(37).to({_off:false},0).to({scaleX:1.1,scaleY:1.1},12,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},6,cjs.Ease.get(1)).wait(73).to({startPosition:0},0).wait(1));

	// hand01
	this.instance_26 = new lib.hand01("synched",0);
	this.instance_26.setTransform(-193.15,-101.95,0.1,0.1);
	this.instance_26._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(34).to({_off:false},0).to({scaleX:1.1,scaleY:1.1},12,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},6,cjs.Ease.get(1)).wait(76).to({startPosition:0},0).wait(1));

	// ear01
	this.instance_27 = new lib.ear01("synched",0);
	this.instance_27.setTransform(-384.7,-101.95,0.1,0.1);
	this.instance_27._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(31).to({_off:false},0).to({scaleX:1.1,scaleY:1.1},12,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},6,cjs.Ease.get(1)).wait(79).to({startPosition:0},0).wait(1));

	// bg
	this.instance_28 = new lib.gh();
	this.instance_28.setTransform(3.4,4.1);
	this.instance_28.alpha = 0.0117;

	this.timeline.addTween(cjs.Tween.get(this.instance_28).to({alpha:1},10).wait(119));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-819.8,-300.7,2168.3,729.0999999999999);


// stage content:
(lib.Interface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
		stage.enableMouseOver(10); 
		//this.strFrame = "strFrame1"
		this.nF = 1;
		this.fLaunchProduct = function()
		{
			if(this.mcAttachMovieClip)
			{
				this.removeChild(this.mcAttachMovieClip);
			}
			this.mcAttachMovieClip = new lib["mcMain"+this.nF];
			this.mcAttachMovieClip.x = 488.1;
			this.mcAttachMovieClip.y = 295.05;	
			this.mcAttachMovieClip.gotoAndPlay(this.strFrame);
			this.addChild(this.mcAttachMovieClip);	
			if(this.nF == 1)
			{
				//this.play();
				this.fbAudio = main.playAudio('instruction');
			}
			this.nF = this.nF + 1;
		}
		//this.fLaunchProduct();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);
// library properties:
lib.properties = {
	id: 'ECDF1A6AC5E395468828BABD79B3D8C3',
	width: 977,
	height: 588,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Interface_atlas_1.png?1638118801095", id:"Interface_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['ECDF1A6AC5E395468828BABD79B3D8C3'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;