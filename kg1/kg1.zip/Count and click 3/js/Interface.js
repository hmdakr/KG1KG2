(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Interface_atlas_1", frames: [[0,0,977,605],[1175,126,112,117],[798,710,44,48],[684,775,63,44],[1175,0,124,124],[1289,126,112,117],[1301,0,112,117],[684,657,112,116],[0,895,112,116],[1159,245,112,117],[979,490,312,54],[1273,245,112,117],[114,895,112,116],[228,895,112,116],[1108,364,112,117],[1222,364,112,117],[0,657,112,117],[0,776,112,117],[979,0,194,194],[877,607,158,263],[114,657,112,117],[0,607,875,48],[114,776,112,117],[342,895,112,116],[456,895,112,116],[228,657,112,117],[228,776,112,117],[979,350,127,138],[342,657,112,117],[342,776,112,117],[570,895,112,116],[979,196,178,152],[798,872,112,116],[456,657,112,117],[456,776,112,117],[749,775,96,26],[798,657,46,51],[570,657,112,117],[570,776,112,117],[912,872,112,116],[1026,872,112,116],[684,872,112,117]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Bitmap1 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap10 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap12 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap13 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap14 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap15 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap16 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap17 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap18 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap19 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap20 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap21 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap22 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap23 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap24 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap25 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap26 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap27 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap28 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap29 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap3 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap31 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap32 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap33 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap34 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap35 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap36 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap37 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap38 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap39 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap4 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap40 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap41 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap42 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap43 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap44 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap8 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap9 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tree = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap28();
	this.instance.setTransform(-18,-30);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-18,-30,158,263);


(lib.text01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap3();
	this.instance.setTransform(-438,-24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-438,-24,875,48);


(lib.right_wrong = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// Layer_1
	this.instance = new lib.Bitmap44();
	this.instance.setTransform(-26,-24);

	this.instance_1 = new lib.Bitmap12();
	this.instance_1.setTransform(-25,-22);

	this.instance_2 = new lib.Bitmap13();
	this.instance_2.setTransform(-28,-22);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28,-24,63,51);


(lib.rat = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap4();
	this.instance.setTransform(-1,-1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,178,152);


(lib.heading_ = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap2();
	this.instance.setTransform(-147,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-147,-28,312,54);


(lib.gh = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap1();
	this.instance.setTransform(-492,-307);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gh, new cjs.Rectangle(-492,-307,977,605), null);


(lib.flower = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap14();
	this.instance.setTransform(-1,-1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,124,124);


(lib.btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("EgjAAHeIAAu7MBGBAAAIAAO7g");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-224.1,-47.8,448.2,95.6), null);


(lib.Ball = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap27();
	this.instance.setTransform(-97,-103);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.Bitmap43();
	this.instance_1.setTransform(-48,26);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-97,-103,194,194);


(lib.Apple = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap36();
	this.instance.setTransform(-22,-24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22,-24,127,138);


(lib.box3_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap34();
	this.instance.setTransform(-54,-61);

	this.instance_1 = new lib.Bitmap35();
	this.instance_1.setTransform(-54,-61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-61,114,117);


(lib.box3_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap41();
	this.instance.setTransform(-54,-61);

	this.instance_1 = new lib.Bitmap42();
	this.instance_1.setTransform(-54,-61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-61,114,117);


(lib.box3_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap23();
	this.instance.setTransform(-54,-61);

	this.instance_1 = new lib.Bitmap24();
	this.instance_1.setTransform(-54,-61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-61,114,117);


(lib.box3_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap19();
	this.instance.setTransform(-54,-61);

	this.instance_1 = new lib.Bitmap20();
	this.instance_1.setTransform(-54,-61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-61,114,117);


(lib.box3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap9();
	this.instance.setTransform(-54,-61);

	this.instance_1 = new lib.Bitmap10();
	this.instance_1.setTransform(-54,-61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-61,114,117);


(lib.box2_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap32();
	this.instance.setTransform(-54,-60);

	this.instance_1 = new lib.Bitmap33();
	this.instance_1.setTransform(-54,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-60,114,116);


(lib.box2_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap39();
	this.instance.setTransform(-54,-60);

	this.instance_1 = new lib.Bitmap40();
	this.instance_1.setTransform(-54,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-60,114,116);


(lib.box2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap21();
	this.instance.setTransform(-54,-60);

	this.instance_1 = new lib.Bitmap22();
	this.instance_1.setTransform(-54,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-60,114,116);


(lib.box2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap17();
	this.instance.setTransform(-54,-60);

	this.instance_1 = new lib.Bitmap18();
	this.instance_1.setTransform(-54,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-60,114,116);


(lib.box2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap7();
	this.instance.setTransform(-54,-60);

	this.instance_1 = new lib.Bitmap8();
	this.instance_1.setTransform(-54,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-60,114,116);


(lib.box_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap29();
	this.instance.setTransform(-54,-61);

	this.instance_1 = new lib.Bitmap31();
	this.instance_1.setTransform(-54,-61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-61,114,117);


(lib.box_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap37();
	this.instance.setTransform(-54,-61);

	this.instance_1 = new lib.Bitmap38();
	this.instance_1.setTransform(-54,-61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-61,114,117);


(lib.box_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap25();
	this.instance.setTransform(-54,-61);

	this.instance_1 = new lib.Bitmap26();
	this.instance_1.setTransform(-54,-61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-61,114,117);


(lib.box_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0,0.65,0.2498,1.0595,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap15();
	this.instance.setTransform(-54,-61);

	this.instance_1 = new lib.Bitmap16();
	this.instance_1.setTransform(-54,-61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-61,114,117);


(lib.box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(1.95,2.45,0.2498,1.1022,0,0,0,0,0.5);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap5();
	this.instance.setTransform(-54,-61);

	this.instance_1 = new lib.Bitmap6();
	this.instance_1.setTransform(-54,-61);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54,-61,112,117);


(lib.mcMain5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_106 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 3;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();
			//objRef.mcFish.gotoAndPlay(2);
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					//this.parent.fLaunchProduct();
					this.play();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				this.play();
				//this.parent.strFrame = "strFrame2";
				//this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}
	this.frame_107 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_134 = function() {
		/* stop();
		this.blnPlay = false;
		fCalculateScore();
		function fCalculateScore() {
			mcNext.mcBlinker.gotoAndStop(2);
			var nPercentage = (__nScore/5)*100;
			nPercentage = Math.ceil(nPercentage);
			trace(nPercentage + "---------------------");
			if (nPercentage < 70) {
				mcFinal.mcRank.gotoAndPlay("rank2");		
			} else {
				mcFinal.mcRank.gotoAndPlay("rank1_1");
			}
		}*/
		
		//alert("---EndFinal------");
		main.showRestartBtn();
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(106).call(this.frame_106).wait(1).call(this.frame_107).wait(27).call(this.frame_134).wait(1));

	// right_wrong_txt
	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-186.55,207.35,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(91.45,207.35,1.728,1.728);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(357.45,207.35,1.728,1.728);

	this.mc_3 = new lib.box3_4();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(247,208.65);

	this.mc_2 = new lib.box2_4();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(-18,208.65);

	this.mc_1 = new lib.box_4();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-293,208.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mcTick_3},{t:this.mcTick_2},{t:this.mcTick_1}]},106).wait(29));

	// box3
	this.instance = new lib.box3_4();
	this.instance.setTransform(1087,208.65);
	this.instance.shadow = new cjs.Shadow("#890A2E",0,0,0);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(83).to({_off:false},0).to({x:237},13,cjs.Ease.get(1)).to({x:247},5,cjs.Ease.get(1)).to({_off:true},5).wait(1).to({_off:false},0).wait(28));

	// box2
	this.instance_1 = new lib.box2_4();
	this.instance_1.setTransform(822,208.65);
	this.instance_1.shadow = new cjs.Shadow("#890A2E",0,0,0);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(80).to({_off:false},0).to({x:-28},13,cjs.Ease.get(1)).to({x:-18},5,cjs.Ease.get(1)).to({_off:true},8).wait(1).to({_off:false},0).wait(28));

	// box
	this.instance_2 = new lib.box_4();
	this.instance_2.setTransform(547,208.65);
	this.instance_2.shadow = new cjs.Shadow("#890A2E",0,0,0);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(77).to({_off:false},0).to({x:-303},13,cjs.Ease.get(1)).to({x:-293},5,cjs.Ease.get(1)).to({_off:true},11).wait(1).to({_off:false},0).wait(28));

	// Apple
	this.instance_3 = new lib.Apple("synched",0);
	this.instance_3.setTransform(-585.6,61.1,1,1,0,0,0,41.5,45.2);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(58).to({_off:false},0).to({x:334.4},13,cjs.Ease.get(1)).to({x:324.4},5,cjs.Ease.get(1)).wait(59));

	// Apple
	this.instance_4 = new lib.Apple("synched",0);
	this.instance_4.setTransform(-747.8,61.1,1,1,0,0,0,41.5,45.2);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(58).to({_off:false},0).to({x:172.2},13,cjs.Ease.get(1)).to({x:162.2},5,cjs.Ease.get(1)).wait(59));

	// Apple
	this.instance_5 = new lib.Apple("synched",0);
	this.instance_5.setTransform(-910,61.1,1,1,0,0,0,41.5,45.2);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(58).to({_off:false},0).to({x:10},13,cjs.Ease.get(1)).to({x:0},5,cjs.Ease.get(1)).wait(59));

	// Apple
	this.instance_6 = new lib.Apple("synched",0);
	this.instance_6.setTransform(-1072.2,61.1,1,1,0,0,0,41.5,45.2);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(58).to({_off:false},0).to({x:-152.2},13,cjs.Ease.get(1)).to({x:-162.2},5,cjs.Ease.get(1)).wait(59));

	// Apple
	this.instance_7 = new lib.Apple("synched",0);
	this.instance_7.setTransform(-1234.4,61.1,1,1,0,0,0,41.5,45.2);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(58).to({_off:false},0).to({x:-314.4},13,cjs.Ease.get(1)).to({x:-324.4},5,cjs.Ease.get(1)).wait(59));

	// Apple
	this.instance_8 = new lib.Apple("synched",0);
	this.instance_8.setTransform(1244.4,-110.4,1,1,0,0,0,41.5,45.2);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(53).to({_off:false},0).to({x:314.4},13,cjs.Ease.get(1)).to({x:324.4},5,cjs.Ease.get(1)).wait(64));

	// Apple
	this.instance_9 = new lib.Apple("synched",0);
	this.instance_9.setTransform(1082.2,-110.4,1,1,0,0,0,41.5,45.2);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(53).to({_off:false},0).to({x:152.2},13,cjs.Ease.get(1)).to({x:162.2},5,cjs.Ease.get(1)).wait(64));

	// Apple
	this.instance_10 = new lib.Apple("synched",0);
	this.instance_10.setTransform(920,-110.4,1,1,0,0,0,41.5,45.2);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(53).to({_off:false},0).to({x:-10},13,cjs.Ease.get(1)).to({x:0},5,cjs.Ease.get(1)).wait(64));

	// Apple
	this.instance_11 = new lib.Apple("synched",0);
	this.instance_11.setTransform(757.8,-110.4,1,1,0,0,0,41.5,45.2);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(53).to({_off:false},0).to({x:-172.2},13,cjs.Ease.get(1)).to({x:-162.2},5,cjs.Ease.get(1)).wait(64));

	// Apple
	this.instance_12 = new lib.Apple("synched",0);
	this.instance_12.setTransform(595.6,-110.4,1,1,0,0,0,41.5,45.2);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(53).to({_off:false},0).to({x:-334.4},13,cjs.Ease.get(1)).to({x:-324.4},5,cjs.Ease.get(1)).wait(64));

	// box3
	this.instance_13 = new lib.box3_5();
	this.instance_13.setTransform(247,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(26).to({x:257},5,cjs.Ease.get(1)).to({x:-623},10,cjs.Ease.get(1)).to({_off:true},1).wait(93));

	// box2
	this.instance_14 = new lib.box2_5();
	this.instance_14.setTransform(-18,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(24).to({x:-8},5,cjs.Ease.get(1)).to({x:-888},10,cjs.Ease.get(1)).to({_off:true},3).wait(93));

	// box
	this.instance_15 = new lib.box_5();
	this.instance_15.setTransform(-293,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(22).to({x:-283},5).to({x:-1163},10,cjs.Ease.get(1)).to({_off:true},5).wait(93));

	// Tree
	this.instance_16 = new lib.Tree("synched",0);
	this.instance_16.setTransform(335.5,-27.85,1,1,0,0,0,60.8,101);

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(18).to({startPosition:0},0).to({x:325.5},5,cjs.Ease.get(1)).to({x:1315.5},10,cjs.Ease.get(1)).to({_off:true},1).wait(101));

	// Tree
	this.instance_17 = new lib.Tree("synched",0);
	this.instance_17.setTransform(111.85,-27.85,1,1,0,0,0,60.8,101);

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(21).to({startPosition:0},0).to({x:101.85},5,cjs.Ease.get(1)).to({x:1091.85},10,cjs.Ease.get(1)).to({_off:true},1).wait(98));

	// Tree
	this.instance_18 = new lib.Tree("synched",0);
	this.instance_18.setTransform(-111.8,-27.85,1,1,0,0,0,60.8,101);

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(23).to({startPosition:0},0).to({x:-121.8},5,cjs.Ease.get(1)).to({x:868.2},10,cjs.Ease.get(1)).to({_off:true},1).wait(96));

	// Tree
	this.instance_19 = new lib.Tree("synched",0);
	this.instance_19.setTransform(-335.45,-27.85,1,1,0,0,0,60.8,101);

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(26).to({startPosition:0},0).to({x:-345.45},5,cjs.Ease.get(1)).to({x:644.55},10,cjs.Ease.get(1)).to({_off:true},1).wait(93));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1297.9,-179.6,2692.6000000000004,456.29999999999995);


(lib.mcMain4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_112 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 1;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();
			//objRef.mcFish.gotoAndPlay(2);
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(112).call(this.frame_112).wait(1));

	// right_wrong_txt
	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-186.55,207.35,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(91.45,207.35,1.728,1.728);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(357.45,207.35,1.728,1.728);

	this.mc_3 = new lib.box3_5();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(247,208.65);

	this.mc_2 = new lib.box2_5();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(-18,208.65);

	this.mc_1 = new lib.box_5();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-293,208.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mcTick_3},{t:this.mcTick_2},{t:this.mcTick_1}]},112).wait(1));

	// box3
	this.instance = new lib.box3_5();
	this.instance.setTransform(1087,208.65);
	this.instance.shadow = new cjs.Shadow("#890A2E",0,0,0);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(82).to({_off:false},0).to({x:237},13,cjs.Ease.get(1)).to({x:247},5,cjs.Ease.get(1)).to({_off:true},12).wait(1));

	// box2
	this.instance_1 = new lib.box2_5();
	this.instance_1.setTransform(822,208.65);
	this.instance_1.shadow = new cjs.Shadow("#890A2E",0,0,0);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(79).to({_off:false},0).to({x:-28},13,cjs.Ease.get(1)).to({x:-18},5,cjs.Ease.get(1)).to({_off:true},15).wait(1));

	// box
	this.instance_2 = new lib.box_5();
	this.instance_2.setTransform(547,208.65);
	this.instance_2.shadow = new cjs.Shadow("#890A2E",0,0,0);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(76).to({_off:false},0).to({x:-303},13,cjs.Ease.get(1)).to({x:-293},5,cjs.Ease.get(1)).to({_off:true},18).wait(1));

	// Tree
	this.instance_3 = new lib.Tree("synched",0);
	this.instance_3.setTransform(-762.5,-27.85,1,1,0,0,0,60.8,101);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(48).to({_off:false},0).to({x:345.5},12,cjs.Ease.get(1)).to({x:335.5},6,cjs.Ease.get(1)).wait(47));

	// Tree
	this.instance_4 = new lib.Tree("synched",0);
	this.instance_4.setTransform(-986.15,-27.85,1,1,0,0,0,60.8,101);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(51).to({_off:false},0).to({x:121.85},12,cjs.Ease.get(1)).to({x:111.85},6,cjs.Ease.get(1)).wait(44));

	// Tree
	this.instance_5 = new lib.Tree("synched",0);
	this.instance_5.setTransform(-1209.8,-27.85,1,1,0,0,0,60.8,101);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(54).to({_off:false},0).to({x:-101.8},12,cjs.Ease.get(1)).to({x:-111.8},6,cjs.Ease.get(1)).wait(41));

	// Tree
	this.instance_6 = new lib.Tree("synched",0);
	this.instance_6.setTransform(-1433.45,-27.85,1,1,0,0,0,60.8,101);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(58).to({_off:false},0).to({x:-325.45},12,cjs.Ease.get(1)).to({x:-335.45},6,cjs.Ease.get(1)).wait(37));

	// box3
	this.instance_7 = new lib.box3_3();
	this.instance_7.setTransform(247,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(20).to({x:257},5,cjs.Ease.get(1)).to({x:-553},10,cjs.Ease.get(1)).to({_off:true},1).wait(77));

	// box2
	this.instance_8 = new lib.box2_3();
	this.instance_8.setTransform(-18,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(18).to({x:-8},5,cjs.Ease.get(1)).to({x:-818},10,cjs.Ease.get(1)).to({_off:true},1).wait(79));

	// box
	this.instance_9 = new lib.box_3();
	this.instance_9.setTransform(-293,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(16).to({x:-283},5,cjs.Ease.get(1)).to({x:-1093},10,cjs.Ease.get(1)).to({_off:true},1).wait(81));

	// Ball
	this.instance_10 = new lib.Ball("synched",0);
	this.instance_10.setTransform(-355.3,-12.7,0.7167,0.7167,0,0,0,0,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(21).to({startPosition:0},0).to({x:-365.3},4,cjs.Ease.get(1)).to({x:651.2},10,cjs.Ease.get(1)).to({_off:true},1).wait(77));

	// Ball
	this.instance_11 = new lib.Ball("synched",0);
	this.instance_11.setTransform(-177.65,-12.7,0.7167,0.7167,0,0,0,0,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(19).to({startPosition:0},0).to({x:-187.65},4,cjs.Ease.get(1)).to({x:828.85},10,cjs.Ease.get(1)).to({_off:true},1).wait(79));

	// Ball
	this.instance_12 = new lib.Ball("synched",0);
	this.instance_12.setTransform(0,-12.7,0.7167,0.7167,0,0,0,0,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(17).to({startPosition:0},0).to({x:-10},4,cjs.Ease.get(1)).to({x:1006.5},10,cjs.Ease.get(1)).to({_off:true},1).wait(81));

	// Ball
	this.instance_13 = new lib.Ball("synched",0);
	this.instance_13.setTransform(177.65,-12.7,0.7167,0.7167,0,0,0,0,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(15).to({startPosition:0},0).to({x:167.65},4,cjs.Ease.get(1)).to({x:1184.15},10,cjs.Ease.get(1)).to({_off:true},1).wait(83));

	// Ball
	this.instance_14 = new lib.Ball("synched",0);
	this.instance_14.setTransform(355.3,-12.7,0.7167,0.7167,0,0,0,0,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(13).to({startPosition:0},0).to({x:345.3},4,cjs.Ease.get(1)).to({x:1361.8},10,cjs.Ease.get(1)).to({_off:true},1).wait(85));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1512.2,-158.8,2943.5,435.5);


(lib.mcMain3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_114 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 2;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();
			//objRef.mcFish.gotoAndPlay(2);
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(114).call(this.frame_114).wait(1));

	// right_wrong_txt
	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-186.55,207.35,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(91.45,207.35,1.728,1.728);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(357.45,207.35,1.728,1.728);

	this.mc_3 = new lib.box3_3();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(247,208.65);

	this.mc_2 = new lib.box2_3();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(-18,208.65);

	this.mc_1 = new lib.box_3();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-293,208.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mcTick_3},{t:this.mcTick_2},{t:this.mcTick_1}]},114).wait(1));

	// box3
	this.instance = new lib.box3_3();
	this.instance.setTransform(1087,208.65);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(87).to({_off:false},0).to({x:237},13,cjs.Ease.get(1)).to({x:247},5,cjs.Ease.get(1)).to({_off:true},9).wait(1));

	// box2
	this.instance_1 = new lib.box2_3();
	this.instance_1.setTransform(822,208.65);
	this.instance_1.shadow = new cjs.Shadow("#890A2E",0,0,0);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(84).to({_off:false},0).to({x:-28},13,cjs.Ease.get(1)).to({x:-18},5,cjs.Ease.get(1)).to({_off:true},12).wait(1));

	// box
	this.instance_2 = new lib.box_3();
	this.instance_2.setTransform(547,208.65);
	this.instance_2.shadow = new cjs.Shadow("#890A2E",0,0,0);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(81).to({_off:false},0).to({x:-303},13,cjs.Ease.get(1)).to({x:-293},5,cjs.Ease.get(1)).to({_off:true},15).wait(1));

	// Ball
	this.instance_3 = new lib.Ball("synched",0);
	this.instance_3.setTransform(-1457.3,-12.7,0.7167,0.7167,0,0,0,0,-0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(67).to({_off:false},0).to({x:-345.3},11,cjs.Ease.get(1)).to({x:-355.3},5).wait(32));

	// Ball
	this.instance_4 = new lib.Ball("synched",0);
	this.instance_4.setTransform(-1279.65,-12.7,0.7167,0.7167,0,0,0,0,-0.1);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(64).to({_off:false},0).to({x:-167.65},11,cjs.Ease.get(1)).to({x:-177.65},5,cjs.Ease.get(1)).wait(35));

	// Ball
	this.instance_5 = new lib.Ball("synched",0);
	this.instance_5.setTransform(-1102,-12.7,0.7167,0.7167,0,0,0,0,-0.1);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(61).to({_off:false},0).to({x:10},11,cjs.Ease.get(1)).to({x:0},5,cjs.Ease.get(1)).wait(38));

	// Ball
	this.instance_6 = new lib.Ball("synched",0);
	this.instance_6.setTransform(-924.35,-12.7,0.7167,0.7167,0,0,0,0,-0.1);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(58).to({_off:false},0).to({x:187.65},11,cjs.Ease.get(1)).to({x:177.65},5,cjs.Ease.get(1)).wait(41));

	// Ball
	this.instance_7 = new lib.Ball("synched",0);
	this.instance_7.setTransform(-746.7,-12.7,0.7167,0.7167,0,0,0,0,-0.1);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(55).to({_off:false},0).to({x:365.3},11,cjs.Ease.get(1)).to({x:355.3},5,cjs.Ease.get(1)).wait(44));

	// box3
	this.instance_8 = new lib.box3_2();
	this.instance_8.setTransform(247,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(27).to({x:257},5,cjs.Ease.get(1)).to({x:-553},10,cjs.Ease.get(1)).to({_off:true},1).wait(72));

	// box2
	this.instance_9 = new lib.box2_2();
	this.instance_9.setTransform(-18,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(25).to({x:-8},5,cjs.Ease.get(1)).to({x:-818},10,cjs.Ease.get(1)).to({_off:true},1).wait(74));

	// box
	this.instance_10 = new lib.box_2();
	this.instance_10.setTransform(-293,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(23).to({x:-283},5,cjs.Ease.get(1)).to({x:-1093},10,cjs.Ease.get(1)).to({_off:true},1).wait(76));

	// flower
	this.instance_11 = new lib.flower("synched",0);
	this.instance_11.setTransform(-263,56.6,1,1,0,0,0,60.8,61.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(24).to({startPosition:0},0).to({x:-273},4,cjs.Ease.get(1)).to({x:617},10,cjs.Ease.get(1)).to({_off:true},1).wait(76));

	// flower
	this.instance_12 = new lib.flower("synched",0);
	this.instance_12.setTransform(-87.65,56.6,1,1,0,0,0,60.8,61.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(22).to({startPosition:0},0).to({x:-97.65},4,cjs.Ease.get(1)).to({x:792.35},10,cjs.Ease.get(1)).to({_off:true},1).wait(78));

	// flower
	this.instance_13 = new lib.flower("synched",0);
	this.instance_13.setTransform(87.7,56.6,1,1,0,0,0,60.8,61.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(20).to({startPosition:0},0).to({x:77.7},4,cjs.Ease.get(1)).to({x:967.7},10,cjs.Ease.get(1)).to({_off:true},1).wait(80));

	// flower
	this.instance_14 = new lib.flower("synched",0);
	this.instance_14.setTransform(263.05,56.6,1,1,0,0,0,60.8,61.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(18).to({startPosition:0},0).to({x:253.05},4,cjs.Ease.get(1)).to({x:1143.05},10,cjs.Ease.get(1)).to({_off:true},1).wait(82));

	// flower
	this.instance_15 = new lib.flower("synched",0);
	this.instance_15.setTransform(350.7,-89.8,1,1,0,0,0,60.8,61.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(26).to({startPosition:0},0).to({x:360.7},4,cjs.Ease.get(1)).to({x:-599.3},10,cjs.Ease.get(1)).to({_off:true},1).wait(74));

	// flower
	this.instance_16 = new lib.flower("synched",0);
	this.instance_16.setTransform(175.35,-89.8,1,1,0,0,0,60.8,61.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(24).to({startPosition:0},0).to({x:185.35},4,cjs.Ease.get(1)).to({x:-774.65},10,cjs.Ease.get(1)).to({_off:true},1).wait(76));

	// flower
	this.instance_17 = new lib.flower("synched",0);
	this.instance_17.setTransform(0,-89.8,1,1,0,0,0,60.8,61.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(22).to({startPosition:0},0).to({x:10},4,cjs.Ease.get(1)).to({x:-950},10,cjs.Ease.get(1)).to({_off:true},1).wait(78));

	// flower
	this.instance_18 = new lib.flower("synched",0);
	this.instance_18.setTransform(-175.35,-89.8,1,1,0,0,0,60.8,61.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(20).to({startPosition:0},0).to({x:-165.35},4,cjs.Ease.get(1)).to({x:-1125.35},10,cjs.Ease.get(1)).to({_off:true},1).wait(80));

	// flower
	this.instance_19 = new lib.flower("synched",0);
	this.instance_19.setTransform(-350.7,-89.8,1,1,0,0,0,60.8,61.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(16).to({startPosition:0},0).to({x:-340.7},4,cjs.Ease.get(1)).to({x:-1300.7},10,cjs.Ease.get(1)).to({_off:true},1).wait(84));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1526.8,-151.9,2732.1,428.6);


(lib.mcMain2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_98 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 1;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();
			//objRef.mcFish.gotoAndPlay(2);
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(98).call(this.frame_98).wait(1));

	// right_wrong_txt
	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-186.55,207.35,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(91.45,207.35,1.728,1.728);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(357.45,207.35,1.728,1.728);

	this.mc_3 = new lib.box3_2();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(247,208.65);

	this.mc_2 = new lib.box2_2();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(-18,208.65);

	this.mc_1 = new lib.box_2();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-293,208.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mcTick_3},{t:this.mcTick_2},{t:this.mcTick_1}]},98).wait(1));

	// box3
	this.instance = new lib.box3_2();
	this.instance.setTransform(1087,208.65);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(74).to({_off:false},0).to({x:237},13,cjs.Ease.get(1)).to({x:247},5,cjs.Ease.get(1)).to({_off:true},6).wait(1));

	// box2
	this.instance_1 = new lib.box2_2();
	this.instance_1.setTransform(822,208.65);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(71).to({_off:false},0).to({x:-28},13,cjs.Ease.get(1)).to({x:-18},5,cjs.Ease.get(1)).to({_off:true},9).wait(1));

	// box
	this.instance_2 = new lib.box_2();
	this.instance_2.setTransform(547,208.65);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(68).to({_off:false},0).to({x:-303},13,cjs.Ease.get(1)).to({x:-293},5,cjs.Ease.get(1)).to({_off:true},12).wait(1));

	// flower
	this.instance_3 = new lib.flower("synched",0);
	this.instance_3.setTransform(-1123,56.6,1,1,0,0,0,60.8,61.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(52).to({_off:false},0).to({x:-253},13,cjs.Ease.get(1)).to({x:-263},6,cjs.Ease.get(1)).wait(28));

	// flower
	this.instance_4 = new lib.flower("synched",0);
	this.instance_4.setTransform(-947.65,56.6,1,1,0,0,0,60.8,61.1);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(50).to({_off:false},0).to({x:-77.65},13,cjs.Ease.get(1)).to({x:-87.65},6,cjs.Ease.get(1)).wait(30));

	// flower
	this.instance_5 = new lib.flower("synched",0);
	this.instance_5.setTransform(-772.3,56.6,1,1,0,0,0,60.8,61.1);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(48).to({_off:false},0).to({x:97.7},13,cjs.Ease.get(1)).to({x:87.7},6,cjs.Ease.get(1)).wait(32));

	// flower
	this.instance_6 = new lib.flower("synched",0);
	this.instance_6.setTransform(-596.95,56.6,1,1,0,0,0,60.8,61.1);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(45).to({_off:false},0).to({x:273.05},13,cjs.Ease.get(1)).to({x:263.05},6,cjs.Ease.get(1)).wait(35));

	// flower
	this.instance_7 = new lib.flower("synched",0);
	this.instance_7.setTransform(1357.2,-89.8,1,1,0,0,0,60.8,61.1);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(54).to({_off:false},0).to({x:340.7},13,cjs.Ease.get(1)).to({x:350.7},6,cjs.Ease.get(1)).wait(26));

	// flower
	this.instance_8 = new lib.flower("synched",0);
	this.instance_8.setTransform(1181.85,-89.8,1,1,0,0,0,60.8,61.1);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(52).to({_off:false},0).to({x:165.35},13,cjs.Ease.get(1)).to({x:175.35},6,cjs.Ease.get(1)).wait(28));

	// flower
	this.instance_9 = new lib.flower("synched",0);
	this.instance_9.setTransform(1006.5,-89.8,1,1,0,0,0,60.8,61.1);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(50).to({_off:false},0).to({x:-10},13,cjs.Ease.get(1)).to({x:0},6,cjs.Ease.get(1)).wait(30));

	// flower
	this.instance_10 = new lib.flower("synched",0);
	this.instance_10.setTransform(831.15,-89.8,1,1,0,0,0,60.8,61.1);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(48).to({_off:false},0).to({x:-185.35},13,cjs.Ease.get(1)).to({x:-175.35},6,cjs.Ease.get(1)).wait(32));

	// flower
	this.instance_11 = new lib.flower("synched",0);
	this.instance_11.setTransform(655.8,-89.8,1,1,0,0,0,60.8,61.1);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(46).to({_off:false},0).to({x:-360.7},13,cjs.Ease.get(1)).to({x:-350.7},6,cjs.Ease.get(1)).wait(34));

	// box3
	this.instance_12 = new lib.box3();
	this.instance_12.setTransform(247,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(21).to({x:257},5,cjs.Ease.get(1)).to({x:-553},10,cjs.Ease.get(1)).to({_off:true},1).wait(62));

	// box2
	this.instance_13 = new lib.box2();
	this.instance_13.setTransform(-18,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(19).to({x:-8},5,cjs.Ease.get(1)).to({x:-818},10,cjs.Ease.get(1)).to({_off:true},1).wait(64));

	// box
	this.instance_14 = new lib.box();
	this.instance_14.setTransform(-293,208.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(17).to({x:-283},5,cjs.Ease.get(1)).to({x:-1093},10,cjs.Ease.get(1)).to({_off:true},1).wait(66));

	// rat
	this.instance_15 = new lib.rat("synched",0);
	this.instance_15.setTransform(-209.4,70.1,1,1,0,0,0,88,74.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(23).to({startPosition:0},0).to({x:-219.4},5,cjs.Ease.get(1)).to({x:746.1},10,cjs.Ease.get(1)).to({_off:true},1).wait(60));

	// rat
	this.instance_16 = new lib.rat("synched",0);
	this.instance_16.setTransform(5.35,70.1,1,1,0,0,0,88,74.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(21).to({startPosition:0},0).to({x:-4.65},5,cjs.Ease.get(1)).to({x:960.85},10,cjs.Ease.get(1)).to({_off:true},1).wait(62));

	// rat
	this.instance_17 = new lib.rat("synched",0);
	this.instance_17.setTransform(220.1,70.1,1,1,0,0,0,88,74.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(19).to({startPosition:0},0).to({x:210.1},5,cjs.Ease.get(1)).to({x:1175.6},10,cjs.Ease.get(1)).to({_off:true},1).wait(64));

	// rat
	this.instance_18 = new lib.rat("synched",0);
	this.instance_18.setTransform(-316.75,-94.05,1,1,0,0,0,88,74.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(17).to({startPosition:0},0).to({x:-326.75},5,cjs.Ease.get(1)).to({x:638.75},10,cjs.Ease.get(1)).to({_off:true},1).wait(66));

	// rat
	this.instance_19 = new lib.rat("synched",0);
	this.instance_19.setTransform(-102,-94.05,1,1,0,0,0,88,74.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(15).to({startPosition:0},0).to({x:-112},5,cjs.Ease.get(1)).to({x:853.5},10,cjs.Ease.get(1)).to({_off:true},1).wait(68));

	// rat
	this.instance_20 = new lib.rat("synched",0);
	this.instance_20.setTransform(112.75,-94.05,1,1,0,0,0,88,74.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(13).to({startPosition:0},0).to({x:102.75},5,cjs.Ease.get(1)).to({x:1068.25},10,cjs.Ease.get(1)).to({_off:true},1).wait(70));

	// rat
	this.instance_21 = new lib.rat("synched",0);
	this.instance_21.setTransform(327.5,-94.05,1,1,0,0,0,88,74.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(11).to({startPosition:0},0).to({x:317.5},5,cjs.Ease.get(1)).to({x:1283},10,cjs.Ease.get(1)).to({_off:true},1).wait(72));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1184.8,-169.9,2604.2,446.6);


(lib.mcMain1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;
		var objRef = this;
		var __nCorrectAnswer = 0;
		var blnLastQuestion = false;
		var __nScore = 0;
		var blnEnd = false;
		function init() {
			for (var i:Number = 1; objRef["mc_"+i] != null; i++) {
				objRef["mc_"+i].id = i;
				objRef["mc_" + i].addEventListener(MouseEvent.CLICK, fClickEvent);
				objRef["mc_"+i].buttonMode = true;
			}
		}
		
		function fClickEvent(e) {
			mcFish.gotoAndPlay(2);
			fRemoveListeners();
			if (e.currentTarget.id == __nCorrectAnswer) {
						e.currentTarget.gotoAndStop(2);
				__nScore++;
				//setTimeout(fChangeQuestion, 3000);
				var mcRight = new Right();
				objRef.addChild(mcRight);
				objRef["mcTick_" + e.currentTarget.id].gotoAndStop(3);
				return;
			}
			//setTimeout(fChangeQuestion, 5000);
			var mcWrong = new ShowAnswer();
			objRef.addChild(mcWrong);
			objRef["mcTick_" + e.currentTarget.id].gotoAndStop(2);
		}
		function fShowCorrectAnswer() {
			objRef["mc_"+__nCorrectAnswer].gotoAndStop(2);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(3);
		}
		function fChangeQuestion() {
			fRemoveListeners();
			play();
		}
		function fRemoveListeners() {
			for (var i:Number = 1; objRef["mc_"+i] != null; i++) {
				objRef["mc_" + i].removeEventListener(MouseEvent.CLICK, fClickEvent);
				objRef["mc_"+i].buttonMode = false;
				if (!blnEnd) {
					objRef["mc_" + i].gotoAndStop(1);
				}
			}
		}*/
	}
	this.frame_143 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 3;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();
			//objRef.mcFish.gotoAndPlay(2);
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(143).call(this.frame_143).wait(1));

	// right_wrong_txt
	this.mc_3 = new lib.box3();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(247,208.65);

	this.mc_2 = new lib.box2();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(-18,208.65);

	this.mc_1 = new lib.box();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-293,208.65);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-186.55,207.35,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(91.45,207.35,1.728,1.728);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(357.45,207.35,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_3},{t:this.mcTick_2},{t:this.mcTick_1},{t:this.mc_1},{t:this.mc_2},{t:this.mc_3}]},143).wait(1));

	// HEADING
	this.instance = new lib.heading_("synched",0);
	this.instance.setTransform(-662.85,-272.75);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(6).to({_off:false},0).to({x:-342.85},11,cjs.Ease.get(1)).wait(127));

	// box3
	this.instance_1 = new lib.box3();
	this.instance_1.setTransform(1087,208.65);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(52).to({_off:false},0).to({x:237},13,cjs.Ease.get(1)).to({x:247},5,cjs.Ease.get(1)).to({_off:true},73).wait(1));

	// box2
	this.instance_2 = new lib.box2();
	this.instance_2.setTransform(822,208.65);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(49).to({_off:false},0).to({x:-28},13,cjs.Ease.get(1)).to({x:-18},5,cjs.Ease.get(1)).to({_off:true},76).wait(1));

	// box
	this.instance_3 = new lib.box();
	this.instance_3.setTransform(547,208.65);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(46).to({_off:false},0).to({x:-303},13,cjs.Ease.get(1)).to({x:-293},5,cjs.Ease.get(1)).to({_off:true},79).wait(1));

	// rat
	this.instance_4 = new lib.rat("synched",0);
	this.instance_4.setTransform(-1139.4,70.1,1,1,0,0,0,88,74.9);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(34).to({_off:false},0).to({x:-199.4},11).to({x:-209.4},6).wait(93));

	// rat
	this.instance_5 = new lib.rat("synched",0);
	this.instance_5.setTransform(-924.65,70.1,1,1,0,0,0,88,74.9);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(32).to({_off:false},0).to({x:15.35},11).to({x:5.35},6).wait(95));

	// rat
	this.instance_6 = new lib.rat("synched",0);
	this.instance_6.setTransform(-709.9,70.1,1,1,0,0,0,88,74.9);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(30).to({_off:false},0).to({x:230.1},11).to({x:220.1},6).wait(97));

	// rat
	this.instance_7 = new lib.rat("synched",0);
	this.instance_7.setTransform(-1246.75,-94.05,1,1,0,0,0,88,74.9);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(34).to({_off:false},0).to({x:-306.75},11).to({x:-316.75},6).wait(93));

	// rat
	this.instance_8 = new lib.rat("synched",0);
	this.instance_8.setTransform(-1032,-94.05,1,1,0,0,0,88,74.9);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(32).to({_off:false},0).to({x:-92},11).to({x:-102},6).wait(95));

	// rat
	this.instance_9 = new lib.rat("synched",0);
	this.instance_9.setTransform(-817.25,-94.05,1,1,0,0,0,88,74.9);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(30).to({_off:false},0).to({x:122.75},11).to({x:112.75},6).wait(97));

	// rat
	this.instance_10 = new lib.rat("synched",0);
	this.instance_10.setTransform(-602.5,-94.05,1,1,0,0,0,88,74.9);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(28).to({_off:false},0).to({x:337.5},11).to({x:327.5},6).wait(99));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1335.7,-300.7,2480.7,565.4);


// stage content:
(lib.Interface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,31];
	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		stage.enableMouseOver(10); 
		//this.strFrame = "strFrame1"
		this.nF = 1;
		this.fLaunchProduct = function()
		{
			if(this.mcAttachMovieClip)
			{
				this.removeChild(this.mcAttachMovieClip);
			}
			this.mcAttachMovieClip = new lib["mcMain"+this.nF];
			this.mcAttachMovieClip.x = 488.1;
			this.mcAttachMovieClip.y = 295.05;	
			this.mcAttachMovieClip.gotoAndPlay(this.strFrame);
			this.addChild(this.mcAttachMovieClip);	
			if(this.nF == 1)
			{
				this.play();
				this.fbAudio = main.playAudio('instruction');
			}
			this.nF = this.nF + 1;
		}
		//this.fLaunchProduct();
	}
	this.frame_31 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(31).call(this.frame_31).wait(1));

	// HEADING
	this.instance = new lib.heading_("synched",0);
	this.instance.setTransform(-174.35,21.25);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(6).to({_off:false},0).to({x:145.65},11,cjs.Ease.get(1)).wait(15));

	// Layer_1
	this.instance_1 = new lib.text01("synched",0);
	this.instance_1.setTransform(1422.5,70.05);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(11).to({_off:false},0).to({x:456.5},10,cjs.Ease.get(1)).to({x:476.5},5).wait(6));

	// bg
	this.instance_2 = new lib.gh();
	this.instance_2.setTransform(491.9,298.1);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({alpha:1},11).wait(21));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(167.1,285.1,1692.4,311);
// library properties:
lib.properties = {
	id: 'ECDF1A6AC5E395468828BABD79B3D8C3',
	width: 977,
	height: 588,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Interface_atlas_1.png?1638118734825", id:"Interface_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['ECDF1A6AC5E395468828BABD79B3D8C3'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;