(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Interface_atlas_1", frames: [[1853,1367,155,173],[2026,303,18,24],[0,1178,497,497],[1119,1454,116,118],[1351,1178,522,84],[0,0,1969,1176],[1646,1732,395,54],[1971,929,38,53],[1971,866,63,61],[1971,475,70,109],[946,1758,95,90],[1875,1178,144,187],[355,1677,111,155],[1370,1732,274,137],[868,1758,76,123],[251,1677,102,182],[1131,1178,218,274],[1971,586,67,70],[750,1662,116,197],[1971,0,73,301],[1971,303,53,170],[1237,1454,108,107],[868,1178,261,266],[499,1178,367,482],[1351,1264,249,154],[1872,1542,149,163],[1971,658,67,70],[1602,1264,249,154],[1351,1420,249,154],[1602,1420,249,154],[868,1446,249,154],[1971,730,67,70],[1119,1576,249,154],[1370,1576,249,154],[1621,1576,249,154],[868,1602,249,154],[499,1662,249,154],[0,1677,249,154],[1119,1732,249,154],[2011,929,35,55],[1971,984,35,55],[1971,802,73,62]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_263 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_262 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_261 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_260 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_259 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_258 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap10 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap12 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap13 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap14 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap15 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap16 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap17 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap18 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap19 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap20 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap21 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap22 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap24 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap28 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap29 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap3 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap30 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap31 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap32 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap33 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap34 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap35 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap36 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap37 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap38 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap39 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap4 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap40 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap8 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap9 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.vbvbv = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap17();
	this.instance.setTransform(-38,-62);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-38,-62,76,123);


(lib.vbncvbnv = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap16();
	this.instance.setTransform(-137,-69);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-137,-69,274,137);


(lib.vbcbcbcv = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap22();
	this.instance.setTransform(-26,-85);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-85,53,170);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_263();
	this.instance.setTransform(-22.45,-25,0.2894,0.2894);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.4,-25,44.8,50.1);


(lib.orDange = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap28();
	this.instance.setTransform(-124,-161);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-124,-161,261,266);


(lib.numbring01_2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap31();
	this.instance.setTransform(-34,-35);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34,-35,67,70);


(lib.numbring01_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap36();
	this.instance.setTransform(-34,-35);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34,-35,67,70);


(lib.numbring01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap2();
	this.instance.setTransform(-34,-35);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34,-35,67,70);


(lib.ncvvbcvb = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap21();
	this.instance.setTransform(-36,-150);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36,-150,73,301);


(lib.lioneye = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(0.3,1,1).p("ABIAAQAAApgVAcQgVAdgeAAQgdAAgVgdQgVgcAAgpQAAgoAVgcQAVgdAdAAQAeAAAVAdQAVAcAAAog");
	this.shape.setTransform(0,-9.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(70));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgxBFQgWgcABgpQgBgnAWgdQAUgdAdAAQAeAAAUAdQAWAdgBAnQABApgWAcQgUAcgeABQgdgBgUgcg");
	mask.setTransform(0,-9.75);

	// Layer_5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#333333").ss(0.3,1,1).p("AB2AkQh6hPhxBPIAAhHIDrAAg");
	this.shape_1.setTransform(0.95,-20.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EFAD00").s().p("Ah1AkIAAhHIDrAAIAABHQh6hPhxBPg");
	this.shape_2.setTransform(0.95,-20.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#333333").ss(0.3,1,1).p("Ah1gvIDrAAIAABfQh6grhxArg");
	this.shape_3.setTransform(0.95,-18.85);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#EFAD00").s().p("Ah1AwIAAhfIDrAAIAABfQh6grhxArg");
	this.shape_4.setTransform(0.95,-18.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#333333").ss(0.3,1,1).p("Ah1g7IDrAAIAAB3Qh6gGhxAGg");
	this.shape_5.setTransform(0.95,-17.425);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#EFAD00").s().p("Ah1A8IAAh3IDrAAIAAB3Qh5gGhyAGg");
	this.shape_6.setTransform(0.95,-17.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#333333").ss(0.3,1,1).p("Ah1hPIDrAAIAACQQh6Afhxgfg");
	this.shape_7.setTransform(0.95,-15.2125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EFAD00").s().p("Ah1BBIAAiQIDrAAIAACQQg9APg6AAQg7AAg5gPg");
	this.shape_8.setTransform(0.95,-15.2125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#333333").ss(0.3,1,1).p("Ah1hlIDrAAIAACpQh5BEhyhEg");
	this.shape_9.setTransform(0.95,-12.8625);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#EFAD00").s().p("Ah1BEIAAipIDrAAIAACpQg9Aig6AAQg7AAg5gig");
	this.shape_10.setTransform(0.95,-12.8625);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#333333").ss(0.3,1,1).p("AB2BNQh5ByhyhyIAAjSIDrAAg");
	this.shape_11.setTransform(0.95,-10.5089,1,0.9238);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#EFAD00").s().p("Ah1BNIAAjSIDrAAIAADSQg9A5g6AAQg7AAg5g5g");
	this.shape_12.setTransform(0.95,-10.5089,1,0.9238);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},14).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},2).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).to({state:[]},1).wait(43));

	// Layer_1
	this.instance = new lib.CachedBmp_262();
	this.instance.setTransform(-5.35,-12.65,0.4899,0.4899);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(70));

	// Layer_2
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgxBFQgWgcABgpQgBgnAWgdQAUgdAdAAQAeAAAUAdQAWAdgBAnQABApgWAcQgUAcgeABQgdgBgUgcg");
	this.shape_13.setTransform(0,-9.75);

	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(70));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.1,-20.5,16.299999999999997,21.5);


(lib.iceDCream = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.Bitmap29();
	this.instance.setTransform(-289,-200);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.iceDCream, new cjs.Rectangle(-289,-200,367,482), null);


(lib.heading_txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF7B24").s().p("Aq2C7IAAAAQhFhKAAhwQAAhsBDhMQAKgMALgKIACgBIAAgBQBAg4BaAAQB1AABDBHIAAABQALAOgBAJQABAIgbAvIAAAAQgZAvgIAFIABgCQgHAHgJAAQgGADgVgVIgBAAQgRgPgQgHIAAAAQgXgNgZAAQgrAAgZAgQgYAfgBAtQAAAtAZAfQAZAgArAAQAaAAAYgLIAAAAIACgBIACgBQANgHAOgMIAAAAIAAAAQAWgUAFADQAKgCAIAMQAIAJAWAhQAdAugCAFQACAJgMAOIAAAAQhDBQhuAAQhwAAhGhNgApfDXQAqATA1AAIAHAAIABAAIgBgDIgJheQgWgBgTgIgAnkCHIAJBdIAAADIABAAQAogGAggVIAAgBIgyhNQgQAGgQADgAqlCaIgFACIAJAKIAAABQASATAVAOIA2hXQgLgIgJgLIgEgFgAmqBwIAwBJQALgJAJgLIAAAAIAEgEIgXgiIgZgkIgFAHIgBAAIgSAOgAq7CEIAAAAIACgBIBOhFQgHgRgDgTIgFABIhiAAQAFA7AcAugArdgCIBjAAIADABQABgSADgQIhiggQgIAfAAAigAqiijQgbAfgOAkIBgAgQAGgNAIgMIg8hUIgJAKgAnEh/IAAABIAFADIABAAQAUAJAUASIAAAAIAGAIQAHgKAQgeIAAAAQAVgjABgFIgDgEQghgjgwgPgAqCjBIA6BRQALgKAOgGIAAgCIgOhhQgmAKgfAYgAnhiIIANhdQgXgEgcAAIgZABIAOBfQAKgCAMAAIAAAAQAOAAANADgACnCtQgwgxgBhLQABhIAvgzQAxg1BLAAQBTAAAuAwQAFAFAAAEQAAAFgSAdQgRAdgFAEQgBAAAAABQgBAAAAAAQgBAAAAABQgBAAgBAAQgBAAgLgKQgOgMgNgGQgVgKgVAAQglAAgWAbQgVAXAAAkQAAAkAVAZQAWAbAlAAQAWAAAUgJQANgGANgLQALgJACAAQADAAACADQAEAEASAZQASAbAAADQABAEgGAGQguA0hOAAQhPAAgxgzgAiFDbIg5gBIhMgBIgEAAIgcgBQgHgBgBgHIABhOIABhOIgChSIgBhTQgBgFAJAAIAWAAIAHABIAQAAIAYgBIAZgBQAEAAAAAFIAAADQgEAtgDBZIAAA/IAAAtIAAAGQAAABAAAAQAAABABAAQAAABABAAQABAAAAAAIAHAAIBFgCQAtgCAWAAQAIAAgBAFQAAApgGAeQgBAGgEABIgKABIg5gBgAKdDYQgHgBgCgCIgGgHIgkhAQgegzgGgGQgcAKAAAEIACA2IABA2QABAIgIABQgNACgjAAQggAAgLgCQgHgCAAgGQAAgaADg0QACg0AAgaQAAgcgCg2IgDhUQABgFAEAAIAZABIAXABIAYgBIAYgBQAEAAAAAEQABASgDAkIgCA1QAAAUAMAAQAeAAARgPQANgLAMgfQAIgXATgtQADgGAIAAIAUABIAUABIAUgBIAUAAQAHAAAAAFQAAAIgLAfQgfBZgpAXQgIAEAAADIAuBIQAvBIAAANQAAALgKADQgHACggAAQggAAgOgCgAgTDYQgIgCAAgGIACgqQAFhhAAgeIgBhMQgDgzAAgaQAAgFAGAAIAXABIAXABIAYgBIAXgBQAHAAAAAFQAAAagDAzQgCAyAAAaIABBVIABBVQAAAFgBABIgIABQgQACgcAAQgkAAgJgCg");
	this.shape.setTransform(-154.2,-4.075);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.instance = new lib.CachedBmp_260();
	this.instance.setTransform(-73.05,-29,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_259();
	this.instance_1.setTransform(-13.1,-15.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-230.6,-30.5,478.5,60.5);


(lib.heading_ = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap1();
	this.instance.setTransform(-147,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-147,-28,395,54);


(lib.fgneye = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#766D03").ss(0.5,1,1).p("AAigiQAPAPAAATQAAAUgPAOQgOAPgUAAQgTAAgPgPQgOgOAAgUQAAgTAOgPQAPgOATAAQAUAAAOAOg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(89));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AghAiQgOgOgBgUQABgTAOgOQAOgOATgBQAUABAOAOQAPAOAAATQAAAUgPAOQgOAPgUAAQgTAAgOgPg");

	// Layer_5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#766D03").ss(0.5,1,1).p("AhAAmIAAhLICBAAIAABLQg8h6hFB6g");
	this.shape_1.setTransform(-0.0896,-3.3,1.1945,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DFCF06").s().p("AhAAmIAAhLICBAAIAABLQg8h6hFB6g");
	this.shape_2.setTransform(-0.0896,-3.3,1.1945,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#766D03").ss(0.5,1,1).p("AhMglICZAAIAABLQhHhUhSBUg");
	this.shape_3.setTransform(-0.075,-3.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#DFCF06").s().p("AhMAmIAAhLICZAAIAABLQhHhUhSBUg");
	this.shape_4.setTransform(-0.075,-3.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#766D03").ss(0.5,1,1).p("AhMglICZAAIAABLQhIgvhRAvg");
	this.shape_5.setTransform(-0.075,-3.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#DFCF06").s().p("AhMAmIAAhLICZAAIAABLQhIgvhRAvg");
	this.shape_6.setTransform(-0.075,-3.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#766D03").ss(0.5,1,1).p("AhMglICZAAIAABLQhIgKhRAKg");
	this.shape_7.setTransform(-0.075,-3.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#DFCF06").s().p("AhMAmIAAhLICZAAIAABLQhIgKhRAKg");
	this.shape_8.setTransform(-0.075,-3.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#766D03").ss(0.5,1,1).p("AhMgsICZAAIAABLQhIAchRgcg");
	this.shape_9.setTransform(-0.075,-2.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#DFCF06").s().p("AhMAfIAAhLICZAAIAABLQgkAOgmAAQgmAAgpgOg");
	this.shape_10.setTransform(-0.075,-2.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#766D03").ss(0.5,1,1).p("AhMg1ICZAAIAABLQhIBBhRhBg");
	this.shape_11.setTransform(-0.075,-1.6625);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#DFCF06").s().p("AhMAWIAAhLICZAAIAABLQgkAggnAAQglAAgpggg");
	this.shape_12.setTransform(-0.075,-1.6625);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#766D03").ss(0.5,1,1).p("AhAAMIAAhLICBAAIAABLQg9BohEhog");
	this.shape_13.setTransform(-0.0896,-0.7137,1.1945,1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#DFCF06").s().p("AhAAMIAAhLICBAAIAABLQgfA0ggAAQgfAAgjg0g");
	this.shape_14.setTransform(-0.0896,-0.7137,1.1945,1);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},18).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},4).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).wait(55));

	// Layer_2
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgKALQgEgFAAgGQAAgFAEgEQAFgFAFAAQAGAAAEAFQAFAEAAAFQAAAGgFAFQgEAEgGAAQgFAAgFgEg");
	this.shape_15.setTransform(-0.4384,0.9736,0.7192,0.7192);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgXAYQgKgKAAgOQAAgNAKgKQAKgKANAAQAOAAAKAKQAKAKAAANQAAAOgKAKQgKAKgOAAQgNAAgKgKg");
	this.shape_16.setTransform(1.4474,1.6855,0.7571,0.7571);

	var maskedShapeInstanceList = [this.shape_15,this.shape_16];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15}]}).wait(89));

	// Layer_3
	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AghAiQgOgOgBgUQABgTAOgOQAOgOATgBQAUABAOAOQAPAOAAATQAAAUgPAOQgOAPgUAAQgTAAgOgPg");

	this.timeline.addTween(cjs.Tween.get(this.shape_17).wait(89));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.8,-5.8,11.7,11.7);


(lib.f_eyec = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#455900").ss(0.5,1,1).p("AB9iWQAzA/AABXQAABYgzA/Qg0A+hJAAQhIAAg0g+Qgzg/AAhYQAAhXAzg/QA0g+BIAAQBJAAA0A+g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(82));

	// Layer_5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah7CWQg0g+AAhYQAAhXA0g+QAzg/BIAAQBJAAAzA/QA0A+AABXQAABYg0A+QgzA/hJAAQhIAAgzg/g");

	// Layer_6
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#455900").ss(0.5,1,1).p("AjYCJIAAkRIGxAAIAAERQjHn8jqH8g");
	this.shape_1.setTransform(-0.3172,-12.0178,1.0182,1.1377);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#779807").s().p("AjYCJIAAkRIGxAAIAAERQjHn8jqH8g");
	this.shape_2.setTransform(-0.3172,-12.0178,1.0182,1.1377);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#455900").ss(0.5,1,1).p("AjcibIG5AAIAAE3QjMmcjtGcg");
	this.shape_3.setTransform(-0.3,-12.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#779807").s().p("AjbCcIAAk3IG4AAIAAE3QjMmcjsGcg");
	this.shape_4.setTransform(-0.3,-12.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#455900").ss(0.5,1,1).p("AjcibIG5AAIAAE3QjNj2jsD2g");
	this.shape_5.setTransform(-0.3,-12.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#779807").s().p("AjbCcIAAk3IG4AAIAAE3QjNj2jrD2g");
	this.shape_6.setTransform(-0.3,-12.025);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#455900").ss(0.5,1,1).p("AjcibIG5AAIAAE3QjOhRjrBRg");
	this.shape_7.setTransform(-0.3,-12.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#779807").s().p("AjbCcIAAk3IG4AAIAAE3QjPhRjpBRg");
	this.shape_8.setTransform(-0.3,-12.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#455900").ss(0.5,1,1).p("AjciwIG5AAIAAE3QjQBVjphVg");
	this.shape_9.setTransform(-0.3,-9.9125);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#779807").s().p("AjbCHIAAk3IG4AAIAAE3QhoAqhvAAQhtAAh0gqg");
	this.shape_10.setTransform(-0.3,-9.9125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#455900").ss(0.5,1,1).p("AjcjaIG5AAIAAE4QjRD6joj6g");
	this.shape_11.setTransform(-0.3,-5.7625);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#779807").s().p("AjbBeIAAk4IG4AAIAAE4QhpB9huAAQhtAAh0h9g");
	this.shape_12.setTransform(-0.3,-5.7625);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#455900").ss(0.5,1,1).p("AjYAuIAAkSIGxAAIAAESQjPFujilug");
	this.shape_13.setTransform(-0.3172,-1.6073,1.0182,1.1377);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#779807").s().p("AjYAuIAAkSIGxAAIAAESQhoC3hsAAQhrAAhyi3g");
	this.shape_14.setTransform(-0.3172,-1.6073,1.0182,1.1377);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},19).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},4).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).wait(47));

	// Layer_3
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgYAeQgKgNAAgRQAAgQAKgNQAKgMAOAAQAPAAAKAMQAKANAAAQQAAARgKANQgKAMgPAAQgOAAgKgMg");
	this.shape_15.setTransform(-4.6,-0.325);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("Ag8BJQgYgfAAgqQAAgqAYgeQAZgeAjAAQAjAAAaAeQAZAeAAAqQAAAqgZAfQgaAegjAAQgjAAgZgeg");
	this.shape_16.setTransform(1.15,3.1);

	var maskedShapeInstanceList = [this.shape_15,this.shape_16];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15}]}).wait(82));

	// Layer_4
	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FEBF3C").s().p("Ah7CWQg0g+AAhYQAAhXA0g+QAzg/BIAAQBJAAAzA/QA0A+AABXQAABYg0A+QgzA/hJAAQhIAAgzg/g");

	this.timeline.addTween(cjs.Tween.get(this.shape_17).wait(82));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-18.6,-22.3,37.2,44.6);


(lib.eye2_bug = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(0.5,1,1).p("AAmgpQAPARAAAYQAAAZgPARQgQARgWAAQgVAAgQgRQgPgRAAgZQAAgYAPgRQAQgRAVAAQAWAAAQARg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(60));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AglApQgPgQAAgZQAAgXAPgSQAQgRAVAAQAWAAAQARQAPASAAAXQAAAZgPAQQgQASgWAAQgVAAgQgSg");

	// Layer_6
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#333333").ss(0.5,1,1).p("ABwAtQh7iEhkCEIAAhZIDfAAg");
	this.shape_1.setTransform(-1.1542,-4.2284,0.9986,0.9986,-22.7509);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#515151").s().p("AhvAtIAAhZIDfAAIAABZQh7iEhkCEg");
	this.shape_2.setTransform(-1.1542,-4.2284,0.9986,0.9986,-22.7509);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4ACIDOhWIAjBTQicg5gyCPg");
	this.shape_3.setTransform(-1.15,-4.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#515151").s().p("Ah4ACIDOhWIAiBTQibg5gyCPg");
	this.shape_4.setTransform(-1.15,-4.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4ACIDOhWIAjBTQiTgog7B+g");
	this.shape_5.setTransform(-1.15,-4.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#515151").s().p("Ah4ACIDOhWIAiBTQiSgog7B+g");
	this.shape_6.setTransform(-1.15,-4.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4ACIDOhWIAjBTQiKgXhEBtg");
	this.shape_7.setTransform(-1.15,-4.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#515151").s().p("Ah4ACIDOhWIAiBTQiJgXhEBtg");
	this.shape_8.setTransform(-1.15,-4.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4ACIDOhWIAjBTQiBgHhNBdg");
	this.shape_9.setTransform(-1.15,-4.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#515151").s().p("Ah4ACIDOhWIAiBTQiAgHhNBdg");
	this.shape_10.setTransform(-1.15,-4.225);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4ACIDOhWIAjBTQh5AJhVBNg");
	this.shape_11.setTransform(-1.15,-4.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#515151").s().p("Ah4ACIDOhWIAiBTQh4AJhVBNg");
	this.shape_12.setTransform(-1.15,-4.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4ACIDOhWIAjBTQhxAahdA8g");
	this.shape_13.setTransform(-1.15,-4.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#515151").s().p("Ah4ACIDOhWIAiBTQhvAaheA8g");
	this.shape_14.setTransform(-1.15,-4.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#333333").ss(0.5,1,1).p("ABwAtIjfAAIAAhZIDfAAg");
	this.shape_15.setTransform(-1.1542,-4.2284,0.9986,0.9986,-22.7509);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#515151").s().p("AhvAtIAAhZIDfAAIAABZg");
	this.shape_16.setTransform(-1.1542,-4.2284,0.9986,0.9986,-22.7509);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4ACIDOhWIAjBTIjOBWg");
	this.shape_17.setTransform(-1.15,-4.225);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#515151").s().p("Ah4ACIDOhWIAiBTIjNBWg");
	this.shape_18.setTransform(-1.15,-4.225);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},14).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_16},{t:this.shape_15}]},1).to({state:[{t:this.shape_18},{t:this.shape_17}]},1).to({state:[{t:this.shape_18},{t:this.shape_17}]},1).to({state:[{t:this.shape_16},{t:this.shape_15}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).wait(29));

	// Layer_5
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#333333").ss(0.5,1,1).p("ABwAtIjfAAIAAhZQBvB7Bwh7g");
	this.shape_19.setTransform(2.2458,4.1716,0.9986,0.9986,-22.7509);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#515151").s().p("AhvAtIAAhZQBvB7Bwh7IAABZg");
	this.shape_20.setTransform(2.2458,4.1716,0.9986,0.9986,-22.7509);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4ACQCPA2A/iMIAjBTIjOBWg");
	this.shape_21.setTransform(2.25,4.175);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#515151").s().p("Ah4ACQCQA2A+iMIAjBTIjOBWg");
	this.shape_22.setTransform(2.25,4.175);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4ACQCJAmBFh8IAjBTIjOBWg");
	this.shape_23.setTransform(2.25,4.175);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#515151").s().p("Ah4ACQCJAmBFh8IAjBTIjOBWg");
	this.shape_24.setTransform(2.25,4.175);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4ACQCCAWBMhsIAjBTIjOBWg");
	this.shape_25.setTransform(2.25,4.175);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#515151").s().p("Ah4ACQCCAWBMhsIAjBTIjOBWg");
	this.shape_26.setTransform(2.25,4.175);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4ACQB8AFBShbIAjBTIjOBWg");
	this.shape_27.setTransform(2.25,4.175);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#515151").s().p("Ah4ACQB7AFBThbIAjBTIjOBWg");
	this.shape_28.setTransform(2.25,4.175);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4ACQB1gKBZhMIAjBTIjOBWg");
	this.shape_29.setTransform(2.25,4.175);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#515151").s().p("Ah4ACQB2gKBYhMIAjBTIjOBWg");
	this.shape_30.setTransform(2.25,4.175);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4ACQBvgaBfg8IAjBTIjOBWg");
	this.shape_31.setTransform(2.25,4.175);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#515151").s().p("Ah4ACQBvgaBfg8IAjBTIjOBWg");
	this.shape_32.setTransform(2.25,4.175);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#333333").ss(0.5,1,1).p("ABwAtIjfAAIAAhZIDfAAg");
	this.shape_33.setTransform(2.2458,4.1716,0.9986,0.9986,-22.7509);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#515151").s().p("AhvAtIAAhZIDfAAIAABZg");
	this.shape_34.setTransform(2.2458,4.1716,0.9986,0.9986,-22.7509);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4ACIDOhWIAjBTIjOBWg");
	this.shape_35.setTransform(2.25,4.175);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#515151").s().p("Ah4ACIDOhWIAjBTIjOBWg");
	this.shape_36.setTransform(2.25,4.175);

	var maskedShapeInstanceList = [this.shape_19,this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29,this.shape_30,this.shape_31,this.shape_32,this.shape_33,this.shape_34,this.shape_35,this.shape_36];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19}]}).to({state:[{t:this.shape_20},{t:this.shape_19}]},14).to({state:[{t:this.shape_22},{t:this.shape_21}]},1).to({state:[{t:this.shape_24},{t:this.shape_23}]},1).to({state:[{t:this.shape_26},{t:this.shape_25}]},1).to({state:[{t:this.shape_28},{t:this.shape_27}]},1).to({state:[{t:this.shape_30},{t:this.shape_29}]},1).to({state:[{t:this.shape_32},{t:this.shape_31}]},1).to({state:[{t:this.shape_34},{t:this.shape_33}]},1).to({state:[{t:this.shape_36},{t:this.shape_35}]},1).to({state:[{t:this.shape_36},{t:this.shape_35}]},1).to({state:[{t:this.shape_34},{t:this.shape_33}]},1).to({state:[{t:this.shape_32},{t:this.shape_31}]},1).to({state:[{t:this.shape_30},{t:this.shape_29}]},1).to({state:[{t:this.shape_28},{t:this.shape_27}]},1).to({state:[{t:this.shape_26},{t:this.shape_25}]},1).to({state:[{t:this.shape_24},{t:this.shape_23}]},1).to({state:[{t:this.shape_22},{t:this.shape_21}]},1).to({state:[{t:this.shape_20},{t:this.shape_19}]},1).wait(29));

	// Layer_2
	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgIAJQgEgDAAgGQAAgEAEgEQAEgEAEAAQAGAAADAEQAEAEAAAEQAAAGgEADQgDAEgGAAQgEAAgEgEg");
	this.shape_37.setTransform(1.4408,-3.2074,0.656,0.656);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#090909").s().p("AgVAXQgIgKAAgNQAAgNAIgJQAKgKALAAQANAAAIAKQAJAJAAANQAAANgJAKQgIAJgNAAQgLAAgKgJg");
	this.shape_38.setTransform(-0.5548,-2.6326,0.656,0.656);

	var maskedShapeInstanceList = [this.shape_37,this.shape_38];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_38},{t:this.shape_37}]}).wait(60));

	// Layer_1
	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AglApQgPgQAAgZQAAgXAPgSQAQgRAVAAQAWAAAQARQAPASAAAXQAAAZgPAQQgQASgWAAQgVAAgQgSg");

	this.timeline.addTween(cjs.Tween.get(this.shape_39).wait(60));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6.3,-6.9,12.6,13.8);


(lib.eye_bug = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(0.5,1,1).p("AAKA6QgHABgHABQgaAAgTgPQgPgMgBgUQAAgFABgHQAEgbARgQQAAgBABgBQAQgPAWgGQAWgHAUAUQAUATABAdQAAATgJAPQAHgCAJgBAADBEQADgGAEgEQAQgVAYgH");
	this.shape.setTransform(0.0167,0.0093);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(60));

	// Layer_5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AguAxQgOgMgBgUIAAgMQAEgbARgQIACgCQAQgPAWgGQAVgHAUAUQAUATABAdQABATgKAPQgXAHgRAVIgNACQgbAAgTgPg");
	mask.setTransform(-0.3321,-0.3907);

	// Layer_2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#333333").ss(0.5,1,1).p("ABoAsQhwh6hfB6IAAhXIDPAAg");
	this.shape_1.setTransform(-3.0275,-4.4067,0.9991,0.9991,-37.497);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#515151").s().p("AhnAsIAAhXIDPAAIAABXQhwh6hfB6g");
	this.shape_2.setTransform(-3.0275,-4.4067,0.9991,0.9991,-37.497);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#333333").ss(0.5,1,1).p("AhtAdIClh/IA2BHQiXgRgOCPg");
	this.shape_3.setTransform(-3.025,-4.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#515151").s().p("AhtAdIClh+IA2BFQiXgRgOCQg");
	this.shape_4.setTransform(-3.025,-4.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#333333").ss(0.5,1,1).p("AhtAdIClh/IA2BHQiKgGgbCEg");
	this.shape_5.setTransform(-3.025,-4.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#515151").s().p("AhtAdIClh+IA2BFQiKgFgbCEg");
	this.shape_6.setTransform(-3.025,-4.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#333333").ss(0.5,1,1).p("AhtAdIClh/IA2BHQh9AFgoB5g");
	this.shape_7.setTransform(-3.025,-4.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#515151").s().p("AhtAdIClh+IA2BFQh9AGgoB5g");
	this.shape_8.setTransform(-3.025,-4.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#333333").ss(0.5,1,1).p("AhtAdIClh/IA2BHQhvARg2Btg");
	this.shape_9.setTransform(-3.025,-4.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#515151").s().p("AhtAdIClh+IA2BFQhvARg2Bug");
	this.shape_10.setTransform(-3.025,-4.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#333333").ss(0.5,1,1).p("AhtAdIClh/IA2BHQhjAbhCBjg");
	this.shape_11.setTransform(-3.025,-4.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#515151").s().p("AhtAdIClh+IA2BFQhjAchCBjg");
	this.shape_12.setTransform(-3.025,-4.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#333333").ss(0.5,1,1).p("AhtAdIClh/IA2BHQhWAmhPBYg");
	this.shape_13.setTransform(-3.025,-4.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#515151").s().p("AhtAdIClh+IA2BFQhWAnhPBYg");
	this.shape_14.setTransform(-3.025,-4.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#333333").ss(0.5,1,1).p("ABoAsQhYgDh3ADIAAhXIDPAAg");
	this.shape_15.setTransform(-3.0275,-4.4067,0.9991,0.9991,-37.497);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#515151").s().p("AhnAsIAAhXIDPAAIAABXQhYgDh3ADg");
	this.shape_16.setTransform(-3.0275,-4.4067,0.9991,0.9991,-37.497);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#333333").ss(0.5,1,1).p("AhtAdIClh/IA2BHQhJAyhcBMg");
	this.shape_17.setTransform(-3.025,-4.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#515151").s().p("AhtAdIClh+IA2BFQhJAyhcBNg");
	this.shape_18.setTransform(-3.025,-4.4);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},14).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_16},{t:this.shape_15}]},1).to({state:[{t:this.shape_18},{t:this.shape_17}]},1).to({state:[{t:this.shape_18},{t:this.shape_17}]},1).to({state:[{t:this.shape_16},{t:this.shape_15}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).wait(29));

	// Layer_6
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#333333").ss(0.5,1,1).p("ABoAsQhYgDh3ADIAAhXQBdCTByiTg");
	this.shape_19.setTransform(2.323,2.5439,0.9989,0.9989,-37.4972);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#515151").s().p("AhnAsIAAhXQBdCTByiTIAABXQhYgDh3ADg");
	this.shape_20.setTransform(2.323,2.5439,0.9989,0.9989,-37.4972);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#333333").ss(0.5,1,1).p("AhtAdQCYAqANipIA2BGQhJAyhcBNg");
	this.shape_21.setTransform(2.325,2.55);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#515151").s().p("AhtAdQCYAqANioIA2BGQhJAxhcBNg");
	this.shape_22.setTransform(2.325,2.55);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#333333").ss(0.5,1,1).p("AhtAdQCMAZAZiYIA2BGQhJAyhcBNg");
	this.shape_23.setTransform(2.325,2.55);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#515151").s().p("AhtAdQCMAYAZiWIA2BGQhJAxhcBNg");
	this.shape_24.setTransform(2.325,2.55);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#333333").ss(0.5,1,1).p("AhtAdQCBAHAkiGIA2BGQhJAyhcBNg");
	this.shape_25.setTransform(2.325,2.55);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#515151").s().p("AhtAdQCBAHAkiFIA2BGQhJAxhcBNg");
	this.shape_26.setTransform(2.325,2.55);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#333333").ss(0.5,1,1).p("AhtAdQB1gLAwh0IA2BGQhJAyhcBNg");
	this.shape_27.setTransform(2.325,2.55);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#515151").s().p("AhtAdQB1gLAwhzIA2BGQhJAxhcBNg");
	this.shape_28.setTransform(2.325,2.55);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#333333").ss(0.5,1,1).p("AhtAdQBrgdA6hiIA2BGQhJAyhcBNg");
	this.shape_29.setTransform(2.325,2.55);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#515151").s().p("AhtAdQBrgdA6hhIA2BGQhJAxhcBNg");
	this.shape_30.setTransform(2.325,2.55);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#333333").ss(0.5,1,1).p("AhtAdQBfguBGhRIA2BGQhJAyhcBNg");
	this.shape_31.setTransform(2.325,2.55);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#515151").s().p("AhtAdQBfgtBGhRIA2BGQhJAxhcBNg");
	this.shape_32.setTransform(2.325,2.55);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#333333").ss(0.5,1,1).p("ABoAsQhYgDh3ADIAAhXIDPAAg");
	this.shape_33.setTransform(2.323,2.5439,0.9989,0.9989,-37.4972);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#515151").s().p("AhnAsIAAhXIDPAAIAABXQhYgDh3ADg");
	this.shape_34.setTransform(2.323,2.5439,0.9989,0.9989,-37.4972);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#333333").ss(0.5,1,1).p("AhtAdIClh/IA2BGQhJAyhcBNg");
	this.shape_35.setTransform(2.325,2.55);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#515151").s().p("AhtAdIClh+IA2BGQhJAxhcBNg");
	this.shape_36.setTransform(2.325,2.55);

	var maskedShapeInstanceList = [this.shape_19,this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29,this.shape_30,this.shape_31,this.shape_32,this.shape_33,this.shape_34,this.shape_35,this.shape_36];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19}]}).to({state:[{t:this.shape_20},{t:this.shape_19}]},14).to({state:[{t:this.shape_22},{t:this.shape_21}]},1).to({state:[{t:this.shape_24},{t:this.shape_23}]},1).to({state:[{t:this.shape_26},{t:this.shape_25}]},1).to({state:[{t:this.shape_28},{t:this.shape_27}]},1).to({state:[{t:this.shape_30},{t:this.shape_29}]},1).to({state:[{t:this.shape_32},{t:this.shape_31}]},1).to({state:[{t:this.shape_34},{t:this.shape_33}]},1).to({state:[{t:this.shape_36},{t:this.shape_35}]},1).to({state:[{t:this.shape_36},{t:this.shape_35}]},1).to({state:[{t:this.shape_34},{t:this.shape_33}]},1).to({state:[{t:this.shape_32},{t:this.shape_31}]},1).to({state:[{t:this.shape_30},{t:this.shape_29}]},1).to({state:[{t:this.shape_28},{t:this.shape_27}]},1).to({state:[{t:this.shape_26},{t:this.shape_25}]},1).to({state:[{t:this.shape_24},{t:this.shape_23}]},1).to({state:[{t:this.shape_22},{t:this.shape_21}]},1).to({state:[{t:this.shape_20},{t:this.shape_19}]},1).wait(29));

	// Layer_3
	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgIAJQgEgDAAgGQAAgEAEgEQAEgEAEAAQAGAAADAEQAEAEAAAEQAAAGgEADQgDAEgGAAQgEAAgEgEg");
	this.shape_37.setTransform(-1.4257,-2.9921,0.729,0.729);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#090909").s().p("AgVAXQgIgKAAgNQAAgNAIgJQAKgKALAAQANAAAIAKQAJAJAAANQAAANgJAKQgIAJgNAAQgLAAgKgJg");
	this.shape_38.setTransform(-3.6374,-2.2089,0.729,0.729);

	var maskedShapeInstanceList = [this.shape_37,this.shape_38];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_38},{t:this.shape_37}]}).wait(60));

	// Layer_1
	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AguAxQgOgMgBgUIAAgMQAEgbARgQIACgCQAQgPAWgGQAVgHAUAUQAUATABAdQABATgKAPQgXAHgRAVIgNACQgbAAgTgPg");
	this.shape_39.setTransform(-0.3321,-0.3907);

	this.timeline.addTween(cjs.Tween.get(this.shape_39).wait(60));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.5,-7.8,15.1,15.6);


(lib.bvnvnbvn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap15();
	this.instance.setTransform(-55,-77);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-55,-77,111,155);


(lib.btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("EgjAAHeIAAu7MBGBAAAIAAO7g");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-224.1,-47.8,448.2,95.6), null);


(lib.broadCastInterface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_1 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_599 = function() {
		/* stop();
		this.blnPlay = false;
		MovieClip(parent.parent.parent.parent).mcForward.mcGlow.gotoAndPlay(6);*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(598).call(this.frame_599).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.bg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.CachedBmp_258();
	this.instance.setTransform(-491.65,-296.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F9F2E3","#E8D2A1"],[0,1],19.2,-7.7,0,19.2,-7.7,781.7).s().p("EhMUAt8MAAAhb3MCYpAAAMAAABb3g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-491.6,-296.7,984.5,590.7);


(lib.B_R = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap13();
	this.instance.setTransform(-47,-45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47,-45,95,90);


(lib.B_L = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap12();
	this.instance.setTransform(-35,-55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-35,-55,70,109);


(lib.B_eye = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DC9C0A").ss(0.5,1,1).p("AAhgNQAEAOgIAOQgHAOgOAGQgNAGgMgHQgMgGgEgOQgDgOAIgOQAHgPAOgFQANgGAMAGQAMAHADAOg");
	this.shape.setTransform(-7.8872,-0.4875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#DC9C0A").ss(0.5,1,1).p("AgfgIQABgDACgDQAAAAAAAAQAHgPAOgFQANgGAMAGQAMAHADAOQADANgFALQgBACgBACQAAABgBABQgHANgNAFQgNAGgMgHQgMgGgEgOQgCgMAEgKgAAcARQgPgcgsAD");
	this.shape_1.setTransform(-7.8872,-0.4875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F9C54D").s().p("AggABIADgFIAAAAQAHgOAOgGQANgFAMAGQAMAGADAOQADAMgFAMIgCAFIgBACQgPgcgsABg");
	this.shape_2.setTransform(-7.7562,-1.5065);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#DC9C0A").ss(0.5,1,1).p("AAhgNQADANgFALQgBACgBACQAAABgBABQgHANgNAFQgNAGgMgHQgMgGgEgOQgCgMAEgKQABgDACgDQAAAAAAAAQAHgPAOgFQANgGAMAGQAMAHADAOg");
	this.shape_3.setTransform(-7.8872,-0.4875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F9C54D").s().p("AgRAiQgMgGgEgOQgCgMAEgKIADgGIAAAAQAHgPAOgFQANgGAMAGQAMAHADAOQADANgFALIgCAEIgBACQgHANgNAFQgHADgFAAQgGAAgHgEg");
	this.shape_4.setTransform(-7.8872,-0.4875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},19).to({state:[{t:this.shape_4},{t:this.shape_3}]},4).to({state:[{t:this.shape_2},{t:this.shape_1}]},5).to({state:[{t:this.shape}]},4).wait(48));

	// Layer_7 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgRAiQgMgGgEgOQgDgOAIgOQAHgPAOgFQANgGAMAGQAMAHADAOQAEAOgIAOQgHAOgOAGQgHADgFAAQgGAAgHgEg");
	mask.setTransform(-7.8872,-0.4875);

	// Layer_2
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgOAPQgGgGAAgJQAAgIAGgGQAGgGAIAAQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape_5.setTransform(-8.539,0.6346,0.3601,0.3601,0,0,180);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgkAlQgPgPAAgWQAAgUAPgQQAPgPAVAAQAWAAAPAPQAPAQAAAUQAAAWgPAPQgPAPgWAAQgVAAgPgPg");
	this.shape_6.setTransform(-7.4699,1.2048,0.3602,0.3602,0,0,180);

	var maskedShapeInstanceList = [this.shape_5,this.shape_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5}]}).wait(80));

	// Layer_3
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgRAiQgMgGgEgOQgDgOAIgOQAHgPAOgFQANgGAMAGQAMAHADAOQAEAOgIAOQgHAOgOAGQgHADgFAAQgGAAgHgEg");
	this.shape_7.setTransform(-7.8872,-0.4875);

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(80));

	// Layer_6
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#DC9C0A").ss(0.5,1,1).p("AAJgjQgOgGgMAHQgNAGgDAPQgEAOAIAPQAHAOAPAGQANAGAMgGQANgHADgPQAEgOgIgOQgHgPgOgGg");
	this.shape_8.setTransform(7.5861,0.243);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#DC9C0A").ss(0.5,1,1).p("AAdgRQgIgNgMgFQgOgGgMAHQgNAGgDAPQgEAOAIAPQABACABACQAHALANAFQANAGAMgGQANgHADgPQAEgOgIgOQgBgCAAgBgAgbAUQAVggAjgF");
	this.shape_9.setTransform(7.5861,0.243);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F9C54D").s().p("AgaAZQgIgOAEgPQADgOANgHQAMgGAOAFQANAGAHANQgjAFgVAfIgCgEg");
	this.shape_10.setTransform(7.2554,-0.726);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#DC9C0A").ss(0.5,1,1).p("AAdgRQgIgNgMgFQgOgGgMAHQgNAGgDAPQgEAOAIAPQABACABACQAHALANAFQANAGAMgGQANgHADgPQAEgOgIgOQgBgCAAgBg");
	this.shape_11.setTransform(7.5861,0.243);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F9C54D").s().p("AgHAkQgNgFgHgLIgCgEQgIgPAEgOQADgPANgGQAMgHAOAGQAMAFAIANIABADQAIAOgEAOQgDAPgNAHQgGADgHAAQgFAAgHgDg");
	this.shape_12.setTransform(7.5861,0.243);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#DC9C0A").ss(0.5,1,1).p("AAdgRQAAABABACQAIAOgEAOQgDAPgNAHQgMAGgNgGQgNgFgHgLAAdgRQgIgNgMgFQgOgGgMAHQgNAGgDAPQgEAOAIAPQABACABACQAVggAjgFg");
	this.shape_13.setTransform(7.5861,0.243);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8}]}).to({state:[{t:this.shape_10},{t:this.shape_9}]},19).to({state:[{t:this.shape_12},{t:this.shape_11}]},4).to({state:[{t:this.shape_10},{t:this.shape_13}]},5).to({state:[{t:this.shape_8}]},4).wait(48));

	// Layer_5 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgHAkQgPgGgHgOQgIgPAEgOQADgPANgGQAMgHAOAGQAOAGAHAPQAIAOgEAOQgDAPgNAHQgGADgHAAQgFAAgHgDg");
	mask_1.setTransform(7.5861,0.243);

	// Layer_4
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgOAPQgGgGAAgJQAAgIAGgGQAGgGAIAAQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape_14.setTransform(7.861,1.5346,0.3601,0.3601,0,0,180);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgkAlQgPgPAAgWQAAgUAPgQQAPgPAVAAQAWAAAPAPQAPAQAAAUQAAAWgPAPQgPAPgWAAQgVAAgPgPg");
	this.shape_15.setTransform(8.9301,2.0048,0.3602,0.3602,0,0,180);

	var maskedShapeInstanceList = [this.shape_14,this.shape_15];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14}]}).wait(80));

	// Layer_8
	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgHAkQgPgGgHgOQgIgPAEgOQADgPANgGQAMgHAOAGQAOAGAHAPQAIAOgEAOQgDAPgNAHQgGADgHAAQgFAAgHgDg");
	this.shape_16.setTransform(7.5861,0.243);

	this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(80));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12.3,-5.2,24.4,10.4);


(lib.B_body = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap11();
	this.instance.setTransform(-32,-31);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32,-31,63,61);


(lib.ant_eye = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#802904").ss(0.5,1,1).p("AgohRQAigUAiAJQAkAIARAkQARAkgIAmQgKAngfASQgfASgngHQgogHgTgjQgTgjAMgnQAMgnAjgUg");
	this.shape.setTransform(-28.3888,-1.9538);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#802904").ss(0.5,1,1).p("AhbgFQBvgoBHA+QAFghgPggQgRgkgkgIQgigJgiAUQgjAUgMAnQgDAJgBAIQgDAdAOAcQATAjAoAHQAnAHAfgSQAfgSAKgnQABgFAAgE");
	this.shape_1.setTransform(-28.3885,-1.9538);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#A73705").s().p("AhbAiIADgRQAMgmAjgUQAjgUAiAIQAjAIARAkQAPAfgEAiQhIg+huAog");
	this.shape_2.setTransform(-28.3487,-5.9143);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#802904").ss(0.5,1,1).p("AhbgFQgDAdAOAcQATAjAoAHQAnAHAfgSQAfgSAKgnQABgFAAgEQAFghgPggQgRgkgkgIQgigJgiAUQgjAUgMAnQgDAJgBAIg");
	this.shape_3.setTransform(-28.3885,-1.9538);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#A73705").s().p("AgVBeQgogHgTgjQgOgcADgdIAEgRQAMgnAjgUQAigUAiAJQAkAIARAkQAPAggFAhIgBAJQgKAngfASQgWANgbAAQgKAAgLgCg");
	this.shape_4.setTransform(-28.3885,-1.9538);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},16).to({state:[{t:this.shape_4},{t:this.shape_3}]},2).to({state:[{t:this.shape_2},{t:this.shape_1}]},4).to({state:[{t:this.shape}]},2).wait(54));

	// Layer_7 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgVBeQgogHgTgjQgTgjAMgnQAMgnAjgUQAigUAiAJQAkAIARAkQARAkgIAmQgKAngfASQgWANgbAAQgKAAgLgCg");
	mask.setTransform(-28.3888,-1.9538);

	// Layer_2
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgUAWQgJgJAAgNQAAgLAJgJQAIgJAMAAQAMAAAJAJQAJAJAAALQAAANgJAJQgJAIgMAAQgMAAgIgIg");
	this.shape_5.setTransform(-22.2885,-0.6667,0.8799,0.8799);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgrAsQgRgTgBgZQABgYARgTQATgRAYgBQAZABATARQARATABAYQgBAZgRATQgTARgZABQgYgBgTgRg");
	this.shape_6.setTransform(-24.9581,-0.1367,0.88,0.88);

	var maskedShapeInstanceList = [this.shape_5,this.shape_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5}]}).wait(78));

	// Layer_3
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgVBeQgogHgTgjQgTgjAMgnQAMgnAjgUQAigUAiAJQAkAIARAkQARAkgIAmQgKAngfASQgWANgbAAQgKAAgLgCg");
	this.shape_7.setTransform(-28.3888,-1.9538);

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(78));

	// Layer_6
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#802904").ss(0.5,1,1).p("AAChwQArgCAfAkQAeAjACAuQACAugeAeQgfAegvAEQgvAEgggiQgggiABgwQABguAighQAighApgBg");
	this.shape_8.setTransform(25.4003,0.218);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#802904").ss(0.5,1,1).p("AhrgEQADgrAfgfQAighApgBQArgCAfAkQAeAjACAuQABAFgBAGAhrgEQAAADgBACQgBAwAgAiQAgAiAvgEQAvgEAfgeQAagbACgmQhdg+h6Asg");
	this.shape_9.setTransform(25.4013,0.218);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#A73705").s().p("AhrAtQADgsAfgdQAighApgBQArgCAfAkQAeAiACAvIAAALQhdhAh6Atg");
	this.shape_10.setTransform(25.4171,-4.753);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#802904").ss(0.5,1,1).p("AhJhOQAighApgBQArgCAfAkQAeAjACAuQABAFgBAGQgCAmgaAbQgfAegvAEQgvAEgggiQgggiABgwQABgCAAgDQADgrAfgfg");
	this.shape_11.setTransform(25.4013,0.218);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#A73705").s().p("AhNBTQgggiABgwIABgFQADgrAfgfQAighApgBQArgCAfAkQAeAjACAuIAAALQgCAmgaAbQgfAegvAEIgJAAQgpAAgdgeg");
	this.shape_12.setTransform(25.4013,0.218);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8}]}).to({state:[{t:this.shape_10},{t:this.shape_9}]},16).to({state:[{t:this.shape_12},{t:this.shape_11}]},2).to({state:[{t:this.shape_10},{t:this.shape_9}]},4).to({state:[{t:this.shape_8}]},2).wait(54));

	// Layer_8 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AhNBTQgggiACgwQAAguAjghQAhghApgBQArgCAfAkQAeAjACAuQACAugeAeQgfAegvAEIgJAAQgpAAgdgeg");
	mask_1.setTransform(25.4003,0.218);

	// Layer_4
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgUAWQgJgJAAgNQAAgLAJgJQAIgJAMAAQAMAAAJAJQAJAJAAALQAAANgJAJQgJAIgMAAQgMAAgIgIg");
	this.shape_13.setTransform(32.875,1.275);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgrAsQgRgTgBgZQABgYARgTQATgRAYgBQAZABATARQARATABAYQgBAZgRATQgTARgZABQgYgBgTgRg");
	this.shape_14.setTransform(29.8,1.85);

	var maskedShapeInstanceList = [this.shape_13,this.shape_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13}]}).wait(78));

	// Layer_5
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AhNBTQgggiACgwQAAguAjghQAhghApgBQArgCAfAkQAeAjACAuQACAugeAeQgfAegvAEIgJAAQgpAAgdgeg");
	this.shape_15.setTransform(25.4003,0.218);

	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(78));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-38.6,-12.5,75.9,25.1);


(lib.vbnvnvbn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.ant_eye();
	this.instance.setTransform(-10.6,32.4,1.2958,1.2958,0,0,0,-0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.Bitmap14();
	this.instance_1.setTransform(-72,-93);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-72,-93,144,187);


(lib.Symbol3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.orDange("synched",0);
	this.instance.setTransform(-3.85,17.15,0.6188,0.6188,0,0,0,0,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(-80.5,-82.4,161.5,164.60000000000002), null);


(lib.right_wrong = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// Layer_1
	this.instance = new lib.Symbol1("synched",0);
	this.instance.setTransform(-3.45,1.75);
	this.instance.alpha = 0.0117;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0.251)").s().p("AsuryIAKgKQAxgyBHAAQBGAAAyAyIIhIgIIgogQAxgyBHAAQBGAAAyAyQAyAyAABGQAABHgyAxIohIgIIhIhQAyAxAABHQAABGgyAzIgKAJg");
	this.shape.setTransform(-2.7088,0.9623,0.2531,0.2749);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().ls(["#C80000","#7E0101"],[0,1],-84.6,-0.2,84.3,-0.2).ss(2,1,1).p("AqYtCQhHAAgxAyQgFAEgFAGQgZAdgKAkQgFAVAAAYQAABGAyAyIIgIgIogIhQgyAxAABHQAABHAyAyQAxAxBHAAQBGAAAygxIIgohIIhIhQAxAxBHAAQAXAAAWgGQAkgJAdgZQAFgFAFgEQAygyAAhHQAAhHgygxIohohIIhogQAygyAAhGQAAhHgygxQgygyhGAAQhHAAgxAyIohIgIogogQgygyhGAAg");
	this.shape_1.setTransform(-3.1668,1.5329,0.2532,0.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#C80000").s().p("AIhMSIohoiIogIiQgxAxhHAAQhHAAgxgxQgygzAAhGQAAhHAygxIIgohIogogQgygxAAhHQAAgXAGgWQAJgkAagdIAJgKQAxgyBHAAQBHAAAxAyIIgIgIIhogQAygyBGAAQBHAAAxAyQAyAyAABGQAABHgyAxIogIgIIgIhQAyAxAABHQAABGgyAzIgKAJQgdAZgkAKQgVAFgYAAQhGAAgygxg");
	this.shape_2.setTransform(-3.1668,1.5329,0.2532,0.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(224,254,103,0.251)").s().p("As9D+QgygxAAhHQAAhGAygyQAxgxBHAAQBGAAAzAxIEEEEIl7BmgAJOlFQAxgyBHAAQBHAAAyAyQAxAxAABHQAABGgxAzIhCBBIqSCvg");
	this.shape_3.setTransform(3.4074,-7.6853,0.3453,0.3453);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().ls(["#95C801","#667E01"],[0,1],-60.6,-41.6,23.3,42.2).ss(2,1,1).p("AM+ovQgygyhGAAQhHAAgxAyIr3L2ImkmiQgygyhGAAQhHAAgxAyQgyAxAABHQAABGAyAxIIcIcQAxAyBHAAQBGAAAygyINvtvQAygyAAhGQAAhHgygxg");
	this.shape_4.setTransform(3.4509,0.4017,0.3454,0.3454);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#95C801").s().p("AkhIwIococQgygwAAhHQAAhGAygyQAxgyBHAAQBGAAAzAyIGjGiIL3r2QAxgyBHAAQBHAAAyAyQAxAxAABHQAABGgxAzItvNuQgzAyhGAAQhHAAgxgyg");
	this.shape_5.setTransform(3.4509,0.4017,0.3454,0.3454);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.9,-23.2,62.8,50);


(lib.lionhead = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.lioneye();
	this.instance.setTransform(-49.25,-186.2,0.7737,0.7737,0,0,0,0,-10);

	this.instance_1 = new lib.lioneye();
	this.instance_1.setTransform(-8.5,-183.25,1.0206,1.0206,0,0,0,0,-9.8);

	this.instance_2 = new lib.Bitmap19();
	this.instance_2.setTransform(-120,-272);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.lionhead, new cjs.Rectangle(-120,-272,218,274), null);


(lib.lionanim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.lionhead();
	this.instance.setTransform(-72.4,-247.05,1,1,0,0,0,-6,-119.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:-119.4,scaleX:0.9997,scaleY:0.9997,rotation:-3.7817,x:-75.45,y:-238.8},12,cjs.Ease.get(1)).wait(6).to({regY:-119.5,scaleX:1,scaleY:1,rotation:0,x:-72.4,y:-247.05},15).wait(21).to({regY:-119.4,scaleX:0.9997,scaleY:0.9997,rotation:-3.7817,x:-75.45,y:-238.8},12,cjs.Ease.get(1)).wait(6).to({regY:-119.5,scaleX:1,scaleY:1,rotation:0,x:-72.4,y:-247.05},15).wait(19));

	// Layer_1
	this.instance_1 = new lib.Bitmap20();
	this.instance_1.setTransform(-108,-196);

	this.instance_2 = new lib.CachedBmp_261();
	this.instance_2.setTransform(-124.7,-258.6,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1}]}).wait(106));

	// ncvvbcvb
	this.instance_3 = new lib.ncvvbcvb("synched",0);
	this.instance_3.setTransform(117.9,-80.15,1,1,0,0,0,7.9,123.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regY:124,scaleX:0.9998,scaleY:0.9998,rotation:2.7607,x:117.7,y:-80.25},9,cjs.Ease.get(0.5)).wait(3).to({startPosition:0},0).to({regY:123.9,scaleX:1,scaleY:1,rotation:0,x:117.9,y:-80.15},10).wait(4).to({startPosition:0},0).to({regY:124,scaleX:0.9998,scaleY:0.9998,rotation:2.7607,x:117.7,y:-80.25},9,cjs.Ease.get(0.5)).wait(3).to({startPosition:0},0).to({regY:123.9,scaleX:1,scaleY:1,rotation:0,x:117.9,y:-80.15},10).wait(5).to({startPosition:0},0).to({regY:124,scaleX:0.9998,scaleY:0.9998,rotation:2.7607,x:117.7,y:-80.25},9,cjs.Ease.get(0.5)).wait(3).to({startPosition:0},0).to({regY:123.9,scaleX:1,scaleY:1,rotation:0,x:117.9,y:-80.15},10).wait(5).to({startPosition:0},0).to({regY:124,scaleX:0.9998,scaleY:0.9998,rotation:2.7607,x:117.7,y:-80.25},9,cjs.Ease.get(0.5)).wait(3).to({startPosition:0},0).to({regY:123.9,scaleX:1,scaleY:1,rotation:0,x:117.9,y:-80.15},10).wait(4));

	// vbcbcbcv
	this.instance_4 = new lib.vbcbcbcv("synched",0);
	this.instance_4.setTransform(110.95,-352.15,1,1,0,0,0,-25.2,-82.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({regX:-25.1,scaleX:0.999,scaleY:0.999,rotation:-0.7448,x:124.75,y:-351.85},9,cjs.Ease.get(0.5)).wait(3).to({startPosition:0},0).to({regX:-25.2,scaleX:1,scaleY:1,rotation:0,x:110.95,y:-352.15},10).wait(4).to({startPosition:0},0).to({regX:-25.1,scaleX:0.999,scaleY:0.999,rotation:-0.7448,x:124.75,y:-351.85},9,cjs.Ease.get(0.5)).wait(3).to({startPosition:0},0).to({regX:-25.2,scaleX:1,scaleY:1,rotation:0,x:110.95,y:-352.15},10).wait(5).to({startPosition:0},0).to({regX:-25.1,scaleX:0.999,scaleY:0.999,rotation:-0.7448,x:124.75,y:-351.85},9,cjs.Ease.get(0.5)).wait(3).to({startPosition:0},0).to({regX:-25.2,scaleX:1,scaleY:1,rotation:0,x:110.95,y:-352.15},10).wait(5).to({startPosition:0},0).to({regX:-25.1,scaleX:0.999,scaleY:0.999,rotation:-0.7448,x:124.75,y:-351.85},9,cjs.Ease.get(0.5)).wait(3).to({startPosition:0},0).to({regX:-25.2,scaleX:1,scaleY:1,rotation:0,x:110.95,y:-352.15},10).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-199.2,-399.5,378.2,400.5);


(lib.house_shadow_2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_5
	this.instance = new lib.Symbol3();
	this.instance.setTransform(-275.7,-90.75);

	this.instance_1 = new lib.iceDCream();
	this.instance_1.setTransform(31.1,-106.8,0.395,0.395);

	this.instance_2 = new lib.Bitmap30();
	this.instance_2.setTransform(173,-172);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-356.3,-185.8,678.3,190.4);


(lib.heading03_2_2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-72.55,-11.75,0.5555,1.7875,0,0,0,-0.2,0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap35();
	this.instance.setTransform(-197,-91);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-197,-97.5,249.1,171);


(lib.heading03_2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-72.55,-11.75,0.5555,1.7875,0,0,0,-0.2,0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_1
	this.instance = new lib.Bitmap39();
	this.instance.setTransform(-197,-91);

	this.instance_1 = new lib.Bitmap40();
	this.instance_1.setTransform(-197,-91);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-197,-97.5,249.1,171);


(lib.heading03 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-72.55,-11.75,0.5555,1.7875,0,0,0,-0.2,0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap6();
	this.instance.setTransform(-197,-91);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-197,-97.5,249.1,171);


(lib.heading02_2_2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-72.55,-11.75,0.5555,1.7875,0,0,0,-0.2,0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap34();
	this.instance.setTransform(-197,-91);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-197,-97.5,249.1,171);


(lib.heading02_2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-72.55,-11.75,0.5555,1.7875,0,0,0,-0.2,0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap38();
	this.instance.setTransform(-197,-91);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-197,-97.5,249.1,171);


(lib.heading02 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-72.55,-11.75,0.5555,1.7875,0,0,0,-0.2,0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_1
	this.instance = new lib.Bitmap4();
	this.instance.setTransform(-197,-91);

	this.instance_1 = new lib.Bitmap5();
	this.instance_1.setTransform(-197,-91);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-197,-97.5,249.1,171);


(lib.heading01_2_2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-72.55,-11.75,0.5555,1.7875,0,0,0,-0.2,0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_1
	this.instance = new lib.Bitmap32();
	this.instance.setTransform(-197,-91);

	this.instance_1 = new lib.Bitmap33();
	this.instance_1.setTransform(-197,-91);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-197,-97.5,249.1,171);


(lib.heading01_2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-72.55,-11.75,0.5555,1.7875,0,0,0,-0.2,0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap37();
	this.instance.setTransform(-197,-91);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-197,-97.5,249.1,171);


(lib.heading01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(-72.55,-11.75,0.5555,1.7875,0,0,0,-0.2,0.1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap3();
	this.instance.setTransform(-197,-91);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-197,-97.5,249.1,171);


(lib.head_bug = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.eye_bug();
	this.instance.setTransform(-7.2,8);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(1));

	// Layer_1
	this.instance_1 = new lib.Bitmap7();
	this.instance_1.setTransform(-19,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},1).wait(1));

	// Layer_3
	this.instance_2 = new lib.eye2_bug();
	this.instance_2.setTransform(12.9,5.05);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21.4,-28,48.9,55);


(lib.frog01copyx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.f_eyec();
	this.instance.setTransform(-2.95,-2.2,0.34,0.34,0,0,180);

	this.instance_1 = new lib.f_eyec();
	this.instance_1.setTransform(-20.65,-2.2,0.34,0.34);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_2 = new lib.Bitmap24();
	this.instance_2.setTransform(-66,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-66,-13,108,107);


(lib.bug = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// head_bug
	this.instance = new lib.head_bug("single",0);
	this.instance.setTransform(20.9,-2.35,1,1,0,0,0,-11,12.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// body_bug
	this.instance_1 = new lib.Bitmap9();
	this.instance_1.setTransform(-47,-30);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47,-42.5,98.1,74.5);


(lib.B_head = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.B_eye();
	this.instance.setTransform(-3.8,8.3,1,1,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.Bitmap10();
	this.instance_1.setTransform(-19,-26);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.B_head, new cjs.Rectangle(-19,-26,38,53), null);


(lib.Ant = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.vbnvnvbn("single",0);
	this.instance.setTransform(-78.7,-23.8,1,1,0,0,0,15,74.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:0.9995,scaleY:0.9995,rotation:8.5565,x:-74.55,y:-29.15},19,cjs.Ease.get(0.5)).to({scaleX:1,scaleY:1,rotation:0,x:-78.7,y:-23.8},20).wait(7).to({startPosition:0},0).to({scaleX:0.9995,scaleY:0.9995,rotation:8.5565,x:-74.55,y:-29.15},19,cjs.Ease.get(0.5)).to({scaleX:1,scaleY:1,rotation:0,x:-78.7,y:-23.8},20).wait(42).to({startPosition:0},0).to({scaleX:0.9995,scaleY:0.9995,rotation:8.5565,x:-74.55,y:-29.15},19,cjs.Ease.get(0.5)).to({scaleX:1,scaleY:1,rotation:0,x:-78.7,y:-23.8},20).wait(84));

	// Layer_2
	this.instance_1 = new lib.bvnvnbvn("single",0);
	this.instance_1.setTransform(22.35,164.35,1,1,0,0,0,-10,50.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({startPosition:0},19,cjs.Ease.get(0.5)).to({startPosition:0},20).wait(7).to({startPosition:0},0).to({startPosition:0},19,cjs.Ease.get(0.5)).to({startPosition:0},20).wait(42).to({startPosition:0},0).to({startPosition:0},19,cjs.Ease.get(0.5)).to({startPosition:0},20).wait(84));

	// Layer_4
	this.instance_2 = new lib.vbncvbnv("single",0);
	this.instance_2.setTransform(-6.85,46.15,1,1,0,0,0,-35.8,20.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regX:-35.9,scaleX:0.9998,scaleY:0.9998,rotation:3.5517,x:-7.25,y:45.05},19,cjs.Ease.get(0.5)).to({regX:-35.8,scaleX:1,scaleY:1,rotation:0,x:-6.85,y:46.15},20).wait(7).to({startPosition:0},0).to({regX:-35.9,scaleX:0.9998,scaleY:0.9998,rotation:3.5517,x:-7.25,y:45.05},19,cjs.Ease.get(0.5)).to({regX:-35.8,scaleX:1,scaleY:1,rotation:0,x:-6.85,y:46.15},20).wait(42).to({startPosition:0},0).to({regX:-35.9,scaleX:0.9998,scaleY:0.9998,rotation:3.5517,x:-7.25,y:45.05},19,cjs.Ease.get(0.5)).to({regX:-35.8,scaleX:1,scaleY:1,rotation:0,x:-6.85,y:46.15},20).wait(84));

	// Layer_5
	this.instance_3 = new lib.vbvbv("single",0);
	this.instance_3.setTransform(-87.05,122.15,1,1,0,0,0,7.9,47.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({startPosition:0},19,cjs.Ease.get(0.5)).to({startPosition:0},20).wait(7).to({startPosition:0},0).to({startPosition:0},19,cjs.Ease.get(0.5)).to({startPosition:0},20).wait(42).to({startPosition:0},0).to({startPosition:0},19,cjs.Ease.get(0.5)).to({startPosition:0},20).wait(84));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-165.7,-207.6,336.6,399.9);


(lib.Symbol9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.B_head("single",0);
	this.instance.setTransform(-35.85,15.65,1,1,0,0,0,0,23.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({startPosition:0},10,cjs.Ease.get(1)).to({startPosition:0},10,cjs.Ease.get(1)).wait(1));

	// Layer_1
	this.instance_1 = new lib.B_body("synched",0);
	this.instance_1.setTransform(-22.75,40.8,1,1,0,0,0,-9,-0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({startPosition:0},10,cjs.Ease.get(1)).to({startPosition:0},10,cjs.Ease.get(1)).wait(1));

	// Layer_5
	this.instance_2 = new lib.B_L("synched",0);
	this.instance_2.setTransform(-14.25,37,1,1,0,0,0,-26.2,26.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({scaleX:0.8237,scaleY:1.0008,skewX:-2.285},10,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,skewX:0},10,cjs.Ease.get(1)).wait(1));

	// Layer_6
	this.instance_3 = new lib.B_R("synched",0);
	this.instance_3.setTransform(-27.65,41.85,1,1,0,0,0,35.1,4.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regX:35.2,scaleX:0.84,x:-27.6},10,cjs.Ease.get(1)).to({regX:35.1,scaleX:1,x:-27.65},10,cjs.Ease.get(1)).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.7,-44.9,156.7,126.9);


(lib.strawberryop2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Symbol9();
	this.instance.setTransform(-15.15,-39.6,1.0041,1.0041,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62.2,-84.6,157.3,127.39999999999999);


(lib.house_shadow_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.fgneye();
	this.instance.setTransform(-278,-160);

	this.instance_1 = new lib.fgneye();
	this.instance_1.setTransform(-257.25,-163.8);

	this.instance_2 = new lib.Bitmap18();
	this.instance_2.setTransform(-291,-191);

	this.instance_3 = new lib.frog01copyx("synched",0);
	this.instance_3.setTransform(233.85,-122.3,1.3052,1.3052,0,0,180);

	this.instance_4 = new lib.lionanim();
	this.instance_4.setTransform(-25.85,-100.55,0.5096,0.5096,0,0,180,0,-199.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-291,-202.3,611,204.10000000000002);


(lib.house_shadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.mc_2 = new lib.strawberryop2();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(5.15,-39.65,1.1911,1.1911);

	this.instance = new lib.Ant();
	this.instance.setTransform(308.15,-64.15,0.3862,0.3862);

	this.instance_1 = new lib.bug("single",0);
	this.instance_1.setTransform(-260.3,-57.3,1.44,1.44,0,0,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance},{t:this.mc_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-333.4,-140.5,705.5999999999999,151.7);


(lib.mcMain3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay =  true;*/
	}
	this.frame_134 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 1;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					//this.parent.fLaunchProduct();
					this.play();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				//this.parent.fLaunchProduct();
				this.play();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}
	this.frame_160 = function() {
		/* stop();
		this.blnPlay = false;
		fCalculateScore();
		function fCalculateScore() {
			var nP = Math.floor((__nScore/3)*100);
			trace(__nScore + "---------------------"+3+"---------"+nP);
			if (nP < 70) {
				MovieClip(parent.parent.parent).mcFinal.mcRank.gotoAndPlay("rank2");
			} else {
				MovieClip(parent.parent.parent).mcFinal.mcRank.gotoAndPlay("rank1_1");
			}
		}*/
		
		this.stop();
		//alert("----------EndSlideFunction-------");
		main.showRestartBtn();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(134).call(this.frame_134).wait(26).call(this.frame_160).wait(1));

	// Layer_3
	this.mcInterfaceBlinker = new lib.broadCastInterface();
	this.mcInterfaceBlinker.name = "mcInterfaceBlinker";
	this.mcInterfaceBlinker.setTransform(-453,-389,1,1,0,0,0,11.5,8);
	this.mcInterfaceBlinker._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mcInterfaceBlinker).wait(134).to({_off:false},0).wait(27));

	// Layer_4
	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(310.65,73.75,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(3.25,73.75,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-300.85,73.75,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},134).wait(27));

	// right_wrong_audio
	this.mc_3 = new lib.heading03_2_2_3();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(377.1,209.9);

	this.mc_2 = new lib.heading02_2_2_3();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(69.7,209.9);

	this.mc_1 = new lib.heading01_2_2_3();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-234.4,209.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3}]},134).wait(27));

	// heading02
	this.instance = new lib.heading03_2_2_3("synched",0);
	this.instance.setTransform(377.1,399.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(109).to({_off:false},0).to({y:199.9},10,cjs.Ease.get(1)).to({y:209.9},5).to({_off:true},10).wait(27));

	// heading02
	this.instance_1 = new lib.heading02_2_2_3("synched",0);
	this.instance_1.setTransform(69.7,399.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(104).to({_off:false},0).to({y:199.9},10,cjs.Ease.get(1)).to({y:209.9},5).to({_off:true},15).wait(27));

	// heading01
	this.instance_2 = new lib.heading01_2_2_3("single",0);
	this.instance_2.setTransform(-234.4,399.9);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(99).to({_off:false},0).to({y:199.9},10,cjs.Ease.get(1)).to({y:209.9},5).to({_off:true},20).wait(27));

	// house_shadow
	this.instance_3 = new lib.house_shadow_2_3("synched",0);
	this.instance_3.setTransform(689,14.5,1,1,0,0,0,-0.2,-0.2);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(82).to({_off:false},0).to({x:9},12,cjs.Ease.get(1)).to({x:19},5,cjs.Ease.get(1)).wait(62));

	// numbring01
	this.instance_4 = new lib.numbring01_2_3("synched",0);
	this.instance_4.setTransform(-397.6,-129.8,2,2);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(78).to({_off:false},0).to({scaleX:0.9,scaleY:0.9,alpha:1},12,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5).wait(66));

	// heading02
	this.instance_5 = new lib.heading03_2_2("single",0);
	this.instance_5.setTransform(377.1,209.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(50).to({startPosition:0},0).to({y:199.9},6).to({y:339.9},13,cjs.Ease.get(-1)).to({_off:true},1).wait(91));

	// heading02
	this.instance_6 = new lib.heading02_2_2("synched",0);
	this.instance_6.setTransform(69.7,209.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(45).to({startPosition:0},0).to({y:199.9},6).to({y:339.9},13,cjs.Ease.get(-1)).to({_off:true},1).wait(96));

	// heading01
	this.instance_7 = new lib.heading01_2_2("synched",0);
	this.instance_7.setTransform(-234.4,209.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(42).to({startPosition:0},0).to({y:199.9},6).to({y:339.9},13,cjs.Ease.get(-1)).to({_off:true},1).wait(99));

	// house_shadow
	this.instance_8 = new lib.house_shadow_2("synched",0);
	this.instance_8.setTransform(19,18.5,1,1,0,0,0,-0.2,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(32).to({startPosition:0},0).to({x:29},6,cjs.Ease.get(1)).to({x:-671},13,cjs.Ease.get(1)).to({_off:true},1).wait(109));

	// numbring01
	this.instance_9 = new lib.numbring01_2("synched",0);
	this.instance_9.setTransform(-397.6,-129.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(23).to({startPosition:0},0).to({scaleX:0.9,scaleY:0.9},6,cjs.Ease.get(1)).to({scaleX:2,scaleY:2,alpha:0},10,cjs.Ease.get(1)).to({_off:true},1).wait(121));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-961.8,-199.8,1973,673.2);


(lib.mcMain2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_129 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 3;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(129).call(this.frame_129).wait(1));

	// Layer_4
	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(310.65,73.75,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(3.25,73.75,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-300.85,73.75,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},129).wait(1));

	// right_wrong_audio
	this.mc_3 = new lib.heading03_2_2();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(377.1,209.9);

	this.mc_2 = new lib.heading02_2_2();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(69.7,209.9);

	this.mc_1 = new lib.heading01_2_2();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-234.4,209.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3}]},129).wait(1));

	// heading02
	this.instance = new lib.heading03_2_2("single",0);
	this.instance.setTransform(377.1,399.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(105).to({_off:false},0).to({y:199.9},10,cjs.Ease.get(1)).to({y:209.9},5).to({_off:true},9).wait(1));

	// heading02
	this.instance_1 = new lib.heading02_2_2("synched",0);
	this.instance_1.setTransform(69.7,399.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(100).to({_off:false},0).to({y:199.9},10,cjs.Ease.get(1)).to({y:209.9},5).to({_off:true},14).wait(1));

	// heading01
	this.instance_2 = new lib.heading01_2_2("synched",0);
	this.instance_2.setTransform(-234.4,399.9);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(95).to({_off:false},0).to({y:199.9},10,cjs.Ease.get(1)).to({y:209.9},5).to({_off:true},19).wait(1));

	// house_shadow
	this.instance_3 = new lib.house_shadow_2("synched",0);
	this.instance_3.setTransform(689,18.5,1,1,0,0,0,-0.2,-0.2);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(78).to({_off:false},0).to({x:9},12,cjs.Ease.get(1)).to({x:19},5,cjs.Ease.get(1)).wait(35));

	// numbring01
	this.instance_4 = new lib.numbring01_2("synched",0);
	this.instance_4.setTransform(-397.6,-129.8,2,2);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(74).to({_off:false},0).to({scaleX:0.9,scaleY:0.9,alpha:1},12,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5).wait(39));

	// heading02
	this.instance_5 = new lib.heading03("synched",0);
	this.instance_5.setTransform(377.1,209.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(49).to({startPosition:0},0).to({y:199.9},6).to({y:339.9},13,cjs.Ease.get(-1)).to({_off:true},1).wait(61));

	// heading02
	this.instance_6 = new lib.heading02("single",0);
	this.instance_6.setTransform(69.7,209.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(44).to({startPosition:0},0).to({y:199.9},6).to({y:339.9},13,cjs.Ease.get(-1)).to({_off:true},1).wait(66));

	// heading01
	this.instance_7 = new lib.heading01("synched",0);
	this.instance_7.setTransform(-234.4,209.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(41).to({startPosition:0},0).to({y:199.9},6).to({y:339.9},13,cjs.Ease.get(-1)).to({_off:true},1).wait(69));

	// house_shadow
	this.instance_8 = new lib.house_shadow("synched",0);
	this.instance_8.setTransform(19,8.5,1,1,0,0,0,-0.2,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(31).to({startPosition:0},0).to({x:29},6,cjs.Ease.get(1)).to({x:-671},13,cjs.Ease.get(1)).to({_off:true},1).wait(79));

	// numbring01
	this.instance_9 = new lib.numbring01("synched",0);
	this.instance_9.setTransform(-397.6,-129.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(22).to({startPosition:0},0).to({scaleX:0.9,scaleY:0.9},6,cjs.Ease.get(1)).to({scaleX:2,scaleY:2,alpha:0},10,cjs.Ease.get(1)).to({_off:true},1).wait(91));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1004.2,-199.8,2013.4,673.2);


(lib.mcMain1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;
		var objRef = this;
		var __nCorrectAnswer = 0;
		var blnLastQuestion = false;
		var __nScore = 0;
		function init() {
			for (var i:Number = 1; objRef["mc_"+i] != null; i++) {
				objRef["mc_"+i].id = i;
				objRef["mc_" + i].addEventListener(MouseEvent.CLICK, fClickEvent);
				objRef["mc_"+i].buttonMode = true;
			}
		}
		
		function fClickEvent(e) {
			fRemoveListeners();	
			mcFish.gotoAndPlay(2);
			if (e.currentTarget.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.gotoAndStop(2);
				var mcRight = new Right();
				objRef.addChild(mcRight);
				objRef["mcTick_"+e.currentTarget.id].gotoAndStop(3);
				return;
			}
			var mcWrong = new ShowAnswer();
			objRef.addChild(mcWrong);
			objRef["mcTick_"+e.currentTarget.id].gotoAndStop(2);
		}
		function fChangeQuestion() {		
			play();
		}
		function fRemoveListeners() {
			for (var i:Number = 1; objRef["mc_"+i] != null; i++) {
				objRef["mc_" + i].removeEventListener(MouseEvent.CLICK, fClickEvent);
				objRef["mc_"+i].buttonMode = false;
			}
		}
		function fShowCorrectAnswer() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(2);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(3);
			//__nCorrectAnswer.gotoAndStop(2);
		}*/
	}
	this.frame_84 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 2;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(84).call(this.frame_84).wait(1));

	// Layer_4
	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(310.65,73.75,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(3.25,73.75,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(-300.85,73.75,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},84).wait(1));

	// right_wrong_audio
	this.mc_3 = new lib.heading03();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(377.1,209.9);

	this.mc_2 = new lib.heading02();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(69.7,209.9);

	this.mc_1 = new lib.heading01();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(-234.4,209.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3}]},84).wait(1));

	// heading02
	this.instance = new lib.heading03("synched",0);
	this.instance.setTransform(377.1,399.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(60).to({_off:false},0).to({y:199.9},10,cjs.Ease.get(1)).to({y:209.9},5).to({_off:true},9).wait(1));

	// heading02
	this.instance_1 = new lib.heading02("single",0);
	this.instance_1.setTransform(69.7,399.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(55).to({_off:false},0).to({y:199.9},10,cjs.Ease.get(1)).to({y:209.9},5).to({_off:true},14).wait(1));

	// heading01
	this.instance_2 = new lib.heading01("synched",0);
	this.instance_2.setTransform(-234.4,399.9);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).to({y:199.9},10,cjs.Ease.get(1)).to({y:209.9},5).to({_off:true},19).wait(1));

	// house_shadow
	this.instance_3 = new lib.house_shadow("synched",0);
	this.instance_3.setTransform(689,8.5,1,1,0,0,0,-0.2,-0.2);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(33).to({_off:false},0).to({x:9},12,cjs.Ease.get(1)).to({x:19},5,cjs.Ease.get(1)).wait(35));

	// numbring01
	this.instance_4 = new lib.numbring01("synched",0);
	this.instance_4.setTransform(-397.6,-129.8,2,2);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(29).to({_off:false},0).to({scaleX:0.9,scaleY:0.9,alpha:1},12,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5).wait(39));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-465.6,-199.8,1527,673.2);


// stage content:
(lib.Interface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,25];
	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		stage.enableMouseOver(10); 
		//this.strFrame = "strFrame1"
		this.nF = 1;
		this.fLaunchProduct = function()
		{
			if(this.mcAttachMovieClip)
			{
				this.removeChild(this.mcAttachMovieClip);
			}
			this.mcAttachMovieClip = new lib["mcMain"+this.nF];
			this.mcAttachMovieClip.x = 488.1;
			this.mcAttachMovieClip.y = 295.05;	
			this.mcAttachMovieClip.gotoAndPlay(this.strFrame);
			this.addChild(this.mcAttachMovieClip);	
			if(this.nF == 1)
			{
				this.play();
				this.fbAudio = main.playAudio('instruction');
			}
			this.nF = this.nF + 1;
		}
		//this.fLaunchProduct();
	}
	this.frame_25 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(25).call(this.frame_25).wait(1));

	// HEADING
	this.instance = new lib.heading_("synched",0);
	this.instance.setTransform(-184.35,21.25);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).to({x:145.65},11,cjs.Ease.get(1)).wait(11));

	// heading_txt
	this.instance_1 = new lib.heading_txt("synched",0);
	this.instance_1.setTransform(1228.5,81.85);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(7).to({_off:false},0).to({x:478.5},12,cjs.Ease.get(1)).to({x:488.5},6,cjs.Ease.get(1)).wait(1));

	// bg
	this.instance_2 = new lib.bg();
	this.instance_2.setTransform(488.5,294);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({alpha:1},11).wait(15));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(157.1,287.3,1319.3000000000002,300.7);
// library properties:
lib.properties = {
	id: 'ECDF1A6AC5E395468828BABD79B3D8C3',
	width: 977,
	height: 588,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Interface_atlas_1.png?1638118712702", id:"Interface_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['ECDF1A6AC5E395468828BABD79B3D8C3'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;