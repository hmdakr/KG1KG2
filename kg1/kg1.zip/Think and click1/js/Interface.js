(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Interface_atlas_1", frames: [[65,121,33,36],[462,104,45,45],[462,54,44,48],[0,121,63,44],[375,0,85,133],[0,0,123,119],[125,0,123,119],[250,0,123,119],[462,0,45,52]]},
		{name:"Interface_atlas_2", frames: [[0,0,1954,1210],[907,1212,246,238],[891,1706,246,238],[1403,1438,128,224],[1533,1438,128,224],[921,1452,246,238],[1155,1212,246,238],[1550,1212,116,224],[1139,1692,246,238],[1387,1666,145,224],[1403,1212,145,224],[1169,1452,221,212],[355,1973,308,54],[0,1618,353,385],[1534,1664,123,119],[1534,1785,123,119],[1623,1906,123,119],[1659,1664,123,119],[1659,1785,123,119],[1748,1906,123,119],[891,1946,730,78],[1873,1212,123,119],[1873,1333,123,119],[663,1465,256,239],[355,1653,306,244],[389,1212,234,439],[1873,1454,123,119],[1873,1575,123,119],[1873,1696,123,119],[1873,1817,123,119],[0,1212,387,404],[1668,1212,123,119],[1668,1333,123,119],[625,1212,280,251],[663,1706,226,265],[1663,1454,123,119]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_165 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_164 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_163 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_162 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_161 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_160 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_159 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_158 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_157 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_156 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_155 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_154 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_153 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_152 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap10 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap12 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap13 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap14 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap15 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap16 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap18 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap19 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap20 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap21 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap22 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap23 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap24 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap25 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap26 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap27 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap28 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap29 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap3 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap30 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap31 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap33 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap34 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap4 = function() {
	this.initialize(ss["Interface_atlas_2"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap9 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.trx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_165();
	this.instance.setTransform(-488.5,-302.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-488.5,-302.4,977,605);


(lib.text01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap2();
	this.instance.setTransform(-365,-37);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-365,-37,730,78);


(lib.tailvat = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap24();
	this.instance.setTransform(9,-137);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(9,-137,85,133);


(lib.right_wrong = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// _
	this.instance = new lib.Bitmap9();
	this.instance.setTransform(-26,-26);

	this.instance_1 = new lib.Bitmap10();
	this.instance_1.setTransform(-25,-22);

	this.instance_2 = new lib.Bitmap11();
	this.instance_2.setTransform(-31,-18);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-26,63,52);


(lib.heading_ = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap1();
	this.instance.setTransform(-147,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-147,-28,308,54);


(lib.eyeboy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#E09F3F").ss(0.5,1,1).p("ABABJQgaAegmAAQglAAgbgeQgageAAgrQAAgqAageQAbgeAlAAQAmAAAaAeQAbAeAAAqQAAArgbAeg");
	this.shape.setTransform(0.025,-10.325);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(75));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhABJQgageAAgrQAAgqAageQAbgeAlAAQAmAAAaAeQAbAeAAAqQAAArgbAeQgaAegmAAQglAAgbgeg");
	mask.setTransform(0.025,-10.325);

	// Layer_5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#333333").ss(0.5,1,1).p("AB5AiQh6hUh3BUIAAhDIDxAAg");
	this.shape_1.setTransform(0.575,-21.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F8D8A9").s().p("Ah4AiIAAhDIDxAAIAABDQh6hUh3BUg");
	this.shape_2.setTransform(0.575,-21.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4grIDxAAIAABXQh7gmh2Amg");
	this.shape_3.setTransform(0.575,-20.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F8D8A9").s().p("Ah4AsIAAhXIDxAAIAABXQh7gmh2Amg");
	this.shape_4.setTransform(0.575,-20.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4g4IDxAAIAABtQh7AIh2gIg");
	this.shape_5.setTransform(0.575,-19.425);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F8D8A9").s().p("Ah4A1IAAhtIDxAAIAABtQg+AEg8AAQg8AAg7gEg");
	this.shape_6.setTransform(0.575,-19.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4hOIDxAAIAACCQh8A2h1g2g");
	this.shape_7.setTransform(0.575,-17.2125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F8D8A9").s().p("Ah4A0IAAiCIDxAAIAACCQg/Abg7AAQg8AAg7gbg");
	this.shape_8.setTransform(0.575,-17.2125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4hkIDxAAIAACWQh9Blh0hlg");
	this.shape_9.setTransform(0.575,-15.025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F8D8A9").s().p("Ah4AyIAAiWIDxAAIAACWQg/Azg7AAQg9AAg6gzg");
	this.shape_10.setTransform(0.575,-15.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#333333").ss(0.5,1,1).p("Ah4h6IDxAAIAACrQh9CUh0iUg");
	this.shape_11.setTransform(0.575,-12.8125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F8D8A9").s().p("Ah4AxIAAirIDxAAIAACrQg/BKg8AAQg8AAg6hKg");
	this.shape_12.setTransform(0.575,-12.8125);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#333333").ss(0.5,1,1).p("AB5AwQh+DChzjCIAAjAIDxAAg");
	this.shape_13.setTransform(0.575,-10.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#F8D8A9").s().p("Ah4AwIAAjAIDxAAIAADAQhABhg7AAQg8AAg6hhg");
	this.shape_14.setTransform(0.575,-10.6);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},15).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},3).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).to({state:[]},1).wait(44));

	// Layer_3
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgNAOQgGgGAAgIQAAgHAGgGQAGgGAHAAQAJAAAFAGQAGAGAAAHQAAAIgGAGQgFAGgJAAQgHAAgGgGg");
	this.shape_15.setTransform(-3.1453,-6.7495,0.8313,0.8313);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#333333").ss(0.5,1,1).p("AAlgkQAPAPAAAVQAAAVgPAPQgPAPgWAAQgUAAgPgPQgPgPAAgVQAAgVAPgPQAPgPAUAAQAWAAAPAPg");
	this.shape_16.setTransform(0.1564,-5.0263,0.8314,0.8314);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgjAkQgPgPgBgVQABgVAPgPQAPgPAUAAQAWAAAPAPQAPAPAAAVQAAAVgPAPQgPAPgWABQgUgBgPgPg");
	this.shape_17.setTransform(0.1564,-5.0263,0.8314,0.8314);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15}]}).wait(75));

	// Layer_1
	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#E09F3F").ss(0.5,1,1).p("ABAhIQAbAeAAAqQAAArgbAeQgaAegmAAQglAAgbgeQgageAAgrQAAgqAageQAbgeAlAAQAmAAAaAeg");
	this.shape_18.setTransform(0.025,-10.325);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AhABJQgageAAgrQAAgqAageQAbgeAlAAQAmAAAaAeQAbAeAAAqQAAArgbAeQgaAegmAAQglAAgbgeg");
	this.shape_19.setTransform(0.025,-10.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18}]}).wait(75));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,-21.6,20.1,22.6);


(lib.eleeye = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(0.3,1,1).p("ABfAAQAAArgcAeQgcAegnAAQgmAAgcgeQgcgeAAgrQAAgqAcgeQAcgeAmAAQAnAAAcAeQAcAeAAAqg");
	this.shape.setTransform(0.025,-10.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(80));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhCBIQgcgdAAgrQAAgqAcgeQAcgeAmAAQAnAAAcAeQAcAeAAAqQAAArgcAdQgcAfgnAAQgmAAgcgfg");
	mask.setTransform(0.025,-10.3);

	// Layer_5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#333333").ss(0.3,1,1).p("AB/AhQh0hhiJBhIAAhBID9AAg");
	this.shape_1.setTransform(-0.15,-20.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#C2C6D2").s().p("Ah+AgIAAg/ID9AAIAAA/Qh0hgiJBgg");
	this.shape_2.setTransform(-0.15,-20.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#333333").ss(0.3,1,1).p("Ah+gpID9AAIAABTQh2gziHAzg");
	this.shape_3.setTransform(-0.15,-19.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#C2C6D2").s().p("Ah+AqIAAhTID9AAIAABTQh2gziHAzg");
	this.shape_4.setTransform(-0.15,-19.325);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#333333").ss(0.3,1,1).p("Ah+gyID9AAIAABlQh4gFiFAFg");
	this.shape_5.setTransform(-0.15,-18.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#C2C6D2").s().p("Ah+AzIAAhlID9AAIAABlQh4gFiFAFg");
	this.shape_6.setTransform(-0.15,-18.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#333333").ss(0.3,1,1).p("Ah+hGID9AAIAAB4Qh6ApiDgpg");
	this.shape_7.setTransform(-0.15,-16.3875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#C2C6D2").s().p("Ah+AyIAAh4ID9AAIAAB4Qg9AVg/AAQg/AAhCgVg");
	this.shape_8.setTransform(-0.15,-16.3875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#333333").ss(0.3,1,1).p("Ah+hbID9AAIAACLQh8BYiBhYg");
	this.shape_9.setTransform(-0.15,-14.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#C2C6D2").s().p("Ah+AwIAAiLID9AAIAACLQg+Asg/AAQg/AAhBgsg");
	this.shape_10.setTransform(-0.15,-14.275);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#333333").ss(0.3,1,1).p("Ah+hwID9AAIAACdQh+CHh/iHg");
	this.shape_11.setTransform(-0.15,-12.1875);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#C2C6D2").s().p("Ah+AtIAAidID9AAIAACdQg/BEg/AAQg/AAhAhEg");
	this.shape_12.setTransform(-0.15,-12.1875);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#333333").ss(0.3,1,1).p("AB/AQQh/BDh+hDIAAhAID9AAg");
	this.shape_13.setTransform(-0.15,-10.0237,1,2.7164);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#C2C6D2").s().p("Ah+AQIAAhAID9AAIAABAQhAAhg/AAQg/AAg/ghg");
	this.shape_14.setTransform(-0.15,-10.0237,1,2.7164);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},14).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},3).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).wait(51));

	// Layer_4
	this.instance = new lib.CachedBmp_164();
	this.instance.setTransform(-6.9,-14.15,0.3636,0.3636);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(80));

	// Layer_1
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FEFEFE").s().p("AhCBIQgcgdAAgrQAAgqAcgeQAcgeAmAAQAnAAAcAeQAcAeAAAqQAAArgcAdQgcAfgnAAQgmAAgcgfg");
	this.shape_15.setTransform(0.025,-10.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(80));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.4,-21.6,20.9,22.6);


(lib.Doll = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap3();
	this.instance.setTransform(-202,-156);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-202,-156,387,404);


(lib.cateye = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#C0700E").ss(0.5,1,1).p("ABvhuQAuAuAABAQAABBguAuQguAuhBAAQhAAAguguQguguAAhBQAAhAAuguQAuguBAAAQBBAAAuAug");
	this.shape.setTransform(0,-15.65);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(89));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhuBvQguguAAhBQAAhAAuguQAuguBAAAQBBAAAuAuQAtAuABBAQgBBBgtAuQguAthBABQhAgBgugtg");
	mask.setTransform(0,-15.65);

	// Layer_5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#333333").ss(0.5,1,1).p("ACtA0Qiwh/ipB/IAAhnIFZAAg");
	this.shape_1.setTransform(5.6336,-31.1477,1.1059,0.999,19.051);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F7B138").s().p("AisA0IAAhnIFZAAIAABnQiwh/ipB/g");
	this.shape_2.setTransform(5.6336,-31.1477,1.1059,0.999,19.051);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#333333").ss(0.5,1,1).p("AjKACIAtiAIFoB9IgtCAQilh7jDgCg");
	this.shape_3.setTransform(5.075,-29.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F7B138").s().p("AjKACIAtiAIFoB9IgtCAQilh6jDgDg");
	this.shape_4.setTransform(5.075,-29.55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#333333").ss(0.5,1,1).p("AjPARIA3ieIFoB9Ig3CeQi9g7irhCg");
	this.shape_5.setTransform(4.525,-27.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F7B138").s().p("AjPARIA3ieIFoB9Ig3CeQi9g7irhCg");
	this.shape_6.setTransform(4.525,-27.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#333333").ss(0.5,1,1).p("AjUAgIBBi9IFoB9IhBC9QjUAEiUiBg");
	this.shape_7.setTransform(3.975,-26.3454);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F7B138").s().p("AjUAgIBBi9IFoB9IhBC9IgLABQjNAAiQh+g");
	this.shape_8.setTransform(3.975,-26.3454);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#333333").ss(0.5,1,1).p("AjaAoIBMjcIFpB9IhNDcQjrBCh9i/g");
	this.shape_9.setTransform(3.4,-23.9025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F7B138").s().p("AjaAoIBMjcIFpB9IhNDcQg8AQg2AAQiZAAhdiNg");
	this.shape_10.setTransform(3.4,-23.9025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#333333").ss(0.5,1,1).p("AjfApIBWj6IFpB9IhWD6QkECChlj/g");
	this.shape_11.setTransform(2.85,-20.9664);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F7B138").s().p("AjfApIBXj6IFoB9IhXD6QhXAshFAAQiJAAhDipg");
	this.shape_12.setTransform(2.85,-20.9664);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#333333").ss(0.5,1,1).p("AC/BRQjLESiykSIAAkqIF9AAg");
	this.shape_13.setTransform(0.0283,-15.0785,0.999,0.999,19.051);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#F7B138").s().p("Ai+BRIAAkqIF9AAIAAEqQhmCJhfAAQhfAAhZiJg");
	this.shape_14.setTransform(0.0283,-15.0785,0.999,0.999,19.051);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},14).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},2).to({state:[{t:this.shape_12},{t:this.shape_11}]},1).to({state:[{t:this.shape_10},{t:this.shape_9}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).to({state:[{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).wait(61));

	// Layer_3
	this.instance = new lib.CachedBmp_163();
	this.instance.setTransform(-5.65,-26.9,0.4785,0.4785);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(89));

	// Layer_1
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AhuBvQguguAAhBQAAhAAuguQAuguBAAAQBBAAAuAuQAtAuABBAQgBBBgtAuQguAthBABQhAgBgugtg");
	this.shape_15.setTransform(0,-15.65);

	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(89));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.6,-32.3,33.3,33.3);


(lib.btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("EgjAAHeIAAu7MBGBAAAIAAO7g");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-224.1,-47.8,448.2,95.6), null);


(lib.body = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap23();
	this.instance.setTransform(-152,-112);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-152,-112,306,244);


(lib.Apple = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap12();
	this.instance.setTransform(-202,-145);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-202,-145,353,385);


(lib.gh = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.trx();
	this.instance.setTransform(-3.4,-4.1);
	this.instance.alpha = 0.4805;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gh, new cjs.Rectangle(-491.9,-306.5,977,605), null);


(lib.elehead = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.eleeye();
	this.instance.setTransform(-62.9,-169.9,0.9,0.9);

	this.instance_1 = new lib.eleeye();
	this.instance_1.setTransform(4,-171.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_2 = new lib.Bitmap34();
	this.instance_2.setTransform(-113,-264);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-113,-264,226,265);


(lib.eleanim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.elehead("synched",0);
	this.instance.setTransform(55.2,-166.05,1,1,0,0,0,-20.3,-124.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({startPosition:0},0).to({regY:-125,scaleX:0.9996,scaleY:0.9996,rotation:-7.2887,x:55.15,y:-166.15},14).to({regY:-124.9,scaleX:1,scaleY:1,rotation:0,x:55.2,y:-166.05},15).wait(9));

	// Layer_1
	this.instance_1 = new lib.Bitmap33();
	this.instance_1.setTransform(-188,-250);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(48));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-188,-320.8,391.4,321.8);


(lib.cathead = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.cateye();
	this.instance.setTransform(-14.7,-93.1);

	this.instance_1 = new lib.cateye();
	this.instance_1.setTransform(-89.35,-116.8,0.7955,0.7955);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_2
	this.instance_2 = new lib.Bitmap22();
	this.instance_2.setTransform(-128,-244);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-128,-244,256,239);


(lib.cat = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// cat_head
	this.instance = new lib.cathead("synched",0);
	this.instance.setTransform(97.95,-164.65,1,1,0,0,0,-26.2,-11.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:0.9996,scaleY:0.9996,rotation:7.2896},14).to({scaleX:1,scaleY:1,rotation:0},15).wait(10));

	// Layer_1
	this.instance_1 = new lib.body("synched",0);
	this.instance_1.setTransform(-46.05,-143.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(39));

	// tail_vat
	this.instance_2 = new lib.tailvat("synched",0);
	this.instance_2.setTransform(-130.05,-236.15,1,1,0,0,0,53.1,-5.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({scaleX:0.9988,scaleY:0.9988,rotation:-9.0493,x:-130.1,y:-236.1},14).to({scaleX:1,scaleY:1,rotation:0,x:-130.05,y:-236.15},15).wait(10));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-198,-407.7,478.3,396.09999999999997);


(lib.boy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_6
	this.instance = new lib.eyeboy();
	this.instance.setTransform(-34.8,-78.9,0.972,0.972);

	this.instance_1 = new lib.eyeboy();
	this.instance_1.setTransform(6.9,-78.1,0.972,0.972);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_5
	this.instance_2 = new lib.Bitmap25();
	this.instance_2.setTransform(-134,-191);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-134,-191,234,439);


(lib.box3_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap29();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box3_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.CachedBmp_159();
	this.instance.setTransform(-34.1,-55.9,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_160();
	this.instance_1.setTransform(-34.1,-55.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	// Layer_1
	this.instance_2 = new lib.CachedBmp_161();
	this.instance_2.setTransform(-61.5,-59.5,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_162();
	this.instance_3.setTransform(-61.5,-59.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).to({state:[{t:this.instance_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61.5,-59.5,123,119);


(lib.box3_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap21();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box3_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap15();
	this.instance.setTransform(-62,-60);

	this.instance_1 = new lib.Bitmap16();
	this.instance_1.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap7();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box2_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap27();
	this.instance.setTransform(-62,-60);

	this.instance_1 = new lib.Bitmap28();
	this.instance_1.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box2_4copy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap30();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box2_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.CachedBmp_156();
	this.instance.setTransform(-27.6,-57.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

	// Layer_1
	this.instance_1 = new lib.CachedBmp_157();
	this.instance_1.setTransform(-61.5,-59.5,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_158();
	this.instance_2.setTransform(-61.5,-59.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61.5,-59.5,123,119);


(lib.box2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap20();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap14();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap5();
	this.instance.setTransform(-62,-60);

	this.instance_1 = new lib.Bitmap6();
	this.instance_1.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap26();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box_4copy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap31();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.CachedBmp_153();
	this.instance.setTransform(-34.85,-57.35,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_152();
	this.instance_1.setTransform(-55.2,-51.55,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_154();
	this.instance_2.setTransform(-34.85,-57.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_2}]},1).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0088D6").s().p("AmeJTQjIAAAAjIIAAsVQAAjIDIAAIM9AAQDIAAAADIIAAMVQAADIjIAAg");

	this.instance_3 = new lib.CachedBmp_155();
	this.instance_3.setTransform(-61.5,-59.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61.5,-59.5,123,119);


(lib.box_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap18();
	this.instance.setTransform(-62,-60);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap13();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap4();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.mcMain2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_73 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 3;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(73).call(this.frame_73).wait(1));

	// _
	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.mc_3 = new lib.box3_2();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,178.45);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_2 = new lib.box2_2();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,54.7);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.box_2();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},73).wait(1));

	// box3
	this.instance = new lib.box3_2();
	this.instance.setTransform(566.5,178.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(56).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},4).wait(1));

	// box2
	this.instance_1 = new lib.box2_2();
	this.instance_1.setTransform(566.5,54.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(52).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},8).wait(1));

	// box
	this.instance_2 = new lib.box_2();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(47).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},13).wait(1));

	// ani
	this.instance_3 = new lib.Apple("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(36).to({_off:false},0).to({scaleX:1.05,scaleY:1.05},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(22));

	// box3
	this.instance_4 = new lib.box3();
	this.instance_4.setTransform(196.5,178.45);
	this.instance_4.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(12).to({x:186.5},6,cjs.Ease.get(1)).to({x:576.5},13,cjs.Ease.get(1)).to({_off:true},1).wait(42));

	// box2
	this.instance_5 = new lib.box2();
	this.instance_5.setTransform(196.5,54.7);
	this.instance_5.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(7).to({x:186.5},6,cjs.Ease.get(1)).to({x:576.5},13,cjs.Ease.get(1)).to({_off:true},1).wait(47));

	// box
	this.instance_6 = new lib.box();
	this.instance_6.setTransform(196.5,-69.05);
	this.instance_6.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(3).to({x:186.5},6,cjs.Ease.get(1)).to({x:576.5},13,cjs.Ease.get(1)).to({_off:true},1).wait(51));

	// ani
	this.instance_7 = new lib.Doll("single",0);
	this.instance_7.setTransform(-179.05,9.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(2).to({startPosition:0},0).to({scaleX:1.1,scaleY:1.1},1,cjs.Ease.get(1)).to({scaleX:0.1,scaleY:0.1},13,cjs.Ease.get(1)).to({_off:true},1).wait(57));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-401.2,-162.1,1059.7,444.4);


(lib.mcMain1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;
		var objRef = this;
		var __nCorrectAnswer = 0;
		var blnLastQuestion = false;
		var blnOk = false;
		var __nScore = 0;
		var blnEnd = false;
		function init() {
			for (var i:Number = 1; objRef["mc_"+i] != null; i++) {
				objRef["mc_"+i].id = i;
				objRef["mc_" + i].addEventListener(MouseEvent.CLICK, fClickEvent);
				objRef["mc_"+i].buttonMode = true;
			}
		}
		
		function fClickEvent(e) {
			mcFish.gotoAndPlay(2);
			fRemoveListeners();
			if (e.currentTarget.id == __nCorrectAnswer) {
				e.currentTarget.gotoAndStop(2);
				__nScore++;
				blnOk = true;
				var mcRight = new Right();
				objRef.addChild(mcRight);
				objRef["mcTick_" + e.currentTarget.id].gotoAndStop(3);
				return;
			}
			blnOk = false;
			var mcWrong = new ShowAnswer();
			objRef.addChild(mcWrong);
			objRef["mcTick_" + e.currentTarget.id].gotoAndStop(2);
		}
		function fShowCorrectAnswer() {
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(3);
			objRef["mc_"+__nCorrectAnswer].gotoAndStop(2);
		}
		function fChangeQuestion() {
			trace("Move Ahead");
			fRemoveListeners();
			play();
		}
		function fRemoveListeners() {
			for (var i:Number = 1; objRef["mc_"+i] != null; i++) {
				if (!blnEnd) {
					objRef["mc_" + i].gotoAndStop(1);
				}
				objRef["mc_" + i].removeEventListener(MouseEvent.CLICK, fClickEvent);
				objRef["mc_"+i].buttonMode = false;
			}
		}*/
	}
	this.frame_164 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 2;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(164).call(this.frame_164).wait(1));

	// _
	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.mc_3 = new lib.box3();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,178.45);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_2 = new lib.box2();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,54.7);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.box();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},164).wait(1));

	// box3
	this.instance = new lib.box3();
	this.instance.setTransform(566.5,178.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(41).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},110).wait(1));

	// box2
	this.instance_1 = new lib.box2();
	this.instance_1.setTransform(566.5,54.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(37).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},114).wait(1));

	// box
	this.instance_2 = new lib.box();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(32).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},119).wait(1));

	// ani
	this.instance_3 = new lib.Doll("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(21).to({_off:false},0).to({scaleX:1.05,scaleY:1.05},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(128));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-391.1,-154.3,1049.6,424.2);


(lib.Elephant = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.eleanim();
	this.instance.setTransform(6.45,234.65,1.25,1.25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-228.5,-146.8,470.6,382.70000000000005);


(lib.cat_mov = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.cat();
	this.instance.setTransform(-22,241.55,0.95,0.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-210.1,-135.4,427.6,365.9);


(lib.mcMain5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_75 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 2;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					//this.parent.fLaunchProduct();
					this.play();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				//this.parent.fLaunchProduct();
				this.play();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}
	this.frame_76 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_87 = function() {
		/* stop();
		this.blnPlay = false;
		fCalculateScore();
		trace("Here-------------------");
		function fCalculateScore() {
			mcNext.mcBlinker.gotoAndStop(2);
			var nPercentage = (__nScore/5)*100;
			nPercentage = Math.ceil(nPercentage);
			trace(nPercentage + "---------------------");
			if (nPercentage < 70) {
				mcFinal.mcRank.gotoAndPlay("rank2");		
			} else {
				mcFinal.mcRank.gotoAndPlay("rank1_1");
			}
		}*/
		
		this.stop();
		//alert("---endSLide----");
		main.showRestartBtn();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(75).call(this.frame_75).wait(1).call(this.frame_76).wait(11).call(this.frame_87).wait(1));

	// _
	this.mc_3 = new lib.box3_5();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,178.45);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_2 = new lib.box2_5();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,54.7);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.box_5();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3},{t:this.mc_1},{t:this.mc_2},{t:this.mc_3}]},75).wait(13));

	// box3
	this.instance = new lib.box3_5();
	this.instance.setTransform(566.5,178.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(59).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},3).wait(1).to({_off:false},0).wait(12));

	// box2
	this.instance_1 = new lib.box2_5();
	this.instance_1.setTransform(566.5,54.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(55).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},7).wait(1).to({_off:false},0).wait(12));

	// box
	this.instance_2 = new lib.box_5();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},12).wait(1).to({_off:false},0).wait(12));

	// elephant
	this.instance_3 = new lib.boy("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(39).to({_off:false},0).to({scaleX:1.05,scaleY:1.05},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(33));

	// box3
	this.instance_4 = new lib.box3_4();
	this.instance_4.setTransform(196.5,178.45);
	this.instance_4.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(12).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(58));

	// box2
	this.instance_5 = new lib.box2_4();
	this.instance_5.setTransform(196.5,54.7);
	this.instance_5.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(10).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(60));

	// box
	this.instance_6 = new lib.box_4();
	this.instance_6.setTransform(196.5,-69.05);
	this.instance_6.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(8).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(62));

	// elephant
	this.instance_7 = new lib.cat_mov("single",0);
	this.instance_7.setTransform(-179.05,9.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(4).to({startPosition:0},0).to({scaleX:1.1,scaleY:1.1},6).to({scaleX:0.1,scaleY:0.1},11,cjs.Ease.get(-1)).to({_off:true},1).wait(66));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-410.1,-191,1068.6,460.9);


(lib.mcMain4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_84 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 3;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(84).call(this.frame_84).wait(1));

	// _
	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.mc_3 = new lib.box3_4();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,178.45);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_2 = new lib.box2_4copy();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,54.7);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.box_4copy();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},84).wait(1));

	// box3
	this.instance = new lib.box3_4();
	this.instance.setTransform(566.5,178.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(60).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},11).wait(1));

	// box2
	this.instance_1 = new lib.box2_4();
	this.instance_1.setTransform(566.5,54.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(56).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},15).wait(1));

	// box
	this.instance_2 = new lib.box_4();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(51).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},20).wait(1));

	// elephant
	this.instance_3 = new lib.cat_mov("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(40).to({_off:false},0).to({scaleX:1.05,scaleY:1.05},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(29));

	// box3
	this.instance_4 = new lib.box3_3();
	this.instance_4.setTransform(196.5,178.45);
	this.instance_4.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(14).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(53));

	// box2
	this.instance_5 = new lib.box2_3();
	this.instance_5.setTransform(196.5,54.7);
	this.instance_5.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(11).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(56));

	// box
	this.instance_6 = new lib.box_3();
	this.instance_6.setTransform(196.5,-69.05);
	this.instance_6.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(9).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(58));

	// elephant
	this.instance_7 = new lib.Elephant("single",0);
	this.instance_7.setTransform(-179.05,9.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(5).to({startPosition:0},0).to({scaleX:1.1,scaleY:1.1},6).to({scaleX:0.1,scaleY:0.1},11,cjs.Ease.get(-1)).to({_off:true},1).wait(62));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-430.4,-152,1088.4,421);


(lib.mcMain3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_80 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 1;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(80).call(this.frame_80).wait(1));

	// _
	this.mc_3 = new lib.box3_3();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,178.45);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.mc_2 = new lib.box2_3();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,54.7);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.box_3();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3},{t:this.mc_3}]},80).wait(1));

	// box3
	this.instance = new lib.box3_3();
	this.instance.setTransform(566.5,178.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(59).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},8).wait(1));

	// box2
	this.instance_1 = new lib.box2_3();
	this.instance_1.setTransform(566.5,54.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(54).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},13).wait(1));

	// box
	this.instance_2 = new lib.box_3();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(49).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},18).wait(1));

	// elephant
	this.instance_3 = new lib.Elephant("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(38).to({_off:false},0).to({scaleX:1.05,scaleY:1.05,alpha:1},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(27));

	// box3
	this.instance_4 = new lib.box3_2();
	this.instance_4.setTransform(196.5,178.45);
	this.instance_4.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(10).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(53));

	// box2
	this.instance_5 = new lib.box2_2();
	this.instance_5.setTransform(196.5,54.7);
	this.instance_5.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(8).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(55));

	// box
	this.instance_6 = new lib.box_2();
	this.instance_6.setTransform(196.5,-69.05);
	this.instance_6.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(6).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(57));

	// ani
	this.instance_7 = new lib.Apple("single",0);
	this.instance_7.setTransform(-179.05,9.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(2).to({startPosition:0},0).to({scaleX:1.1,scaleY:1.1},6).to({scaleX:0.1,scaleY:0.1},11,cjs.Ease.get(-1)).to({_off:true},1).wait(61));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-418.9,-151,1077.4,424.5);


// stage content:
(lib.Interface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,26];
	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		stage.enableMouseOver(10); 
		//this.strFrame = "strFrame1"
		this.nF = 1;
		this.fLaunchProduct = function()
		{
			if(this.mcAttachMovieClip)
			{
				this.removeChild(this.mcAttachMovieClip);
			}
			this.mcAttachMovieClip = new lib["mcMain"+this.nF];
			this.mcAttachMovieClip.x = 488.1;
			this.mcAttachMovieClip.y = 295.05;	
			this.mcAttachMovieClip.gotoAndPlay(this.strFrame);
			this.addChild(this.mcAttachMovieClip);	
			if(this.nF == 1)
			{
				this.play();
				this.fbAudio = main.playAudio('instruction');
			}
			this.nF = this.nF + 1;
		}
		//this.fLaunchProduct();
	}
	this.frame_26 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(26).call(this.frame_26).wait(1));

	// HEADING
	this.instance = new lib.heading_("synched",0);
	this.instance.setTransform(-184.35,21.25);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).to({x:145.65},11,cjs.Ease.get(1)).wait(12));

	// Layer_1
	this.instance_1 = new lib.text01("synched",0);
	this.instance_1.setTransform(1382.45,83.1);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(10).to({_off:false},0).to({x:462.45},11,cjs.Ease.get(1)).to({x:472.45},5,cjs.Ease.get(1)).wait(1));

	// bg
	this.instance_2 = new lib.gh();
	this.instance_2.setTransform(491.9,298.1);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({alpha:1},10).wait(17));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(157.1,285.6,1590.4,311);
// library properties:
lib.properties = {
	id: 'ECDF1A6AC5E395468828BABD79B3D8C3',
	width: 977,
	height: 588,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Interface_atlas_1.png?1638118481290", id:"Interface_atlas_1"},
		{src:"images/Interface_atlas_2.png?1638118481291", id:"Interface_atlas_2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['ECDF1A6AC5E395468828BABD79B3D8C3'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;