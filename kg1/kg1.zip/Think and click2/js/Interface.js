(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Interface_atlas_1", frames: [[0,0,1954,1210],[952,1573,730,78],[952,1212,501,359],[0,1591,123,119],[125,1591,123,119],[250,1591,123,119],[375,1607,123,119],[1956,46,45,52],[1956,100,44,48],[1956,0,63,44],[500,1607,123,119],[625,1607,123,119],[1727,1553,302,54],[750,1607,123,119],[1684,1609,123,119],[492,1212,458,393],[1809,1609,123,119],[875,1653,123,119],[1000,1653,123,119],[1125,1653,123,119],[0,1212,490,377],[1250,1653,123,119],[1375,1653,123,119],[1455,1212,270,341],[1500,1653,123,119],[0,1712,123,119],[1727,1212,245,339],[125,1712,123,119],[250,1712,123,119],[375,1728,123,119],[500,1728,123,119]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_264 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap10 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap12 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap13 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap14 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap15 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap16 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap17 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap18 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap19 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap20 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap21 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap22 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap23 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap24 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap25 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap26 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap27 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap28 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap29 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap3 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap30 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap31 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap8 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap9 = function() {
	this.initialize(ss["Interface_atlas_1"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.trx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_264();
	this.instance.setTransform(-488.5,-302.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-488.5,-302.4,977,605);


(lib.text01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap1();
	this.instance.setTransform(-365,-37);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-365,-37,730,78);


(lib.right_wrong = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// _
	this.instance = new lib.Bitmap15();
	this.instance.setTransform(-26,-26);

	this.instance_1 = new lib.Bitmap16();
	this.instance_1.setTransform(-25,-22);

	this.instance_2 = new lib.Bitmap17();
	this.instance_2.setTransform(-31,-18);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-26,63,52);


(lib.heading_ = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap2();
	this.instance.setTransform(-147,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-147,-28,302,54);


(lib.Elephant = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.Bitmap22();
	this.instance.setTransform(-207,-151);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-207,-151,458,393);


(lib.Doll = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap5();
	this.instance.setTransform(-143,-115);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,0,0,0.102)").s().p("AslBsQjvgghEgpQgbgRAAgSQAAgRAbgQQBEgqDvggQFNgsHYAAQHYAAFOAsQFOAtAAA+QAABAlOAsQlOAtnYAAQnYAAlNgtg");
	this.shape.setTransform(-44.45,219);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-158.4,-115,260.4,349.3);


(lib.cat_mov = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.Bitmap27();
	this.instance.setTransform(-232,-162);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-232,-162,490,377);


(lib.btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("EgjAAHeIAAu7MBGBAAAIAAO7g");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn, new cjs.Rectangle(-224.1,-47.8,448.2,95.6), null);


(lib.boy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_5
	this.instance = new lib.Bitmap3();
	this.instance.setTransform(-135,-145);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(153,153,153,0.612)").s().p("AoqCCQjng1AAhNQAAhLDng3QDmg2FEAAQFFAADmA2QDmA3ABBLQgBBNjmA1QjmA3lFAAQlEAAjmg3g");
	this.shape.setTransform(-3.85,184.15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-145,270,347.7);


(lib.Apple = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap10();
	this.instance.setTransform(-250,-140);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-250,-140,501,359);


(lib.gh = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.trx();
	this.instance.setTransform(-3.4,-4.1);
	this.instance.alpha = 0.4805;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gh, new cjs.Rectangle(-491.9,-306.5,977,605), null);


(lib.box3_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap31();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box3_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap26();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box3_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap21();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box3_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap13();
	this.instance.setTransform(-62,-60);

	this.instance_1 = new lib.Bitmap14();
	this.instance_1.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap9();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box2_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap29();
	this.instance.setTransform(-62,-60);

	this.instance_1 = new lib.Bitmap30();
	this.instance_1.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box2_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap25();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box2_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap20();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap12();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap7();
	this.instance.setTransform(-62,-60);

	this.instance_1 = new lib.Bitmap8();
	this.instance_1.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap28();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap23();
	this.instance.setTransform(-62,-60);

	this.instance_1 = new lib.Bitmap24();
	this.instance_1.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.blnPlay=false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_4
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(2));

	// Layer_2
	this.instance = new lib.Bitmap18();
	this.instance.setTransform(-62,-60);

	this.instance_1 = new lib.Bitmap19();
	this.instance_1.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap11();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.setTransform(0.05,0.55,0.2744,1.2442,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap6();
	this.instance.setTransform(-62,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-60,123.5,119.5);


(lib.mcMain5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_75 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 2;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					//this.parent.fLaunchProduct();
					this.play();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				//this.parent.fLaunchProduct();
				this.play();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}
	this.frame_76 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_87 = function() {
		/* stop();
		this.blnPlay = false;
		fCalculateScore();
		function fCalculateScore() {
			mcNext.mcBlinker.gotoAndStop(2);
			var nPercentage = (__nScore/5)*100;
			nPercentage = Math.ceil(nPercentage);
			trace(nPercentage + "---------------------");
			if (nPercentage < 70) {
				mcFinal.mcRank.gotoAndPlay("rank2");		
			} else {
				mcFinal.mcRank.gotoAndPlay("rank1_1");
			}
		}*/
		
		this.stop();
		//alert("end slide");
		main.showRestartBtn();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(75).call(this.frame_75).wait(1).call(this.frame_76).wait(11).call(this.frame_87).wait(1));

	// _
	this.mc_3 = new lib.box3_5();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,178.45);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_2 = new lib.box2_5();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,54.7);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.box_5();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3},{t:this.mc_1},{t:this.mc_2},{t:this.mc_3}]},75).wait(13));

	// box3
	this.instance = new lib.box3_5();
	this.instance.setTransform(566.5,178.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(59).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},3).wait(1).to({_off:false},0).wait(12));

	// box2
	this.instance_1 = new lib.box2_5();
	this.instance_1.setTransform(566.5,54.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(55).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},7).wait(1).to({_off:false},0).wait(12));

	// box
	this.instance_2 = new lib.box_5();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},12).wait(1).to({_off:false},0).wait(12));

	// elephant
	this.instance_3 = new lib.boy("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(39).to({_off:false},0).to({scaleX:1.05,scaleY:1.05},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(33));

	// box3
	this.instance_4 = new lib.box3_4();
	this.instance_4.setTransform(196.5,178.45);
	this.instance_4.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(12).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(58));

	// box2
	this.instance_5 = new lib.box2_4();
	this.instance_5.setTransform(196.5,54.7);
	this.instance_5.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(10).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(60));

	// box
	this.instance_6 = new lib.box_4();
	this.instance_6.setTransform(196.5,-69.05);
	this.instance_6.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(8).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(62));

	// elephant
	this.instance_7 = new lib.cat_mov("single",0);
	this.instance_7.setTransform(-179.05,9.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(4).to({startPosition:0},0).to({scaleX:1.1,scaleY:1.1},6).to({scaleX:0.1,scaleY:0.1},11,cjs.Ease.get(-1)).to({_off:true},1).wait(66));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-434.2,-168.7,1092.7,436.2);


(lib.mcMain4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_84 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 1;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(84).call(this.frame_84).wait(1));

	// _
	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.mc_3 = new lib.box3_4();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,178.45);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_2 = new lib.box2_4();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,54.7);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.box_4();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},84).wait(1));

	// box3
	this.instance = new lib.box3_4();
	this.instance.setTransform(566.5,178.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(60).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},11).wait(1));

	// box2
	this.instance_1 = new lib.box2_4();
	this.instance_1.setTransform(566.5,54.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(56).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},15).wait(1));

	// box
	this.instance_2 = new lib.box_4();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(51).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},20).wait(1));

	// elephant
	this.instance_3 = new lib.cat_mov("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(40).to({_off:false},0).to({scaleX:1.05,scaleY:1.05},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(29));

	// box3
	this.instance_4 = new lib.box3_3();
	this.instance_4.setTransform(196.5,178.45);
	this.instance_4.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(14).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(53));

	// box2
	this.instance_5 = new lib.box2_3();
	this.instance_5.setTransform(196.5,54.7);
	this.instance_5.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(11).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(56));

	// box
	this.instance_6 = new lib.box_3();
	this.instance_6.setTransform(196.5,-69.05);
	this.instance_6.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(9).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(58));

	// elephant
	this.instance_7 = new lib.Elephant("single",0);
	this.instance_7.setTransform(-179.05,9.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(5).to({startPosition:0},0).to({scaleX:1.1,scaleY:1.1},6).to({scaleX:0.1,scaleY:0.1},11,cjs.Ease.get(-1)).to({_off:true},1).wait(62));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-422.6,-160.6,1081.1,436.29999999999995);


(lib.mcMain3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_80 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 1;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(80).call(this.frame_80).wait(1));

	// _
	this.mc_3 = new lib.box3_3();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,178.45);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.mc_2 = new lib.box2_3();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,54.7);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.box_3();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3},{t:this.mc_3}]},80).wait(1));

	// box3
	this.instance = new lib.box3_3();
	this.instance.setTransform(566.5,178.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(59).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},8).wait(1));

	// box2
	this.instance_1 = new lib.box2_3();
	this.instance_1.setTransform(566.5,54.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(54).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},13).wait(1));

	// box
	this.instance_2 = new lib.box_3();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(49).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},18).wait(1));

	// elephant
	this.instance_3 = new lib.Elephant("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(38).to({_off:false},0).to({scaleX:1.05,scaleY:1.05,alpha:1},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(27));

	// box3
	this.instance_4 = new lib.box3_2();
	this.instance_4.setTransform(196.5,178.45);
	this.instance_4.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(10).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(53));

	// box2
	this.instance_5 = new lib.box2_2();
	this.instance_5.setTransform(196.5,54.7);
	this.instance_5.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(8).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(55));

	// box
	this.instance_6 = new lib.box_2();
	this.instance_6.setTransform(196.5,-69.05);
	this.instance_6.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(6).to({x:186.5},6).to({x:576.5},11,cjs.Ease.get(-1)).to({_off:true},1).wait(57));

	// ani
	this.instance_7 = new lib.Apple("single",0);
	this.instance_7.setTransform(-179.05,9.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(2).to({startPosition:0},0).to({scaleX:1.1,scaleY:1.1},6).to({scaleX:0.1,scaleY:0.1},11,cjs.Ease.get(-1)).to({_off:true},1).wait(61));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-454,-151,1112.5,418.5);


(lib.mcMain2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;*/
	}
	this.frame_73 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 3;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(73).call(this.frame_73).wait(1));

	// _
	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.mc_3 = new lib.box3_2();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,178.45);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_2 = new lib.box2_2();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,54.7);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.box_2();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},73).wait(1));

	// box3
	this.instance = new lib.box3_2();
	this.instance.setTransform(566.5,178.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(56).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},4).wait(1));

	// box2
	this.instance_1 = new lib.box2_2();
	this.instance_1.setTransform(566.5,54.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(52).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},8).wait(1));

	// box
	this.instance_2 = new lib.box_2();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(47).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},13).wait(1));

	// ani
	this.instance_3 = new lib.Apple("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(36).to({_off:false},0).to({scaleX:1.05,scaleY:1.05},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(22));

	// box3
	this.instance_4 = new lib.box3();
	this.instance_4.setTransform(196.5,178.45);
	this.instance_4.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(12).to({x:186.5},6,cjs.Ease.get(1)).to({x:576.5},13,cjs.Ease.get(1)).to({_off:true},1).wait(42));

	// box2
	this.instance_5 = new lib.box2();
	this.instance_5.setTransform(196.5,54.7);
	this.instance_5.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(7).to({x:186.5},6,cjs.Ease.get(1)).to({x:576.5},13,cjs.Ease.get(1)).to({_off:true},1).wait(47));

	// box
	this.instance_6 = new lib.box();
	this.instance_6.setTransform(196.5,-69.05);
	this.instance_6.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(3).to({x:186.5},6,cjs.Ease.get(1)).to({x:576.5},13,cjs.Ease.get(1)).to({_off:true},1).wait(51));

	// ani
	this.instance_7 = new lib.Doll("single",0);
	this.instance_7.setTransform(-179.05,9.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(2).to({startPosition:0},0).to({scaleX:1.1,scaleY:1.1},1,cjs.Ease.get(1)).to({scaleX:0.1,scaleY:0.1},13,cjs.Ease.get(1)).to({_off:true},1).wait(57));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-441.5,-151,1100,418.5);


(lib.mcMain1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		/* this.blnPlay = true;
		var objRef = this;
		var __nCorrectAnswer = 0;
		var blnLastQuestion = false;
		var blnOk = false;
		var __nScore = 0;
		var blnEnd = false;
		function init() {
			for (var i:Number = 1; objRef["mc_"+i] != null; i++) {
				objRef["mc_"+i].id = i;
				objRef["mc_" + i].addEventListener(MouseEvent.CLICK, fClickEvent);
				objRef["mc_"+i].buttonMode = true;
			}
		}
		
		function fClickEvent(e) {
			mcFish.gotoAndPlay(2);
			fRemoveListeners();
			if (e.currentTarget.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.gotoAndStop(2);
				blnOk = true;
				var mcRight = new Right();
				objRef.addChild(mcRight);
				objRef["mcTick_" + e.currentTarget.id].gotoAndStop(3);
				return;
			}
			blnOk = false;
			var mcWrong = new ShowAnswer();
			objRef.addChild(mcWrong);
			objRef["mcTick_" + e.currentTarget.id].gotoAndStop(2);
		}
		function fShowCorrectAnswer() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(2);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(3);
		}
		function fChangeQuestion() {
			if (!blnLastQuestion) {
		
			}
			fRemoveListeners();
			play();
		}
		function fRemoveListeners() {
			for (var i:Number = 1; objRef["mc_"+i] != null; i++) {
				if (!blnEnd) {
					objRef["mc_" + i].gotoAndStop(1);
				}
				objRef["mc_" + i].removeEventListener(MouseEvent.CLICK, fClickEvent);
				objRef["mc_"+i].buttonMode = false;
			}
		}*/
	}
	this.frame_47 = function() {
		this.stop();
		this.blnPlay = false;
		var objRef = this;
		var __nCorrectAnswer = 2;
		var blnLastQuestion = false;
		var __nScore = 0;
		this.init = function() {
			for (var i = 1; objRef["mc_"+i] != undefined; i++) {
				objRef["mc_"+i].id = i;				
				objRef["mc_" + i].btn.addEventListener("mousedown", objRef["mc_" + i].listener = this.fClickEvent.bind(this));
				objRef["mc_" + i].btn.cursor = "pointer";
			}
		}
		this.fClickEvent = function(e) {	
			this.fRemoveListeners();	
			if (e.currentTarget.parent.id == __nCorrectAnswer) {
				__nScore++;
				e.currentTarget.parent.gotoAndStop(1);		
				this.nRandom = Math.floor(Math.random()*3);
				this.nRandom = this.nRandom + 1;		
				this.fbAudio = main.playAudio('right'+this.nRandom);
				setTimeout(function()
				{			
					this.parent.fLaunchProduct();
				}.bind(this), 5000);
				this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(2);
				return;
			}
			this.fbAudio = main.playAudio('incorrect');
			this.fbAudio.addEventListener('complete', this.instAudEnt = function()
			{ 
				this.fbAudio = main.playAudio('showAnswer');
				this.fbAudio.removeEventListener('complete', this.instAudEnt);
				this.fShowCorrectAnswer();
			}.bind(this));	
			this["mcTick_" + e.currentTarget.parent.id].gotoAndStop(1);
		}
		function fChangeQuestion() {
			this.play();
		}
		this.fRemoveListeners = function() {
			for (var i = 1; objRef["mc_"+i] != null; i++) {		
				objRef["mc_" + i].btn.removeEventListener("mousedown", objRef["mc_" + i].listener, false);
				objRef["mc_" + i].btn.cursor = null;
			}
		}
		this.fShowCorrectAnswer = function() {
			objRef["mc_" + __nCorrectAnswer].gotoAndStop(1);
			objRef["mcTick_" + __nCorrectAnswer].gotoAndStop(2);
			setTimeout(function()
			{
				//this.parent.strFrame = "strFrame2";
				this.parent.fLaunchProduct();
				//this.fShowCorrectAnswer();
			}.bind(this), 5000);
		}
		this.init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(47).call(this.frame_47).wait(1));

	// _
	this.mcTick_3 = new lib.right_wrong();
	this.mcTick_3.name = "mcTick_3";
	this.mcTick_3.setTransform(317.8,178.3,1.728,1.728);

	this.mcTick_2 = new lib.right_wrong();
	this.mcTick_2.name = "mcTick_2";
	this.mcTick_2.setTransform(317.8,53.3,1.728,1.728);

	this.mcTick_1 = new lib.right_wrong();
	this.mcTick_1.name = "mcTick_1";
	this.mcTick_1.setTransform(317.8,-69.7,1.728,1.728);

	this.mc_3 = new lib.box3();
	this.mc_3.name = "mc_3";
	this.mc_3.setTransform(196.5,178.45);
	this.mc_3.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_2 = new lib.box2();
	this.mc_2.name = "mc_2";
	this.mc_2.setTransform(196.5,54.7);
	this.mc_2.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.mc_1 = new lib.box();
	this.mc_1.name = "mc_1";
	this.mc_1.setTransform(196.5,-69.05);
	this.mc_1.shadow = new cjs.Shadow("#003D61",0,0,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_1},{t:this.mc_2},{t:this.mc_3},{t:this.mcTick_1},{t:this.mcTick_2},{t:this.mcTick_3}]},47).wait(1));

	// box3
	this.instance = new lib.box3();
	this.instance.setTransform(566.5,178.45);
	this.instance.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(27).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},7).wait(1));

	// box2
	this.instance_1 = new lib.box2();
	this.instance_1.setTransform(566.5,54.7);
	this.instance_1.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(23).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},11).wait(1));

	// box
	this.instance_2 = new lib.box();
	this.instance_2.setTransform(566.5,-69.05);
	this.instance_2.shadow = new cjs.Shadow("#003D61",0,0,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(18).to({_off:false},0).to({x:186.5},8,cjs.Ease.get(1)).to({x:196.5},5,cjs.Ease.get(1)).to({_off:true},16).wait(1));

	// ani
	this.instance_3 = new lib.Doll("single",0);
	this.instance_3.setTransform(-179.05,9.45,0.1,0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(7).to({_off:false},0).to({scaleX:1.05,scaleY:1.05},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(25));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-345.4,-151,1003.9,418.5);


// stage content:
(lib.Interface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
		stage.enableMouseOver(10); 
		//this.strFrame = "strFrame1"
		this.nF = 1;
		this.fLaunchProduct = function()
		{
			if(this.mcAttachMovieClip)
			{
				this.removeChild(this.mcAttachMovieClip);
			}
			this.mcAttachMovieClip = new lib["mcMain"+this.nF];
			this.mcAttachMovieClip.x = 488.1;
			this.mcAttachMovieClip.y = 295.05;	
			this.mcAttachMovieClip.gotoAndPlay(this.strFrame);
			this.addChild(this.mcAttachMovieClip);	
			if(this.nF == 1)
			{
				//this.play();
				this.fbAudio = main.playAudio('instruction');
			}
			this.nF = this.nF + 1;
		}
		//this.fLaunchProduct();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// HEADING
	this.instance = new lib.heading_("synched",0);
	this.instance.setTransform(145.65,21.25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.text01("synched",0);
	this.instance_1.setTransform(472.45,83.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// bg
	this.instance_2 = new lib.gh();
	this.instance_2.setTransform(491.9,298.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(487.2,285.6,489.8,311);
// library properties:
lib.properties = {
	id: 'ECDF1A6AC5E395468828BABD79B3D8C3',
	width: 977,
	height: 588,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Interface_atlas_1.png?1638118755639", id:"Interface_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['ECDF1A6AC5E395468828BABD79B3D8C3'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;